#!/bin/bash

# Показываем сообщение сразу при запуске (до загрузки функций)
if [ "${1:-}" != "--install" ]; then
    echo -e '\033[1;34mПодготовка скрипта к запуску...\033[0m'
fi

# Секрет для привязки лицензии к серверу (не публиковать!)
_LICENSE_BIND_SECRET="r3mn4s4l3-b1nd-s3cr3t-2026"

# Сохраняем состояние терминала при запуске — восстанавливаем при любом выходе
_ORIG_STTY=$(stty -g 2>/dev/null || echo "")

# Переменные для отслеживания состояния установки
INSTALL_STARTED=false
INSTALL_COMPLETED=false
SOURCE_DIR=""
CLEANUP_DIRS=()
TEMP_REPO=""
SCRIPT_CWD="$(cd "$(dirname "$0")" && pwd)"
CLONE_DIR=""

# Переменные путей
PROJECT_DIR="/opt/remnasale"
ENV_FILE="$PROJECT_DIR/.env"
REPO_DIR="/opt/remnasale"
REMNAWAVE_DIR="/opt/remnawave"
SYSTEM_INSTALL_DIR="/usr/local/lib/remnasale"

# Ветка и версия — единый источник: $PROJECT_DIR/version
# Формат файла:
#   version: x.x.x
#   branch:  lic
REPO_BRANCH="lic"
LICENSE_SERVER=""
for _uf in "$PROJECT_DIR/version" "$SCRIPT_CWD/version" "$SCRIPT_CWD/.update"; do
    if [ -f "$_uf" ]; then
        _br=$(grep '^branch:' "$_uf" | cut -d: -f2 | tr -d ' \n')
        [ -n "$_br" ] && REPO_BRANCH="$_br"
        break
    fi
done

# ═══════════════════════════════════════════════
# АУТЕНТИФИКАЦИЯ: ключ лицензии и сервер
# ═══════════════════════════════════════════════

# Приоритет: переменная окружения > LICENSE_KEY из .env
if [ -z "${REMNASALE_LICENSE_KEY:-}" ] && [ -f "$ENV_FILE" ]; then
    REMNASALE_LICENSE_KEY=$(grep '^LICENSE_KEY=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
fi

# LICENSE_SERVER: переменная окружения > .env > version файл
if [ -z "${LICENSE_SERVER:-}" ] && [ -f "$ENV_FILE" ]; then
    _ls_env=$(grep '^LICENSE_SERVER=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    [ -n "$_ls_env" ] && LICENSE_SERVER="$_ls_env"
fi
if [ -z "${REMNASALE_LICENSE_SERVER:-}" ]; then
    REMNASALE_LICENSE_SERVER="$LICENSE_SERVER"
fi

# Статус обновлений
UPDATE_AVAILABLE=0
AVAILABLE_VERSION="unknown"
CHECK_UPDATE_PID=""
UPDATE_STATUS_FILE=""

# ═══════════════════════════════════════════════
# ВОССТАНОВЛЕНИЕ ТЕРМИНАЛА И ОБРАБОТКА ПРЕРЫВАНИЙ
# ═══════════════════════════════════════════════
cleanup_terminal() {
    [ -n "${_ORIG_STTY:-}" ] && stty "$_ORIG_STTY" 2>/dev/null || stty sane 2>/dev/null || true
    tput cnorm 2>/dev/null || true
}

handle_interrupt() {
    cleanup_terminal
    echo
    echo -e "${RED}⚠️  Скрипт был остановлен пользователем${NC}"
    echo
    exit 0
}

trap cleanup_terminal EXIT
trap handle_interrupt INT TERM

# ═══════════════════════════════════════════════
# ЦВЕТА
# ═══════════════════════════════════════════════
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
WHITE='\033[1;37m'
GRAY='\033[0;37m'
NC='\033[0m'
DARKGRAY='\033[1;30m'

# ═══════════════════════════════════════════════
# УТИЛИТЫ ВЫВОДА
# ═══════════════════════════════════════════════

# ═══════════════════════════════════════════════
# СПИННЕРЫ
# ═══════════════════════════════════════════════
show_spinner() {
  local pid=$!
  local delay=0.08
  local spin=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
  local i=0 msg="$1"
  tput civis 2>/dev/null || true
  while kill -0 $pid 2>/dev/null; do
    printf "\r${GREEN}%s${NC}  %s" "${spin[$i]}" "$msg"
    i=$(( (i+1) % 10 ))
    sleep $delay
  done
  wait $pid 2>/dev/null
  local exit_code=$?
  if [ $exit_code -eq 0 ]; then
    printf "\r${GREEN}✅${NC} %s\n" "$msg"
  else
    printf "\r${RED}✖${NC}  %s\n" "$msg"
  fi
  tput cnorm 2>/dev/null || true
  return $exit_code
}

show_spinner_timer() {
  local seconds=$1
  local msg="$2"
  local done_msg="${3:-$msg}"
  local spin=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
  local i=0
  local delay=0.08
  local elapsed=0
  tput civis 2>/dev/null || true
  while [ $elapsed -lt $seconds ]; do
    local remaining=$((seconds - elapsed))
    for ((j=0; j<12; j++)); do
      printf "\r\033[K${GREEN}%s${NC}  %s (%d сек)" "${spin[$i]}" "$msg" "$remaining"
      sleep $delay
      i=$(( (i+1) % 10 ))
    done
    ((elapsed++)) || true
  done
  printf "\r\033[K${GREEN}✅${NC} %s\n" "$done_msg"
  tput cnorm 2>/dev/null || true
}

# Спинер с ожиданием строки в логах
show_spinner_until_log() {
  local container="$1"
  local pattern="$2"
  local msg="$3"
  local timeout=${4:-90}
  local spin=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
  local i=0
  local elapsed=0
  local delay=0.08
  local check_interval=1
  local loops_per_check=$((check_interval * 12))  # 12 loops per second at 0.08s delay
  local loop_count=0
  
  tput civis 2>/dev/null || true
  
  while [ $elapsed -lt $timeout ]; do
    # Анимация спинера
    printf "\r${GREEN}%s${NC}  %s ${DARKGRAY}(%d/%d сек)${NC}" "${spin[$i]}" "$msg" "$elapsed" "$timeout"
    i=$(( (i+1) % 10 ))
    sleep $delay
    loop_count=$((loop_count + 1))
    
    # Проверяем логи каждую секунду
    if [ $((loop_count % loops_per_check)) -eq 0 ]; then
      elapsed=$((elapsed + 1))
      local logs=$(docker logs "$container" 2>&1 | tail -100)
      
      # Проверяем паттерн успеха
      if echo "$logs" | grep -q "$pattern"; then
        printf "\r${GREEN}✅${NC} %s\n" "$msg"
        tput cnorm 2>/dev/null || true
        return 0
      fi
      
      # Проверяем ошибки
      if echo "$logs" | grep -E "^\s*(ERROR|CRITICAL|Traceback)" >/dev/null 2>&1; then
        printf "\r${YELLOW}🔍${NC} %s (проверка)\n" "$msg"
        tput cnorm 2>/dev/null || true
        return 2
      fi
    fi
  done
  
  printf "\r\033[K"
  tput cnorm 2>/dev/null || true
  return 1
}

# Спинер без сообщения (просто ждём процесс)
show_spinner_silent() {
  local pid=$!
  local delay=0.08
  local spin=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
  local i=0
  while kill -0 $pid 2>/dev/null; do
    i=$(( (i+1) % 10 ))
    sleep $delay
  done
  wait $pid 2>/dev/null || true
}

# Красивый вывод
print_action()  { :; }
print_error()   { printf "${RED}✖ %b${NC}\n" "$1"; }
print_success() { printf "${GREEN}✅${NC} %b\n" "$1"; }

# ═══════════════════════════════════════════════
# МЕНЮ СО СТРЕЛОЧКАМИ
# ═══════════════════════════════════════════════
show_arrow_menu() {
    local title="$1"
    shift
    local options=("$@")
    local num_options=${#options[@]}
    local selected=0
    local _esc_label="${MENU_ESC_LABEL:-Назад}"

    # Сохраняем настройки терминала
    local original_stty
    original_stty=$(stty -g 2>/dev/null)

    # Скрываем курсор
    tput civis 2>/dev/null || true

    # Отключаем canonical mode и echo
    stty -icanon -echo min 1 time 0 2>/dev/null || true

    # Пропускаем разделители при начальной позиции
    while [[ "${options[$selected]}" =~ ^[─━═[:space:]]*$ ]]; do
        ((selected++))
        if [ $selected -ge $num_options ]; then
            selected=0
            break
        fi
    done

    while true; do
        clear
        printf "\033[?25l"
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${GREEN}   $title${NC}"
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo

        for i in "${!options[@]}"; do
            # Проверяем, является ли элемент разделителем
            if [[ "${options[$i]}" =~ ^[─━═[:space:]]*$ ]]; then
                echo -e "${DARKGRAY}${options[$i]}${NC}"
            elif [ $i -eq $selected ]; then
                echo -e "${BLUE}▶${NC} ${YELLOW}${options[$i]}${NC}"
            else
                echo -e "  ${options[$i]}"
            fi
        done

        echo
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${DARKGRAY}${BLUE}↑↓${DARKGRAY}: Навигация  ${BLUE}Enter${DARKGRAY}: Выбор  ${BLUE}Esc${DARKGRAY}: ${_esc_label}${NC}"

        local key
        read -rsn1 key 2>/dev/null || key=""

        if [[ "$key" == $'\e' ]]; then
            local seq1="" seq2=""
            read -rsn1 -t 0.1 seq1 2>/dev/null || seq1=""
            if [[ "$seq1" == '[' ]]; then
                read -rsn1 -t 0.1 seq2 2>/dev/null || seq2=""
                case "$seq2" in
                    'A')  # Стрелка вверх
                        ((selected--))
                        if [ $selected -lt 0 ]; then
                            selected=$((num_options - 1))
                        fi
                        while [[ "${options[$selected]}" =~ ^[─━═[:space:]]*$ ]]; do
                            ((selected--))
                            if [ $selected -lt 0 ]; then
                                selected=$((num_options - 1))
                            fi
                        done
                        ;;
                    'B')  # Стрелка вниз
                        ((selected++))
                        if [ $selected -ge $num_options ]; then
                            selected=0
                        fi
                        while [[ "${options[$selected]}" =~ ^[─━═[:space:]]*$ ]]; do
                            ((selected++))
                            if [ $selected -ge $num_options ]; then
                                selected=0
                            fi
                        done
                        ;;
                esac
            else
                # Чистый Esc без последовательности - назад
                stty "$original_stty" 2>/dev/null || true
                return 255
            fi
        else
            local key_code
            if [ -n "$key" ]; then
                key_code=$(printf '%d' "'$key" 2>/dev/null || echo 0)
            else
                key_code=13
            fi

            if [ "$key_code" -eq 10 ] || [ "$key_code" -eq 13 ]; then
                stty "$original_stty" 2>/dev/null || true
                return $selected
            fi
        fi
    done
}

# ═══════════════════════════════════════════════
# ВВОД ТЕКСТА
# ═══════════════════════════════════════════════
reading() {
    local prompt="$1"
    local var_name="$2"
    local input
    echo
    local ps=$'\001\033[34m\002➜\001\033[0m\002  \001\033[33m\002'"$prompt"$'\001\033[0m\002 \001\033[32m\002'
    read -e -p "$ps" input
    printf '\033[0m'
    eval "$var_name='$input'"
}

reading_inline() {
    local prompt="$1"
    local var_name="$2"
    local input=""
    local char
    local _rl_stty
    _rl_stty=$(stty -g 2>/dev/null || echo "")
    tput cnorm 2>/dev/null
    echo -en "${BLUE}➜${NC}  ${YELLOW}${prompt}${NC} \033[32m"
    while IFS= read -r -s -n1 char; do
        if [[ -z "$char" ]]; then
            break
        elif [[ "$char" == $'\x7f' ]] || [[ "$char" == $'\x08' ]]; then
            if [[ -n "$input" ]]; then
                input="${input%?}"
                echo -en "\b \b"
            fi
        elif [[ "$char" == $'\x1b' ]]; then
            local _seq=""
            while IFS= read -r -s -n1 -t 0.1 _sc; do
                _seq+="$_sc"
                [[ "$_sc" =~ [A-Za-z~] ]] && break
            done
            if [[ -z "$_seq" ]]; then
                echo -en "\033[0m"
                echo
                if [ -n "${_rl_stty:-}" ]; then stty "$_rl_stty" 2>/dev/null || true; fi
                tput civis 2>/dev/null
                printf -v "$var_name" ''
                return 2
            fi
        else
            input+="$char"
            echo -en "$char"
        fi
    done
    echo -en "\033[0m"
    if [ -n "${_rl_stty:-}" ]; then stty "$_rl_stty" 2>/dev/null || true; fi
    echo
    tput civis 2>/dev/null
    printf -v "$var_name" '%s' "$input"
    return 0
}

confirm_action() {
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    printf "\033[?25l${YELLOW}⚠️  Нажмите ${BLUE}Enter${YELLOW} для подтверждения, или ${BLUE}Esc${YELLOW} для отмены.${NC} "

    local key
    while true; do
        read -rs -n 1 key
        if [[ "$key" == $'\x1b' ]]; then
            printf "\033[?25h\n"
            return 1
        elif [[ "$key" == "" ]]; then
            printf "\033[?25h\n"
            return 0
        fi
    done
}

# ═══════════════════════════════════════════════
# ПРОВЕРКА ДОМЕНА
# ═══════════════════════════════════════════════
get_server_ip() {
    local ip=""

    ip=$(curl -s4 --max-time 5 ifconfig.me 2>/dev/null)
    if [ -n "$ip" ] && [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        echo "$ip"
        return 0
    fi

    ip=$(curl -s4 --max-time 5 icanhazip.com 2>/dev/null)
    if [ -n "$ip" ] && [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        echo "$ip"
        return 0
    fi

    ip=$(curl -s4 --max-time 5 ident.me 2>/dev/null)
    if [ -n "$ip" ] && [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        echo "$ip"
        return 0
    fi

    ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    if [ -n "$ip" ] && [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        echo "$ip"
        return 0
    fi

    echo "unknown"
}

# ═══════════════════════════════════════════════
# ПРИВЯЗКА ЛИЦЕНЗИИ К IP СЕРВЕРА
# ═══════════════════════════════════════════════

# Вычисляет HMAC-SHA256(ip, _LICENSE_BIND_SECRET) — первые 40 символов
_compute_ip_hash() {
    local ip="$1"
    echo -n "$ip" | openssl dgst -sha256 -hmac "$_LICENSE_BIND_SECRET" 2>/dev/null | awk '{print $2}'
}

# Записывает LICENSE_BIND в .env (вызывается при установке)
_write_license_bind() {
    local env_file="$1"
    local server_ip
    server_ip=$(get_server_ip)

    if [ "$server_ip" = "unknown" ] || [ -z "$server_ip" ]; then
        return 0  # Не блокируем установку если IP не определился
    fi

    local bind_hash
    bind_hash=$(_compute_ip_hash "$server_ip")

    # Сохраняем bind hash в state файл (не в .env)
    mkdir -p /var/lib/remnasale-license
    echo "$bind_hash" > /var/lib/remnasale-license/bind
    chmod 600 /var/lib/remnasale-license/bind
}

# Проверяет LICENSE_BIND — возвращает 0 (ОК) или 1 (другой сервер)
_check_license_bind() {
    local env_file="${1:-$ENV_FILE}"

    # Если нет .env или нет LICENSE_BIND — пропускаем (старые установки)
    [ -f "$env_file" ] || return 0
    local stored_bind
    # Читаем из state файла (не из .env)
    local bind_state_file="/var/lib/remnasale-license/bind"
    if [ -f "$bind_state_file" ]; then
        stored_bind=$(cat "$bind_state_file" 2>/dev/null | tr -d '\t\r\n ')
    else
        # Fallback: старые установки с LICENSE_BIND в .env
        stored_bind=$(grep '^LICENSE_BIND=' "$env_file" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    fi
    [ -n "$stored_bind" ] || return 0

    local server_ip
    server_ip=$(get_server_ip)
    if [ "$server_ip" = "unknown" ] || [ -z "$server_ip" ]; then
        return 0  # Не блокируем если IP не определился
    fi

    local expected_bind
    expected_bind=$(_compute_ip_hash "$server_ip")

    if [ "$stored_bind" = "$expected_bind" ]; then
        return 0
    else
        return 1
    fi
}

check_domain() {
    local domain="$1"

    local domain_ip
    domain_ip=$(dig +short "$domain" A 2>/dev/null | head -1)

    local server_ip
    server_ip=$(get_server_ip)

    if [ -z "$domain_ip" ]; then
        echo
        echo -e "${RED}✖ Домен ${YELLOW}$domain${RED} не привязан к IP вашего сервера ${YELLOW}$server_ip${NC}"
        echo -e "${RED}❗Убедитесь что DNS записи настроены правильно.${NC}"
        return 1
    fi

    local ip_match=false

    # Проверяем прямое совпадение с внешним IP
    if [ "$domain_ip" = "$server_ip" ]; then
        ip_match=true
    else
        # Проверяем локальные IP интерфейсов (для Docker/NAT)
        local local_ips
        local_ips=$(ip -4 addr show 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | grep -v '127.0.0.1')

        if [ -n "$local_ips" ]; then
            while IFS= read -r local_ip; do
                if [ "$domain_ip" = "$local_ip" ]; then
                    ip_match=true
                    break
                fi
            done <<< "$local_ips"
        fi
    fi

    if [ "$ip_match" = false ]; then
        echo
        echo -e "${RED}✖ Домен ${YELLOW}$domain${RED} не привязан к IP вашего сервера ${YELLOW}$server_ip${NC}"
        echo -e "${RED}⚠️  Убедитесь что DNS записи настроены правильно.${NC}"
        return 1
    fi

    return 0
}

# Проверяет, похож ли ввод на токен Telegram-бота (123456789:AAFxxxx)
is_bot_token() {
    [[ "$1" =~ ^[0-9]+:[A-Za-z0-9_-]{35,}$ ]]
}

# Возвращает числовой ID бота по токену через getMe, или пустую строку при ошибке
resolve_bot_token_id() {
    local token="$1"
    local result
    result=$(curl -s --max-time 5 "https://api.telegram.org/bot${token}/getMe" 2>/dev/null)
    if echo "$result" | grep -q '"ok":true'; then
        echo "$result" | grep -oP '"id":\K[0-9]+' | head -1
    fi
}

# Возвращает username бота по токену через getMe, или пустую строку при ошибке
resolve_bot_token_username() {
    local token="$1"
    local result
    result=$(curl -s --max-time 5 "https://api.telegram.org/bot${token}/getMe" 2>/dev/null)
    if echo "$result" | grep -q '"ok":true'; then
        echo "$result" | grep -oP '"username":"\K[^"]+' | head -1
    fi
}

# Функция для безопасного обновления переменной в .env файле
update_env_var() {
    local env_file="$1"
    local var_name="$2"
    local var_value="$3"
    
    # Экранируем спецсимволы для sed
    local escaped_value=$(printf '%s\n' "$var_value" | sed -e 's/[\/&]/\\&/g')
    
    # Проверяем, существует ли переменная в файле
    if grep -q "^${var_name}=" "$env_file"; then
        # Заменяем существующее значение
        sed -i "s|^${var_name}=.*|${var_name}=${escaped_value}|" "$env_file"
    else
        # Добавляем новую переменную
        echo "${var_name}=${var_value}" >> "$env_file"
    fi
}

# Функция для проверки установлен ли бот
is_installed() {
    # Бот считается установленным только если:
    # 1. Директория существует
    # 2. Есть критические файлы (docker-compose.yml и .env)
    # 3. Docker контейнеры запущены или есть следы работы
    if [ -d "$PROJECT_DIR" ] && [ -f "$PROJECT_DIR/docker-compose.yml" ] && [ -f "$PROJECT_DIR/.env" ]; then
        return 0  # installed
    fi
    return 1  # not installed
}

# Уникальный идентификатор сервера для привязки ключа
get_machine_id() {
    if [ -f /etc/machine-id ]; then
        cat /etc/machine-id | tr -d '\n\r '
    elif [ -f /var/lib/dbus/machine-id ]; then
        cat /var/lib/dbus/machine-id | tr -d '\n\r '
    else
        local mid_file="$PROJECT_DIR/.machine_id"
        if [ -f "$mid_file" ]; then
            cat "$mid_file" | tr -d '\n\r '
        else
            local new_id
            new_id=$(head -c 16 /dev/urandom | od -An -tx1 | tr -d ' \n')
            echo "$new_id" > "$mid_file"
            echo "$new_id"
        fi
    fi
}

# Фоновая валидация ключа доступа через license-сервер
# Результат записывается в файл: ok | invalid
_validate_access_key_bg() {
    local key="$1"
    local result_file="$2"
    local server="${LICENSE_SERVER:-$REMNASALE_LICENSE_SERVER}"

    if [ -z "$server" ]; then
        echo "invalid" > "$result_file"
        return
    fi

    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 15 \
        "${server}/api/v1/version?key=${key}")

    if [ "$http_code" = "200" ]; then
        echo "ok" > "$result_file"
    else
        echo "invalid" > "$result_file"
    fi
}

# Проверяет, не привязан ли ключ уже к ДРУГОМУ серверу.
# Возвращает 0 — ключ свободен (или IP совпадает), 1 — ip_mismatch.
_check_license_ip_not_bound() {
    local key="$1"
    local server="${LICENSE_SERVER:-$REMNASALE_LICENSE_SERVER}"
    [ -z "$server" ] && return 0
    [ -z "$key" ] && return 0

    local server_ip
    server_ip=$(get_server_ip)
    [ -z "$server_ip" ] || [ "$server_ip" = "unknown" ] && return 0

    local resp reason
    resp=$(curl -s --max-time 10 \
        -X POST "${server}/api/v1/license/verify" \
        -H "Content-Type: application/json" \
        -d "{\"license_key\": \"${key}\", \"server_ip\": \"${server_ip}\"}" 2>/dev/null)
    reason=$(echo "$resp" | grep -o '"reason"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"//;s/"//')

    if [ "$reason" = "ip_mismatch" ]; then
        return 1
    fi
    return 0
}

# Скачивание архива проекта через лицензионный сервер
# Использование: _download_archive <key> <target_dir>
_download_archive() {
    local target_dir="$2"
    local _key="${REMNASALE_LICENSE_KEY:-}"
    local _server="${LICENSE_SERVER:-$REMNASALE_LICENSE_SERVER}"

    [ -z "$_key" ] && _key=$(grep '^LICENSE_KEY=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    [ -z "$_server" ] && _server=$(grep '^LICENSE_SERVER=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')

    if [ -z "$_key" ] || [ -z "$_server" ]; then
        return 1
    fi

    local archive_file
    archive_file=$(mktemp /tmp/remnasale-archive.XXXXXX.tar.gz)

    local http_code
    http_code=$(curl -sL -o "$archive_file" -w "%{http_code}" --max-time 180 \
        "${_server}/api/v1/download?key=${_key}")

    if [ "$http_code" != "200" ]; then
        rm -f "$archive_file"
        return 1
    fi

    mkdir -p "$target_dir"
    tar -xzf "$archive_file" -C "$target_dir" --strip-components=1
    local rc=$?
    rm -f "$archive_file"
    return $rc
}

# Установка systemd-сервиса и таймера для периодической проверки лицензии
_install_license_checker() {
    local check_script="$PROJECT_DIR/.sys/license-check.sh"

    mkdir -p "$PROJECT_DIR/.sys"

    # Копируем скрипт проверки
    if [ -f "$SCRIPT_CWD/license-check.sh" ]; then
        cp "$SCRIPT_CWD/license-check.sh" "$check_script"
    elif [ -f "$SOURCE_DIR/license-check.sh" ]; then
        cp "$SOURCE_DIR/license-check.sh" "$check_script"
    else
        return 1
    fi
    chmod +x "$check_script"

    # systemd service
    cat > /etc/systemd/system/remnasale-license-check.service << 'SVCEOF'
[Unit]
Description=Remnasale License Check
After=network-online.target docker.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/opt/remnasale/.sys/license-check.sh
TimeoutStartSec=30
SVCEOF

    # Интервал проверки: из сохранённого файла или 5 минут по умолчанию
    local _check_interval="5min"
    if [ -f "/var/lib/remnasale-license/interval" ]; then
        local _saved_interval
        _saved_interval=$(cat /var/lib/remnasale-license/interval 2>/dev/null | tr -d '\n')
        if [[ "$_saved_interval" =~ ^[0-9]+$ ]] && [ "$_saved_interval" -gt 0 ]; then
            _check_interval="${_saved_interval}min"
        fi
    fi

    # systemd timer
    cat > /etc/systemd/system/remnasale-license-check.timer << TMREOF
[Unit]
Description=Remnasale License Check Timer

[Timer]
OnBootSec=60
OnUnitActiveSec=${_check_interval}
AccuracySec=10s

[Install]
WantedBy=timers.target
TMREOF

    systemctl daemon-reload >/dev/null 2>&1
    systemctl enable remnasale-license-check.timer >/dev/null 2>&1
    systemctl start remnasale-license-check.timer >/dev/null 2>&1
}

# Удаление systemd-сервиса и таймера проверки лицензии
_remove_license_checker() {
    systemctl stop remnasale-license-check.timer 2>/dev/null || true
    systemctl disable remnasale-license-check.timer 2>/dev/null || true
    rm -f /etc/systemd/system/remnasale-license-check.service
    rm -f /etc/systemd/system/remnasale-license-check.timer
    systemctl daemon-reload >/dev/null 2>&1 || true
    rm -rf /var/lib/remnasale-license
}

# Освобождает IP-привязку ключа на лицензионном сервере
_release_license_ip() {
    local _key="${REMNASALE_LICENSE_KEY:-}"
    local _server="${LICENSE_SERVER:-$REMNASALE_LICENSE_SERVER}"

    # Пробуем из .env если не в переменных
    if [ -z "$_key" ] && [ -f "$ENV_FILE" ]; then
        _key=$(grep '^LICENSE_KEY=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    fi
    if [ -z "$_server" ] && [ -f "$ENV_FILE" ]; then
        _server=$(grep '^LICENSE_SERVER=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    fi

    [ -z "$_key" ] || [ -z "$_server" ] && return 0

    local _ip
    _ip=$(get_server_ip 2>/dev/null || echo "")
    # fallback: IP переданный из bootstrap-скрипта install.sh
    [ -z "$_ip" ] || [ "$_ip" = "unknown" ] && _ip="${REMNASALE_INSTALL_SERVER_IP:-}"

    # Освобождаем IP-привязку (только если IP известен)
    if [ -n "$_ip" ] && [ "$_ip" != "unknown" ]; then
        curl -s --max-time 10 -X POST \
            -H "Content-Type: application/json" \
            -d "{\"license_key\": \"${_key}\", \"server_ip\": \"${_ip}\"}" \
            "${_server}/api/v1/license/release" >/dev/null 2>&1 || true
    fi

    # Уведомляем лиц. сервер об удалении Remnasale (отправляем всегда, сервер знает IP из БД)
    curl -s --max-time 10 -X POST \
        -H "Content-Type: application/json" \
        -d "{\"license_key\":\"${_key}\",\"server_ip\":\"${_ip:-}\",\"days_left\":0,\"event\":\"uninstalled\"}" \
        "${_server}/api/v1/notify/offline" >/dev/null 2>&1 || true
}

# Функция для сохранения критических переменных из .env перед обновлением
preserve_env_vars() {
    local env_file="$1"
    local temp_storage="/tmp/env_backup_$$"
    
    # Сохраняем ВСЕ переменные окружения из .env файла
    # Исключаем только комментарии и пустые строки
    if [ -f "$env_file" ]; then
        grep -v "^#" "$env_file" | grep -v "^$" > "$temp_storage" 2>/dev/null || true
    fi
    echo "$temp_storage"
}

# Функция для восстановления переменных в .env после обновления
restore_env_vars() {
    local env_file="$1"
    local temp_storage="$2"
    
    # Переменные которые НЕ следует перезаписывать (пароли, криптографические ключи)
    # Переменные которые БУДУТ восстановлены: APP_DOMAIN, BOT_TOKEN, BOT_DEV_ID, и другие пользовательские данные
    local protected_vars=(
        "APP_CRYPT_KEY"
        "DB_PASSWORD"
        "POSTGRES_PASSWORD"
        "REDIS_PASSWORD"
        "SECRET_KEY"
        "JWT_SECRET"
        "API_KEY"
    )
    
    if [ -f "$temp_storage" ]; then
        # Читаем сохранённые переменные и обновляем их в .env
        while IFS='=' read -r var_name var_value; do
            if [ -n "$var_name" ] && [ -n "$var_value" ]; then
                # Пропускаем пустые строки
                var_name=$(echo "$var_name" | xargs)
                if [ -n "$var_name" ]; then
                    # Проверяем не входит ли переменная в защищённый список
                    is_protected=0
                    for protected in "${protected_vars[@]}"; do
                        if [ "$var_name" = "$protected" ]; then
                            is_protected=1
                            break
                        fi
                    done
                    
                    # Обновляем только незащищённые переменные (включая домен, токен и ID)
                    if [ $is_protected -eq 0 ]; then
                        update_env_var "$env_file" "$var_name" "$var_value"
                    fi
                fi
            fi
        done < "$temp_storage"
        
        # Удаляем временный файл
        rm -f "$temp_storage" 2>/dev/null || true
    fi
}

# Функция для получения версии из файла version
get_version_from_file() {
    local update_file="$1"
    if [ -f "$update_file" ]; then
        grep '^version:' "$update_file" 2>/dev/null | head -1 | cut -d: -f2 | tr -d ' \n' || echo ""
    else
        echo ""
    fi
}

# Функция для получения локальной версии (из version)
get_local_version() {
    # Приоритет 1: пытаемся прочитать версию из работающего контейнера
    # (т.к. файл version запекается в образ при сборке, это самый достоверный источник)
    local _cv
    _cv=$(docker exec remnasale cat /opt/remnasale/version 2>/dev/null | grep '^version:' | head -1 | cut -d: -f2 | tr -d ' \n')
    if [ -n "$_cv" ]; then
        # Синхронизируем хостовый файл version с контейнером
        if [ -f "$PROJECT_DIR/version" ]; then
            local _hv
            _hv=$(grep '^version:' "$PROJECT_DIR/version" 2>/dev/null | head -1 | cut -d: -f2 | tr -d ' \n')
            if [ "$_hv" != "$_cv" ]; then
                docker exec remnasale cat /opt/remnasale/version > "$PROJECT_DIR/version" 2>/dev/null || true
            fi
        fi
        echo "$_cv"
        return
    fi

    # Приоритет 2: файл на хосте ($PROJECT_DIR или $SCRIPT_CWD)
    for _uf in "$PROJECT_DIR/version" "$SCRIPT_CWD/version"; do
        if [ -f "$_uf" ]; then
            # Поддерживаем оба формата: "version: X.Y.Z" и plain "X.Y.Z"
            local _v=$(grep '^version:' "$_uf" 2>/dev/null | head -1 | cut -d: -f2 | tr -d ' \n')
            if [ -n "$_v" ]; then
                echo "$_v"
                return
            else
                # Plain format — первая непустая строка которая выглядит как версия (x.y.z)
                _v=$(grep -v '^#\|^[[:space:]]*$' "$_uf" 2>/dev/null | head -1 | tr -d ' \n')
                if [ -n "$_v" ]; then
                    echo "$_v"
                    return
                fi
            fi
        fi
    done
    echo ""
}

# Функция для парсинга версии из содержимого файла version
# Поддерживает оба формата: "version: X.Y.Z" и plain "X.Y.Z"
parse_version_from_content() {
    local content="$1"
    local _v=$(echo "$content" | grep '^version:' 2>/dev/null | head -1 | cut -d: -f2 | tr -d ' \n')
    if [ -n "$_v" ]; then
        echo "$_v"
    else
        # Plain format — первая непустая строка
        echo "$content" | grep -v '^#\|^[[:space:]]*$' 2>/dev/null | head -1 | tr -d ' \n'
    fi
}

# Функция для сравнения версий (true если version1 < version2)
version_less_than() {
    local v1="$1"
    local v2="$2"
    
    # Простое сравнение версий (для формата X.Y.Z)
    # Преобразуем версии в числа для сравнения
    local v1_num=$(echo "$v1" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
    local v2_num=$(echo "$v2" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
    
    [ "$v1_num" -lt "$v2_num" ]
}

# Функция для проверки доступности обновлений
check_updates_available() {
    # Создаем временный файл для хранения статуса и версии
    UPDATE_STATUS_FILE=$(mktemp)
    echo "0" > "$UPDATE_STATUS_FILE"
    
    # Проверка обновлений в фоне
    {
        # Получаем локальную версию из PROJECT_DIR (production)
        LOCAL_VERSION=$(get_local_version)
        
        local _key="${REMNASALE_LICENSE_KEY:-}"
        local _server="${LICENSE_SERVER:-$REMNASALE_LICENSE_SERVER}"

        if [ -n "$_key" ] && [ -n "$_server" ]; then
            # Запрашиваем версию с license-сервера
            local _resp
            _resp=$(curl -s --max-time 15 "${_server}/api/v1/version?key=${_key}" 2>/dev/null)
            REMOTE_VERSION=$(echo "$_resp" | grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' | cut -d'"' -f4)

            if [ -n "$REMOTE_VERSION" ] && [ -n "$LOCAL_VERSION" ]; then
                local_num=$(echo "$LOCAL_VERSION" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
                remote_num=$(echo "$REMOTE_VERSION" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
                
                if [ "$local_num" -lt "$remote_num" ]; then
                    echo "1|$REMOTE_VERSION" > "$UPDATE_STATUS_FILE"
                else
                    echo "0|$REMOTE_VERSION" > "$UPDATE_STATUS_FILE"
                fi
            else
                echo "0|unknown" > "$UPDATE_STATUS_FILE"
            fi
        else
            echo "0|unknown" > "$UPDATE_STATUS_FILE"
        fi
    } &
    CHECK_UPDATE_PID=$!
}

wait_for_update_check() {
    if [ -n "$CHECK_UPDATE_PID" ]; then
        wait $CHECK_UPDATE_PID 2>/dev/null || true
    fi
    
    # Читаем результат из файла (формат: status|version)
    if [ -n "$UPDATE_STATUS_FILE" ] && [ -f "$UPDATE_STATUS_FILE" ]; then
        local update_info=$(cat "$UPDATE_STATUS_FILE" 2>/dev/null || echo "0|unknown")
        UPDATE_AVAILABLE=$(echo "$update_info" | cut -d'|' -f1)
        AVAILABLE_VERSION=$(echo "$update_info" | cut -d'|' -f2)
        rm -f "$UPDATE_STATUS_FILE" 2>/dev/null || true
    fi
}

# Функция для проверки режима (установка или меню)
check_mode() {
    # Если передан аргумент --install, пропускаем меню
    if [ "$1" = "--install" ]; then
        return 0
    fi
    
    # Проверяем обновления в фоне перед показом меню
    check_updates_available
    
    # Если бот установлен и скрипт вызван без аргументов, показываем полное меню
    if is_installed && [ -z "$1" ]; then
        show_full_menu
    fi
    
    # Если бот не установлен и скрипт вызван без аргументов, показываем меню с одним пунктом
    if ! is_installed && [ -z "$1" ]; then
        show_simple_menu
    fi
}

# Функция очистки при выходе из установки
cleanup_on_exit() {
    # Удаляем скачанные файлы если они были скачаны но установка не началась
    if [ -n "$TEMP_REPO" ] && [ -d "$TEMP_REPO" ]; then
        rm -rf "$TEMP_REPO" 2>/dev/null || true
    fi
    # Удаляем временную папку клонирования репозитория
    if [ -n "$CLONE_DIR" ] && [ -d "$CLONE_DIR" ]; then
        cd /opt 2>/dev/null || true
        rm -rf "$CLONE_DIR" 2>/dev/null || true
    fi
}

# Перезапуск через системный скрипт с предварительной очисткой CLONE_DIR
# Используется вместо exec "$0" чтобы не оставлять /tmp/tmp.* папку
restart_script() {
    local extra_arg="${1:-}"
    # Явно удаляем CLONE_DIR перед exec (trap EXIT не сработает после exec)
    if [ -n "$CLONE_DIR" ] && [ -d "$CLONE_DIR" ]; then
        local _clone_to_remove="$CLONE_DIR"
        CLONE_DIR=""
        cd /opt 2>/dev/null || true
        rm -rf "$_clone_to_remove" 2>/dev/null || true
    fi

    # Для установки (--install) нужно скачать архив с license-сервера,
    # т.к. системная копия содержит только remnasale-install.sh без исходников
    if [ "$extra_arg" = "--install" ]; then
        CLONE_DIR=$(mktemp -d)
        if _download_archive "" "$CLONE_DIR"; then
            chmod +x "$CLONE_DIR/remnasale-install.sh"
            cd "$CLONE_DIR"
            exec "$CLONE_DIR/remnasale-install.sh" --install "$CLONE_DIR" "${INSTALL_MODE:-dev}"
        else
            echo -e "${RED}❌ Ошибка при скачивании файлов с GitHub${NC}"
            rm -rf "$CLONE_DIR" 2>/dev/null || true
            exit 1
        fi
    fi

    # Для остальных случаев — запускаем из системной папки если доступна, иначе $0
    local _target="/usr/local/lib/remnasale/remnasale-install.sh"
    if [ ! -f "$_target" ]; then
        _target="$0"
    fi
    if [ -n "$extra_arg" ]; then
        exec "$_target" "$extra_arg"
    else
        exec "$_target"
    fi
}

# Простое меню при отсутствии бота
show_simple_menu() {
    # Ждём завершения проверки обновлений
    wait_for_update_check
    
    # Определяем версию для отображения
    local display_version=""
    if [ -f "$SCRIPT_CWD/version" ]; then
        display_version=$(grep '^version:' "$SCRIPT_CWD/version" 2>/dev/null | head -1 | cut -d: -f2 | tr -d ' \n' || echo "")
    elif [ -n "$AVAILABLE_VERSION" ] && [ "$AVAILABLE_VERSION" != "unknown" ]; then
        display_version="$AVAILABLE_VERSION"
    fi
    
    # Формируем заголовок
    local menu_title
    if [ -n "$display_version" ]; then
        menu_title="       🚀 Remnasale v${display_version}\n${DARKGRAY}Проект развивается благодаря вашей поддержке\n        https://github.com/DanteFuaran${NC}"
    else
        menu_title="       🚀 Remnasale\n${DARKGRAY}Проект развивается благодаря вашей поддержке\n        https://github.com/DanteFuaran${NC}"
    fi
    MENU_ESC_LABEL="Выход"
    
    show_arrow_menu "$menu_title" \
        "🚀  Установить" \
        "──────────────────────────────────────" \
        "❌  Выход"
    local choice=$?
    
    case $choice in
        0)  # Установить
            restart_script --install
            ;;
        2|255)  # Выход / Esc
            clear
            exit 0
            ;;
    esac
}

# Полное меню при установленном боте
show_full_menu() {
    # Получаем текущую версию
    local LOCAL_VERSION=$(get_local_version)
    [ -z "$LOCAL_VERSION" ] && LOCAL_VERSION="0.1.0"
    
    # Ждём завершения проверки обновлений
    wait_for_update_check
    
    # Создаём глобальную команду remnasale если её нет
    if [ ! -f "/usr/local/bin/remnasale" ]; then
        (  
            sudo tee /usr/local/bin/remnasale > /dev/null << 'EOF'
#!/bin/bash
# Запускаем remnasale-install.sh из системной папки
if [ -f "/usr/local/lib/remnasale/remnasale-install.sh" ]; then
    exec /usr/local/lib/remnasale/remnasale-install.sh
else
    echo "❌ remnasale-install.sh не найден. Переустановите бота."
    exit 1
fi
EOF
            sudo chmod +x /usr/local/bin/remnasale
            sudo ln -sf /usr/local/bin/remnasale /usr/local/bin/rs
        ) >/dev/null 2>&1
    fi
    
    # Формируем пункт обновления с индикатором
    local update_label="🔄  Обновить"
    if [ $UPDATE_AVAILABLE -eq 1 ]; then
        if [ -n "$AVAILABLE_VERSION" ] && [ "$AVAILABLE_VERSION" != "unknown" ]; then
            update_label="🔄  Обновить ${YELLOW}( Доступно обновление - версия $AVAILABLE_VERSION ! )${NC}"
        else
            update_label="🔄  Обновить ${YELLOW}( Доступно обновление! )${NC}"
        fi
    fi
    
    while true; do
        local menu_title="       🚀 Remnasale v${LOCAL_VERSION}\n${DARKGRAY}Проект развивается благодаря вашей поддержке\n        https://github.com/DanteFuaran${NC}"
        MENU_ESC_LABEL="Выход"
        show_arrow_menu "$menu_title" \
            "$update_label" \
            "ℹ️   Просмотр логов" \
            "📊  Логи в реальном времени" \
            "──────────────────────────────────────" \
            "🔃  Перезагрузить бота" \
            "🔃  Перезагрузить с логами" \
            "⬆️   Включить бота" \
            "⬇️   Выключить бота" \
            "──────────────────────────────────────" \
            "💾  База данных" \
            "──────────────────────────────────────" \
            "�  Сменить ключ лицензии" \
            "🔄  Переустановить" \
            "⚙️   Изменить настройки" \
            "🧹  Очистить данные" \
            "🗑️   Удалить бота" \
            "──────────────────────────────────────" \
            "❌  Выход"
        local choice=$?
        
        case $choice in
            0)  manage_update_bot ;;
            1)  manage_view_logs ;;
            2)  manage_view_logs_live ;;
            4)  manage_restart_bot ;;
            5)  manage_restart_bot_with_logs ;;
            6)  manage_start_bot ;;
            7)  manage_stop_bot ;;
            9)  manage_database ;;
            11) manage_change_license_key ;;
            12) manage_reinstall_bot ;;
            13) manage_change_settings ;;
            14) manage_cleanup_database ;;
            15) manage_uninstall_bot ;;
            17) clear; exit 0 ;;
            255) clear; exit 0 ;;
        esac
    done
}

# ═══════════════════════════════════════════════
# БАЗА ДАННЫХ: СОХРАНЕНИЕ/ЗАГРУЗКА/АВТОБЕКАП
# ═══════════════════════════════════════════════

AUTOBACKUP_SCRIPT="/usr/local/lib/remnasale/autobackup.sh"
AUTOBACKUP_CONFIG="/opt/remnasale/.env"

db_backup() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       💾  Сохранение базы данных${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # Проверяем что контейнер БД запущен
    if ! docker ps --filter "name=remnasale-db" --format "{{.Names}}" 2>/dev/null | grep -q "remnasale-db"; then
        print_error "Контейнер remnasale-db не запущен"
        echo
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
        read -p ""
        return 1
    fi

    local backup_dir="/opt/remnasale/backups"
    mkdir -p "$backup_dir"

    local mn_ts mn_final
    mn_ts=$(date +%Y-%m-%d_%H-%M)
    mn_final="${backup_dir}/Remnasale_${mn_ts}.sql.gz"

    local mn_db_user mn_db_name
    mn_db_user=$(grep "^POSTGRES_USER=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$mn_db_user" ] && mn_db_user=$(grep "^DATABASE_USER=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$mn_db_user" ] && mn_db_user="postgres"
    mn_db_name=$(grep "^POSTGRES_DB=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$mn_db_name" ] && mn_db_name=$(grep "^DATABASE_NAME=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$mn_db_name" ] && mn_db_name="$mn_db_user"

    (
        docker exec remnasale-db pg_dump -U "$mn_db_user" --clean --if-exists --no-owner --no-acl "$mn_db_name" 2>/dev/null | gzip -9 > "$mn_final"
    ) &
    show_spinner "Создание дампа базы данных"

    if [ ! -s "$mn_final" ]; then
        rm -f "$mn_final"
        print_error "Не удалось создать дамп"
        echo
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
        read -p ""
        return 1
    fi

    local mn_size
    mn_size=$(du -h "$mn_final" | awk '{print $1}')
    local mn_date
    mn_date=$(date '+%d.%m.%Y %H:%M')

    # Отправка в Telegram (если настроен автобекап)
    if [ -f "$AUTOBACKUP_CONFIG" ]; then
        local mn_token mn_chat
        mn_token=$(grep '^BACKUP_BOT_TOKEN=' "$AUTOBACKUP_CONFIG" 2>/dev/null | cut -d= -f2-)
        mn_chat=$(grep '^BACKUP_CHAT_ID=' "$AUTOBACKUP_CONFIG" 2>/dev/null | cut -d= -f2-)

        if [ -n "$mn_token" ] && [ -n "$mn_chat" ]; then
            local mn_caption
            mn_caption="📦 Приложение: Remnasale
📁 Дамп базы данных
📏 Размер: ${mn_size}
📅 ${mn_date} МСК

✅ Бекап создан вручную"
            (
                curl -s \
                    -F "chat_id=$mn_chat" \
                    -F "document=@$mn_final" \
                    -F "caption=$mn_caption" \
                    "https://api.telegram.org/bot${mn_token}/sendDocument" > /tmp/_rs_ab_result 2>&1
            ) &
            show_spinner "Отправка в Telegram"

            local send_ok=false
            grep -q '"ok":true' /tmp/_rs_ab_result 2>/dev/null && send_ok=true
            rm -f /tmp/_rs_ab_result 2>/dev/null || true

            if ! $send_ok; then
                print_error "Не удалось отправить в Telegram"
            fi
        fi
    fi

    echo
    print_success "Бекап успешно создан!"
    echo
    echo -e "  📄 $(basename "$mn_final")"
    echo -e "  📏 Размер: ${YELLOW}${mn_size}${NC}"
    echo

    # Удаляем бекапы старше 7 дней
    find "$backup_dir" -maxdepth 1 -name "Remnasale_*.sql.gz" -mtime +7 -delete 2>/dev/null || true

    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
    read -p ""
}

db_restore() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}   📥 ЗАГРУЗКА БАЗЫ ДАННЫХ${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # Проверяем что контейнер БД запущен
    if ! docker ps --filter "name=remnasale-db" --format "{{.Names}}" 2>/dev/null | grep -q "remnasale-db"; then
        print_error "Контейнер remnasale-db не запущен"
        echo
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
        read -p ""
        return 1
    fi

    local backup_dir="/opt/remnasale/backups"
    local has_files=false

    if [ -d "$backup_dir" ]; then
        { compgen -G "$backup_dir/*.sql.gz" > /dev/null 2>&1 || compgen -G "$backup_dir/*.sql" > /dev/null 2>&1; } && has_files=true
    fi

    if [ "$has_files" = false ]; then
        echo -e "${YELLOW}⚠️  Бекапы не найдены в ${WHITE}${backup_dir}${NC}"
        echo
        echo -e "${WHITE}Поместите файл бекапа (.sql.gz или .sql) в эту папку${NC}"
        echo -e "${WHITE}или укажите путь к файлу вручную.${NC}"
        echo

        tput cnorm 2>/dev/null || true
        reading "Путь к файлу бэкапа (или Enter для отмены):" custom_dump_path

        if [ -z "$custom_dump_path" ]; then
            return 0
        fi

        if [ ! -f "$custom_dump_path" ]; then
            print_error "Файл не найден: ${custom_dump_path}"
            echo
            echo -e "${BLUE}══════════════════════════════════════${NC}"
            echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
            read -p ""
            return 1
        fi

        if [[ "$custom_dump_path" != *.sql.gz ]] && [[ "$custom_dump_path" != *.sql ]]; then
            print_error "Поддерживаются только файлы .sql.gz и .sql"
            echo
            echo -e "${BLUE}══════════════════════════════════════${NC}"
            echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
            read -p ""
            return 1
        fi

        mkdir -p "$backup_dir"
        cp "$custom_dump_path" "$backup_dir/"
    fi

    # Собираем список бэкапов
    local backup_files=()
    local menu_items=()
    while IFS= read -r file; do
        backup_files+=("$file")
        local fname fsize display_label
        fname=$(basename "$file")
        fsize=$(du -h "$file" | cut -f1)
        if [[ "$fname" =~ ^([A-Za-z]+)_([0-9]{4})-([0-9]{2})-([0-9]{2})_([0-9]{2})-([0-9]{2})\.(sql\.gz|sql)$ ]]; then
            local pname pyear pmon pday phour pmin pext
            pname="${BASH_REMATCH[1]}"
            pyear="${BASH_REMATCH[2]}"
            pmon="${BASH_REMATCH[3]}"
            pday="${BASH_REMATCH[4]}"
            phour="${BASH_REMATCH[5]}"
            pmin="${BASH_REMATCH[6]}"
            pext="${BASH_REMATCH[7]}"
            display_label="${pname} | ${pday}.${pmon}.${pyear} | ${phour}:${pmin} | ${fsize} | .${pext}"
        else
            display_label="${fname} (${fsize})"
        fi
        menu_items+=("📄  ${display_label}")
    done < <(find "$backup_dir" -maxdepth 1 \( -name "*.sql.gz" -o -name "*.sql" \) | sort -r)

    if [ ${#backup_files[@]} -eq 0 ]; then
        print_error "Файлы бэкапов не найдены"
        echo
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
        read -p ""
        return 1
    fi

    menu_items+=("──────────────────────────────────────")
    menu_items+=("❌  Назад")

    show_arrow_menu "📥  Выберите бэкап для загрузки" "${menu_items[@]}"
    local choice=$?

    if [ $choice -ge ${#backup_files[@]} ] || [ $choice -eq 255 ]; then
        return 0
    fi

    local selected_file="${backup_files[$choice]}"
    local selected_name
    selected_name=$(basename "$selected_file")

    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}   📥 ЗАГРУЗКА БАЗЫ ДАННЫХ${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${WHITE}Файл:${NC} ${DARKGRAY}${selected_name}${NC}"
    echo -e "${WHITE}Режим:${NC} ${YELLOW}Полное восстановление${NC}"
    echo
    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
    echo
    echo -e "${YELLOW}⚠️  ВНИМАНИЕ!${NC}"
    echo -e "${WHITE}Все текущие данные бота будут заменены.${NC}"
    echo

    if ! confirm_action; then
        print_error "Операция отменена"
        sleep 2
        return 0
    fi

    echo

    # Определяем текущего пользователя, базу данных и пароль Redis
    local db_user db_name redis_pass
    db_user=$(grep "^POSTGRES_USER=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$db_user" ] && db_user=$(grep "^DATABASE_USER=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$db_user" ] && db_user="postgres"
    db_name=$(grep "^POSTGRES_DB=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$db_name" ] && db_name=$(grep "^DATABASE_NAME=" /opt/remnasale/.env 2>/dev/null | cut -d= -f2)
    [ -z "$db_name" ] && db_name="$db_user"
    redis_pass=$(grep '^REDIS_PASSWORD=' /opt/remnasale/.env 2>/dev/null | cut -d= -f2)

    # Step 1: Останавливаем бота
    (
        cd /opt/remnasale
        docker compose stop remnasale remnasale-taskiq-worker remnasale-taskiq-scheduler >/dev/null 2>&1
    ) &
    show_spinner "Остановка бота"

    # Step 2: Сохраняем текущие платёжные шлюзы перед восстановлением
    local gateways_json=""
    gateways_json=$(docker exec remnasale-db psql -U "$db_user" -d "$db_name" -t -A -c \
        "SELECT json_agg(row_to_json(pg)) FROM payment_gateways pg" 2>/dev/null) || gateways_json=""

    # Step 3: Завершаем все активные соединения к базе
    docker exec remnasale-db psql -U "$db_user" -d postgres -c \
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$db_name' AND pid <> pg_backend_pid();" >/dev/null 2>&1 || true

    # Step 4: Очищаем базу данных (с GRANT ALL, как в боте)
    (
        docker exec remnasale-db psql -U "$db_user" -d "$db_name" -c \
            "DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public; GRANT ALL ON SCHEMA public TO public;" >/dev/null 2>&1
    ) &
    show_spinner "Подготовка базы данных"

    # Step 5: Восстанавливаем дамп
    # Фильтрация для совместимости со старыми бэкапами:
    # - \restrict / \unrestrict — нестандартные команды, psql их не поддерживает
    # - OWNER TO <old_user> → заменяем на текущего пользователя БД
    (
        if [[ "$selected_file" == *.gz ]]; then
            zcat "$selected_file"
        else
            cat "$selected_file"
        fi \
        | grep -v '^\\restrict\|^\\unrestrict' \
        | sed "s/OWNER TO [a-zA-Z_][a-zA-Z0-9_]*/OWNER TO ${db_user}/g" \
        | docker exec -i remnasale-db psql -U "$db_user" -d "$db_name" -v ON_ERROR_STOP=0 >/dev/null 2>&1
    ) &
    show_spinner "Загрузка данных из бэкапа"

    # Step 6: Восстанавливаем платёжные шлюзы, которые были до бэкапа, но отсутствуют после
    if [ -n "$gateways_json" ] && [ "$gateways_json" != "null" ] && [ "$gateways_json" != "" ]; then
        (
            docker exec -i remnasale-db psql -U "$db_user" -d "$db_name" << EOSQL >/dev/null 2>&1
DO \$body\$
DECLARE
    saved_data json := \$gw_json\$${gateways_json}\$gw_json\$;
    gw json;
    gw_type text;
    gw_currency text;
    gw_settings jsonb;
    next_order int;
BEGIN
    FOR gw IN SELECT * FROM json_array_elements(saved_data)
    LOOP
        gw_type := gw->>'type';
        gw_currency := COALESCE(gw->>'currency', 'USD');
        gw_settings := COALESCE((gw->'settings')::jsonb, 'null'::jsonb);
        IF gw_type IS NOT NULL AND NOT EXISTS (SELECT 1 FROM payment_gateways WHERE type = gw_type) THEN
            SELECT COALESCE(MAX(order_index), 0) + 1 INTO next_order FROM payment_gateways;
            INSERT INTO payment_gateways (order_index, type, currency, is_active, settings)
            VALUES (next_order, gw_type, gw_currency, false, gw_settings);
        END IF;
    END LOOP;
    PERFORM setval('payment_gateways_id_seq', (SELECT COALESCE(MAX(id), 1) FROM payment_gateways));
END \$body\$;
EOSQL
        ) &
        show_spinner "Восстановление платёжных шлюзов"
    fi

    # Step 7: Очищаем Redis кэш
    if [ -n "$redis_pass" ]; then
        docker exec remnasale-redis valkey-cli -a "$redis_pass" --no-auth-warning \
            EVAL "local keys = redis.call('keys', ARGV[1]) if #keys > 0 then return redis.call('del', unpack(keys)) end return 0" 0 "cache:*" >/dev/null 2>&1 || true
    fi

    echo

    # Step 8: Запускаем бота (Alembic миграции запустятся автоматически в entrypoint)
    (
        cd /opt/remnasale
        docker compose up -d remnasale remnasale-taskiq-worker remnasale-taskiq-scheduler >/dev/null 2>&1
    ) &
    show_spinner "Запуск бота"

    # Step 9: Ожидаем запуска бота и применения Alembic миграций (без отображения в UI)
    local _hw_max=120 _hw_waited=0 _hw_hs
    while [ $_hw_waited -lt $_hw_max ]; do
        _hw_hs=$(docker inspect --format='{{.State.Health.Status}}' remnasale 2>/dev/null || echo "")
        [ "$_hw_hs" = "healthy" ] && break
        sleep 3
        _hw_waited=$((_hw_waited + 3))
    done

    # Step 10: Синхронизация данных из бота в панель Remnawave
    (
        docker exec remnasale python -c "
import asyncio
from src.infrastructure.taskiq.broker import broker
from src.infrastructure.taskiq.tasks.importer import sync_bot_to_panel_task
async def main():
    await broker.startup()
    task = await sync_bot_to_panel_task.kiq()
    try:
        result = await asyncio.wait_for(task.wait_result(), timeout=300)
    except Exception:
        pass
    await broker.shutdown()
asyncio.run(main())
" >/dev/null 2>&1
    ) &
    show_spinner "Синхронизация с панелью Remnawave"

    echo
    print_success "База данных успешно загружена!"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    printf "\033[?25l${DARKGRAY}    ${BLUE}Enter${DARKGRAY}: Продолжить${NC} "
    while true; do
        read -rs -n1 _k 2>/dev/null
        [[ "$_k" == "" ]] && break
    done
    printf "\033[?25h\n"
}

# Создание скрипта автобекапа (только дамп БД)
_create_autobackup_script() {
    sudo mkdir -p "$(dirname "$AUTOBACKUP_SCRIPT")" 2>/dev/null || true
    cat > "$AUTOBACKUP_SCRIPT" << 'BACKUP_SCRIPT'
#!/bin/bash
set -euo pipefail

CONFIG="/opt/remnasale/.env"
[ -f "$CONFIG" ] || exit 0
BOT_TOKEN=$(grep '^BACKUP_BOT_TOKEN=' "$CONFIG" | cut -d= -f2-)
CHAT_ID=$(grep '^BACKUP_CHAT_ID=' "$CONFIG" | cut -d= -f2-)
[ -z "$BOT_TOKEN" ] || [ -z "$CHAT_ID" ] && exit 1

DB_USER=$(grep '^DATABASE_USER=' "$CONFIG" | cut -d= -f2-)
[ -z "$DB_USER" ] && DB_USER="postgres"
DB_NAME=$(grep '^DATABASE_NAME=' "$CONFIG" | cut -d= -f2-)
[ -z "$DB_NAME" ] && DB_NAME="$DB_USER"

BACKUP_DIR="/opt/remnasale/backups"
mkdir -p "$BACKUP_DIR"
TIMESTAMP=$(date +%Y-%m-%d_%H-%M)
FINAL_FILE="${BACKUP_DIR}/Remnasale_${TIMESTAMP}.sql.gz"

# Дамп БД
docker exec remnasale-db pg_dump -U "$DB_USER" --clean --if-exists --no-owner --no-acl "$DB_NAME" 2>/dev/null | gzip -9 > "$FINAL_FILE"
if [ ! -s "$FINAL_FILE" ]; then
    rm -f "$FINAL_FILE"
    exit 1
fi

SIZE=$(du -h "$FINAL_FILE" | awk '{print $1}')
DATE=$(date '+%d.%m.%Y %H:%M')
CAPTION="📦 Приложение: Remnasale
📁 Дамп базы данных
📏 Размер: ${SIZE}
📅 ${DATE} МСК

✅ Бекап создан автоматически"
curl -s -F "chat_id=$CHAT_ID" \
     -F "document=@$FINAL_FILE" \
     -F "caption=$CAPTION" \
     "https://api.telegram.org/bot${BOT_TOKEN}/sendDocument" >/dev/null 2>&1
find "$BACKUP_DIR" -name "Remnasale_*.sql.gz" -mtime +7 -delete 2>/dev/null || true
BACKUP_SCRIPT
    chmod +x "$AUTOBACKUP_SCRIPT"
}

# Получение cron-выражения по частоте
_get_cron_schedule() {
    local freq="$1"
    case "$freq" in
        hourly)  echo "0 * * * *" ;;
        daily)   echo "0 21 * * *" ;;
        weekly)  echo "0 21 * * 0" ;;
        monthly) echo "0 21 1 * *" ;;
    esac
}

# Проверка статуса автобекапа
_autobackup_is_active() {
    crontab -l 2>/dev/null | grep -q "$AUTOBACKUP_SCRIPT"
}

# Получение текущей частоты
_autobackup_get_frequency() {
    if ! _autobackup_is_active; then
        echo ""
        return
    fi
    local cron_line
    cron_line=$(crontab -l 2>/dev/null | grep "$AUTOBACKUP_SCRIPT")
    case "$cron_line" in
        "0 * * * *"*)    echo "Каждый час" ;;
        "0 21 * * *"*)   echo "Каждый день (00:00 МСК)" ;;
        "0 21 * * 0"*)   echo "Каждую неделю (Вс 00:00 МСК)" ;;
        "0 21 1 * *"*)   echo "Каждый месяц (1-е число, 00:00 МСК)" ;;
        *)               echo "Пользовательское расписание" ;;
    esac
}

# Настройка автобекапа
_configure_autobackup() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}   ⚙️  НАСТРОЙКА АВТОБЕКАПА${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # Токен бота
    local backup_bot_token=""
    if [ -f "$AUTOBACKUP_CONFIG" ]; then
        backup_bot_token=$(grep '^BACKUP_BOT_TOKEN=' "$AUTOBACKUP_CONFIG" 2>/dev/null | cut -d= -f2-)
    fi
    local current_hint=""
    [ -n "$backup_bot_token" ] && current_hint=" (Enter = оставить текущий)"
    tput cnorm 2>/dev/null || true
    reading_inline "Токен бота для бекапов${current_hint}:" new_backup_token
    local _ri_rc=$?
    [ $_ri_rc -eq 2 ] && return 1
    if [ -z "$new_backup_token" ] && [ -n "$backup_bot_token" ]; then
        new_backup_token="$backup_bot_token"
    fi
    if [ -z "$new_backup_token" ]; then
        print_error "Токен не может быть пустым"
        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
        read -p ""
        return
    fi

    # Chat ID
    local backup_chat_id=""
    if [ -f "$AUTOBACKUP_CONFIG" ]; then
        backup_chat_id=$(grep '^BACKUP_CHAT_ID=' "$AUTOBACKUP_CONFIG" 2>/dev/null | cut -d= -f2-)
    fi
    current_hint=""
    [ -n "$backup_chat_id" ] && current_hint=" (Enter = оставить текущий)"
    reading_inline "Telegram ID для получения бекапов${current_hint}:" new_chat_id
    local _ri_rc=$?
    [ $_ri_rc -eq 2 ] && return 1
    if [ -z "$new_chat_id" ] && [ -n "$backup_chat_id" ]; then
        new_chat_id="$backup_chat_id"
    fi
    if [ -z "$new_chat_id" ]; then
        print_error "ID не может быть пустым"
        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
        read -p ""
        return
    fi

    # Частота
    echo
    show_arrow_menu "Частота бекапа" \
        "⏱️   Каждый час" \
        "📅  Каждый день (00:00 МСК)" \
        "📆  Каждую неделю (Вс 00:00 МСК)" \
        "🗓️   Каждый месяц (1-е число, 00:00 МСК)"
    local freq_choice=$?

    local frequency=""
    case $freq_choice in
        0) frequency="hourly" ;;
        1) frequency="daily" ;;
        2) frequency="weekly" ;;
        3) frequency="monthly" ;;
        255) return ;;
    esac

    # Сохраняем настройки в .env
    mkdir -p "$(dirname "$AUTOBACKUP_CONFIG")" 2>/dev/null || true
    local _rs_envfile="$AUTOBACKUP_CONFIG"
    for _rs_pair in "BACKUP_BOT_TOKEN=$new_backup_token" "BACKUP_CHAT_ID=$new_chat_id" "BACKUP_FREQUENCY=$frequency"; do
        local _rs_key="${_rs_pair%%=*}" _rs_val="${_rs_pair#*=}"
        if grep -q "^${_rs_key}=" "$_rs_envfile" 2>/dev/null; then
            sed -i "s|^${_rs_key}=.*|${_rs_key}=${_rs_val}|" "$_rs_envfile"
        else
            echo "${_rs_key}=${_rs_val}" >> "$_rs_envfile"
        fi
    done

    # Создаём скрипт бекапа
    _create_autobackup_script

    # Устанавливаем cron
    local cron_schedule
    cron_schedule=$(_get_cron_schedule "$frequency")
    (crontab -l 2>/dev/null | grep -v "$AUTOBACKUP_SCRIPT"; echo "$cron_schedule $AUTOBACKUP_SCRIPT") | crontab -

    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       💾 АВТОБЕКАП НАСТРОЕН${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${GREEN}✅ Автобекап успешно настроен${NC}"
    echo
    local freq_label
    case $frequency in
        hourly)  freq_label="Каждый час" ;;
        daily)   freq_label="Каждый день (00:00 МСК)" ;;
        weekly)  freq_label="Каждую неделю (Вс 00:00 МСК)" ;;
        monthly) freq_label="Каждый месяц (1-е число, 00:00 МСК)" ;;
    esac
    echo -e "  Частота: ${YELLOW}${freq_label}${NC}"
    echo -e "  Получатель: ${YELLOW}${new_chat_id}${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
    read -p ""
}

# Остановка автобекапа
_stop_autobackup() {
    (crontab -l 2>/dev/null | grep -v "$AUTOBACKUP_SCRIPT") | crontab -
    sed -i '/^BACKUP_BOT_TOKEN=\|^BACKUP_CHAT_ID=\|^BACKUP_FREQUENCY=/d' "$AUTOBACKUP_CONFIG" 2>/dev/null || true
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       💾 АВТОБЕКАП${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${GREEN}✅ Автобекап остановлен${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
    read -p ""
}

# Меню базы данных
manage_database() {
    while true; do
        local menu_items=()
        local db_actions=()

        menu_items+=("💾  Сохранить базу данных");     db_actions+=("backup")
        menu_items+=("📥  Загрузить базу данных");     db_actions+=("restore")
        menu_items+=("──────────────────────────────────────"); db_actions+=("sep")

        if _autobackup_is_active; then
            menu_items+=("⚙️   Изменить настройки автобекапа"); db_actions+=("ab_configure")
            menu_items+=("⛔  Остановить автобекап");           db_actions+=("ab_stop")
        else
            menu_items+=("⚙️   Включить автобекап");            db_actions+=("ab_configure")
        fi
        menu_items+=("──────────────────────────────────────"); db_actions+=("sep")
        menu_items+=("❌  Назад");                              db_actions+=("back")

        local menu_title=" 💾  Работа с базой данных"
        if _autobackup_is_active; then
            local freq
            freq=$(_autobackup_get_frequency)
            menu_title=" 💾  Работа с базой данных\n    📊  Автобекап: ${GREEN}${freq}${NC}"
        fi

        show_arrow_menu "$menu_title" "${menu_items[@]}"
        local choice=$?
        [[ $choice -eq 255 ]] && return
        local db_action="${db_actions[$choice]:-back}"

        case "$db_action" in
            backup)       db_backup ;;
            restore)      db_restore ;;
            ab_configure) _configure_autobackup ;;
            ab_stop)      _stop_autobackup ;;
            back)         return ;;
            *)            continue ;;
        esac
    done
}

# Функция обновления бота
manage_update_bot() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       🔄 ОБНОВЛЕНИЕ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # --- Проверка ключа доступа ---
    local access_key=""

    # Пробуем из .env
    if [ -f "$ENV_FILE" ]; then
        access_key=$(grep "^LICENSE_KEY=" "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    fi

    # Пробуем из переменной окружения
    if [ -z "$access_key" ] && [ -n "${REMNASALE_LICENSE_KEY:-}" ]; then
        access_key="$REMNASALE_LICENSE_KEY"
    fi

    # Если ключ не найден — запрашиваем у пользователя
    if [ -z "$access_key" ]; then
        echo -e "${YELLOW}⚠  Ключ доступа не найден${NC}"
        echo
        echo -e "   Для обновления необходим ключ доступа."
        echo
        read -r -p "   Ключ: " access_key
        echo

        if [ -z "$access_key" ]; then
            echo -e "${RED}❌ Ключ доступа не указан${NC}"
            echo
            echo -e "${DARKGRAY}Нажмите Enter для возврата в меню...${NC}"
            read -r
            return
        fi
    fi

    # Валидация ключа
    local _validate_file
    _validate_file=$(mktemp)
    _validate_access_key_bg "$access_key" "$_validate_file" &
    show_spinner "Проверка ключа доступа"

    local _vresult
    _vresult=$(cat "$_validate_file" 2>/dev/null)
    rm -f "$_validate_file"

    case "$_vresult" in
        "ok") ;; # Ключ валиден
        *)
            echo
            echo -e "  ${RED}Указан недействительный ключ доступа${NC}"
            echo
            echo -e "${DARKGRAY}Нажмите Enter для возврата в меню...${NC}"
            read -r
            return
            ;;
    esac

    # Проверка привязки лицензии к серверу
    if ! _check_license_bind "$ENV_FILE"; then
        echo
        echo -e "  ${RED}❌ Этот ключ уже используется на другом сервере.${NC}"
        echo -e "  ${YELLOW}Обновление невозможно. Обратитесь к разработчику.${NC}"
        echo
        echo -e "${DARKGRAY}Нажмите Enter для возврата в меню...${NC}"
        read -r
        return
    fi

    # Сохраняем ключ в .env
    update_env_var "$ENV_FILE" "LICENSE_KEY" "$access_key"

    # Сохраняем позицию курсора перед выводом информации о проверке
    tput sc 2>/dev/null || true

    # Скрываем курсор во время проверки
    tput civis 2>/dev/null || true

    # Создаём временную папку для скачивания архива
    TEMP_REPO=$(mktemp -d)

    # Скачиваем архив с GitHub для проверки версии
    _download_archive "" "$TEMP_REPO" >/dev/null 2>&1 &
    show_spinner "Поиск обновлений"
    
    # Получаем версии (из файла version)
    REMOTE_VERSION=$(parse_version_from_content "$(cat "$TEMP_REPO/version" 2>/dev/null)")
    LOCAL_VERSION=$(get_local_version)
    
    UPDATE_NEEDED=1
    
    # Проверяем версии
    if [ -n "$REMOTE_VERSION" ] && [ -n "$LOCAL_VERSION" ]; then
        # Сравниваем семантически — обновление нужно ТОЛЬКО если remote > local
        local_num=$(echo "$LOCAL_VERSION" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
        remote_num=$(echo "$REMOTE_VERSION" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
        if [ "$remote_num" -le "$local_num" ]; then
            UPDATE_NEEDED=0
        fi
    else
        # Fallback на старый метод с хешами если версии не доступны
        REMOTE_HASH=$(cd "$TEMP_REPO" && git rev-parse HEAD 2>/dev/null)
        LOCAL_HASH=""
        
        local _hash_state="/var/lib/remnasale-license/last_update_hash"
        if [ -f "$_hash_state" ]; then
            LOCAL_HASH=$(cat "$_hash_state" 2>/dev/null | tr -d '\t\r\n ')
        elif [ -f "$ENV_FILE" ] && grep -q "^LAST_UPDATE_HASH=" "$ENV_FILE"; then
            LOCAL_HASH=$(grep "^LAST_UPDATE_HASH=" "$ENV_FILE" | cut -d'=' -f2)
            
            if [ "$LOCAL_HASH" = "$REMOTE_HASH" ]; then
                UPDATE_NEEDED=0
            fi
        elif [ -d "$PROJECT_DIR/.git" ]; then
            # Если это git репозиторий, просто сравним хеши
            LOCAL_HASH=$(cd "$PROJECT_DIR" && git rev-parse HEAD 2>/dev/null || echo "")
            
            if [ "$LOCAL_HASH" = "$REMOTE_HASH" ]; then
                UPDATE_NEEDED=0
            fi
        else
            # Если нет .git и нет сохранённого хеша - нужно обновить
            UPDATE_NEEDED=1
        fi
    fi
    
    # Выводим результат проверки
    if [ $UPDATE_NEEDED -eq 0 ]; then
        clear
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${GREEN}       🔄 ОБНОВЛЕНИЕ REMNASALE${NC}"
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo
        echo -e "${GREEN}✅ Уже установлена последняя версия бота!${NC}"
        echo
        if [ -n "$LOCAL_VERSION" ] && [ "$LOCAL_VERSION" != "unknown" ]; then
            echo -e "   Текущая версия:  ${CYAN}v${LOCAL_VERSION}${NC}"
        fi
        if [ -n "$REMOTE_VERSION" ]; then
            echo -e "   Версия на сервере: ${CYAN}v${REMOTE_VERSION}${NC}"
        fi
        echo
        echo -e "${GRAY}Нажмите Enter для возврата в меню...${NC}"
        read -r
        rm -rf "$TEMP_REPO" 2>/dev/null || true
        return
    else
        # Автоматическое начало обновления без диалога
        clear
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${GREEN}       🔄 ОБНОВЛЕНИЕ REMNASALE${NC}"
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo
        if [ -n "$LOCAL_VERSION" ] && [ "$LOCAL_VERSION" != "unknown" ]; then
            echo -e "   Текущая версия:  ${CYAN}v${LOCAL_VERSION}${NC}"
        fi
        if [ -n "$REMOTE_VERSION" ]; then
            echo -e "   Новая версия:    ${GREEN}v${REMOTE_VERSION}${NC}"
        fi
        echo
        echo -e "${BLUE}──────────────────────────────────────${NC}"
        echo
        # Сохраняем критические переменные перед обновлением
        ENV_BACKUP_FILE=$(preserve_env_vars "$ENV_FILE")
            
            # Копируем только необходимые файлы конфигурации в PROJECT_DIR
            {
                cd "$TEMP_REPO" || return
                
                # Список файлов для копирования в PROJECT_DIR (только конфигурация)
                INCLUDE_FILES=(
                    "docker-compose.yml"
                    "assets"
                )
                
                for item in "${INCLUDE_FILES[@]}"; do
                    if [ -e "$item" ]; then
                        if [ -d "$item" ]; then
                            mkdir -p "$PROJECT_DIR/$item" 2>/dev/null || true
                            # Копируем всё содержимое
                            if [ "$item" = "assets" ]; then
                                # Для папки assets копируем всё содержимое
                                for subitem in "$item"/*; do
                                    subname=$(basename "$subitem")
                                    if [ -d "$subitem" ]; then
                                        # Для папки banners - не трогаем если уже существует (пользовательские баннеры)
                                        if [ "$subname" = "banners" ]; then
                                            if [ ! -d "$PROJECT_DIR/$item/banners" ]; then
                                                cp -r "$subitem" "$PROJECT_DIR/$item/" 2>/dev/null || true
                                            fi
                                        else
                                            cp -r "$subitem" "$PROJECT_DIR/$item/" 2>/dev/null || true
                                        fi
                                    else
                                        cp -f "$subitem" "$PROJECT_DIR/$item/" 2>/dev/null || true
                                    fi
                                done
                            else
                                cp -r "$item"/* "$PROJECT_DIR/$item/" 2>/dev/null || true
                            fi
                        else
                            cp -f "$item" "$PROJECT_DIR/" 2>/dev/null || true
                        fi
                    fi
                done
                
                # Копируем файл версии из временного репозитория
                if [ -f "version" ]; then
                    cp -f "version" "$PROJECT_DIR/version"
                fi
                
                # Копируем remnasale-install.sh в системную папку (не в корень бота)
                sudo mkdir -p "$SYSTEM_INSTALL_DIR" 2>/dev/null || true
                _src="$(realpath "remnasale-install.sh" 2>/dev/null || echo "remnasale-install.sh")"
                _dst="$(realpath "$SYSTEM_INSTALL_DIR/remnasale-install.sh" 2>/dev/null || echo "$SYSTEM_INSTALL_DIR/remnasale-install.sh")"
                if [ "$_src" != "$_dst" ]; then
                    sudo cp -f "remnasale-install.sh" "$SYSTEM_INSTALL_DIR/remnasale-install.sh" 2>/dev/null || true
                fi
                sudo chmod +x "$SYSTEM_INSTALL_DIR/remnasale-install.sh" 2>/dev/null || true
            } &
            show_spinner "Обновление конфигурации"
            
            {
                cd "$PROJECT_DIR" || return
                docker compose down >/dev/null 2>&1
            } &
            show_spinner "Остановка сервисов"
            
            {
                # Предварительно скачиваем базовые образы из Docker Hub (кешируем)
                for _pull_attempt in 1 2 3; do
                    docker pull node:20-alpine >/dev/null 2>&1 && break
                    [ "$_pull_attempt" -lt 3 ] && sleep 10
                done
                # Собираем образ из временной папки с исходниками
                cd "$TEMP_REPO" || return
                DOCKER_BUILDKIT=1 docker build -t remnasale:local \
                    --network=host \
                    --build-arg BUILD_TIME="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
                    --build-arg BUILD_BRANCH="$REPO_BRANCH" \
                    --build-arg BUILD_COMMIT="$(git rev-parse --short HEAD 2>/dev/null || echo 'unknown')" \
                    --build-arg BUILD_TAG="$(grep '^version:' version 2>/dev/null | head -1 | cut -d: -f2 | tr -d ' \n' || echo 'unknown')" \
                    . >/tmp/remnasale-build.log 2>&1
            } &
            show_spinner "Пересборка образа" || echo -e "  ${YELLOW}⚠  Сборка Docker образа не удалась. Лог: ${WHITE}cat /tmp/remnasale-build.log${NC}"
            
            # Восстанавливаем сохранённые переменные в .env после обновления (до запуска контейнеров)
            if [ -n "$ENV_BACKUP_FILE" ] && [ -f "$ENV_BACKUP_FILE" ]; then
                {
                    restore_env_vars "$ENV_FILE" "$ENV_BACKUP_FILE"
                } &
                show_spinner "Применение сохранённых параметров"
            fi
            
            # Запускаем контейнеры и ожидаем запуска бота
            cd "$PROJECT_DIR" || return
            docker compose up -d >/dev/null 2>&1 &
            
            # Ждем появления логотипа Remnasale в логах
            show_spinner_until_log "remnasale" "Digital.*Freedom.*Core" "Запуск бота" 90
            local spinner_result=$?
            
            echo
            
            if [ $spinner_result -eq 0 ]; then
                echo -e "${GREEN}✅ Бот успешно обновлен${NC}"
                
                # Обновляем license-check.sh (если есть обновлённая версия)
                SCRIPT_CWD="$TEMP_REPO" _install_license_checker 2>/dev/null || true
                
                # Сохраняем хеш обновления в state файл
                mkdir -p /var/lib/remnasale-license
                echo "$REMOTE_HASH" > /var/lib/remnasale-license/last_update_hash 2>/dev/null || true
                
                # Удаляем временную папку репозитория
                rm -rf "$TEMP_REPO" 2>/dev/null || true
                
                echo
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                printf "\033[?25l${DARKGRAY}    Нажмите ${BLUE}Enter${DARKGRAY} для продолжения${NC} "
                while true; do
                    read -rs -n1 _k 2>/dev/null
                    [[ "$_k" == "" ]] && break
                done
                printf "\033[?25h\n"
                
                # Перезапускаем скрипт чтобы вернуться в главное меню
                # При перезапуске check_updates_available автоматически пересчитает флаг обновления
                restart_script
            elif [ $spinner_result -eq 2 ]; then
                echo -e "${RED}❌ Ошибка при обновлении бота!${NC}"
                echo
                echo -ne "${YELLOW}Показать лог ошибки? [Y/n]: ${NC}"
                read -n 1 -r show_logs
                echo
                
                if [[ -z "$show_logs" || "$show_logs" =~ ^[Yy]$ ]]; then
                    echo
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${RED}ЛОГИ ОШИБОК:${NC}"
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    docker compose -f "$PROJECT_DIR/docker-compose.yml" logs --tail 50 remnasale
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                fi
                
                # Удаляем временную папку репозитория
                rm -rf "$TEMP_REPO" 2>/dev/null || true
                
                echo
                echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                read -p ""
                return
            else
                echo -e "${YELLOW}Бот может всё ещё запускаться...${NC}"
                
                # Обновляем license-check.sh (если есть обновлённая версия)
                SCRIPT_CWD="$TEMP_REPO" _install_license_checker 2>/dev/null || true
                
                # Сохраняем хеш обновления даже при таймауте
                mkdir -p /var/lib/remnasale-license
                echo "$REMOTE_HASH" > /var/lib/remnasale-license/last_update_hash 2>/dev/null || true
                
                # Удаляем временную папку репозитория
                rm -rf "$TEMP_REPO" 2>/dev/null || true
                
                echo
                echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                read -p ""
                
                # Перезапускаем скрипт
                restart_script
            fi
    fi
    
    # Очистка временной папки репозитория в конце функции (на случай если не прошли через exec)
    rm -rf "$TEMP_REPO" 2>/dev/null || true
}

# Функция перезагрузки бота с ожиданием логотипа Remnasale
manage_restart_bot() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}      🔃 ПЕРЕЗАГРУЗКА REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${YELLOW}Бот будет перезагружен...${NC}"
    echo
    
    {
        cd "$PROJECT_DIR" || return
        docker compose down >/dev/null 2>&1
        docker compose up -d >/dev/null 2>&1
    } &
    show_spinner "Перезагрузка бота"
    
    # Ждем появления логотипа Remnasale в логах
    show_spinner_until_log "remnasale" "Digital.*Freedom.*Core" "Запуск бота" 90
    local spinner_result=$?
    
    echo
    if [ $spinner_result -eq 2 ]; then
        echo -e "${RED}❌ Обнаружена ошибка при запуске. Проверьте логи.${NC}"
    else
        echo -e "${GREEN}✅Бот успешно обновлен и запущен!${NC}"
    fi
    
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    tput cnorm 2>/dev/null || true
    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
    read -p ""
}

# Функция перезагрузки бота с отображением логов
manage_restart_bot_with_logs() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}    🔃📊 ПЕРЕЗАГРУЗКА С ЛОГАМИ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${YELLOW}Бот будет перезагружен с отображением логов...${NC}"
    echo -e "${DARKGRAY}(Нажмите Ctrl+C для выхода из логов)${NC}"
    echo
    
    # Восстанавливаем нормальные настройки терминала
    stty sane 2>/dev/null || true
    tput cnorm 2>/dev/null || true
    
    cd "$PROJECT_DIR" || return
    
    # Перезагружаем и одновременно смотрим логи
    docker compose down >/dev/null 2>&1
    docker compose up -d >/dev/null 2>&1
    sleep 2
    
    # Выводим логи с автоматическим обновлением
    # Перехватываем Ctrl+C чтобы не завершать весь скрипт
    trap '' INT
    docker compose logs -f remnasale
    trap handle_interrupt INT
    
    # После выхода из логов возвращаемся в меню
    echo
    echo -e "${DARKGRAY}Отображение логов остановлено${NC}"
    echo
    tput civis 2>/dev/null || true
    echo -e "${DARKGRAY}Нажмите Enter для возврата в меню${NC}"
    read -p ""
}

# Функция смены лицензионного ключа
manage_change_license_key() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       🔑 СМЕНА КЛЮЧА ЛИЦЕНЗИИ${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    local current_key=""
    if [ -f "$ENV_FILE" ]; then
        current_key=$(grep '^LICENSE_KEY=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    fi
    if [ -n "$current_key" ]; then
        local masked="${current_key:0:6}...${current_key: -4}"
        echo -e "  Текущий ключ: ${DARKGRAY}${masked}${NC}"
        echo
    fi

    local new_key=""
    reading_inline "Введите новый ключ лицензии:" new_key
    local rc=$?

    if [ $rc -eq 2 ] || [ -z "$new_key" ]; then
        echo -e "${YELLOW}  Отменено${NC}"
        echo
        echo -e "${DARKGRAY}Нажмите Enter для продолжения...${NC}"
        read -p ""
        return
    fi

    # Проверяем ключ через лицензионный сервер
    local _server="${LICENSE_SERVER:-$REMNASALE_LICENSE_SERVER}"
    if [ -z "$_server" ] && [ -f "$ENV_FILE" ]; then
        _server=$(grep '^LICENSE_SERVER=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
    fi

    if [ -n "$_server" ]; then
        echo
        local _verify_result=""
        local _cur_ip
        _cur_ip=$(get_server_ip 2>/dev/null || echo "")
        (
            _body="{\"license_key\": \"${new_key}\""
            if [ -n "$_cur_ip" ] && [ "$_cur_ip" != "unknown" ]; then
                _body="${_body}, \"server_ip\": \"${_cur_ip}\""
            fi
            _body="${_body}}"
            _resp=$(curl -s --max-time 15 -X POST \
                -H "Content-Type: application/json" \
                -d "$_body" \
                "${_server}/api/v1/license/verify" 2>/dev/null)
            _valid=$(echo "$_resp" | grep -o '"valid" *: *true')
            if [ -n "$_valid" ]; then
                echo "ok" > /tmp/_rl_verify_result
            else
                _reason=$(echo "$_resp" | grep -o '"reason" *: *"[^"]*"' | sed 's/.*: *"//;s/"//')
                echo "fail:${_reason:-unknown}" > /tmp/_rl_verify_result
            fi
        ) &
        show_spinner "Проверка ключа"

        _verify_result=$(cat /tmp/_rl_verify_result 2>/dev/null)
        rm -f /tmp/_rl_verify_result

        if [ "${_verify_result}" != "ok" ]; then
            local _fail_reason="${_verify_result#fail:}"
            local _fail_msg
            case "$_fail_reason" in
                ip_mismatch) _fail_msg="Ключ уже используется на другом сервере" ;;
                suspended)   _fail_msg="Ключ приостановлен" ;;
                expired)     _fail_msg="Срок действия ключа истёк" ;;
                not_found)   _fail_msg="Ключ не найден" ;;
                *)           _fail_msg="${_fail_reason}" ;;
            esac
            echo -e "${RED}✖  Ключ недействителен: ${_fail_msg}${NC}"
            echo
            echo -e "${DARKGRAY}Нажмите Enter для продолжения...${NC}"
            read -p ""
            return
        fi
    fi

    # Записываем новый ключ в .env
    update_env_var "$ENV_FILE" "LICENSE_KEY" "$new_key"
    echo -e "${GREEN}✅${NC} Ключ обновлён"

    # Перезагружаем бота
    echo
    (
        cd "$PROJECT_DIR" 2>/dev/null || true
        docker compose restart >/dev/null 2>&1
    ) &
    show_spinner "Перезагрузка бота" "Бот перезагружен с новым ключом"

    echo
    echo -e "${DARKGRAY}Нажмите Enter для продолжения...${NC}"
    read -p ""
}

# Функция переустановки бота с удалением всех данных
manage_reinstall_bot() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}      🔄 ПЕРЕУСТАНОВКА REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${RED}⚠️  ВНИМАНИЕ!${NC}"
    echo -e "${RED}Это действие удалит весь бот и ВСЕ данные:${NC}"
    echo -e "  - База данных PostgreSQL"
    echo -e "  - Redis/Valkey"
    echo -e "  - Все конфигурационные файлы"
    echo -e "  - Логи и кэш"
    echo
    echo -e "${YELLOW}После этого будет произведена чистая переустановка бота.${NC}"
    echo
    
    if ! confirm_action; then
        return
    fi
    
    echo
    
    # Освобождаем IP-привязку ключа (до удаления .env)
    _release_license_ip &
    show_spinner "Освобождение лицензии"

    # Удаляем контейнеры и данные
    {
        cd "$PROJECT_DIR" || return
        docker compose down -v >/dev/null 2>&1 || true
        
        # Удаляем все локальные данные
        rm -rf "$PROJECT_DIR/db_data" 2>/dev/null || true
        rm -rf "$PROJECT_DIR/redis_data" 2>/dev/null || true
        rm -rf "$PROJECT_DIR/.env" 2>/dev/null || true
    } &
    show_spinner "Удаление данных и контейнеров"
    
    echo
    
    # Запускаем переустановку
    if confirm_action "Начать переустановку?"; then
        # Восстанавливаем нормальные настройки терминала
        stty sane 2>/dev/null || true
        tput cnorm 2>/dev/null || true
        
        # Запускаем скрипт установки
        restart_script --install
    else
        echo -e "${YELLOW}Переустановка отменена${NC}"
        echo
        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
        read -p ""
        tput civis 2>/dev/null || true
    fi
}

# Функция выключения бота
manage_stop_bot() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}      ⬇️  ВЫКЛЮЧЕНИЕ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${YELLOW}Бот будет выключен...${NC}"
    echo
    
    {
        cd "$PROJECT_DIR" || return
        docker compose down >/dev/null 2>&1
    } &
    show_spinner "Выключение бота"
    
    echo
    echo -e "${GREEN}✅ Бот успешно выключен${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    tput civis 2>/dev/null || true
    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
    read -p ""
}

# Функция включения бота
manage_start_bot() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}      ⬆️  ВКЛЮЧЕНИЕ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${YELLOW}Бот будет включен...${NC}"
    echo
    
    {
        cd "$PROJECT_DIR" || return
        docker compose up -d >/dev/null 2>&1
    } &
    show_spinner "Включение бота"
    
    echo
    echo -e "${GREEN}✅ Бот успешно включен${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    tput civis 2>/dev/null || true
    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
    read -p ""
}

# Функция просмотра логов
manage_view_logs() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       📋 ПРОСМОТР ЛОГОВ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${DARKGRAY}Последние 50 строк логов...${NC}"
    echo -e "${DARKGRAY}(Нажмите Enter для продолжения)${NC}"
    echo
    
    cd "$PROJECT_DIR" || return
    docker compose logs remnasale 2>&1 | tail -50
    
    echo
    tput civis 2>/dev/null || true
    echo -e "${DARKGRAY}Нажмите Enter для возврата в меню${NC}"
    read -p ""
}

# Функция просмотра логов в реальном времени
manage_view_logs_live() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}     📊 ЛОГИ В РЕАЛЬНОМ ВРЕМЕНИ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${DARKGRAY}Запуск просмотра логов...${NC}"
    echo -e "${DARKGRAY}(Для выхода нажмите Ctrl+C)${NC}"
    echo
    
    # Восстанавливаем нормальные настройки терминала
    stty sane 2>/dev/null || true
    tput cnorm 2>/dev/null || true
    
    cd "$PROJECT_DIR" || return
    
    # Перехватываем Ctrl+C чтобы не завершать весь скрипт
    trap '' INT
    docker compose logs -f remnasale
    trap handle_interrupt INT
    
    # После выхода возвращаемся в raw mode
    tput civis 2>/dev/null || true
    echo
    echo -e "${DARKGRAY}Отображение логов остановлено${NC}"
    echo
    echo -e "${DARKGRAY}Нажмите Enter для возврата в меню${NC}"
    read -p ""
}

# Функция изменения настроек
manage_change_settings() {
    while true; do
        show_arrow_menu "⚙️  ИЗМЕНЕНИЕ НАСТРОЕК" \
            "🌐 Изменить домен бота" \
            "🌐 Изменить домен веб-сайта" \
            "🤖 Изменить Токен телеграм бота" \
            "👤 Изменить Телеграм ID разработчика" \
            "💬 Изменить бот поддержки" \
            "🔑 Изменить API Токен Remnawave" \
            "──────────────────────────────────────" \
            "⬅️  Назад"
        local choice=$?
        
        case $choice in
            7|255)  # Назад / Esc
                return
                ;;
            0)  # Изменить домен бота
                while true; do
                    clear
                    tput civis 2>/dev/null || true
                    
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${GREEN}       🌐 ИЗМЕНИТЬ ДОМЕН${NC}"
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Введите новые данные или нажмите Esc для отмены${NC}"
                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    echo "Текущее значение: $(grep "^APP_DOMAIN=" "$ENV_FILE" | cut -d'=' -f2)"
                    
                    # Используем read с опцией -p для защиты промпта от удаления
                    tput cnorm 2>/dev/null || true
                    read -e -p $'\e[33mВведите новый домен:\e[0m ' new_domain
                    
                    tput civis 2>/dev/null || true
                    echo
                    
                    if [ -z "$new_domain" ]; then
                        echo -e "${YELLOW}ℹ️  Отменено${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    fi

                    # Проверяем привязку домена к IP сервера
                    if ! check_domain "$new_domain"; then
                        echo
                        echo -e "${DARKGRAY}Нажмите Enter чтобы ввести другой домен, или Esc для отмены.${NC}"
                        local key
                        while true; do
                            read -s -n 1 key
                            if [[ "$key" == $'\x1b' ]]; then
                                break 2
                            elif [[ "$key" == "" ]]; then
                                continue 2
                            fi
                        done
                    fi

                    # Проверяем, не занят ли домен другим сервисом
                    local domain_in_use=false
                    local new_domain_escaped_check
                    new_domain_escaped_check=$(printf '%s' "$new_domain" | sed 's/[.[\/\*^$]/\\&/g')
                    local _nginx_cf
                    _nginx_cf=""
                    [ -f "/opt/nginx/nginx.conf" ] && _nginx_cf="/opt/nginx/nginx.conf"
                    [ -z "$_nginx_cf" ] && [ -f "/opt/remnawave/nginx.conf" ] && _nginx_cf="/opt/remnawave/nginx.conf"
                    if [ -n "$_nginx_cf" ]; then
                        local old_current
                        old_current=$(grep "^APP_DOMAIN=" "$ENV_FILE" | cut -d'=' -f2)
                        # Проверяем есть ли server_name с таким доменом, не принадлежащий боту
                        if grep -q "server_name ${new_domain_escaped_check};" "$_nginx_cf" 2>/dev/null; then
                            domain_in_use=true
                        fi
                    fi
                    if [ -f "/opt/remnawave/caddy/Caddyfile" ] && grep -q "https://${new_domain_escaped_check}" /opt/remnawave/caddy/Caddyfile 2>/dev/null; then
                        domain_in_use=true
                    fi
                    if [ "$domain_in_use" = true ]; then
                        echo -e "${RED}✖ Домен ${YELLOW}$new_domain${RED} уже используется другим сервисом на этом сервере${NC}"
                        echo -e "${RED}⚠️  Укажите другой домен, который не занят.${NC}"
                        echo
                        echo -e "${DARKGRAY}Нажмите Enter чтобы ввести другой домен, или Esc для отмены.${NC}"
                        local key
                        while true; do
                            read -s -n 1 key
                            if [[ "$key" == $'\x1b' ]]; then
                                break 2
                            elif [[ "$key" == "" ]]; then
                                continue 2
                            fi
                        done
                    fi

                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    {
                        old_domain=$(grep "^APP_DOMAIN=" "$ENV_FILE" | cut -d'=' -f2)
                        update_env_var "$ENV_FILE" "APP_DOMAIN" "$new_domain" >/dev/null 2>&1
                        update_env_var "$ENV_FILE" "BOT_MINI_APP" "https://${new_domain}/web/miniapp" >/dev/null 2>&1
                        
                        # Обновляем Caddyfile в /opt/remnawave/caddy/
                        if [ -f "/opt/remnawave/caddy/Caddyfile" ]; then
                            old_domain_escaped=$(printf '%s\n' "$old_domain" | sed -e 's/[\.]/\\&/g')
                            new_domain_escaped=$(printf '%s\n' "$new_domain" | sed -e 's/[\/&]/\\&/g')
                            sed -i "s/https:\/\/$old_domain_escaped/https:\/\/$new_domain_escaped/g" /opt/remnawave/caddy/Caddyfile 2>/dev/null || true
                            # Перезапускаем Caddy
                            cd /opt/remnawave && docker compose restart caddy >/dev/null 2>&1 || true
                        fi
                        
                        # Обновляем nginx.conf: заменяем server_name и пути к сертификатам
                        local _nc=""
                        local _nd=""
                        [ -f "/opt/nginx/nginx.conf" ] && _nc="/opt/nginx/nginx.conf" && _nd="/opt/nginx"
                        [ -z "$_nc" ] && [ -f "/opt/remnawave/nginx.conf" ] && _nc="/opt/remnawave/nginx.conf" && _nd="/opt/remnawave"
                        if [ -n "$_nc" ]; then
                            old_domain_escaped=$(printf '%s\n' "$old_domain" | sed -e 's/[.[\/\*^$]/\\&/g')
                            new_domain_escaped=$(printf '%s\n' "$new_domain" | sed -e 's/[.[\/\*^$]/\\&/g')
                            sed -i "s/server_name ${old_domain_escaped};/server_name ${new_domain_escaped};/g" "$_nc" 2>/dev/null || true
                            sed -i "s|/${old_domain_escaped}/|/${new_domain_escaped}/|g" "$_nc" 2>/dev/null || true

                            # Получаем SSL-сертификат если его нет
                            if [ ! -d "/etc/letsencrypt/live/$new_domain" ]; then
                                if [ -f "/etc/letsencrypt/cloudflare.ini" ]; then
                                    cert_base_domain=$(echo "$new_domain" | awk -F. '{print $(NF-1)"."$NF}')
                                    cert_base_escaped=$(printf '%s\n' "$cert_base_domain" | sed -e 's/[.[\/*^$]/\\&/g')
                                    if [ -d "/etc/letsencrypt/live/$cert_base_domain" ]; then
                                        sed -i "s|/${new_domain_escaped}/|/${cert_base_escaped}/|g" "$_nc" 2>/dev/null || true
                                    else
                                        certbot certonly --dns-cloudflare \
                                            --dns-cloudflare-credentials /etc/letsencrypt/cloudflare.ini \
                                            --dns-cloudflare-propagation-seconds 30 \
                                            -d "$cert_base_domain" -d "*.$cert_base_domain" \
                                            --email "admin@$cert_base_domain" --agree-tos --non-interactive \
                                            --key-type ecdsa >/dev/null 2>&1 || true
                                        sed -i "s|/${new_domain_escaped}/|/${cert_base_escaped}/|g" "$_nc" 2>/dev/null || true
                                    fi
                                else
                                    # Standalone certbot: останавливаем nginx, открываем порт 80
                                    (cd "$_nd" && docker compose down >/dev/null 2>&1) || true
                                    sleep 2
                                    ufw allow 80/tcp >/dev/null 2>&1 || true
                                    ufw reload >/dev/null 2>&1 || true
                                    iptables -I INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || true
                                    sleep 1
                                    certbot certonly --standalone \
                                        -d "$new_domain" \
                                        --email "admin@$new_domain" --agree-tos --non-interactive \
                                        --http-01-port 80 \
                                        --key-type ecdsa >/dev/null 2>&1 || true
                                    ufw delete allow 80/tcp >/dev/null 2>&1 || true
                                    ufw reload >/dev/null 2>&1 || true
                                    iptables -D INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || true
                                fi
                            fi

                            # Копируем сертификаты в /opt/nginx/ssl/
                            local _cd
                            _cd=$(extract_cert_domain "$new_domain" 2>/dev/null || echo "$new_domain")
                            if [ -d "/etc/letsencrypt/live/$_cd" ]; then
                                mkdir -p "/opt/nginx/ssl/$_cd"
                                cp -L "/etc/letsencrypt/live/$_cd/fullchain.pem" "/opt/nginx/ssl/$_cd/" 2>/dev/null || true
                                cp -L "/etc/letsencrypt/live/$_cd/privkey.pem" "/opt/nginx/ssl/$_cd/" 2>/dev/null || true
                            fi

                            # Удаляем сертификаты старого домена из /opt/nginx/ssl/
                            local _old_cd
                            _old_cd=$(extract_cert_domain "$old_domain" 2>/dev/null || echo "$old_domain")
                            rm -rf "/opt/nginx/ssl/${_old_cd}" 2>/dev/null || true

                            (cd "$_nd" && docker compose up -d --force-recreate >/dev/null 2>&1) || true
                        fi

                        # Обновляем WEBHOOK_URL в /opt/remnawave/.env
                        if [ -f "/opt/remnawave/.env" ]; then
                            # Caddy: прямое подключение Docker→Docker (без hairpin NAT)
                            # Nginx: подключение через HTTPS домен
                            if [ -d "/opt/remnawave/caddy" ]; then
                                sed -i "s|^WEBHOOK_URL=.*|WEBHOOK_URL=http://remnasale:5000/api/v1/remnawave|" /opt/remnawave/.env 2>/dev/null || true
                            else
                                local old_webhook_escaped
                                old_webhook_escaped=$(printf '%s\n' "$old_domain" | sed -e 's/[.[\/*^$]/\\&/g')
                                local new_webhook_escaped
                                new_webhook_escaped=$(printf '%s\n' "$new_domain" | sed -e 's/[.[\/*^$]/\\&/g')
                                sed -i "s|${old_webhook_escaped}|${new_webhook_escaped}|g" /opt/remnawave/.env 2>/dev/null || true
                            fi
                            # Пересоздаём remnawave для применения нового WEBHOOK_URL
                            cd /opt/remnawave && docker compose up -d --force-recreate remnawave >/dev/null 2>&1 || true
                        fi
                    } &
                    show_spinner "Обновление домена"
                    
                    # Очищаем webhook lock в Redis чтобы бот переустановил webhook
                    local redis_pass
                    redis_pass=$(grep "^REDIS_PASSWORD=" "$ENV_FILE" | cut -d'=' -f2)
                    if [ -n "$redis_pass" ]; then
                        cd "$PROJECT_DIR" && docker compose exec -T remnasale-redis redis-cli -a "$redis_pass" keys "*webhook_lock*" 2>/dev/null | grep -v "^Warning" | while read -r key; do
                            docker compose exec -T remnasale-redis redis-cli -a "$redis_pass" del "$key" >/dev/null 2>&1
                        done
                    fi

                    # Пересоздаём бота для применения нового домена
                    cd "$PROJECT_DIR" && docker compose up -d --force-recreate remnasale >/dev/null 2>&1
                    
                    # Ждём запуска бота
                    show_spinner_until_log "remnasale" "Digital.*Freedom.*Core" "Перезагрузка бота" 90
                    local spinner_result=$?
                    
                    echo
                    if [ $spinner_result -eq 0 ]; then
                        echo -e "${GREEN}✅ Домен обновлён${NC}"
                        echo -e "${GREEN}✅ Бот запущен${NC}"
                    elif [ $spinner_result -eq 2 ]; then
                        echo -e "${GREEN}✅ Домен обновлён${NC}"
                        echo -e "${RED}❌ Обнаружена ошибка при запуске бота. Проверьте логи.${NC}"
                    else
                        echo -e "${GREEN}✅ Домен обновлён${NC}"
                        echo -e "${YELLOW}⚠️  Бот запускается (таймаут ожидания истёк)${NC}"
                    fi
                    echo
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                    read -p ""
                    break
                done
                ;;
            1)  # Изменить домен веб-сайта
                while true; do
                    clear
                    tput civis 2>/dev/null || true
                    
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${GREEN}       🌐 ИЗМЕНИТЬ ДОМЕН ВЕБ-САЙТА${NC}"
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Введите новые данные или нажмите Esc для отмены${NC}"
                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    local current_web_domain
                    current_web_domain=$(grep "^APP_WEB_DOMAIN=" "$ENV_FILE" | cut -d'=' -f2)
                    echo "Текущее значение: ${current_web_domain:-не задан}"
                    
                    tput cnorm 2>/dev/null || true
                    read -e -p $'\e[33mВведите новый домен веб-сайта:\e[0m ' new_web_domain
                    
                    tput civis 2>/dev/null || true
                    echo
                    
                    if [ -z "$new_web_domain" ]; then
                        echo -e "${YELLOW}ℹ️  Отменено${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    fi

                    if ! check_domain "$new_web_domain"; then
                        echo
                        echo -e "${DARKGRAY}Нажмите Enter чтобы ввести другой домен, или Esc для отмены.${NC}"
                        local key
                        while true; do
                            read -s -n 1 key
                            if [[ "$key" == $'\x1b' ]]; then
                                break 2
                            elif [[ "$key" == "" ]]; then
                                continue 2
                            fi
                        done
                    fi

                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    {
                        local old_web_domain
                        old_web_domain=$(grep "^APP_WEB_DOMAIN=" "$ENV_FILE" | cut -d'=' -f2)
                        update_env_var "$ENV_FILE" "APP_WEB_DOMAIN" "$new_web_domain" >/dev/null 2>&1

                        if [ -f "/opt/remnawave/caddy/Caddyfile" ] && [ -n "$old_web_domain" ]; then
                            local owd_esc nwd_esc
                            owd_esc=$(printf '%s\n' "$old_web_domain" | sed -e 's/[\.]/\\&/g')
                            nwd_esc=$(printf '%s\n' "$new_web_domain" | sed -e 's/[\/&]/\\&/g')
                            sed -i "s/https:\/\/$owd_esc/https:\/\/$nwd_esc/g" /opt/remnawave/caddy/Caddyfile 2>/dev/null || true
                            cd /opt/remnawave && docker compose restart caddy >/dev/null 2>&1 || true
                        fi

                        if [ -n "$_nginx_cf" ] && [ -n "$old_web_domain" ]; then
                            local owd_esc nwd_esc
                            owd_esc=$(printf '%s\n' "$old_web_domain" | sed -e 's/[.[\/\*^$]/\\&/g')
                            nwd_esc=$(printf '%s\n' "$new_web_domain" | sed -e 's/[.[\/\*^$]/\\&/g')
                            sed -i "s/server_name ${owd_esc};/server_name ${nwd_esc};/g" "$_nginx_cf" 2>/dev/null || true
                            sed -i "s|/${owd_esc}/|/${nwd_esc}/|g" "$_nginx_cf" 2>/dev/null || true
                            local _nginx_d=""
                            [ -f "/opt/nginx/nginx.conf" ] && _nginx_d="/opt/nginx"
                            [ -z "$_nginx_d" ] && [ -f "/opt/remnawave/nginx.conf" ] && _nginx_d="/opt/remnawave"
                            [ -n "$_nginx_d" ] && (cd "$_nginx_d" && docker compose up -d --force-recreate >/dev/null 2>&1) || true
                        fi
                    } &
                    show_spinner "Обновление домена веб-сайта"
                    echo -e "${GREEN}✅ Домен веб-сайта обновлён${NC}"
                    echo
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                    read -p ""
                    break
                done
                ;;
            2)  # Изменить Токен телеграм бота
                while true; do
                    clear
                    tput civis 2>/dev/null || true
                    
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${GREEN}       🤖 ИЗМЕНИТЬ ТОКЕН ТЕЛЕГРАМ БОТА${NC}"
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Введите новые данные или нажмите Esc для отмены${NC}"
                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    echo "Текущее значение: (скрыто)"
                    
                    # Используем read с опцией -p для защиты промпта от удаления
                    tput cnorm 2>/dev/null || true
                    read -e -p $'\e[33mВведите новый токен:\e[0m ' new_token
                    
                    tput civis 2>/dev/null || true
                    echo
                    
                    if [ -z "$new_token" ]; then
                        echo -e "${YELLOW}ℹ️  Отменено${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    else
                        echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                        echo
                        {
                            update_env_var "$ENV_FILE" "BOT_TOKEN" "$new_token" >/dev/null 2>&1
                        } &
                        show_spinner "Обновление токена"
                        
                        {
                            cd "$PROJECT_DIR" || return
                            docker compose down >/dev/null 2>&1
                            docker compose up -d >/dev/null 2>&1
                        } &
                        show_spinner "Перезагрузка сервисов"
                        echo -e "${GREEN}✅ Токен обновлён и сервисы перезагружены${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    fi
                done
                ;;
            3)  # Изменить Телеграм ID разработчика
                while true; do
                    clear
                    tput civis 2>/dev/null || true
                    
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${GREEN}       👤 ИЗМЕНИТЬ ТЕЛЕГРАМ ID РАЗРАБОТЧИКА${NC}"
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Введите новые данные или нажмите Esc для отмены${NC}"
                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    echo "Текущее значение: $(grep "^BOT_DEV_ID=" "$ENV_FILE" | cut -d'=' -f2)"
                    
                    # Используем read с опцией -p для защиты промпта от удаления
                    tput cnorm 2>/dev/null || true
                    read -e -p $'\e[33mВведите новый ID:\e[0m ' new_dev_id
                    
                    tput civis 2>/dev/null || true
                    echo
                    
                    if [ -z "$new_dev_id" ]; then
                        echo -e "${YELLOW}ℹ️  Отменено${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    else
                        echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                        echo
                        {
                            update_env_var "$ENV_FILE" "BOT_DEV_ID" "$new_dev_id" >/dev/null 2>&1
                        } &
                        show_spinner "Обновление ID разработчика"
                        echo -e "${GREEN}✅ ID обновлён${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    fi
                done
                ;;
            4)  # Изменить бот поддержки
                while true; do
                    clear
                    tput civis 2>/dev/null || true
                    
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${GREEN}       💬 ИЗМЕНИТЬ БОТ ПОДДЕРЖКИ${NC}"
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Введите новые данные или нажмите Esc для отмены${NC}"
                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    echo "Текущее значение: $(grep "^BOT_SUPPORT_USERNAME=" "$ENV_FILE" | cut -d'=' -f2)"
                    
                    tput cnorm 2>/dev/null || true
                    read -e -p $'\e[33mВведите username бота поддержки (без @):\e[0m ' new_support
                    
                    tput civis 2>/dev/null || true
                    echo
                    
                    if [ -z "$new_support" ]; then
                        echo -e "${YELLOW}ℹ️  Отменено${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    else
                        # Убираем @ если пользователь добавил
                        new_support="${new_support#@}"
                        echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                        echo
                        {
                            update_env_var "$ENV_FILE" "BOT_SUPPORT_USERNAME" "$new_support" >/dev/null 2>&1
                        } &
                        show_spinner "Обновление бота поддержки"
                        
                        {
                            cd "$PROJECT_DIR" || return
                            docker compose up -d --force-recreate remnasale >/dev/null 2>&1
                        } &
                        show_spinner "Перезагрузка бота"
                        echo -e "${GREEN}✅ Бот поддержки обновлён${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    fi
                done
                ;;
            5)  # Изменить API Токен Remnawave
                while true; do
                    clear
                    tput civis 2>/dev/null || true
                    
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${GREEN}       🔑 ИЗМЕНИТЬ API ТОКЕН REMNAWAVE${NC}"
                    echo -e "${BLUE}══════════════════════════════════════${NC}"
                    echo -e "${DARKGRAY}Введите новые данные или нажмите Esc для отмены${NC}"
                    echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                    echo
                    echo "Текущее значение: (скрыто)"
                    
                    tput cnorm 2>/dev/null || true
                    read -e -p $'\e[33mВведите новый API Токен Remnawave:\e[0m ' new_remna_token
                    
                    tput civis 2>/dev/null || true
                    echo
                    
                    if [ -z "$new_remna_token" ]; then
                        echo -e "${YELLOW}ℹ️  Отменено${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    else
                        echo -e "${DARKGRAY}──────────────────────────────────────${NC}"
                        echo
                        {
                            update_env_var "$ENV_FILE" "REMNAWAVE_TOKEN" "$new_remna_token" >/dev/null 2>&1
                        } &
                        show_spinner "Обновление API токена"
                        
                        {
                            cd "$PROJECT_DIR" || return
                            docker compose up -d --force-recreate remnasale >/dev/null 2>&1
                        } &
                        show_spinner "Перезагрузка бота"
                        echo -e "${GREEN}✅ API Токен Remnawave обновлён${NC}"
                        echo
                        echo -e "${BLUE}══════════════════════════════════════${NC}"
                        echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                        read -p ""
                        break
                    fi
                done
                ;;
        esac
    done
}

# Функция очистки базы данных
manage_cleanup_database() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       🧹 ОЧИСТКА БАЗЫ ДАННЫХ${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${RED}⚠️  Внимание!${NC} Это удалит всех пользователей и данные!"
    echo
    
    if ! confirm_action; then
        return
    fi
    
    echo
    
    # PostgreSQL
    {
        if command -v psql &> /dev/null; then
            psql -h 127.0.0.1 -U "$(grep "^DB_USER=" "$ENV_FILE" | cut -d= -f2 | tr -d '\"')" \
                -d "$(grep "^DB_NAME=" "$ENV_FILE" | cut -d= -f2 | tr -d '\"')" \
                -c "DELETE FROM users;" >/dev/null 2>&1 || true
        fi
    } &
    show_spinner "Очистка базы данных"
    
    # Redis
    {
        if command -v redis-cli &> /dev/null; then
            redis-cli FLUSHALL >/dev/null 2>&1 || true
        fi
    } &
    show_spinner "Очистка кэша"
    
    echo
    echo -e "${GREEN}✅ Данные успешно очищены${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
    read -p ""
}

# Функция удаления бота
manage_uninstall_bot() {
    cd /opt || true
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       🗑️  УДАЛЕНИЕ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${RED}⚠️  Внимание!${NC} Это удалит бота и все его данные!"
    echo
    
    if ! confirm_action; then
        return
    fi
    
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       🗑️  УДАЛЕНИЕ REMNASALE${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    
    # Подготовка к удалению (очистка реверс-прокси)
    {
        remove_from_caddy >/dev/null 2>&1 || true
        remove_from_nginx >/dev/null 2>&1 || true
    } &
    show_spinner "Подготовка к удалению"
    
    # Освобождаем IP-привязку ключа (до удаления .env)
    _release_license_ip &
    show_spinner "Освобождение лицензии"

    # Сначала останавливаем только контейнер бота — Redis при этом ещё работает,
    # что даёт боту возможность отправить уведомление "Бот остановлен" DEV пользователям
    {
        docker stop remnasale --time 30 >/dev/null 2>&1 || true
    } &
    show_spinner "Остановка бота"

    # Остановка остальных контейнеров и удаление
    {
        cd /opt
        if [ -d "$PROJECT_DIR" ]; then
            cd "$PROJECT_DIR" && docker compose down >/dev/null 2>&1 || true
            cd /opt
        fi
        rm -rf "$PROJECT_DIR"
    } &
    show_spinner "Удаление бота и контейнеров"
    
    # Удаляем проверку лицензии
    _remove_license_checker

    # Удаляем глобальную команду
    {
        sudo rm -f /usr/local/bin/remnasale 2>/dev/null || true
        sudo rm -rf /usr/local/lib/remnasale 2>/dev/null || true
    } &
    show_spinner "Удаление ярлыка команды"
    
    echo
    echo -e "${GREEN}✅ Бот был успешно удален!${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    printf "\033[?25l${DARKGRAY}${BLUE}Enter${DARKGRAY}: Продолжить${NC}"
    while true; do
        read -rs -n1 _k 2>/dev/null
        [[ "$_k" == "" ]] && break
    done
    printf "\033[?25h"
    echo
    clear
    exit 0
}

# Функция очистки при ошибке или отмене
cleanup_on_error() {
    local exit_code=$?

    # Восстанавливаем терминал в первую очередь
    [ -n "${_ORIG_STTY:-}" ] && stty "$_ORIG_STTY" 2>/dev/null || stty sane 2>/dev/null || true
    tput cnorm >/dev/null 2>&1 || true
    tput sgr0 >/dev/null 2>&1 || true

    # Освобождаем IP-привязку только если шла реальная установка (не менеджмент меню)
    if [ "$INSTALL_STARTED" = "true" ] && [ "$INSTALL_COMPLETED" != "true" ] && [ -n "${REMNASALE_LICENSE_KEY:-}" ]; then
        _release_license_ip 2>/dev/null || true
    fi

    # Очистка выполняется ТОЛЬКО если установка была начата (--install) и не завершена
    if [ "$INSTALL_STARTED" = "true" ] && [ "$INSTALL_COMPLETED" != "true" ]; then
        # Очищаем экран
        clear
        
        # Проверяем был ли это Ctrl+C (exit code 130)
        if [ $exit_code -eq 130 ]; then
            # Пользователь прервал скрипт
            echo -e "${BLUE}══════════════════════════════════════${NC}"
            echo -e "${YELLOW}  ⚠️  УСТАНОВКА ПРЕРВАНА ПОЛЬЗОВАТЕЛЕМ${NC}"
            echo -e "${BLUE}══════════════════════════════════════${NC}"
        else
            # Ошибка установки
            echo -e "${RED}══════════════════════════════════════${NC}"
            echo -e "${RED}  ⚠️  ОШИБКА УСТАНОВКИ ПРИЛОЖЕНИЯ${NC}"
            echo -e "${RED}══════════════════════════════════════${NC}"
        fi
        echo
        
        # Удаляем исходную папку с клоном репозитория
        if [ -n "$SOURCE_DIR" ] && [ "$SOURCE_DIR" != "/opt/remnasale" ] && [ "$SOURCE_DIR" != "/" ] && [ -d "$SOURCE_DIR" ]; then
            rm -rf "$SOURCE_DIR" 2>/dev/null || true
        fi

        # Останавливаем контейнеры если они запущены
        if command -v docker &> /dev/null && [ -d "$PROJECT_DIR" ]; then
            cd "$PROJECT_DIR" 2>/dev/null && docker compose down >/dev/null 2>&1 || true
        fi

        # Удаляем системный чекер лицензии
        _remove_license_checker 2>/dev/null || true
        
        # Удаляем папку /opt/remnasale при ошибке установки
        if [ -d "$PROJECT_DIR" ]; then
            rm -rf "$PROJECT_DIR" 2>/dev/null || true
        fi
        
        echo -e "${GREEN}✅ Очистка временных файлов приложения${NC}"
        echo
        
        # Показываем совет только если это не было прерыванием пользователем
        if [ $exit_code -ne 130 ]; then
            echo -e "${WHITE}Попробуйте запустить установку снова${NC}"
            echo
        fi
    fi
    
    # Удаляем временную папку клонирования если она была создана
    if [ -n "$CLONE_DIR" ] && [ -d "$CLONE_DIR" ]; then
        cd /opt 2>/dev/null || true
        rm -rf "$CLONE_DIR" 2>/dev/null || true
    fi
    
    # Удаляем временную папку TEMP_REPO если она была создана
    if [ -n "$TEMP_REPO" ] && [ -d "$TEMP_REPO" ]; then
        rm -rf "$TEMP_REPO" 2>/dev/null || true
    fi
    
    # Удаляем временную папку TEMP_CHECK_DIR если она была создана
    if [ -n "$TEMP_CHECK_DIR" ] && [ -d "$TEMP_CHECK_DIR" ]; then
        rm -rf "$TEMP_CHECK_DIR" 2>/dev/null || true
    fi
    
    exit $exit_code
}

# Установка trap для обработки ошибок, прерываний и выхода
trap cleanup_on_error EXIT
trap handle_interrupt INT TERM

# Автоматически даем права на выполнение самому себе
chmod +x "$0" 2>/dev/null || true

# Скрыть курсор
tput civis >/dev/null 2>&1 || true

# Режим установки: dev или prod
INSTALL_MODE="dev"

# Если это первый запуск (скрипт запущен из системы, не из временной папки)
if [ "$1" != "--install" ]; then

    # Проверяем режим если скрипт вызван без аргументов --install
    if [ "$1" != "--prod" ] && [ "$1" != "-p" ]; then
        check_mode "$1"
        exit $?
    fi
    
    if [ "$1" = "--prod" ] || [ "$1" = "-p" ]; then
        INSTALL_MODE="prod"
    fi
    
    # Проверяем что это не dev окружение (не должна быть .git папка в текущей директории)
    # Если это dev окружение - принудительно скачиваем в temp
    CURRENT_DIR="$(cd "$(dirname "$0")" && pwd)"
    if [ -d "$CURRENT_DIR/.git" ] && [ "$CURRENT_DIR" != "/opt/remnasale" ]; then
        # Создаем временную папку и скачиваем архив
        CLONE_DIR=$(mktemp -d)
        trap "cd /opt 2>/dev/null || true; rm -rf '$CLONE_DIR' 2>/dev/null || true" EXIT

        if ! _download_archive "" "$CLONE_DIR" >/dev/null 2>&1; then
            echo "❌ Ошибка при скачивании файлов с GitHub"
            exit 1
        fi
        
        chmod +x "$CLONE_DIR/remnasale-install.sh"
        cd "$CLONE_DIR"
        exec "$CLONE_DIR/remnasale-install.sh" --install "$CLONE_DIR" "$INSTALL_MODE"
    fi
    
    # Создаем временную папку и скачиваем архив
    CLONE_DIR=$(mktemp -d)
    trap "cd /opt 2>/dev/null || true; rm -rf '$CLONE_DIR' 2>/dev/null || true" EXIT

    if ! _download_archive "" "$CLONE_DIR" >/dev/null 2>&1; then
        echo -e "${RED}❌ Ошибка при скачивании файлов с GitHub${NC}"
        exit 1
    fi

    if [ -f "$CLONE_DIR/remnasale-install.sh" ]; then
        cd "$CLONE_DIR"
        exec "$CLONE_DIR/remnasale-install.sh" --install "$CLONE_DIR" "$INSTALL_MODE"
    else
        echo -e "${RED}❌ Не удалось скачать файлы с GitHub${NC}"
        exit 1
    fi
else
    # Это повторный запуск из временной папки
    CLONE_DIR="$2"
    INSTALL_MODE="$3"
    if [ "$INSTALL_MODE" = "prod" ] || [ "$INSTALL_MODE" = "-p" ]; then
        INSTALL_MODE="prod"
    fi
fi

# Проверяем режим если скрипт вызван без аргументов --install
if [ "$1" != "--install" ] && [ "$1" != "--prod" ] && [ "$1" != "-p" ]; then
    check_mode "$1"
    exit $?
fi

if [ "$1" = "--prod" ] || [ "$1" = "-p" ]; then
    INSTALL_MODE="prod"
fi

# Очистка старых временных директорий (старше 1 часа)
find /tmp -maxdepth 1 -type d -name "tmp.*" -mmin +60 -exec rm -rf {} \; 2>/dev/null || true
# Очистка старых директорий сборки Docker
rm -rf /tmp/remnasale-build 2>/dev/null || true

# ═══════════════════════════════════════════════
# ФУНКЦИИ УСТАНОВКИ
# ═══════════════════════════════════════════════

generate_token() {
    openssl rand -hex 64 | tr -d '\n'
}

generate_password() {
    openssl rand -hex 32 | tr -d '\n'
}

generate_key() {
    openssl rand -base64 32 | tr -d '\n'
}

remove_from_caddy() {
    local caddy_dir="/opt/remnawave/caddy"
    local caddy_file="${caddy_dir}/Caddyfile"

    # Если Caddy нет — выходим
    [ -d "$caddy_dir" ] || return 0
    [ -f "$caddy_file" ] || return 0

    # Удаляем все блоки которые проксируют на remnasale:5000
    # (покрывает APP_DOMAIN и APP_WEB_DOMAIN без необходимости читать .env)
    awk '
        /^[[:space:]]*https?:\/\// { block=1; buf=$0 "\n"; next }
        block && /^[[:space:]]*\}/ {
            buf = buf $0 "\n"
            if (buf !~ /remnasale:5000/) printf "%s", buf
            block=0; buf=""; next
        }
        block { buf = buf $0 "\n"; next }
        !block { print }
    ' "$caddy_file" > "${caddy_file}.tmp" && mv "${caddy_file}.tmp" "$caddy_file"

    # Удаляем лишние пустые строки
    sed -i '/^$/N;/^\n$/d' "$caddy_file" 2>/dev/null || true

    # Перезапускаем Caddy (без затрагивания остальных сервисов)
    cd "$caddy_dir"
    docker compose restart caddy >/dev/null 2>&1 || true
}

configure_caddy() {
    local app_domain="$1"
    local caddy_dir="/opt/remnawave/caddy"
    local caddy_file="${caddy_dir}/Caddyfile"

    # Нет Caddy — тихо выходим
    [ -d "$caddy_dir" ] || return 0
    [ -f "$caddy_file" ] || return 0

    if grep -q -E "https://${app_domain}\s*\{" "$caddy_file"; then
        # Блок с доменом уже есть — гарантируем что upstream указывает на remnasale:5000
        # (может быть устаревшим от предыдущей версии бота с другим именем)
        sed -i -E "/https:\/\/${app_domain}[[:space:]]*\{/,/\}/ s|reverse_proxy \* http://[^:]+:5000|reverse_proxy * http://remnasale:5000|" "$caddy_file"
    else
        cat >> "$caddy_file" <<EOF

https://${app_domain} {
    reverse_proxy * http://remnasale:5000
}
EOF
    fi

    # Перезапуск Caddy (без затрагивания остальных сервисов)
    cd "$caddy_dir"
    docker compose restart caddy >/dev/null 2>&1 || true
}

remove_from_nginx() {
    # Автоопределение пути nginx.conf
    local nginx_conf=""
    local nginx_dir=""
    if [ -f "/opt/nginx/nginx.conf" ]; then
        nginx_conf="/opt/nginx/nginx.conf"
        nginx_dir="/opt/nginx"
    elif [ -f "/opt/remnawave/nginx.conf" ]; then
        nginx_conf="/opt/remnawave/nginx.conf"
        nginx_dir="/opt/remnawave"
    else
        return 0
    fi

    # Если есть маркеры REMNASALE_BLOCK — удаляем по ним
    if grep -q '# BEGIN_REMNASALE_BLOCK' "$nginx_conf" 2>/dev/null; then
        sed -i '/^# BEGIN_REMNASALE_BLOCK$/,/^# END_REMNASALE_BLOCK$/d' "$nginx_conf" 2>/dev/null || true
    else
        # Fallback: удаляем server-блоки, проксирующие на remnasale (старый формат)
        awk '
            /^server \{/ { block = 1; buf = $0 "\n"; next }
            block && /^\}/ {
                buf = buf $0 "\n"
                if (buf ~ /proxy_pass http:\/\/remnasale/) {
                    block = 0; buf = ""; next
                }
                printf "%s", buf
                block = 0; buf = ""
                next
            }
            block { buf = buf $0 "\n"; next }
            !block { print }
        ' "$nginx_conf" > "${nginx_conf}.tmp" && mv "${nginx_conf}.tmp" "$nginx_conf"

        # Удаляем upstream remnasale блок
        sed -i '/^upstream remnasale {$/,/^}$/d' "$nginx_conf" 2>/dev/null || true
    fi

    # Удаляем лишние пустые строки
    sed -i '/^$/N;/^\n$/d' "$nginx_conf" 2>/dev/null || true

    # Удаляем SSL-файлы
    rm -rf "/opt/nginx/ssl/${APP_DOMAIN:-}" 2>/dev/null || true

    # Удаляем маппинг порта 5000 из docker-compose.yml бота
    if [ -f "$PROJECT_DIR/docker-compose.yml" ]; then
        sed -i "/^      - '127.0.0.1:5000:5000'$/d" "$PROJECT_DIR/docker-compose.yml" 2>/dev/null || true
    fi

    # Сбрасываем WEBHOOK_ENABLED=false в .env бота
    if [ -f "$ENV_FILE" ]; then
        sed -i 's/^WEBHOOK_ENABLED=true$/WEBHOOK_ENABLED=false/' "$ENV_FILE" 2>/dev/null || true
    fi

    # Перезапускаем nginx
    (cd "$nginx_dir" && docker compose up -d --force-recreate >/dev/null 2>&1) || true
}

configure_nginx() {
    local app_domain="$1"

    # Автоопределение пути nginx.conf
    local nginx_conf=""
    local nginx_dir=""
    if [ -f "/opt/nginx/nginx.conf" ]; then
        nginx_conf="/opt/nginx/nginx.conf"
        nginx_dir="/opt/nginx"
    elif [ -f "/opt/remnawave/nginx.conf" ]; then
        nginx_conf="/opt/remnawave/nginx.conf"
        nginx_dir="/opt/remnawave"
    else
        return 0
    fi

    # Определяем домен сертификата (может быть wildcard от базового домена)
    local cert_domain
    cert_domain=$(extract_cert_domain "$app_domain")

    # ── Определяем тип конфигурации nginx ──
    local listen_type="direct"
    if grep -q 'listen unix:/dev/shm/nginx.sock' "$nginx_conf" 2>/dev/null; then
        listen_type="unix_socket"
    fi

    # Определяем путь сертификатов из существующих блоков
    local cert_path_prefix="/etc/nginx/ssl"
    local existing_cert_path
    existing_cert_path=$(grep -m1 'ssl_certificate[^_]' "$nginx_conf" 2>/dev/null | sed 's/.*ssl_certificate[^_]* *"*//;s|/fullchain\.pem.*||;s|/cert\.pem.*||;s/"//g')
    if [ -n "$existing_cert_path" ]; then
        cert_path_prefix=$(echo "$existing_cert_path" | sed 's|/[^/]*$||')
    fi

    # ── Получаем SSL-сертификат если его нет ──
    if [ ! -d "/etc/letsencrypt/live/$cert_domain" ]; then
        if [ -f "/etc/letsencrypt/cloudflare.ini" ]; then
            local base_domain
            base_domain=$(echo "$app_domain" | awk -F. '{print $(NF-1)"."$NF}')
            if [ ! -d "/etc/letsencrypt/live/$base_domain" ]; then
                (
                    certbot certonly --dns-cloudflare \
                        --dns-cloudflare-credentials /etc/letsencrypt/cloudflare.ini \
                        --dns-cloudflare-propagation-seconds 30 \
                        -d "$base_domain" -d "*.$base_domain" \
                        --email "admin@$base_domain" --agree-tos --non-interactive \
                        --key-type ecdsa >/dev/null 2>&1
                ) &
                show_spinner "Получение wildcard сертификата для *.$base_domain"
                cert_domain="$base_domain"
            else
                cert_domain="$base_domain"
            fi
        else
            # ACME HTTP-01: standalone certbot
            # Останавливаем nginx чтобы освободить порт 80
            (cd "$nginx_dir" && docker compose down >/dev/null 2>&1) || true
            sleep 2

            ufw allow 80/tcp >/dev/null 2>&1 || true
            ufw reload >/dev/null 2>&1 || true
            iptables -I INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || true
            sleep 1

            (
                certbot certonly --standalone \
                    -d "$app_domain" \
                    --email "admin@$app_domain" --agree-tos --non-interactive \
                    --http-01-port 80 \
                    --key-type ecdsa >/dev/null 2>&1
            ) &
            show_spinner "Получение сертификата для $app_domain"
            cert_domain="$app_domain"

            ufw delete allow 80/tcp >/dev/null 2>&1 || true
            ufw reload >/dev/null 2>&1 || true
            iptables -D INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || true
        fi
    fi

    # ── Копируем сертификаты в /opt/nginx/ssl/ ──
    if [ -d "/etc/letsencrypt/live/$cert_domain" ]; then
        mkdir -p "/opt/nginx/ssl/${cert_domain}"
        cp -L "/etc/letsencrypt/live/${cert_domain}/fullchain.pem" "/opt/nginx/ssl/${cert_domain}/" 2>/dev/null || true
        cp -L "/etc/letsencrypt/live/${cert_domain}/privkey.pem" "/opt/nginx/ssl/${cert_domain}/" 2>/dev/null || true
    fi

    # ── Если REMNASALE_BLOCK уже есть — добавляем домен внутрь, иначе создаём ──
    if grep -q '# BEGIN_REMNASALE_BLOCK' "$nginx_conf" 2>/dev/null; then
        # Домен уже в блоке — ничего не делаем (идемпотентность)
        if grep -q "server_name ${app_domain};" "$nginx_conf" 2>/dev/null; then
            return 0
        fi
        # Формируем listen-директивы для нового server{} блока
        local listen_ssl real_ip_header
        if [ "$listen_type" = "unix_socket" ]; then
            listen_ssl="    listen unix:/dev/shm/nginx.sock ssl proxy_protocol;\n    listen 443 ssl;\n    http2 on;"
            real_ip_header="\$proxy_protocol_addr"
        else
            listen_ssl="    listen 443 ssl;\n    listen [::]:443 ssl;\n    http2 on;"
            real_ip_header="\$remote_addr"
        fi
        # Вставляем server{} перед маркером END через awk (надёжная многострочная вставка)
        local _srv_block _srv_tmp
        _srv_block="server {
    server_name ${app_domain};
$(echo -e "$listen_ssl")

    ssl_certificate     \"${cert_path_prefix}/${cert_domain}/fullchain.pem\";
    ssl_certificate_key \"${cert_path_prefix}/${cert_domain}/privkey.pem\";
    ssl_trusted_certificate \"${cert_path_prefix}/${cert_domain}/fullchain.pem\";

    access_log /dev/stdout combined if=\$loggable;

    location / {
        proxy_http_version 1.1;
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$connection_upgrade;
        proxy_set_header X-Real-IP ${real_ip_header};
        proxy_set_header X-Forwarded-For ${real_ip_header};
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Port \$server_port;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}"
        _srv_tmp=$(mktemp)
        printf '%s\n' "$_srv_block" > "$_srv_tmp"
        awk -v sf="$_srv_tmp" '
            /^# END_REMNASALE_BLOCK$/ {
                print ""
                while ((getline line < sf) > 0) print line
                close(sf)
                print ""
            }
            { print }
        ' "$nginx_conf" > "${nginx_conf}.tmp" && mv "${nginx_conf}.tmp" "$nginx_conf"
        rm -f "$_srv_tmp"
        rm -f "${nginx_dir}/nginx.conf.bak" 2>/dev/null || true
        # Перезапускаем nginx
        (
            cd "$nginx_dir"
            docker compose up -d --force-recreate >/dev/null 2>&1 || true
        ) &
        if [ "${_NGINX_RESTARTED:-}" != "1" ]; then
            _NGINX_RESTARTED=1
            show_spinner "Перезапуск Nginx"
        else
            wait
        fi
        return 0
    fi

    # Формируем listen-директивы
    local listen_ssl real_ip_header
    if [ "$listen_type" = "unix_socket" ]; then
        listen_ssl="    listen unix:/dev/shm/nginx.sock ssl proxy_protocol;\n    listen 443 ssl;\n    http2 on;"
        real_ip_header="\$proxy_protocol_addr"
    else
        listen_ssl="    listen 443 ssl;\n    listen [::]:443 ssl;\n    http2 on;"
        real_ip_header="\$remote_addr"
    fi

    # Собираем полный блок
    local block="# BEGIN_REMNASALE_BLOCK
server {
    server_name ${app_domain};
$(echo -e "$listen_ssl")

    ssl_certificate     \"${cert_path_prefix}/${cert_domain}/fullchain.pem\";
    ssl_certificate_key \"${cert_path_prefix}/${cert_domain}/privkey.pem\";
    ssl_trusted_certificate \"${cert_path_prefix}/${cert_domain}/fullchain.pem\";

    access_log /dev/stdout combined if=\$loggable;

    location / {
        proxy_http_version 1.1;
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection \$connection_upgrade;
        proxy_set_header X-Real-IP ${real_ip_header};
        proxy_set_header X-Forwarded-For ${real_ip_header};
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Port \$server_port;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
# END_REMNASALE_BLOCK"

    # Вставляем перед закрывающей скобкой http {}
    local end_line
    end_line=$(grep -n '} # .* end http' "$nginx_conf" 2>/dev/null | tail -1 | cut -d: -f1)
    if [ -n "$end_line" ]; then
        # Экранируем блок для sed
        local block_escaped
        block_escaped=$(echo -e "$block" | sed 's/[&/\]/\\&/g; s/$/\\/' | sed '$ s/\\$//')
        sed -i "${end_line}i\\${block_escaped}" "$nginx_conf" 2>/dev/null || true
    fi

    # ── Добавляем порт 5000 в docker-compose бота (для nginx host mode) ──
    if [ -f "$PROJECT_DIR/docker-compose.yml" ]; then
        if ! grep -q "127.0.0.1:5000:5000" "$PROJECT_DIR/docker-compose.yml"; then
            if grep -q 'ports:' "$PROJECT_DIR/docker-compose.yml" 2>/dev/null && \
               grep -A1 'ports:' "$PROJECT_DIR/docker-compose.yml" | grep -q '5000'; then
                : # Порт уже есть
            else
                sed -i '/^    hostname: remnasale$/a\    ports:\n      - '\''127.0.0.1:5000:5000'\''' "$PROJECT_DIR/docker-compose.yml" 2>/dev/null || true
            fi
        fi
    fi

    # ── Перезапускаем nginx ──
    rm -f "${nginx_dir}/nginx.conf.bak" 2>/dev/null || true
    (
        cd "$nginx_dir"
        docker compose up -d --force-recreate >/dev/null 2>&1 || true
    ) &
    if [ "${_NGINX_RESTARTED:-}" != "1" ]; then
        _NGINX_RESTARTED=1
        show_spinner "Перезапуск Nginx"
    else
        wait
    fi
}

# Вспомогательная функция: определить домен сертификата
# (проверяет наличие wildcard или прямого сертификата)
extract_cert_domain() {
    local domain="$1"
    local base_domain
    base_domain=$(echo "$domain" | awk -F. '{print $(NF-1)"."$NF}')

    # Сначала проверяем прямой сертификат для конкретного домена
    if [ -d "/etc/letsencrypt/live/$domain" ]; then
        echo "$domain"
        return
    fi

    # Затем wildcard (базовый домен)
    if [ -d "/etc/letsencrypt/live/$base_domain" ]; then
        echo "$base_domain"
        return
    fi

    # По умолчанию — базовый домен (wildcard будет получен)
    echo "$base_domain"
}

# ═══════════════════════════════════════════════
# ПРОВЕРКИ ПРЕДУСЛОВИЙ
# ═══════════════════════════════════════════════

# Быстрые проверки ДО сбора данных
if ! command -v docker &> /dev/null; then
    print_error "Docker не установлен!"
    exit 1
fi
if ! command -v openssl &> /dev/null; then
    print_error "OpenSSL не установлен!"
    exit 1
fi

# REVERSE_PROXY определяется в _collect_install_data() через меню выбора

# ═══════════════════════════════════════════════
# СБОР ДАННЫХ ДЛЯ УСТАНОВКИ
# ═══════════════════════════════════════════════

# Возвращает 0 если все данные введены, 1 если пользователь нажал ESC
_collect_install_data() {
    # ── Выбор варианта установки ──
    MENU_ESC_LABEL="Выход" show_arrow_menu "   Вариант установки Remnawave" \
        "🔧  DFC Manager" \
        "🌐  Caddy (стандартный)" \
        "🌐  Nginx (стандартный)" \
        "──────────────────────────────────────" \
        "❌  Выход"
    local _rp_choice=$?
    case $_rp_choice in
        0) REVERSE_PROXY="dfc" ;;
        1) REVERSE_PROXY="caddy" ;;
        2) REVERSE_PROXY="nginx" ;;
        *) return 1 ;;
    esac

    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}       🚀 Установка Remnasale${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # APP_DOMAIN
    while true; do
        printf '\033[s'  # сохраняем позицию курсора перед промптом
        reading_inline "Введите домен бота (напр. bot.example.com):" APP_DOMAIN
        _rc=$?
        [ $_rc -eq 2 ] && return 1
        if [ -z "$APP_DOMAIN" ]; then
            print_error "Домен не может быть пустым!"
            exit 1
        fi
        if check_domain "$APP_DOMAIN"; then
            break
        fi
        echo
        echo -e "${DARKGRAY}Нажмите Enter чтобы ввести другой домен, или Esc для выхода.${NC}"
        key=""
        while true; do
            read -s -n 1 key
            if [[ "$key" == $'\x1b' ]]; then
                echo
                return 1
            elif [[ "$key" == "" ]]; then
                break
            fi
        done
        printf '\033[u\033[J'  # возвращаемся к сохранённой позиции и очищаем всё ниже
    done

    # APP_WEB_DOMAIN
    while true; do
        printf '\033[s'
        reading_inline "Введите домен веб-сайта (Enter = пропустить, настроите позже):" APP_WEB_DOMAIN
        _rc=$?
        [ $_rc -eq 2 ] && return 1
        if [ -z "$APP_WEB_DOMAIN" ]; then
            break
        fi
        if check_domain "$APP_WEB_DOMAIN"; then
            break
        fi
        echo
        echo -e "${DARKGRAY}Нажмите Enter чтобы ввести другой домен, или Esc для выхода.${NC}"
        key=""
        while true; do
            read -s -n 1 key
            if [[ "$key" == $'\x1b' ]]; then
                echo
                return 1
            elif [[ "$key" == "" ]]; then
                break
            fi
        done
        printf '\033[u\033[J'
    done

    # BOT_TOKEN
    reading_inline "Введите Токен телеграм бота:" BOT_TOKEN
    _rc=$?; [ $_rc -eq 2 ] && return 1
    if [ -z "$BOT_TOKEN" ]; then
        print_error "BOT_TOKEN не может быть пустым!"
        exit 1
    fi

    # BOT_DEV_ID
    while true; do
        reading_inline "Введите телеграм ID разработчика:" BOT_DEV_ID
        _rc=$?; [ $_rc -eq 2 ] && return 1
        if [ -z "$BOT_DEV_ID" ]; then
            print_error "BOT_DEV_ID не может быть пустым!"
            continue
        fi
        break
    done

    # REMNAWAVE_TOKEN
    reading_inline "Введите API Токен Remnawave:" REMNAWAVE_TOKEN
    _rc=$?; [ $_rc -eq 2 ] && return 1
    if [ -z "$REMNAWAVE_TOKEN" ]; then
        print_error "REMNAWAVE_TOKEN не может быть пустым!"
        exit 1
    fi

    return 0
}

# Проверяем что ключ не привязан уже к другому серверу
if [ -n "${REMNASALE_LICENSE_KEY:-}" ]; then
    _check_license_ip_not_bound "$REMNASALE_LICENSE_KEY" || {
        clear
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "${RED}       ❌ Ошибка лицензии${NC}"
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo
        echo -e "  ${RED}Этот ключ уже используется на другом сервере.${NC}"
        echo -e "  ${YELLOW}Сначала удалите бот на предыдущем сервере и сбросьте${NC}"
        echo -e "  ${YELLOW}IP-привязку ключа. Обратитесь к разработчику.${NC}"
        echo
        exit 1
    }
fi

if ! _collect_install_data; then
    show_simple_menu
    exit $?
fi

# ═══════════════════════════════════════════════
# ПРОЦЕСС УСТАНОВКИ
# ═══════════════════════════════════════════════

clear
echo -e "${BLUE}══════════════════════════════════════${NC}"
echo -e "${GREEN}       🚀 ПРОЦЕСС УСТАНОВКИ${NC}"
echo -e "${BLUE}══════════════════════════════════════${NC}"
echo

# Отмечаем, что установка началась - теперь при ошибке нужно очищать
INSTALL_STARTED=true

# Открываем порт license-сервера в ufw для проверки ключа
if command -v ufw &>/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow 9777/tcp >/dev/null 2>&1 || true
    ufw reload >/dev/null 2>&1 || true
fi

(
  # Docker log rotation: создаём daemon.json если нет
  if [ ! -f /etc/docker/daemon.json ]; then
      cat > /etc/docker/daemon.json <<'DJSON'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
DJSON
  fi
) &
show_spinner "Настройка системы"

# 2. Подготовка целевой директории
(
  # Создаем целевую директорию
  mkdir -p "$PROJECT_DIR"
  mkdir -p "$PROJECT_DIR/logs"
  mkdir -p "$PROJECT_DIR/backups"
  mkdir -p "$PROJECT_DIR/assets"
  chmod 755 "$PROJECT_DIR/logs" "$PROJECT_DIR/backups" "$PROJECT_DIR/assets"

  # Создаем сеть Docker если не существует
  if ! docker network ls | grep -q "remnawave-network"; then
      docker network create remnawave-network 2>/dev/null || true
  fi
) &
show_spinner "Подготовка целевой директории"

# 3. Определение, откуда копировать файлы
# Если скрипт запущен не из целевой директории, значит мы в клонированной папке
SCRIPT_PATH="$(realpath "$0")"
SCRIPT_DIR="$(dirname "$SCRIPT_PATH")"
SOURCE_DIR="$SCRIPT_DIR"

if [ "$SOURCE_DIR" = "/opt/remnasale" ]; then
    # Скрипт уже в целевой директории - ничего не копируем
    COPY_FILES=false
else
    # Скрипт в клонированной папке - копируем только конфигурационные файлы
    COPY_FILES=true
    # Только конфигурационные файлы - БЕЗ исходников (src, scripts останутся во временной папке)
    SOURCE_FILES=(
        "docker-compose.yml"
    )
fi

# 4. Копирование конфигурационных файлов если нужно
if [ "$COPY_FILES" = true ]; then
    (
      # Копируем только конфигурационные файлы
      for file in "${SOURCE_FILES[@]}"; do
          if [ -f "$SOURCE_DIR/$file" ]; then
              cp "$SOURCE_DIR/$file" "$PROJECT_DIR/"
          fi
      done
      
      # Копируем только assets (для кастомизации баннеров пользователем)
      if [ -d "$SOURCE_DIR/assets" ]; then
          rm -rf "$PROJECT_DIR/assets" 2>/dev/null || true
          cp -r "$SOURCE_DIR/assets" "$PROJECT_DIR/"
      fi
      
      # Копируем version в корень бота
      if [ -f "$SOURCE_DIR/version" ]; then
          cp "$SOURCE_DIR/version" "$PROJECT_DIR/version"
      fi

      # Копируем remnasale-install.sh в системную папку (не в корень бота)
      sudo mkdir -p "$SYSTEM_INSTALL_DIR"
      _src="$(realpath "$SOURCE_DIR/remnasale-install.sh" 2>/dev/null || echo "$SOURCE_DIR/remnasale-install.sh")"
      _dst="$(realpath "$SYSTEM_INSTALL_DIR/remnasale-install.sh" 2>/dev/null || echo "$SYSTEM_INSTALL_DIR/remnasale-install.sh")"
      if [ "$_src" != "$_dst" ]; then
          sudo cp "$SOURCE_DIR/remnasale-install.sh" "$SYSTEM_INSTALL_DIR/remnasale-install.sh"
      fi
      sudo chmod +x "$SYSTEM_INSTALL_DIR/remnasale-install.sh"
    )
    wait  # Ждем завершения копирования без спиннера
fi

# 5. Создание .env файла
if [ ! -f "$ENV_FILE" ]; then
    if [ ! -f "$SOURCE_DIR/.env.example" ]; then
        print_error "Файл .env.example не найден в исходной директории!"
        print_error "Возможно предыдущая установка была прервана. Запустите установку заново."
        # Очистка остатков прерванной установки
        sudo rm -rf "$SYSTEM_INSTALL_DIR" 2>/dev/null || true
        exit 1
    fi
    (
      cp "$SOURCE_DIR/.env.example" "$ENV_FILE"
    ) &
    show_spinner "Инициализация конфигурации"
else
    print_success "Конфигурация уже существует"
fi

# 6. Реверс-прокси (выбран пользователем)
if [ "$REVERSE_PROXY" = "dfc" ]; then
    echo
    print_success "Вариант установки: DFC Manager"
    echo
elif [ "$REVERSE_PROXY" = "caddy" ]; then
    echo
    print_success "Вариант установки: Caddy"
    echo
elif [ "$REVERSE_PROXY" = "nginx" ]; then
    echo
    print_success "Вариант установки: Nginx"
    echo
fi

# 7. Записываем собранные данные и генерируем ключи — всё в одном шаге
(
  update_env_var "$ENV_FILE" "APP_DOMAIN" "$APP_DOMAIN"
  update_env_var "$ENV_FILE" "BOT_MINI_APP" "https://${APP_DOMAIN}/web/miniapp"
  update_env_var "$ENV_FILE" "APP_WEB_DOMAIN" "$APP_WEB_DOMAIN"
  update_env_var "$ENV_FILE" "BOT_TOKEN" "$BOT_TOKEN"
  update_env_var "$ENV_FILE" "BOT_DEV_ID" "$BOT_DEV_ID"
  update_env_var "$ENV_FILE" "REMNAWAVE_TOKEN" "$REMNAWAVE_TOKEN"
  if [ -n "${REMNASALE_LICENSE_KEY:-}" ]; then
    update_env_var "$ENV_FILE" "LICENSE_KEY" "$REMNASALE_LICENSE_KEY"
  fi
  if [ -n "${REMNASALE_LICENSE_SERVER:-}" ]; then
    update_env_var "$ENV_FILE" "LICENSE_SERVER" "$REMNASALE_LICENSE_SERVER"
  fi

  # Автогенерация ключей безопасности
  if grep -q "^APP_CRYPT_KEY=$" "$ENV_FILE"; then
    APP_CRYPT_KEY=$(openssl rand -base64 32 | tr -d '\n')
    update_env_var "$ENV_FILE" "APP_CRYPT_KEY" "$APP_CRYPT_KEY"
  fi

  if grep -q "^BOT_SECRET_TOKEN=$" "$ENV_FILE"; then
    BOT_SECRET_TOKEN=$(openssl rand -hex 64 | tr -d '\n')
    update_env_var "$ENV_FILE" "BOT_SECRET_TOKEN" "$BOT_SECRET_TOKEN"
  fi

  # Генерация пароля БД
  if grep -q "^DATABASE_PASSWORD=" "$ENV_FILE"; then
    CURRENT_DB_PASS=$(grep "^DATABASE_PASSWORD=" "$ENV_FILE" | cut -d'=' -f2 | tr -d ' ')
    if [ -z "$CURRENT_DB_PASS" ]; then
      DATABASE_PASSWORD=$(openssl rand -hex 32 | tr -d '\n')
      update_env_var "$ENV_FILE" "DATABASE_PASSWORD" "$DATABASE_PASSWORD"
    else
      DATABASE_PASSWORD="$CURRENT_DB_PASS"
    fi
  else
    DATABASE_PASSWORD=$(openssl rand -hex 32 | tr -d '\n')
    echo "DATABASE_PASSWORD=$DATABASE_PASSWORD" >> "$ENV_FILE"
  fi

  # Синхронизируем DATABASE_USER с POSTGRES_USER
  DATABASE_USER=$(grep "^DATABASE_USER=" "$ENV_FILE" | cut -d'=' -f2 | tr -d ' ')
  if [ -n "$DATABASE_USER" ]; then
    if grep -q "^POSTGRES_USER=" "$ENV_FILE"; then
      update_env_var "$ENV_FILE" "POSTGRES_USER" "$DATABASE_USER"
    else
      echo "POSTGRES_USER=$DATABASE_USER" >> "$ENV_FILE"
    fi
  fi

  # Синхронизируем DATABASE_PASSWORD с POSTGRES_PASSWORD
  if grep -q "^POSTGRES_PASSWORD=" "$ENV_FILE"; then
    update_env_var "$ENV_FILE" "POSTGRES_PASSWORD" "$DATABASE_PASSWORD"
  else
    echo "POSTGRES_PASSWORD=$DATABASE_PASSWORD" >> "$ENV_FILE"
  fi

  # Синхронизируем DATABASE_NAME с POSTGRES_DB
  DATABASE_NAME=$(grep "^DATABASE_NAME=" "$ENV_FILE" | cut -d'=' -f2 | tr -d ' ')
  if [ -n "$DATABASE_NAME" ]; then
    if grep -q "^POSTGRES_DB=" "$ENV_FILE"; then
      update_env_var "$ENV_FILE" "POSTGRES_DB" "$DATABASE_NAME"
    else
      echo "POSTGRES_DB=$DATABASE_NAME" >> "$ENV_FILE"
    fi
  fi

  # Исправляем DATABASE_HOST и REDIS_HOST на актуальные имена контейнеров
  if grep -q "^DATABASE_HOST=" "$ENV_FILE"; then
    update_env_var "$ENV_FILE" "DATABASE_HOST" "remnasale-db"
  else
    echo "DATABASE_HOST=remnasale-db" >> "$ENV_FILE"
  fi
  if grep -q "^REDIS_HOST=" "$ENV_FILE"; then
    update_env_var "$ENV_FILE" "REDIS_HOST" "remnasale-redis"
  else
    echo "REDIS_HOST=remnasale-redis" >> "$ENV_FILE"
  fi

  # Генерация пароля Redis
  if grep -q "^REDIS_PASSWORD=$" "$ENV_FILE"; then
    CURRENT_REDIS_PASS=$(grep "^REDIS_PASSWORD=" "$ENV_FILE" | cut -d'=' -f2 | tr -d ' ')
    if [ -z "$CURRENT_REDIS_PASS" ]; then
      REDIS_PASSWORD=$(openssl rand -hex 32 | tr -d '\n')
      update_env_var "$ENV_FILE" "REDIS_PASSWORD" "$REDIS_PASSWORD"
    fi
  fi

  if grep -q "^REMNAWAVE_WEBHOOK_SECRET=" "$ENV_FILE"; then
    CURRENT_WEBHOOK_SECRET=$(grep "^REMNAWAVE_WEBHOOK_SECRET=" "$ENV_FILE" | cut -d'=' -f2 | tr -d ' ')
    if [ -z "$CURRENT_WEBHOOK_SECRET" ]; then
      REMNAWAVE_WEBHOOK_SECRET=$(openssl rand -hex 32 | tr -d '\n')
      update_env_var "$ENV_FILE" "REMNAWAVE_WEBHOOK_SECRET" "$REMNAWAVE_WEBHOOK_SECRET"
    fi
  fi
) &
show_spinner "Инициализация конфигурации"

# 2. Синхронизация webhook (в фоне со спинером)
(
  REMNAWAVE_ENV="/opt/remnawave/.env"

  if [ -f "$REMNAWAVE_ENV" ]; then
    # Включаем webhook
    if grep -q "^WEBHOOK_ENABLED=" "$REMNAWAVE_ENV"; then
      sed -i "s|^WEBHOOK_ENABLED=.*|WEBHOOK_ENABLED=true|" "$REMNAWAVE_ENV"
    else
      echo "WEBHOOK_ENABLED=true" >> "$REMNAWAVE_ENV"
    fi

    # Копируем WEBHOOK_SECRET_HEADER
    REMNAWAVE_SECRET=$(grep "^WEBHOOK_SECRET_HEADER=" "$REMNAWAVE_ENV" | cut -d'=' -f2)
    if [ -n "$REMNAWAVE_SECRET" ]; then
      update_env_var "$ENV_FILE" "REMNAWAVE_WEBHOOK_SECRET" "$REMNAWAVE_SECRET"
    fi

    # Подставляем webhook URL
    # Caddy: оба контейнера в одной Docker-сети — прямое подключение без hairpin NAT
    # Nginx: нативный на хосте — подключение через HTTPS домен
    if [ -n "$APP_DOMAIN" ]; then
      if [ "$REVERSE_PROXY" = "caddy" ]; then
        WEBHOOK_TARGET="http://remnasale:5000/api/v1/remnawave"
      else
        WEBHOOK_TARGET="https://${APP_DOMAIN}/api/v1/remnawave"
      fi
      if grep -q "^WEBHOOK_URL=" "$REMNAWAVE_ENV"; then
        sed -i "s|^WEBHOOK_URL=.*|WEBHOOK_URL=${WEBHOOK_TARGET}|" "$REMNAWAVE_ENV"
      else
        echo "WEBHOOK_URL=${WEBHOOK_TARGET}" >> "$REMNAWAVE_ENV"
      fi
    fi

    # Перезапускаем remnawave для применения новых webhook-настроек
    cd /opt/remnawave && docker compose up -d --force-recreate remnawave >/dev/null 2>&1 || true

    # Копируем DATABASE_URL из remnawave .env для выравнивания ID при бэкапах
    RW_DB_URL=$(grep "^DATABASE_URL=" "$REMNAWAVE_ENV" | cut -d'=' -f2- | tr -d '"')
    if [ -n "$RW_DB_URL" ]; then
      update_env_var "$ENV_FILE" "REMNAWAVE_DATABASE_URL" "$RW_DB_URL"
    fi
  fi
) &
show_spinner "Синхронизация с Remnawave"

# 3. Подготовка файлов: создание структуры папок + очистка старых томов + сборка Docker образа
(
  mkdir -p "$PROJECT_DIR"/{assets,backups,logs}

  # Останавливаем контейнеры и удаляем том БД для чистой инициализации
  cd "$PROJECT_DIR"
  docker compose down >/dev/null 2>&1 || true
  docker volume rm remnasale-db-data >/dev/null 2>&1 || true

  # Сохраняем старый образ как резервный (пригодится если сборка нового упадёт)
  docker tag remnasale:local remnasale:backup 2>/dev/null || true
  # Удаляем старый образ чтобы при провале сборки не запустился устаревший
  docker rmi remnasale:local >/dev/null 2>&1 || true
  rm -f /tmp/remnasale_build_status

  # Собираем Docker образ из SOURCE_DIR (временная папка с исходниками)
  if [ "$COPY_FILES" = true ] && [ -d "$SOURCE_DIR" ]; then
    cd "$SOURCE_DIR"

    # Предварительно скачиваем базовые образы из Docker Hub.
    # Если они уже в кеше — pull ничего не делает (мгновенно).
    # Финальный образ использует ghcr.io/astral-sh/uv:python3.12-alpine
    # (не Docker Hub), поэтому здесь только node:20-alpine.
    for _pull_attempt in 1 2 3; do
      docker pull node:20-alpine >/dev/null 2>&1 && break
      [ "$_pull_attempt" -lt 3 ] && sleep 10
    done

    BUILD_OK=false
    for _attempt in 1 2 3; do
      if DOCKER_BUILDKIT=1 docker build -t remnasale:local \
        --network=host \
        --build-arg BUILD_TIME="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        --build-arg BUILD_BRANCH="$REPO_BRANCH" \
        --build-arg BUILD_COMMIT="$(git rev-parse --short HEAD 2>/dev/null || echo 'unknown')" \
        --build-arg BUILD_TAG="$(grep '^version:' version 2>/dev/null | head -1 | cut -d: -f2 | tr -d ' \n' || echo 'unknown')" \
        . >/tmp/remnasale-build.log 2>&1; then
        BUILD_OK=true
        break
      fi
      [ "$_attempt" -lt 3 ] && sleep 15
    done

    if [ "$BUILD_OK" = "false" ]; then
      # Все попытки не удались — пробуем восстановить резервный образ
      if docker image inspect remnasale:backup >/dev/null 2>&1; then
        docker tag remnasale:backup remnasale:local >/dev/null 2>&1
        echo "BUILD_FAILED_USING_BACKUP" > /tmp/remnasale_build_status
      else
        docker rmi remnasale:backup >/dev/null 2>&1 || true
        exit 1
      fi
    fi
  fi

  # Удаляем резервный образ (больше не нужен)
  docker rmi remnasale:backup >/dev/null 2>&1 || true
) &
show_spinner "Подготовка файлов" || {
  echo -e "  ${YELLOW}⚠  Сборка Docker образа не удалась. Лог: ${WHITE}cat /tmp/remnasale-build.log${NC}"
  echo
  exit 1
}

# Если сборка не удалась, но используется резервный образ — предупреждаем пользователя
if [ -f /tmp/remnasale_build_status ] && grep -q "BUILD_FAILED_USING_BACKUP" /tmp/remnasale_build_status 2>/dev/null; then
  rm -f /tmp/remnasale_build_status
  echo -e "  ${YELLOW}⚠  Не удалось собрать новый образ (сетевые ошибки Docker Hub).${NC}"
  echo -e "  ${WHITE}   Запущена предыдущая версия образа. Лог: ${YELLOW}cat /tmp/remnasale-build.log${NC}"
  echo
fi

# 6. Настройка реверс-прокси ПЕРЕД запуском бота
#    (бот при старте сразу проверяет webhook — nginx должен быть готов)
if [ "$REVERSE_PROXY" = "caddy" ]; then
  (
    configure_caddy "$APP_DOMAIN"
    # Add web domain to Caddy if different from bot domain
    if [ -n "$APP_WEB_DOMAIN" ] && [ "$APP_WEB_DOMAIN" != "$APP_DOMAIN" ]; then
        configure_caddy "$APP_WEB_DOMAIN"
    fi
  ) &
  show_spinner "Настройка и перезапуск Caddy"
elif [ "$REVERSE_PROXY" = "nginx" ] || [ "$REVERSE_PROXY" = "dfc" ]; then
  configure_nginx "$APP_DOMAIN"
  # Add web domain to Nginx if different from bot domain
  if [ -n "$APP_WEB_DOMAIN" ] && [ "$APP_WEB_DOMAIN" != "$APP_DOMAIN" ]; then
      configure_nginx "$APP_WEB_DOMAIN"
  fi
fi
echo

# 7. Запуск контейнеров и ожидание запуска бота
cd "$PROJECT_DIR"
docker compose up -d >/dev/null 2>&1 &
show_spinner_until_log "remnasale" "Digital.*Freedom.*Core" "Запуск бота" 90 && BOT_START_RESULT=0 || BOT_START_RESULT=$?
echo

# ═══════════════════════════════════════════════
# ЗАВЕРШЕНИЕ УСТАНОВКИ
# ═══════════════════════════════════════════════

if [ ${BOT_START_RESULT:-1} -eq 0 ]; then
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "${GREEN}    🎉 Установка успешно завершена!${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "${GREEN}✅ Бот успешно установлен и запущен${NC}"
    echo
    echo -e "${BLUE}──────────────────────────────────────${NC}"
    echo
    echo -e "${WHITE}✅ Команда вызова меню бота:${NC} ${YELLOW}remnasale${NC} или ${YELLOW}rs${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
elif [ ${BOT_START_RESULT:-1} -eq 2 ]; then
    while true; do
        MENU_ESC_LABEL="Выход"
        show_arrow_menu "❌ Ошибка при запуске бота" \
            "📜 Показать лог запуска" \
            "──────────────────────────────────────" \
            "❌ Выйти из программы установки"
        error_choice=$?
        case $error_choice in
            0)  # Показать логи
                clear
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo -e "${RED}ЛОГИ ОШИБОК:${NC}"
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                docker compose -f "$PROJECT_DIR/docker-compose.yml" logs --tail 50 remnasale
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo
                echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                read -p ""
                continue
                ;;
            2|255)  # Выход / Esc
                break
                ;;
        esac
    done
else
    while true; do
        MENU_ESC_LABEL="Выход"
        show_arrow_menu "⚠️  Запуск бота не был произведен\n       за отведенное время" \
            "📜 Показать лог запуска" \
            "──────────────────────────────────────" \
            "❌ Выйти из программы установки"
        timeout_choice=$?
        case $timeout_choice in
            0)  # Показать логи
                clear
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo -e "${WHITE}ЛОГИ БОТА:${NC}"
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                docker compose -f "$PROJECT_DIR/docker-compose.yml" logs --tail 50 remnasale
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo
                echo -e "${DARKGRAY}Нажмите Enter для продолжения${NC}"
                read -p ""
                continue
                ;;
            2|255)  # Выход / Esc
                break
                ;;
        esac
    done
fi
echo

# Отмечаем успешное завершение установки
INSTALL_STARTED=false
INSTALL_COMPLETED=true

# Привязываем лицензию к IP текущего сервера
_write_license_bind "$ENV_FILE"

# Устанавливаем периодическую проверку лицензии
if [ -n "${REMNASALE_LICENSE_KEY:-}" ] && [ -n "${REMNASALE_LICENSE_SERVER:-$LICENSE_SERVER}" ]; then
    _install_license_checker
fi

# Ключ доступа сохранён в .env (LICENSE_KEY) — отдельный файл не нужен

# Создание глобальной команды remnasale
(
    sudo mkdir -p /usr/local/lib/remnasale
    # Копируем remnasale-install.sh в системную папку (до удаления SOURCE_DIR)
    _src="$(realpath "$SOURCE_DIR/remnasale-install.sh" 2>/dev/null || echo "$SOURCE_DIR/remnasale-install.sh")"
    _dst="$(realpath "/usr/local/lib/remnasale/remnasale-install.sh" 2>/dev/null || echo "/usr/local/lib/remnasale/remnasale-install.sh")"
    if [ "$_src" != "$_dst" ] && [ -f "$SOURCE_DIR/remnasale-install.sh" ]; then
        sudo cp "$SOURCE_DIR/remnasale-install.sh" /usr/local/lib/remnasale/remnasale-install.sh
    fi
    sudo chmod +x /usr/local/lib/remnasale/remnasale-install.sh

    sudo tee /usr/local/bin/remnasale > /dev/null << 'EOF'
#!/bin/bash
# Запускаем remnasale-install.sh из системной папки
if [ -f "/usr/local/lib/remnasale/remnasale-install.sh" ]; then
    exec /usr/local/lib/remnasale/remnasale-install.sh
else
    echo "❌ remnasale-install.sh не найден. Переустановите бота."
    exit 1
fi
EOF
    sudo chmod +x /usr/local/bin/remnasale
    sudo ln -sf /usr/local/bin/remnasale /usr/local/bin/rs
) >/dev/null 2>&1

# Удаление исходной папки если она не в /opt/remnasale (после копирования в системную папку)
if [ "$COPY_FILES" = true ] && [ "$SOURCE_DIR" != "/opt/remnasale" ] && [ "$SOURCE_DIR" != "/" ]; then
    cd /opt
    rm -rf "$SOURCE_DIR" 2>/dev/null || true
fi

# Ожидание ввода перед возвратом в главное меню
echo
printf "\033[?25l${DARKGRAY}${BLUE}Enter${DARKGRAY}: Продолжить${NC}"
read -rs -n1 2>/dev/null
printf "\033[?25h"
clear

cd /opt

# Удаляем временную папку клонирования если она была создана
if [ -n "$CLONE_DIR" ] && [ -d "$CLONE_DIR" ]; then
    rm -rf "$CLONE_DIR" 2>/dev/null || true
fi

# Возвращаемся в главное меню
show_full_menu
