#!/bin/bash
# ═══════════════════════════════════════════════
# Remnasale — Bootstrap-скрипт установки
# Запрашивает ключ лицензии, проверяет его и
# скачивает основной установочный скрипт с сервера лицензий
# ═══════════════════════════════════════════════

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
WHITE='\033[1;37m'
NC='\033[0m'

LICENSE_SERVER="http://66.151.40.26:8080"

echo
echo -e "${BLUE}══════════════════════════════════════${NC}"
echo -e "${GREEN}       🚀 Установка Remnasale${NC}"
echo -e "${BLUE}══════════════════════════════════════${NC}"
echo

# Запрашиваем ключ лицензии
read -r -p "$(echo -e "${WHITE}  Введите ключ лицензии: ${NC}")" LICENSE_KEY

if [ -z "$LICENSE_KEY" ]; then
    echo -e "${RED}❌ Ключ лицензии не указан${NC}"
    exit 1
fi

echo
echo -ne "${BLUE}  Проверка ключа...${NC}"

# Проверяем ключ через license-сервер
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 15 \
    "${LICENSE_SERVER}/api/v1/version?key=${LICENSE_KEY}")

if [ "$HTTP_CODE" != "200" ]; then
    echo -e "\r${RED}  ❌ Недействительный ключ лицензии${NC}          "
    echo
    case "$HTTP_CODE" in
        403) echo -e "  ${YELLOW}Ключ заблокирован, истёк или не найден${NC}" ;;
        401) echo -e "  ${YELLOW}Ключ не указан${NC}" ;;
        *)   echo -e "  ${YELLOW}Сервер недоступен (HTTP $HTTP_CODE)${NC}" ;;
    esac
    exit 1
fi

echo -e "\r${GREEN}  ✅ Ключ валиден${NC}                              "
echo

# Скачиваем основной установочный скрипт
echo -ne "${BLUE}  Загрузка установщика...${NC}"

INSTALL_SCRIPT=$(mktemp /tmp/remnasale-install.XXXXXX.sh)

HTTP_CODE=$(curl -s -o "$INSTALL_SCRIPT" -w "%{http_code}" --max-time 30 \
    "${LICENSE_SERVER}/api/v1/install/script?key=${LICENSE_KEY}")

if [ "$HTTP_CODE" != "200" ] || [ ! -s "$INSTALL_SCRIPT" ]; then
    echo -e "\r${RED}  ❌ Не удалось скачать установщик${NC}           "
    rm -f "$INSTALL_SCRIPT"
    exit 1
fi

echo -e "\r${GREEN}  ✅ Установщик загружен${NC}                       "
echo

chmod +x "$INSTALL_SCRIPT"

# Запускаем основной скрипт, передавая ключ и сервер через переменные окружения
export REMNASALE_LICENSE_KEY="$LICENSE_KEY"
export REMNASALE_LICENSE_SERVER="$LICENSE_SERVER"

cd /opt
exec bash "$INSTALL_SCRIPT"
