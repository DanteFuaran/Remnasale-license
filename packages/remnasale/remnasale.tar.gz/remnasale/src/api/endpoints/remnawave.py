import traceback
from typing import cast

from aiogram.utils.formatting import Text
from dishka import FromDishka
from dishka.integrations.fastapi import inject
from fastapi import APIRouter, HTTPException, Request, Response, status
from loguru import logger
from pydantic import ValidationError
from remnapy.controllers import WebhookUtility
from remnapy.models.webhook import NodeDto, UserDto, UserHwidDeviceEventDto
from sqlalchemy.exc import InterfaceError as SQLAlchemyInterfaceError
from sqlalchemy.exc import ProgrammingError as SQLAlchemyProgrammingError

from src.core.config import AppConfig
from src.core.constants import API_V1, REMNAWAVE_WEBHOOK_PATH
from src.core.utils.message_payload import MessagePayload
from src.infrastructure.taskiq.tasks.notifications import send_error_notification_task
from src.services.remnawave import RemnawaveService

router = APIRouter(prefix=API_V1)


@router.post(REMNAWAVE_WEBHOOK_PATH)
@inject
async def remnawave_webhook(
    request: Request,
    config: FromDishka[AppConfig],
    remnawave_service: FromDishka[RemnawaveService],
) -> Response:
    try:
        raw_body = await request.body()
        data = await request.json()
        logger.info(f"Received Remnawave webhook: event='{data.get('event', 'unknown')}'")
        payload = WebhookUtility.parse_webhook(
            body=raw_body.decode("utf-8"),
            headers=dict(request.headers),
            webhook_secret=config.remnawave.webhook_secret.get_secret_value(),
            validate=True,
        )
    except Exception as exception:
        logger.exception(f"Webhook validation failed with error '{exception}'")
        raise HTTPException(status_code=401)

    if not payload:
        logger.warning("Payload is empty after validation")
        raise HTTPException(status_code=401, detail="Unauthorized")

    try:
        if WebhookUtility.is_user_event(payload.event):
            user = cast(UserDto, WebhookUtility.get_typed_data(payload))
            await remnawave_service.handle_user_event(payload.event, user)

        elif WebhookUtility.is_user_hwid_devices_event(payload.event):
            event = cast(UserHwidDeviceEventDto, WebhookUtility.get_typed_data(payload))
            await remnawave_service.handle_device_event(
                payload.event,
                event.user,
                event.hwid_user_device,
            )

        elif WebhookUtility.is_node_event(payload.event):
            try:
                node = cast(NodeDto, WebhookUtility.get_typed_data(payload))
            except ValidationError as ve:
                logger.debug(f"Node event '{payload.event}' skipped due to validation: {ve}")
                return Response(status_code=status.HTTP_200_OK)
            logger.info(
                f"Node webhook: event='{payload.event}', "
                f"node='{node.name}' (uuid={node.uuid}), "
                f"connected={node.is_connected}, traffic={node.traffic_used_bytes}"
            )
            await remnawave_service.handle_node_event(payload.event, node)

        elif payload.event.startswith("service."):
            logger.debug(f"Remnawave service event: '{payload.event}'")

        else:
            logger.warning(f"Unhandled Remnawave event type '{payload.event}'")

    except SQLAlchemyInterfaceError:
        logger.warning(
            f"Database connection lost while processing webhook event '{payload.event}'. "
            f"This is expected during mass plan sync operations."
        )
        return Response(status_code=status.HTTP_503_SERVICE_UNAVAILABLE)

    except SQLAlchemyProgrammingError as pe:
        logger.warning(
            f"Database schema unavailable for webhook event '{payload.event}': {pe}. "
            f"This is expected during backup restore."
        )
        return Response(status_code=status.HTTP_503_SERVICE_UNAVAILABLE)

    except Exception as exception:
        logger.exception(f"Failed to process Remnawave webhook due to '{exception}'")
        traceback_str = traceback.format_exc()
        error_type_name = type(exception).__name__
        error_message = Text(str(exception)[:512])

        await send_error_notification_task.kiq(
            traceback_str=traceback_str,
            payload=MessagePayload.not_deleted(
                i18n_key="ntf-event-error",
                i18n_kwargs={
                    "user": False,
                    "error": f"{error_type_name}: {error_message.as_html()}",
                },
            ),
        )

    return Response(status_code=status.HTTP_200_OK)
