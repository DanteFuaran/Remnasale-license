import asyncio
from typing import Any, Awaitable, Callable, Optional

from aiogram import Bot
from aiogram.types import TelegramObject
from aiogram.types import User as AiogramUser
from dishka import AsyncContainer
from loguru import logger

from src.core.constants import CONTAINER_KEY
from src.core.enums import MiddlewareEventType
from src.services.access import AccessService

from .base import EventTypedMiddleware

_LICENSE_RESTRICTED_NTF_KEY = "license:restricted_ntf:{user_id}"


class AccessMiddleware(EventTypedMiddleware):
    __event_types__ = [MiddlewareEventType.MESSAGE, MiddlewareEventType.CALLBACK_QUERY]

    async def middleware_logic(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        aiogram_user: Optional[AiogramUser] = self._get_aiogram_user(event)

        if aiogram_user is None or aiogram_user.is_bot:
            logger.warning("Terminating middleware: event from bot or missing user")
            return

        container: AsyncContainer = data[CONTAINER_KEY]
        access_service: AccessService = await container.get(AccessService)

        # Удаляем предыдущее уведомление об ограниченном режиме при любом новом событии
        redis_key = _LICENSE_RESTRICTED_NTF_KEY.format(user_id=aiogram_user.id)
        try:
            bot: Bot = await container.get(Bot)
            prev_msg_raw = await access_service.redis_client.get(redis_key)
            if prev_msg_raw:
                prev_msg_id = int(prev_msg_raw) if isinstance(prev_msg_raw, int) else int(prev_msg_raw.decode() if isinstance(prev_msg_raw, bytes) else prev_msg_raw)
                await access_service.redis_client.delete(redis_key)
                try:
                    await bot.delete_message(chat_id=aiogram_user.id, message_id=prev_msg_id)
                except Exception:
                    pass
        except Exception as e:
            logger.debug(f"Failed to clean up restricted notification: {e}")

        if not await access_service.is_access_allowed(aiogram_user=aiogram_user, event=event):
            # Если бот в ограниченном режиме по лицензии — уведомить пользователя
            if await access_service.is_license_restricted():
                try:
                    msg = await bot.send_message(
                        chat_id=aiogram_user.id,
                        text=(
                            "⚠️ Сервис недоступен по техническим причинам.\n"
                            "Пожалуйста, попробуйте позже."
                        ),
                    )

                    # Сохраняем message_id для удаления при следующем взаимодействии
                    await access_service.redis_client.set(redis_key, str(msg.message_id), ex=300)

                    async def _auto_delete(b: Bot, chat_id: int, message_id: int, rkey: str) -> None:
                        await asyncio.sleep(5)
                        try:
                            await b.delete_message(chat_id=chat_id, message_id=message_id)
                        except Exception:
                            pass
                        try:
                            await access_service.redis_client.delete(rkey)
                        except Exception:
                            pass

                    asyncio.create_task(_auto_delete(bot, aiogram_user.id, msg.message_id, redis_key))
                except Exception as e:
                    logger.debug(f"Failed to send license restricted notification: {e}")
            return

        return await handler(event, data)
