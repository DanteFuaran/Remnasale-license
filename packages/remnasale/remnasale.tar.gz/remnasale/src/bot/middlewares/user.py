import asyncio
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Optional

from aiogram.types import TelegramObject
from aiogram.types import User as AiogramUser
from aiogram_dialog.api.internal import FakeUser
from cachetools import TTLCache
from dishka import AsyncContainer
from fluentogram import TranslatorHub
from loguru import logger
from remnapy.models.users import UpdateUserRequestDto

from src.bot.keyboards import get_user_keyboard
from src.core.config import AppConfig
from src.core.constants import CONTAINER_KEY, IMPORTED_TAG, IS_SUPER_DEV_KEY, USER_KEY, SETTINGS_KEY
from src.core.enums import MiddlewareEventType, PlanType, SystemNotificationType
from src.core.utils.formatters import format_bytes_to_gb, format_device_count
from src.core.utils.message_payload import MessagePayload
from src.core.utils.types import CreateUserInput
from src.infrastructure.database.models.dto import (
    PlanSnapshotDto,
    SubscriptionDto,
    UserDto,
)
from src.services.notification import NotificationService
from src.services.plan import PlanService
from src.services.referral import ReferralService
from src.services.remnawave import RemnawaveService
from src.services.settings import SettingsService
from src.services.subscription import SubscriptionService
from src.services.user import UserService

from .base import EventTypedMiddleware

# Debounce activity updates — skip if user was active within last 30s.
# This saves 3 Redis commands (lrem+lpush+ltrim) per redundant update.
_ACTIVITY_DEBOUNCE: TTLCache[int, None] = TTLCache(maxsize=10_000, ttl=30)


class UserMiddleware(EventTypedMiddleware):
    __event_types__ = [
        MiddlewareEventType.MESSAGE,
        MiddlewareEventType.CALLBACK_QUERY,
        MiddlewareEventType.ERROR,
        MiddlewareEventType.AIOGD_UPDATE,
        MiddlewareEventType.MY_CHAT_MEMBER,
        MiddlewareEventType.PRE_CHECKOUT_QUERY,
    ]

    async def middleware_logic(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        aiogram_user: Optional[AiogramUser] = self._get_aiogram_user(event)

        if aiogram_user is None or aiogram_user.is_bot:
            logger.debug("Terminating middleware: event from bot or missing user")
            return

        container: AsyncContainer = data[CONTAINER_KEY]

        # ── Fast path: resolve only essential services ──────────────────
        # Heavy services (RemnawaveService, PlanService, etc.) are resolved
        # lazily — only when a NEW user is being created.
        config: AppConfig = await container.get(AppConfig)
        user_service: UserService = await container.get(UserService)
        settings_service: SettingsService = await container.get(SettingsService)

        # Sequential load: settings + user (same DB session, can't use gather)
        settings = await settings_service.get()
        user = await user_service.get(telegram_id=aiogram_user.id)
        data[SETTINGS_KEY] = settings

        if user is None:
            # ── NEW USER: resolve heavy services lazily ─────────────────
            notification_service: NotificationService = await container.get(NotificationService)
            referral_service: ReferralService = await container.get(ReferralService)
            remnawave_service: RemnawaveService = await container.get(RemnawaveService)
            plan_service: PlanService = await container.get(PlanService)
            subscription_service: SubscriptionService = await container.get(SubscriptionService)
            translator_hub: TranslatorHub = await container.get(TranslatorHub)

            user = await user_service.create(
                CreateUserInput(
                    telegram_id=aiogram_user.id,
                    full_name=aiogram_user.full_name,
                    username=aiogram_user.username,
                    language_code=aiogram_user.language_code,
                ),
                settings=settings,
            )

            # Проверяем существующую подписку в Remnawave
            try:
                existing_users = await remnawave_service.remnawave.users.get_users_by_telegram_id(
                    telegram_id=str(user.telegram_id)
                )
                if existing_users:
                    existing_user = existing_users[0]
                    existing_tag = existing_user.tag
                    logger.debug(
                        f"Found existing Remnawave user {user.telegram_id} "
                        f"with tag='{existing_tag}', status='{existing_user.status}'"
                    )
                    if existing_user.status in ["ACTIVE", "active"]:
                        # Пытаемся найти план по тегу
                        matching_plan = None
                        if existing_tag:
                            matching_plan = await plan_service.get_by_tag(existing_tag)
                        
                        if matching_plan:
                                # Вычисляем duration из expire_at
                                if existing_user.expire_at:
                                    now = datetime.now(timezone.utc)
                                    time_left = existing_user.expire_at - now
                                    duration_days = max(1, time_left.days)  # Минимум 1 день
                                else:
                                    duration_days = -1  # Безлимит если нет expire_at
                                
                                # План найден, импортируем подписку
                                plan_snapshot = PlanSnapshotDto(
                                    id=matching_plan.id,
                                    name=matching_plan.name,
                                    tag=matching_plan.tag,
                                    type=matching_plan.type,
                                    traffic_limit=matching_plan.traffic_limit,
                                    device_limit=matching_plan.device_limit,
                                    duration=duration_days,
                                    traffic_limit_strategy=matching_plan.traffic_limit_strategy,
                                    internal_squads=matching_plan.internal_squads,
                                    external_squad=matching_plan.external_squad,
                                )
                                
                                imported_subscription = SubscriptionDto(
                                    user_remna_id=existing_user.uuid,
                                    status=existing_user.status,
                                    is_trial=False,
                                    traffic_limit=format_bytes_to_gb(existing_user.traffic_limit_bytes) if existing_user.traffic_limit_bytes else matching_plan.traffic_limit,
                                    device_limit=existing_user.hwid_device_limit or matching_plan.device_limit,
                                    traffic_limit_strategy=existing_user.traffic_limit_strategy or matching_plan.traffic_limit_strategy,
                                    tag=matching_plan.tag,
                                    internal_squads=matching_plan.internal_squads,
                                    external_squad=matching_plan.external_squad,
                                    expire_at=existing_user.expire_at,
                                    url=existing_user.subscription_url,
                                    plan=plan_snapshot,
                                )
                                
                                await subscription_service.create(user, imported_subscription)
                                
                                # Обновляем device_limit в Remnawave в соответствии с планом бота
                                await remnawave_service.remnawave.users.update_user(
                                    UpdateUserRequestDto(
                                        uuid=existing_user.uuid,
                                        hwid_device_limit=matching_plan.device_limit,
                                    )
                                )
                                
                                # Инвалидируем кеш пользователя чтобы загрузить актуальные данные с подпиской
                                await user_service.clear_user_cache(user.telegram_id)
                                user = await user_service.get(telegram_id=user.telegram_id)
                                data[USER_KEY] = user  # Обновляем объект user в контексте
                                
                                logger.info(
                                    f"Imported existing subscription for user {user.telegram_id} "
                                    f"with tag '{matching_plan.tag}' and plan '{matching_plan.name}', "
                                    f"updated device_limit to {matching_plan.device_limit}"
                                )
                        else:
                            # План не найден (или тег пустой), создаём подписку «Импорт»
                            # и сохраняем параметры пользователя (device_limit, expire_at) из Remnawave
                            
                            # Определяем теги
                            if not existing_tag:
                                import_tag_remnawave = IMPORTED_TAG
                                import_tag_display = "IMPORT"
                                should_update_remnawave_tag = False
                            elif existing_tag.startswith("IMPORT_"):
                                import_tag_remnawave = existing_tag
                                original_tag = existing_tag[7:]
                                import_tag_display = f"IMPORT({original_tag})"
                                should_update_remnawave_tag = False
                            else:
                                import_tag_remnawave = f"IMPORT_{existing_tag}"
                                import_tag_display = f"IMPORT({existing_tag})"
                                should_update_remnawave_tag = True
                                
                            # Получаем переведённое название для профиля
                            i18n = translator_hub.get_translator_by_locale(locale=user.language)
                            import_name = i18n.get("frg-import-name")
                            
                            logger.info(
                                f"Creating IMPORT subscription for user {user.telegram_id} "
                                f"(tag='{existing_tag or ''}', display='{import_tag_display}')"
                            )
                            
                            # Вычисляем duration из expire_at пользователя
                            if existing_user.expire_at:
                                now = datetime.now(timezone.utc)
                                time_left = existing_user.expire_at - now
                                duration_days = max(1, time_left.days)
                            else:
                                duration_days = -1
                            
                            # Используем device_limit пользователя из Remnawave, по умолчанию 3
                            user_device_limit = existing_user.hwid_device_limit or 3
                            
                            # Определяем traffic_limit из данных Remnawave
                            traffic_limit_gb = format_bytes_to_gb(existing_user.traffic_limit_bytes) if existing_user.traffic_limit_bytes else -1
                            
                            # Определяем тип плана на основе данных
                            if traffic_limit_gb and traffic_limit_gb > 0 and user_device_limit and user_device_limit > 0:
                                plan_type = PlanType.BOTH
                            elif traffic_limit_gb and traffic_limit_gb > 0:
                                plan_type = PlanType.TRAFFIC
                            elif user_device_limit and user_device_limit > 0:
                                plan_type = PlanType.DEVICES
                            else:
                                plan_type = PlanType.UNLIMITED
                            
                            plan_snapshot = PlanSnapshotDto(
                                id=0,
                                name=import_name,
                                tag=import_tag_display,
                                type=plan_type,
                                traffic_limit=traffic_limit_gb,
                                device_limit=user_device_limit,
                                duration=duration_days,
                                traffic_limit_strategy=existing_user.traffic_limit_strategy or "NO_RESET",
                                internal_squads=[],
                                external_squad=None,
                            )
                            
                            imported_subscription = SubscriptionDto(
                                user_remna_id=existing_user.uuid,
                                status=existing_user.status,
                                is_trial=False,
                                traffic_limit=traffic_limit_gb,
                                device_limit=user_device_limit,
                                traffic_limit_strategy=existing_user.traffic_limit_strategy or "NO_RESET",
                                tag=import_tag_display,
                                internal_squads=[],
                                external_squad=None,
                                expire_at=existing_user.expire_at,
                                url=existing_user.subscription_url,
                                plan=plan_snapshot,
                            )
                            
                            await subscription_service.create(user, imported_subscription)
                            
                            # Меняем тег в панели Remnawave только если нужно
                            if should_update_remnawave_tag:
                                await remnawave_service.remnawave.users.update_user(
                                    UpdateUserRequestDto(
                                        uuid=existing_user.uuid,
                                        tag=import_tag_remnawave,
                                        hwid_device_limit=format_device_count(user_device_limit),
                                    )
                                )
                            else:
                                await remnawave_service.remnawave.users.update_user(
                                    UpdateUserRequestDto(
                                        uuid=existing_user.uuid,
                                        hwid_device_limit=format_device_count(user_device_limit),
                                    )
                                )
                            
                            # Инвалидируем кеш пользователя
                            await user_service.clear_user_cache(user.telegram_id)
                            user = await user_service.get(telegram_id=user.telegram_id)
                            data[USER_KEY] = user
                            
                            logger.info(
                                f"Created '{import_tag_display}' subscription for user {user.telegram_id}, "
                                f"device_limit={user_device_limit}, duration={duration_days} days"
                            )
                    else:
                        logger.debug(f"User {user.telegram_id} is not active in Remnawave (status={existing_user.status})")
                else:
                    logger.debug(f"User {user.telegram_id} not found in Remnawave")
            except Exception as e:
                logger.error(f"Error checking existing Remnawave subscription: {e}")

            referrer = await referral_service.get_referrer_by_event(event, user.telegram_id)

            base_i18n_kwargs = {
                "user_id": str(user.telegram_id),
                "user_name": user.name,
                "username": user.username or False,
            }

            if referrer:
                referrer_i18n_kwargs = {
                    "has_referrer": True,
                    "referrer_user_id": str(referrer.telegram_id),
                    "referrer_user_name": referrer.name,
                    "referrer_username": referrer.username or False,
                }
            else:
                referrer_i18n_kwargs = {"has_referrer": False}

            await notification_service.system_notify(
                payload=MessagePayload.not_deleted(
                    i18n_key="ntf-event-new-user",
                    i18n_kwargs={**base_i18n_kwargs, **referrer_i18n_kwargs},
                    reply_markup=get_user_keyboard(user.telegram_id),
                    close_button_style="success",
                ),
                ntf_type=SystemNotificationType.USER_REGISTERED,
            )

            if await referral_service.is_referral_event(event, user.telegram_id):
                referral_code = await referral_service.get_ref_code_by_event(event)
                logger.info(f"Registered with referral code: '{referral_code}'")

                await referral_service.handle_referral(user, referral_code)

                logger.info(
                    f"Referral processed for user '{user.telegram_id}'. "
                    f"is_invited_user will be resolved via relations."
                )

        elif not isinstance(aiogram_user, FakeUser):
            await user_service.compare_and_update(
                user,
                CreateUserInput(
                    telegram_id=aiogram_user.id,
                    full_name=aiogram_user.full_name,
                    username=aiogram_user.username,
                    language_code=aiogram_user.language_code,
                ),
                settings=settings,
            )

        # Fire-and-forget: don't block handler on 3 Redis commands for activity
        tid = user.telegram_id
        if tid not in _ACTIVITY_DEBOUNCE:
            _ACTIVITY_DEBOUNCE[tid] = None
            asyncio.create_task(user_service.update_recent_activity(telegram_id=tid))

        data[USER_KEY] = user
        data[IS_SUPER_DEV_KEY] = tid == config.bot.dev_id

        return await handler(event, data)
