from typing import Any, Awaitable, Callable, cast

from aiogram.types import CallbackQuery, TelegramObject
from cachetools import TTLCache
from dishka import AsyncContainer
from loguru import logger

from src.core.constants import CONTAINER_KEY, USER_KEY
from src.core.enums import MiddlewareEventType
from src.core.utils.message_payload import MessagePayload
from src.infrastructure.database.models.dto import UserDto
from src.services.notification import NotificationService

from .base import EventTypedMiddleware


class ThrottlingMiddleware(EventTypedMiddleware):
    __event_types__ = [MiddlewareEventType.MESSAGE, MiddlewareEventType.CALLBACK_QUERY]

    def __init__(self, ttl: float = 0.5) -> None:
        # Основной кеш: блокирует повторные запросы в течение ttl
        self.cache: TTLCache[int, Any] = TTLCache(maxsize=10_000, ttl=ttl)
        # Кеш для уведомлений: не спамим пользователя чаще раза в 3 секунды
        self.notify_cache: TTLCache[int, Any] = TTLCache(maxsize=10_000, ttl=3.0)

    async def middleware_logic(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user: UserDto = data[USER_KEY]

        if user.telegram_id in self.cache:
            logger.warning(f"User '{user.telegram_id}' throttled")

            # Для callback_query (навигация по меню) — мгновенно снимаем индикатор загрузки
            # на кнопке без каких-либо тяжёлых операций. Сообщение не отправляем.
            if isinstance(event, CallbackQuery):
                try:
                    await event.answer()
                except Exception:
                    pass
                return

            # Для текстовых сообщений — один раз за 3 сек показываем предупреждение
            if user.telegram_id not in self.notify_cache:
                self.notify_cache[user.telegram_id] = None
                container: AsyncContainer = data[CONTAINER_KEY]
                try:
                    notification_service: NotificationService = await container.get(NotificationService)
                    await notification_service.notify_user(
                        user=user,
                        payload=MessagePayload(i18n_key="ntf-throttling-many-requests"),
                    )
                except Exception:
                    pass
            return

        self.cache[user.telegram_id] = None
        return await handler(event, data)
