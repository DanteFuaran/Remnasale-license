import asyncio
import os
import subprocess
import time
from typing import cast

import httpx

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery, Message
from dishka import FromDishka
from dishka.integrations.aiogram import inject
from loguru import logger

from src.bot.states import Notification
from src.core.constants import REPOSITORY, get_update_branch
from src.core.utils.formatters import format_user_log as log
from src.core.utils.license_host import get_license_host
from src.infrastructure.database.models.dto import UserDto
from src.services.notification import NotificationService
from src.services.update_checker import (
    UPDATE_CLOSE,
    UPDATE_NOW,
    UPDATE_SNOOZE_PREFIX,
    UpdateCheckerService,
)

router = Router(name=__name__)

# Host project directory (matches install.sh PROJECT_DIR)
_HOST_PROJECT_DIR = "/opt/remnasale"

# Track pending update confirmations: {user_id: (timestamp, warning_message_id)}
_update_confirmations: dict[int, tuple[float, int]] = {}


@router.callback_query(F.data.startswith(Notification.CLOSE.state))
@inject
async def on_close_notification(
    callback: CallbackQuery,
    bot: Bot,
    user: UserDto,
    notification_service: FromDishka[NotificationService],
) -> None:
    notification: Message = cast(Message, callback.message)
    notification_id = notification.message_id

    logger.debug(f"{log(user)} Closed notification '{notification_id}'")

    # Remove from auto-cleanup tracking (pass bot_id to cover both main & mirror formats)
    try:
        await notification_service.untrack_closeable_message(
            chat_id=notification.chat.id,
            message_id=notification_id,
            bot_id=bot.id,
        )
    except Exception:
        pass

    # Answer the callback FIRST — if the query is too old after a bot restart this
    # fails silently, but crucially we never leave the button in an infinite loading state.
    try:
        await callback.answer()
    except Exception:
        pass  # query already expired (e.g. bot was restarted while message was open)

    try:
        await notification.delete()
        logger.debug(f"Notification '{notification_id}' for user '{user.telegram_id}' deleted")
    except Exception as exception:
        logger.debug(f"Failed to delete notification '{notification_id}': {exception}")

        # Message still exists but couldn't be deleted — strip the keyboard so it
        # doesn't keep showing an unanswerable button.
        try:
            await bot.edit_message_reply_markup(
                chat_id=notification.chat.id,
                message_id=notification.message_id,
                reply_markup=None,
            )
            logger.debug(f"Keyboard removed from notification '{notification_id}'")
        except Exception:
            pass  # message was already deleted or edited by something else


@router.callback_query(F.data == UPDATE_NOW)
@inject
async def on_update_now(
    callback: CallbackQuery,
    bot: Bot,
    user: UserDto,
    update_checker_service: FromDishka[UpdateCheckerService],
) -> None:
    """Handle 'Update now' button — trigger bot update via Docker."""
    notification: Message = cast(Message, callback.message)
    user_id = user.telegram_id
    now = time.time()

    # Check if this is a confirmation (second click within 5 seconds)
    last_confirmation = _update_confirmations.get(user_id)
    if not last_confirmation or now - last_confirmation[0] >= 5:
        # First click — show warning as separate message below
        await callback.answer()
        warning_msg = await bot.send_message(
            chat_id=user_id,
            text="⚠️ <b>Бот будет перезагружен!</b>\n<i>Нажмите ещё раз для подтверждения.</i>",
            parse_mode="HTML",
        )
        _update_confirmations[user_id] = (now, warning_msg.message_id)
        click_ts = now

        async def _revert_warning() -> None:
            await asyncio.sleep(5)
            # Only delete if no second click happened
            if user_id in _update_confirmations and _update_confirmations[user_id][0] == click_ts:
                _update_confirmations.pop(user_id, None)
                try:
                    await bot.delete_message(
                        chat_id=user_id,
                        message_id=warning_msg.message_id,
                    )
                except Exception:
                    pass

        asyncio.create_task(_revert_warning())
        return

    # Second click within 5s — delete warning and proceed with update
    warning_message_id = last_confirmation[1]
    _update_confirmations.pop(user_id, None)
    try:
        await bot.delete_message(chat_id=user_id, message_id=warning_message_id)
    except Exception:
        pass
    logger.info(f"{log(user)} Triggered bot update via notification button")

    try:
        await callback.answer()

        # Replace notification with "updating" message
        try:
            await bot.edit_message_text(
                chat_id=notification.chat.id,
                message_id=notification.message_id,
                text=(
                    "<b>⏳ Запущен процесс обновления!</b>\n"
                    "<i>Бот будет перезапущен автоматически.</i>"
                ),
                parse_mode="HTML",
                reply_markup=None,
            )
        except Exception:
            pass

        # Save message reference to Redis so it can be deleted after restart
        # Format: "{bot_id}:{chat_id}:{message_id}" to support mirror bots
        from src.core.storage.keys import UpdateInProgressKey, UpdateMessageKey
        redis_repo = update_checker_service.redis_repository
        msg_ref = f"{bot.id}:{notification.chat.id}:{notification.message_id}"
        await redis_repo.set(UpdateMessageKey(), msg_ref, ex=1800)  # TTL 30 min
        await redis_repo.set(UpdateInProgressKey(), "1", ex=1800)  # TTL 30 min

        # Get repo info from config
        _license_key = update_checker_service.config.build.license_key.get_secret_value()
        _license_server = await get_license_host(update_checker_service.redis_repository.client, update_checker_service.config)
        branch = get_update_branch()

        if not _license_server or not _license_key:
            logger.error("[update] LICENSE_SERVER or LICENSE_KEY not configured")
            await callback.answer("❌ Не настроен LICENSE_SERVER или LICENSE_KEY", show_alert=True)
            try:
                await redis_repo.delete(UpdateInProgressKey())
            except Exception:
                pass
            return

        # Download archive from license server (no GitHub PAT needed on client side)
        download_url = f"{_license_server.rstrip('/')}/api/v1/download?key={_license_key}"
        archive_path = f"{_HOST_PROJECT_DIR}/logs/.update.tar.gz"

        try:
            logger.info("[update] Downloading archive from license server...")
            async with httpx.AsyncClient(timeout=httpx.Timeout(180.0, connect=15.0)) as client:
                async with client.stream("GET", download_url) as resp:
                    if resp.status_code != 200:
                        raise Exception(f"License server returned {resp.status_code}")
                    with open(archive_path, "wb") as f:
                        async for chunk in resp.aiter_bytes(chunk_size=65536):
                            f.write(chunk)
            logger.info(f"[update] Archive downloaded: {os.path.getsize(archive_path)} bytes")
        except Exception as e:
            logger.error(f"[update] Download failed: {e}")
            await callback.answer("❌ Не удалось скачать обновление", show_alert=True)
            try:
                await redis_repo.delete(UpdateInProgressKey())
                os.remove(archive_path)
            except Exception:
                pass
            return

        # Spawn updater container
        # - Archive is already downloaded to host filesystem
        # - Container only needs to extract, build and restart
        update_script = (
            f"exec > {_HOST_PROJECT_DIR}/logs/update.log 2>&1 && "
            "set -e && "
            f"echo '[update] Started at '$(date) && "
            "echo '[update] Extracting archive...' && "
            "mkdir -p /tmp/repo && "
            f"tar xzf {_HOST_PROJECT_DIR}/logs/.update.tar.gz -C /tmp/repo --strip-components=1 && "
            f"rm -f {_HOST_PROJECT_DIR}/logs/.update.tar.gz && "
            f"cp /tmp/repo/docker-compose.yml {_HOST_PROJECT_DIR}/ && "
            f"cp /tmp/repo/Dockerfile {_HOST_PROJECT_DIR}/ && "
            f"cp /tmp/repo/pyproject.toml {_HOST_PROJECT_DIR}/ && "
            f"cp /tmp/repo/uv.lock {_HOST_PROJECT_DIR}/ && "
            f"cp /tmp/repo/version {_HOST_PROJECT_DIR}/ && "
            f"cp -r /tmp/repo/src {_HOST_PROJECT_DIR}/ && "
            f"cp -r /tmp/repo/scripts {_HOST_PROJECT_DIR}/ && "
            f"cp -r /tmp/repo/frontend {_HOST_PROJECT_DIR}/ && "
            f"cp -r /tmp/repo/assets/translations {_HOST_PROJECT_DIR}/assets/ 2>/dev/null || true && "
            f"cp -r /tmp/repo/assets/update {_HOST_PROJECT_DIR}/assets/ 2>/dev/null || true && "
            f"cp /tmp/repo/assets/README.md {_HOST_PROJECT_DIR}/assets/ 2>/dev/null || true && "
            f"cd {_HOST_PROJECT_DIR} && "
            "echo '[update] Building Docker image...' && "
            "docker build -t remnasale:local . && "
            "echo '[update] Restarting containers...' && "
            "if docker compose version >/dev/null 2>&1; then DC='docker compose'; "
            "elif command -v docker-compose >/dev/null 2>&1; then DC='docker-compose'; "
            "else echo '[update] ERROR: docker compose not found' && exit 1; fi && "
            "$DC up -d --force-recreate --no-deps remnasale remnasale-taskiq-worker remnasale-taskiq-scheduler && "
            "echo '[update] Done!' && "
            "rm -rf /tmp/repo || true"
        )

        cmd = [
            "docker", "run", "--rm", "-d",
            "--name", "remnasale-updater",
            "-v", "/var/run/docker.sock:/var/run/docker.sock",
            "-v", f"{_HOST_PROJECT_DIR}:{_HOST_PROJECT_DIR}",
            "-v", "/usr/libexec/docker/cli-plugins:/usr/libexec/docker/cli-plugins:ro",
            "remnasale:local", "sh", "-c", update_script,
        ]

        result = await asyncio.to_thread(subprocess.run, cmd, capture_output=True, text=True, timeout=120)

        if result.returncode == 0:
            logger.info(f"[update] Updater container started: {result.stdout.strip()[:12]}")
            logger.info(f"[update] Progress log: {_HOST_PROJECT_DIR}/logs/update.log")
            # NOTE: Do NOT stop the bot here — docker compose up --force-recreate handles
            # the container lifecycle. Stopping early risks downtime if the build fails.
        else:
            logger.error(f"[update] Failed to start updater: {result.stderr}")
            # Clear the update-in-progress flag so bot doesn't silently stay in update mode
            try:
                await redis_repo.delete(UpdateInProgressKey())
            except Exception:
                pass

    except Exception as e:
        logger.error(f"[update] Failed to trigger update: {e}")
        try:
            await callback.answer("❌ Ошибка запуска обновления", show_alert=True)
        except Exception:
            pass


@router.callback_query(F.data == UPDATE_CLOSE)
async def on_update_close(callback: CallbackQuery, bot: Bot, user: UserDto) -> None:
    """Close update notification."""
    notification: Message = cast(Message, callback.message)
    logger.info(f"{log(user)} Closed update notification '{notification.message_id}'")
    try:
        await notification.delete()
        await callback.answer()
    except Exception:
        try:
            await bot.edit_message_reply_markup(
                chat_id=notification.chat.id,
                message_id=notification.message_id,
                reply_markup=None,
            )
            await callback.answer()
        except Exception:
            pass


@router.callback_query(F.data.startswith(UPDATE_SNOOZE_PREFIX))
@inject
async def on_update_snooze(
    callback: CallbackQuery,
    bot: Bot,
    user: UserDto,
    update_checker_service: FromDishka[UpdateCheckerService],
) -> None:
    """Handle update notification snooze/dismiss buttons."""
    notification: Message = cast(Message, callback.message)
    action = callback.data.split(":", 1)[1] if callback.data else ""

    try:
        if action == "off":
            await update_checker_service.disable_notifications()
            await callback.answer("🔕", show_alert=False)
            logger.info(f"{log(user)} Disabled update notifications")
        elif action in ("1", "3", "7"):
            days = int(action)
            await update_checker_service.set_snooze(days)
            await callback.answer(f"⏰ {days}d", show_alert=False)
            logger.info(f"{log(user)} Snoozed update notifications for {days} day(s)")
        else:
            await callback.answer()
            return

        # Delete the notification message
        try:
            await notification.delete()
        except Exception:
            try:
                await bot.edit_message_reply_markup(
                    chat_id=notification.chat.id,
                    message_id=notification.message_id,
                    reply_markup=None,
                )
            except Exception:
                pass

    except Exception as e:
        logger.error(f"Failed to handle update snooze: {e}")
        await callback.answer()


@router.callback_query(F.data == "donate_close")
async def on_donate_close(callback: CallbackQuery, bot: Bot) -> None:
    """Close donation notification."""
    notification: Message = cast(Message, callback.message)
    try:
        await notification.delete()
        await callback.answer()
    except Exception:
        try:
            await bot.edit_message_reply_markup(
                chat_id=notification.chat.id,
                message_id=notification.message_id,
                reply_markup=None,
            )
            await callback.answer()
        except Exception:
            pass


@router.callback_query(F.data == "delete_message")
async def on_delete_message(callback: CallbackQuery, bot: Bot) -> None:
    """Удаление сообщения с файлом по кнопке Закрыть"""
    message: Message = cast(Message, callback.message)
    
    try:
        # Удаляем сконвертированный файл
        import os
        sqlite_path = "/opt/remnasale/backups/db/sql_convert.db"
        if os.path.exists(sqlite_path):
            os.remove(sqlite_path)
            logger.debug(f"Deleted converted file: {sqlite_path}")
        
        await message.delete()
        try:
            await callback.answer()
        except TelegramBadRequest as e:
            # Query timeout - user clicked button too late, just ignore
            logger.debug(f"Callback query timeout, ignoring: {e}")
    except Exception as exception:
        logger.error(f"Failed to delete message. Exception: {exception}")
