from uuid import UUID

from aiogram_dialog import Dialog, StartMode, Window
from aiogram_dialog.widgets.input import MessageInput
from aiogram_dialog.widgets.kbd import (
    Button,
    Column,
    CopyText,
    Group,
    ListGroup,
    Row,
    ScrollingGroup,
    Select,
    Start,
    SwitchTo,
)
from aiogram_dialog.widgets.text import Case, Format
from magic_filter import F

from src.bot.keyboards import main_menu_button
from src.bot.routers.dashboard.broadcast.handlers import on_content_input, on_preview
from src.bot.routers.extra.test import show_dev_popup
from src.bot.states import DashboardUser, DashboardUsers, Subscription
from src.bot.widgets import Banner, ColoredButton, ColoredSwitchTo, I18nFormat, IgnoreUpdate
from src.core.constants import PURCHASE_PREFIX
from src.core.enums import SubscriptionStatus, UserRole

from .getters import (
    device_limit_getter,
    devices_getter,
    discount_getter,
    expire_time_getter,
    external_squads_getter,
    give_access_getter,
    give_subscription_getter,
    internal_squads_getter,
    points_getter,
    referral_points_getter,
    referrals_getter,
    referrals_list_getter,
    role_getter,
    squads_getter,
    subscription_duration_getter,
    subscription_getter,
    sync_getter,
    traffic_limit_getter,
    transaction_getter,
    transactions_getter,
    user_getter,
)
from .handlers import (
    on_active_toggle,
    on_admin_add_device,
    on_admin_add_device_days_input,
    on_admin_change_device_days_input,
    on_back_to_source,
    on_block_toggle,
    on_current_subscription,
    on_delete_user,
    on_device_delete,
    on_device_delete_now,
    on_device_info,
    on_slot_days_click,
    on_device_limit_input,
    on_device_limit_select,
    on_devices,
    on_discount_input,
    on_discount_select,
    on_duration_input,
    on_duration_select,
    on_external_squad_select,
    on_give_access,
    on_give_subscription,
    on_internal_squad_select,
    on_plan_select,
    on_points_input,
    on_points_select,
    on_referral_bind_input,
    on_referral_points_input,
    on_referral_points_select,
    on_referral_user_select,
    on_referrals,
    on_reset_traffic,
    on_role_select,
    on_send,
    on_subscription_delete,
    on_subscription_duration_keep_current,
    on_subscription_duration_select,
    on_subscription_select,
    on_sync,
    on_sync_from_remnashop,
    on_sync_from_remnawave,
    on_traffic_limit_input,
    on_traffic_limit_select,
    on_transaction_select,
    on_transactions,
    on_cancel_role_change,
    on_accept_role_change,
    on_cancel_balance_change,
    on_accept_balance_change,
    on_cancel_referral_balance_change,
    on_accept_referral_balance_change,
)

user = Window(
    Banner(),
    I18nFormat("msg-user-main"),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-balance"),
            id="points",
            state=DashboardUser.POINTS,
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-user-subscription"),
            id="subscription",
            on_click=on_current_subscription,
        ),
        SwitchTo(
            text=I18nFormat("btn-user-subscription-device-limit"),
            id="device",
            state=DashboardUser.DEVICE_LIMIT,
            when=F["has_subscription"] & F["can_edit"],
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-user-statistics"),
            id="statistics",
            on_click=show_dev_popup,
        ),
        Button(
            text=I18nFormat("btn-user-sync"),
            id="sync",
            on_click=on_sync,
        ),
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-role"),
            id="role",
            state=DashboardUser.ROLE,
            when=F["is_not_self"] & F["can_edit"],
        ),
        Button(
            text=I18nFormat("btn-user-block", is_blocked=F["is_blocked"]),
            id="block",
            on_click=on_block_toggle,
            when=F["is_not_self"] & F["can_edit"],
        ),
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-message"),
            id="message",
            state=DashboardUser.MESSAGE,
        ),
        Button(
            text=I18nFormat("btn-user-referrals"),
            id="referrals",
            on_click=on_referrals,
            when=F["is_referral_enable"],
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-user-delete"),
            id="delete_user",
            on_click=on_delete_user,
            when=F["is_not_self"] & F["can_edit"],
        ),
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-back"),
            id="back_users",
            on_click=on_back_to_source,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.MAIN,
    getter=user_getter,
)

subscription = Window(
    Banner(),
    Case(
        {True: I18nFormat("msg-user-subscription-info"), False: I18nFormat("msg-user-subscription-empty")},
        selector=F["has_subscription"],
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-subscription-traffic-limit"),
            id="traffic",
            state=DashboardUser.TRAFFIC_LIMIT,
        ),
        when=F["has_subscription"] & F["can_edit"],
    ),
    Row(
        Button(
            text=I18nFormat("btn-user-subscription-traffic-reset"),
            id="reset",
            on_click=on_reset_traffic,
        ),
        SwitchTo(
            text=I18nFormat("btn-user-subscription-devices"),
            id="devices_list",
            state=DashboardUser.DEVICES_LIST,
        ),
        when=F["has_subscription"],
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-subscription-expire-time"),
            id="expire_time",
            state=DashboardUser.EXPIRE_TIME,
        ),
        SwitchTo(
            text=I18nFormat("btn-user-subscription-squads"),
            id="squads",
            state=DashboardUser.SQUADS,
            when=F["can_edit"],
        ),
        when=F["has_subscription"],
    ),
    Row(
        Button(
            text=I18nFormat("btn-user-change-subscription"),
            id="give_subscription",
            on_click=on_give_subscription,
            when=F["has_subscription"],
        ),
        Button(
            text=I18nFormat("btn-user-give-subscription"),
            id="give_subscription_new",
            on_click=on_give_subscription,
            when=~F["has_subscription"],
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-user-subscription-active-toggle", is_active=F["is_active"]),
            id="active_toggle",
            on_click=on_active_toggle,
            when=F["has_subscription"] & F["subscription_status"].in_(
                [SubscriptionStatus.ACTIVE, SubscriptionStatus.DISABLED]
            ),
        ),
        Button(
            text=I18nFormat("btn-user-subscription-delete"),
            id="delete",
            on_click=on_subscription_delete,
            when=F["has_subscription"],
        ),
    ),
    Row(
        CopyText(
            text=I18nFormat("btn-user-subscription-url"),
            copy_text=Format("{url}"),
        ),
        when=F["has_subscription"],
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.SUBSCRIPTION,
    getter=subscription_getter,
)

traffic_limit = Window(
    Banner(),
    I18nFormat("msg-user-subscription-traffic-limit"),
    Group(
        Select(
            text=I18nFormat("{item[traffic_limit][0]}", value=F["item"]["traffic"]),
            id="traffic_limit_select",
            item_id_getter=lambda item: item["traffic"],
            items="traffic_count",
            type_factory=int,
            on_click=on_traffic_limit_select,
        ),
        width=3,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.SUBSCRIPTION,
            style="primary",
        ),
    ),
    MessageInput(func=on_traffic_limit_input),
    IgnoreUpdate(),
    state=DashboardUser.TRAFFIC_LIMIT,
    getter=traffic_limit_getter,
)

device_limit = Window(
    Banner(),
    I18nFormat("msg-user-subscription-device-limit"),
    Group(
        Select(
            text=I18nFormat("unit-device-short", value=F["item"]),
            id="device_limit_select",
            item_id_getter=lambda item: item,
            items="devices_count",
            type_factory=int,
            on_click=on_device_limit_select,
        ),
        width=5,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    MessageInput(func=on_device_limit_input),
    IgnoreUpdate(),
    state=DashboardUser.DEVICE_LIMIT,
    getter=device_limit_getter,
)

expire_time = Window(
    Banner(),
    I18nFormat("msg-user-subscription-expire-time"),
    Group(
        Select(
            text=Format("{item[operation]}{item[duration]}"),
            id="duration_select",
            item_id_getter=lambda item: item["days"],
            items="durations",
            type_factory=int,
            on_click=on_duration_select,
        ),
        width=2,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.SUBSCRIPTION,
            style="primary",
        ),
    ),
    MessageInput(func=on_duration_input),
    IgnoreUpdate(),
    state=DashboardUser.EXPIRE_TIME,
    getter=expire_time_getter,
)

squads = Window(
    Banner(),
    I18nFormat("msg-user-subscription-squads"),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-subscription-internal-squads"),
            id="internal",
            state=DashboardUser.INTERNAL_SQUADS,
        ),
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-subscription-external-squads"),
            id="external",
            state=DashboardUser.EXTERNAL_SQUADS,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.SUBSCRIPTION,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.SQUADS,
    getter=squads_getter,
)

internal_squads = Window(
    Banner(),
    I18nFormat("msg-user-subscription-internal-squads"),
    Column(
        Select(
            text=I18nFormat(
                "btn-squad-choice",
                name=F["item"]["name"],
                selected=F["item"]["selected"],
            ),
            id="select_squad",
            item_id_getter=lambda item: item["uuid"],
            items="squads",
            type_factory=UUID,
            on_click=on_internal_squad_select,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.SQUADS,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.INTERNAL_SQUADS,
    getter=internal_squads_getter,
)

external_squads = Window(
    Banner(),
    I18nFormat("msg-user-subscription-external-squads"),
    Column(
        Select(
            text=I18nFormat(
                "btn-squad-choice",
                name=F["item"]["name"],
                selected=F["item"]["selected"],
            ),
            id="select_squad",
            item_id_getter=lambda item: item["uuid"],
            items="squads",
            type_factory=UUID,
            on_click=on_external_squad_select,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.SQUADS,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.EXTERNAL_SQUADS,
    getter=external_squads_getter,
)

devices_list = Window(
    Banner(),
    I18nFormat("msg-user-devices"),
    ListGroup(
        Row(
            Button(
                text=Format("{item[days_display]}"),
                id="slot_days",
                on_click=on_slot_days_click,
                when=F["item"]["show_days_display"],
            ),
            Button(
                text=Format("{item[platform_display]}"),
                id="slot_platform",
                on_click=on_device_info,
                when=F["item"]["is_occupied"],
            ),
            Button(
                text=Format("{item[device_info]}"),
                id="slot_empty",
                when=~F["item"]["is_occupied"],
            ),
            Button(
                text=Format("🗑"),
                id="trash",
                on_click=on_device_delete,
                when=F["item"]["show_trash_button"],
            ),
            Button(
                text=Format("❌"),
                id="delete",
                on_click=on_device_delete,
                when=F["item"]["show_delete_button"],
            ),
            Button(
                text=I18nFormat("btn-device-pending-deletion"),
                id="pending_text",
                when=F["item"]["show_pending_text"],
            ),
            Button(
                text=I18nFormat("btn-device-delete-now"),
                id="delete_now",
                on_click=on_device_delete_now,
                when=F["item"]["show_delete_now_button"],
            ),
        ),
        id="device_slots_list",
        item_id_getter=lambda item: item["id"],
        items="device_slots",
        when=F["has_device_slots"] == 1,
    ),
    Row(
        Button(
            text=I18nFormat("btn-admin-add-device"),
            id="admin_add_device",
            on_click=on_admin_add_device,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.SUBSCRIPTION,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.DEVICES_LIST,
    getter=devices_getter,
)

admin_add_device_days = Window(
    Banner(),
    I18nFormat("msg-admin-add-device-days"),
    MessageInput(
        func=on_admin_add_device_days_input,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.DEVICES_LIST,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.ADMIN_ADD_DEVICE_DAYS,
)

admin_change_device_days = Window(
    Banner(),
    I18nFormat("msg-admin-change-device-days"),
    MessageInput(
        func=on_admin_change_device_days_input,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.DEVICES_LIST,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.ADMIN_CHANGE_DEVICE_DAYS,
)

sync = Window(
    Banner(),
    I18nFormat("msg-user-sync"),
    Column(
        Button(
            text=I18nFormat("btn-user-sync-remnashop"),
            id="sync_from_remnashop",
            on_click=on_sync_from_remnashop,
        ),
        Button(
            text=I18nFormat("btn-user-sync-remnawave"),
            id="sync_from_remnawave",
            on_click=on_sync_from_remnawave,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.SYNC,
    getter=sync_getter,
)

sync_waiting = Window(
    Banner(),
    I18nFormat("msg-user-sync-waiting"),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.SYNC_WAITING,
    getter=sync_getter,
)

give_subscription = Window(
    Banner(),
    I18nFormat("msg-user-give-subscription"),
    Column(
        Select(
            text=Format("{item[plan_name]}"),
            id="plan_select",
            item_id_getter=lambda item: item["plan_id"],
            items="plans",
            type_factory=int,
            on_click=on_subscription_select,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.GIVE_SUBSCRIPTION,
    getter=give_subscription_getter,
)

subscription_duration = Window(
    Banner(),
    I18nFormat("msg-user-give-subscription-duration"),
    Button(
        text=I18nFormat("btn-keep-current-duration", remaining=F["current_remaining_display"]),
        id="keep_current_duration",
        on_click=on_subscription_duration_keep_current,
        when=F["has_current_subscription"],
    ),
    Group(
        Select(
            text=I18nFormat(
                "btn-plan-duration",
                value=F["item"]["days"],
            ),
            id="duration_select",
            item_id_getter=lambda item: item["days"],
            items="durations",
            type_factory=int,
            on_click=on_subscription_duration_select,
        ),
        width=2,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.GIVE_SUBSCRIPTION,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.SUBSCRIPTION_DURATION,
    getter=subscription_duration_getter,
)

transactions_list = Window(
    Banner(),
    I18nFormat("msg-user-transactions"),
    ScrollingGroup(
        Select(
            text=I18nFormat(
                "btn-user-transaction",
                status=F["item"]["status"],
                created_at=F["item"]["created_at"],
            ),
            id="transaction_select",
            item_id_getter=lambda item: item["payment_id"],
            items="transactions",
            type_factory=UUID,
            on_click=on_transaction_select,
        ),
        id="scroll",
        width=1,
        height=7,
        hide_on_single_page=True,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.POINTS,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.TRANSACTIONS_LIST,
    getter=transactions_getter,
)

transaction = Window(
    Banner(),
    I18nFormat("msg-user-transaction-info"),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.TRANSACTIONS_LIST,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.TRANSACTION,
    getter=transaction_getter,
)

message = Window(
    Banner(),
    I18nFormat("msg-user-message"),
    Row(
        Button(
            I18nFormat("btn-user-message-preview"),
            id="preview",
            on_click=on_preview,
        ),
    ),
    Row(
        ColoredButton(
            I18nFormat("btn-user-message-confirm"),
            id="confirm",
            on_click=on_send,
            style="success",
        ),
    ),
    Row(
        ColoredSwitchTo(
            I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    MessageInput(func=on_content_input),
    IgnoreUpdate(),
    state=DashboardUser.MESSAGE,
)

discount = Window(
    Banner(),
    I18nFormat("msg-user-discount"),
    Group(
        Select(
            text=Format("{item}%"),
            id="discount_select",
            item_id_getter=lambda item: item,
            items="percentages",
            type_factory=int,
            on_click=on_discount_select,
        ),
        width=3,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.POINTS,
            style="primary",
        ),
        *main_menu_button,
    ),
    MessageInput(func=on_discount_input),
    IgnoreUpdate(),
    state=DashboardUser.DISCOUNT,
    getter=discount_getter,
)

# Balance menu with two submenus
points = Window(
    Banner(),
    Case(
        {
            True: I18nFormat("msg-user-finance-menu-full"),
            False: I18nFormat("msg-user-finance-menu-short"),
        },
        selector=F["show_finance_details"],
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-main-balance"),
            id="main_balance",
            state=DashboardUser.MAIN_BALANCE,
            when=F["is_balance_enabled"],
        ),
        SwitchTo(
            text=I18nFormat("btn-user-referral-balance"),
            id="referral_balance",
            state=DashboardUser.REFERRAL_BALANCE,
            when=F["is_referral_enable"],
        ),
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-discount"),
            id="discount",
            state=DashboardUser.DISCOUNT,
        ),
        Button(
            text=I18nFormat("btn-user-transactions"),
            id="transactions",
            on_click=on_transactions,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.POINTS,
    getter=points_getter,
)

# Main user balance
main_balance = Window(
    Banner(),
    I18nFormat("msg-user-main-balance"),
    Group(
        Select(
            text=Format("{item[operation]}{item[balance]} ₽"),
            id="main_balance_select",
            item_id_getter=lambda item: item["balance"],
            items="balance",
            type_factory=int,
            on_click=on_points_select,
        ),
        width=2,
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-cancel"),
            id="cancel",
            on_click=on_cancel_balance_change,
            style="danger",
        ),
        ColoredButton(
            text=I18nFormat("btn-accept"),
            id="accept",
            on_click=on_accept_balance_change,
            style="success",
        ),
    ),
    MessageInput(func=on_points_input),
    IgnoreUpdate(),
    state=DashboardUser.MAIN_BALANCE,
    getter=points_getter,
)

# Referral balance
referral_balance = Window(
    Banner(),
    I18nFormat("msg-user-referral-balance"),
    Group(
        Select(
            text=Format("{item[operation]}{item[balance]} ₽"),
            id="referral_balance_select",
            item_id_getter=lambda item: item["balance"],
            items="balance",
            type_factory=int,
            on_click=on_referral_points_select,
        ),
        width=2,
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-cancel"),
            id="cancel",
            on_click=on_cancel_referral_balance_change,
            style="danger",
        ),
        ColoredButton(
            text=I18nFormat("btn-accept"),
            id="accept",
            on_click=on_accept_referral_balance_change,
            style="success",
        ),
    ),
    MessageInput(func=on_referral_points_input),
    IgnoreUpdate(),
    state=DashboardUser.REFERRAL_BALANCE,
    getter=referral_points_getter,
)

give_access = Window(
    Banner(),
    I18nFormat("msg-user-give-access"),
    Column(
        Select(
            text=I18nFormat(
                "btn-user-allowed-plan-choice",
                plan_name=F["item"]["plan_name"],
                selected=F["item"]["selected"],
            ),
            id="plan_select",
            item_id_getter=lambda item: item["plan_id"],
            items="plans",
            type_factory=int,
            on_click=on_plan_select,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.GIVE_ACCESS,
    getter=give_access_getter,
)

role = Window(
    Banner(),
    I18nFormat("msg-user-role"),
    Column(
        Select(
            text=I18nFormat(
                "btn-role-choice",
                name=F["item"]["name"],
                selected=F["item"]["selected"],
            ),
            id="role_select",
            item_id_getter=lambda item: item["role"].value,
            items="roles",
            type_factory=UserRole,
            on_click=on_role_select,
        ),
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-cancel"),
            id="cancel",
            on_click=on_cancel_role_change,
            style="danger",
        ),
        ColoredButton(
            text=I18nFormat("btn-accept"),
            id="accept",
            on_click=on_accept_role_change,
            style="success",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardUser.ROLE,
    getter=role_getter,
)

referrals_window = Window(
    Banner(),
    I18nFormat("msg-user-referrals"),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-referrals-list"),
            id="referrals_list",
            state=DashboardUser.REFERRALS_LIST,
        ),
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-user-referral-bind"),
            id="referral_bind",
            state=DashboardUser.REFERRAL_BIND,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.REFERRALS,
    getter=referrals_getter,
)

referrals_list_window = Window(
    Banner(),
    I18nFormat("msg-user-referrals-list"),
    ScrollingGroup(
        Select(
            text=I18nFormat(
                "btn-user-referral-item",
                telegram_id=F["item"]["telegram_id"],
                name=F["item"]["name"],
                total_spent=F["item"]["total_spent"],
            ),
            id="referral_user_select",
            item_id_getter=lambda item: item["telegram_id"],
            items="referrals",
            on_click=on_referral_user_select,
        ),
        id="referrals_scroll",
        width=1,
        height=7,
        hide_on_single_page=True,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.REFERRALS,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.REFERRALS_LIST,
    getter=referrals_list_getter,
)

referral_bind = Window(
    Banner(),
    I18nFormat("msg-user-referral-bind"),
    MessageInput(
        func=on_referral_bind_input,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.REFERRALS,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.REFERRAL_BIND,
)

delete_confirm = Window(
    Banner(),
    I18nFormat("msg-user-delete-confirm"),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardUser.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardUser.DELETE_CONFIRM,
)

router = Dialog(
    user,
    subscription,
    traffic_limit,
    device_limit,
    expire_time,
    squads,
    internal_squads,
    external_squads,
    devices_list,
    admin_add_device_days,
    admin_change_device_days,
    sync,
    sync_waiting,
    give_subscription,
    subscription_duration,
    transactions_list,
    transaction,
    message,
    discount,
    points,
    main_balance,
    referral_balance,
    give_access,
    role,
    referrals_window,
    referrals_list_window,
    referral_bind,
    delete_confirm,
)
