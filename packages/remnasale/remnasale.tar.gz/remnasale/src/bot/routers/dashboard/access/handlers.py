from aiogram.types import CallbackQuery, Message
from aiogram_dialog import DialogManager, ShowMode, StartMode
from aiogram_dialog.widgets.input import MessageInput
from aiogram_dialog.widgets.kbd import Button, Select
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from loguru import logger
from pydantic import SecretStr

from src.bot.states import DashboardAccess, DashboardBotManagement, DashboardSettings
from src.core.constants import T_ME, USER_KEY
from src.core.enums import AccessMode
from src.core.utils.formatters import format_user_log as log
from src.core.utils.message_payload import MessagePayload
from src.core.utils.validators import is_valid_url, is_valid_username
from src.infrastructure.database.models.dto import UserDto
from src.services.access import AccessService
from src.services.notification import NotificationService
from src.services.settings import SettingsService


@inject
async def on_access_mode_select(
    callback: CallbackQuery,
    widget: Select[AccessMode],
    dialog_manager: DialogManager,
    selected_mode: AccessMode,
    access_service: FromDishka[AccessService],
) -> None:
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    
    # Сохраняем выбранный режим во временное состояние
    if "access_changes" not in dialog_manager.dialog_data:
        dialog_manager.dialog_data["access_changes"] = {}
    
    dialog_manager.dialog_data["access_changes"]["mode"] = selected_mode
    logger.debug(f"{log(user)} Selected access mode (not applied yet) -> '{selected_mode}'")


@inject
async def on_purchases_toggle(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    
    # Сохраняем во временное состояние
    if "access_changes" not in dialog_manager.dialog_data:
        dialog_manager.dialog_data["access_changes"] = {}
    
    # Получаем текущее состояние из временных изменений или из базы
    current_purchases = dialog_manager.dialog_data["access_changes"].get("purchases_allowed")
    if current_purchases is None:
        settings = await settings_service.get()
        current_purchases = settings.purchases_allowed
    
    new_state = not current_purchases
    dialog_manager.dialog_data["access_changes"]["purchases_allowed"] = new_state
    logger.debug(f"{log(user)} Toggled purchases allowed (not applied yet) -> '{new_state}'")


@inject
async def on_registration_toggle(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    
    # Сохраняем во временное состояние
    if "access_changes" not in dialog_manager.dialog_data:
        dialog_manager.dialog_data["access_changes"] = {}
    
    # Получаем текущее состояние из временных изменений или из базы
    current_registration = dialog_manager.dialog_data["access_changes"].get("registration_allowed")
    if current_registration is None:
        settings = await settings_service.get()
        current_registration = settings.registration_allowed
    
    new_state = not current_registration
    dialog_manager.dialog_data["access_changes"]["registration_allowed"] = new_state
    logger.debug(f"{log(user)} Toggled registration allowed (not applied yet) -> '{new_state}'")


@inject
async def on_condition_toggle(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    settings = await settings_service.get()

    if callback.data == "rules":
        new_state = not settings.rules_required
        settings.rules_required = new_state

    if callback.data == "channel":
        new_state = not settings.channel_required
        settings.channel_required = new_state

    await settings_service.update(settings)
    logger.info(f"{log(user)} Toggled '{callback.data}' -> '{new_state}'")


@inject
async def on_rules_input(
    message: Message,
    widget: MessageInput,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
    notification_service: FromDishka[NotificationService],
) -> None:
    dialog_manager.show_mode = ShowMode.EDIT
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    logger.debug(f"{log(user)} Attempted to set rules link")
    input_text: str = message.text.strip() if message.text else ""

    if not is_valid_url(input_text):
        logger.warning(f"{log(user)} Provided invalid rules link format: '{input_text}'")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-access-invalid-link"),
        )
        return

    settings = await settings_service.get()
    settings.rules_link = SecretStr(input_text)
    await settings_service.update(settings)

    logger.info(f"{log(user)} Successfully set rules link")
    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-access-link-saved"),
    )
    await dialog_manager.switch_to(state=DashboardAccess.CONDITIONS)


@inject
async def on_channel_input(
    message: Message,
    widget: MessageInput,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
    notification_service: FromDishka[NotificationService],
) -> None:
    dialog_manager.show_mode = ShowMode.EDIT
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    logger.debug(f"{log(user)} Attempted to set channel link")

    input_text: str = message.text.strip() if message.text else ""
    settings = await settings_service.get()

    if input_text.isdigit():
        channel_id = int(input_text)
        if not input_text.startswith("-100"):
            channel_id = int(f"-100{input_text}")
        settings.channel_id = channel_id
        logger.info(f"{log(user)} Saved channel ID: {channel_id}")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-access-id-saved"),
        )

    elif input_text.startswith("-100") and input_text[1:].isdigit():
        settings.channel_id = int(input_text)
        logger.info(f"{log(user)} Saved channel ID: {input_text}")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-access-id-saved"),
        )

    elif is_valid_username(input_text) or input_text.startswith(T_ME):
        settings.channel_link = SecretStr(input_text)
        logger.info(f"{log(user)} Saved channel link: '{input_text}'")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-access-link-saved"),
        )

    else:
        logger.warning(f"{log(user)} Provided invalid channel input: '{input_text}'")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-access-channel-invalid"),
        )
        return

    await settings_service.update(settings)


@inject
async def on_access_cancel(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Отмена изменений режима доступа - возврат без применения."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    
    # Очищаем временные изменения
    dialog_manager.dialog_data.pop("access_changes", None)
    dialog_manager.dialog_data.pop("initial_access_state", None)
    
    logger.info(f"{log(user)} Cancelled access changes")
    
    # Возврат в меню Управление ботом
    await dialog_manager.start(
        state=DashboardBotManagement.MAIN,
        mode=StartMode.RESET_STACK,
    )


@inject
async def on_access_accept(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
    access_service: FromDishka[AccessService],
) -> None:
    """Применение изменений режима доступа."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]

    # Блокируем изменения если активен ограниченный режим по лицензии
    if await access_service.is_license_restricted():
        await callback.answer(
            "⛔ Режим доступа заблокирован из-за ограничения лицензии",
            show_alert=True,
        )
        return

    changes = dialog_manager.dialog_data.get("access_changes", {})
    initial_state = dialog_manager.dialog_data.get("initial_access_state", {})
    
    if changes:
        settings = await settings_service.get()
        
        # Проверяем, были ли оплаты выключены, а теперь включаются
        was_purchases_disabled = not initial_state.get("purchases_allowed", settings.purchases_allowed)
        
        # Применяем изменения режима доступа
        if "mode" in changes:
            await access_service.set_mode(mode=changes["mode"])
            logger.info(f"{log(user)} Applied access mode -> '{changes['mode']}'")
            # Перезагружаем settings после set_mode(), так как set_mode() сохраняет,
            # сбрасывает кэш и возврат к старому объекту перезапишет access_mode обратно
            settings = await settings_service.get()
        
        # Применяем изменения purchases_allowed
        if "purchases_allowed" in changes:
            settings.purchases_allowed = changes["purchases_allowed"]
            logger.info(f"{log(user)} Applied purchases_allowed -> '{changes['purchases_allowed']}'")
        
        # Применяем изменения registration_allowed
        if "registration_allowed" in changes:
            settings.registration_allowed = changes["registration_allowed"]
            logger.info(f"{log(user)} Applied registration_allowed -> '{changes['registration_allowed']}'")
        
        await settings_service.update(settings)
        
        # Если оплаты были выключены и теперь включаются - уведомляем ожидающих пользователей
        now_purchases_enabled = changes.get("purchases_allowed", initial_state.get("purchases_allowed", True))
        if was_purchases_disabled and now_purchases_enabled:
            from src.infrastructure.taskiq.tasks.notifications import send_payments_available_notifications_task
            waiting_users = await access_service.get_all_waiting_users()
            if waiting_users:
                logger.info(f"{log(user)} Notifying {len(waiting_users)} users about payments re-enabled")
                await send_payments_available_notifications_task.kiq(waiting_users)
                await access_service.clear_all_waiting_users()
    
    # Очищаем временные данные
    dialog_manager.dialog_data.pop("access_changes", None)
    dialog_manager.dialog_data.pop("initial_access_state", None)
    
    logger.info(f"{log(user)} Accepted and saved access changes")
    
    # Возврат в меню Управление ботом
    await dialog_manager.start(
        state=DashboardBotManagement.MAIN,
        mode=StartMode.RESET_STACK,
    )
