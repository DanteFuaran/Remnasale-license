from aiogram import Bot
from aiogram.types import CallbackQuery, FSInputFile, Message
from aiogram_dialog import DialogManager, SubManager
from aiogram_dialog.widgets.kbd import Button
from aiogram_dialog.widgets.input import MessageInput
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from loguru import logger

from src.bot.routers.dashboard.users.user.handlers import start_user_window
from src.bot.states import DashboardTelegram
from src.core.constants import LOG_DIR, USER_KEY
from src.core.enums import MediaType, UserRole
from src.core.logger import LOG_FILENAME
from src.core.utils.formatters import format_user_log as log
from src.core.utils.message_payload import MessagePayload
from src.core.utils.time import datetime_now
from src.core.utils.validators import is_double_click
from src.infrastructure.database.models.dto import UserDto
from src.infrastructure.taskiq.tasks.redirects import redirect_to_main_menu_task
from src.services.notification import NotificationService
from src.services.settings import SettingsService
from src.services.user import UserService


@inject
async def on_logs_request(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    notification_service: FromDishka[NotificationService],
) -> None:
    user: UserDto = dialog_manager.middleware_data[USER_KEY]

    try:
        file = FSInputFile(
            path=LOG_DIR / LOG_FILENAME,
            filename=f"{datetime_now().strftime('%Y-%m-%d_%H-%M-%S')}.log",
        )
    except FileNotFoundError:
        logger.error(f"{log(user)} Log file not found at '{LOG_DIR}/{LOG_FILENAME}'")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-error-log-not-found"),
        )
        return

    logger.info(f"{log(user)} Sending log file '{LOG_DIR / LOG_FILENAME}' as '{file.filename}'")
    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(
            i18n_key="",
            media=file,
            media_type=MediaType.DOCUMENT,
            auto_delete_after=None,
            add_close_button=True,
        ),
    )


@inject
async def on_user_select(
    callback: CallbackQuery,
    widget: Button,
    sub_manager: SubManager,
) -> None:
    user: UserDto = sub_manager.middleware_data[USER_KEY]
    target_telegram_id = int(sub_manager.item_id)

    logger.info(f"{log(user)} User id '{target_telegram_id}' selected")
    await start_user_window(
        manager=sub_manager,
        target_telegram_id=target_telegram_id,
        source_state=None,  # From remnashop dashboard, return to users main
    )


@inject
async def on_user_role_remove(
    callback: CallbackQuery,
    widget: Button,
    sub_manager: SubManager,
    user_service: FromDishka[UserService],
    notification_service: FromDishka[NotificationService],
) -> None:
    await sub_manager.load_data()
    user: UserDto = sub_manager.middleware_data[USER_KEY]
    target_telegram_id = int(sub_manager.item_id)
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"Attempted to remove role for non-existent user '{target_telegram_id}'")

    if is_double_click(
        sub_manager.manager,
        key=f"role_confirm_{target_telegram_id}",
        cooldown=10,
    ):
        await user_service.set_role(user=target_user, role=UserRole.USER)
        await redirect_to_main_menu_task.kiq(target_user.telegram_id)
        logger.info(f"{log(user)} Changed role for {log(target_user)} to '{UserRole.USER}'")
        return

    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-double-click-confirm"),
    )
    logger.debug(f"{log(user)} Waiting for confirmation to delete user role '{target_telegram_id}'")


# --- Extra Devices ---

async def on_extra_devices_menu(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Открыть меню настроек доп. устройств."""
    await dialog_manager.switch_to(DashboardTelegram.EXTRA_DEVICES)


@inject
async def on_edit_extra_devices_price(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Открыть окно редактирования стоимости доп. устройств."""
    await dialog_manager.switch_to(DashboardTelegram.EXTRA_DEVICES_PRICE)


@inject
async def on_extra_devices_preset_price_select(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Сохранить выбранную предустановленную цену в dialog_data."""
    price = int(callback.data.split("_")[-1])
    dialog_manager.dialog_data["pending_price"] = price


@inject
async def on_extra_devices_manual_price_mode(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Переключиться в режим ручного ввода цены."""
    # Сохраняем ID текущего сообщения диалога для последующего удаления
    if callback.message:
        dialog_manager.dialog_data["dialog_window_message_id"] = callback.message.message_id
    await dialog_manager.switch_to(DashboardTelegram.EXTRA_DEVICES_PRICE_MANUAL)


@inject
async def on_extra_devices_price_input(
    message: Message,
    widget: MessageInput,
    dialog_manager: DialogManager,
) -> None:
    """Обработка ввода стоимости доп. устройств (сохранение в dialog_data)."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    
    try:
        price = int(message.text.strip())
        if price < 0:
            await message.answer("❌ Стоимость не может быть отрицательной")
            return
        if price > 100000:
            await message.answer("❌ Стоимость слишком большая (макс. 100000)")
            return
            
        dialog_manager.dialog_data["pending_price"] = price
        logger.info(f"{log(user)} Pending price set -> {price}")
        
        # Получаем bot и chat_id для удаления сообщений
        bot = dialog_manager.middleware_data.get("bot")
        chat_id = message.chat.id
        
        # Удаляем сообщение с вводом пользователя
        try:
            await message.delete()
        except Exception as e:
            logger.debug(f"Failed to delete input message: {e}")
        
        # Удаляем сохранённое сообщение окна ручного ввода
        dialog_window_msg_id = dialog_manager.dialog_data.pop("dialog_window_message_id", None)
        if dialog_window_msg_id and bot:
            try:
                await bot.delete_message(chat_id, dialog_window_msg_id)
            except Exception as e:
                logger.debug(f"Failed to delete dialog window message: {e}")
        
        # Переходим обратно в EXTRA_DEVICES_PRICE
        await dialog_manager.switch_to(DashboardTelegram.EXTRA_DEVICES_PRICE)
        
    except ValueError:
        await message.answer("❌ Введите число")





async def on_back_to_remnashop(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Вернуться к главному меню Телеграм."""
    await dialog_manager.switch_to(DashboardTelegram.MAIN)


@inject
async def on_accept_extra_devices(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Принять и применить изменение типа оплаты доп. устройств."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    pending_payment_type = dialog_manager.dialog_data.pop("pending_payment_type", None)
    
    if pending_payment_type is not None:
        await settings_service.toggle_extra_devices_payment_type()
        payment_type = "единоразово" if pending_payment_type else "ежемесячно"
        logger.info(f"{log(user)} Accepted extra_devices payment type -> {payment_type}")
    
    await dialog_manager.switch_to(DashboardTelegram.MAIN)



async def on_cancel_extra_devices(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Отменить изменения в меню доп. устройств."""
    dialog_manager.dialog_data.pop("pending_payment_type", None)
    await dialog_manager.switch_to(DashboardTelegram.MAIN)


@inject
async def on_accept_extra_devices_price(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Принять и применить изменение цены доп. устройств."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    pending_price = dialog_manager.dialog_data.pop("pending_price", None)
    
    if pending_price is not None:
        await settings_service.set_extra_device_price(pending_price)
        logger.info(f"{log(user)} Accepted extra_device_price -> {pending_price}")
    
    # Очищаем все промежуточные данные - диалог автоматически управляет сообщениями
    for msg_key in ["confirm_message_id", "user_input_message_id", "manual_input_window_id", "price_menu_message_id"]:
        dialog_manager.dialog_data.pop(msg_key, None)
    
    # Переходим обратно на предыдущее состояние
    await dialog_manager.switch_to(DashboardTelegram.EXTRA_DEVICES)


async def on_cancel_extra_devices_price(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Отменить изменения цены доп. устройств."""
    dialog_manager.dialog_data.pop("pending_price", None)
    
    # Очищаем все промежуточные данные - диалог автоматически управляет сообщениями
    for msg_key in ["confirm_message_id", "user_input_message_id", "manual_input_window_id", "price_menu_message_id"]:
        dialog_manager.dialog_data.pop(msg_key, None)
    
    # Переходим обратно на предыдущее состояние
    await dialog_manager.switch_to(DashboardTelegram.EXTRA_DEVICES)


@inject
async def on_toggle_extra_devices_payment_type(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Переключить тип оплаты доп. устройств (единоразово/ежемесячно) - сохранить как pending."""
    # Определяем, какую кнопку нажали по ID кнопки
    button_id = widget.widget_id
    
    # Если нажали на "Единоразово", устанавливаем True; если на "Ежемесячно" - False
    if button_id == "toggle_one_time":
        pending_payment_type = True  # Единоразово
    elif button_id == "toggle_monthly":
        pending_payment_type = False  # Ежемесячно
    else:
        # На случай неизвестной кнопки - инвертируем
        features = await settings_service.get_feature_settings()
        pending_payment_type = not features.extra_devices.is_one_time
    
    # Сохраняем в dialog_data для отложенного применения
    dialog_manager.dialog_data["pending_payment_type"] = pending_payment_type
    payment_type = "единоразово" if pending_payment_type else "ежемесячно"
    logger.info(f"Set extra_devices payment type to pending -> {payment_type}")
    
    # Отправляем acknowledge для обновления UI
    try:
        await callback.answer()
    except Exception as e:
        logger.debug(f"Failed to answer callback: {e}")



