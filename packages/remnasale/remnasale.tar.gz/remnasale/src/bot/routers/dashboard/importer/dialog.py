from aiogram_dialog import Dialog, StartMode, Window
from aiogram_dialog.widgets.input import MessageInput
from aiogram_dialog.widgets.kbd import Button, Column, Row, Select, Start, SwitchTo
from magic_filter import F

from src.bot.keyboards import back_main_menu_button, main_menu_button
from src.bot.states import Dashboard, DashboardImporter, DashboardDB
from src.bot.widgets import Banner, ColoredStart, ColoredSwitchTo
from src.bot.widgets.i18n_format import I18nFormat
from src.bot.widgets.ignore_update import IgnoreUpdate

from .getters import from_xui_getter, import_completed_getter, squads_getter
from .handlers import (
    on_database_input,
    on_import_active_xui,
    on_import_all_xui,
    on_squad_select,
    on_squads,
)

importer = Window(
    Banner(),
    I18nFormat("msg-importer-from-xui"),
    Row(
        Button(
            text=I18nFormat("btn-importer-squads"),
            id="squads",
            on_click=on_squads,
        ),
        when=F["has_exported"] & ~F["has_started"],
    ),
    Column(
        Button(
            text=I18nFormat("btn-importer-import-all"),
            id="import_all",
            on_click=on_import_all_xui,
        ),
        Button(
            text=I18nFormat("btn-importer-import-active"),
            id="import_active",
            on_click=on_import_active_xui,
        ),
        when=F["has_exported"] & ~F["has_started"],
    ),
    Row(
        ColoredStart(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardDB.IMPORTS,
            mode=StartMode.RESET_STACK,
            style="primary",
        ),
        *main_menu_button,
    ),
    MessageInput(func=on_database_input),
    IgnoreUpdate(),
    state=DashboardImporter.MAIN,
    getter=from_xui_getter,
)

import_completed = Window(
    Banner(),
    I18nFormat("msg-importer-import-completed"),
    Row(
        ColoredStart(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardImporter.MAIN,
            mode=StartMode.RESET_STACK,
            style="primary",
        ),
    ),
    *back_main_menu_button,
    IgnoreUpdate(),
    state=DashboardImporter.IMPORT_COMPLETED,
    getter=import_completed_getter,
)

squads = Window(
    Banner(),
    I18nFormat("msg-importer-squads"),
    Column(
        Select(
            text=I18nFormat(
                "btn-squad-choice",
                name=F["item"]["name"],
                selected=F["item"]["selected"],
            ),
            id="select_squad",
            item_id_getter=lambda item: item["uuid"],
            items="squads",
            type_factory=str,
            on_click=on_squad_select,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardImporter.MAIN,
            style="primary",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardImporter.SQUADS,
    getter=squads_getter,
)

router = Dialog(
    importer,
    squads,
    import_completed,
)
