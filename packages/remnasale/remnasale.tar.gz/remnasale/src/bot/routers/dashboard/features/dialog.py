from aiogram_dialog import Dialog, Window
from aiogram_dialog.widgets.kbd import Button, Column, Row, Select, Group
from aiogram_dialog.widgets.input import TextInput
from aiogram_dialog.widgets.text import Const, Format
from magic_filter import F

from src.bot.states import DashboardFeatures
from src.bot.widgets import Banner, ColoredButton, I18nFormat, IgnoreUpdate

from .getters import features_getter
from .handlers import (
    on_toggle_balance,
    on_toggle_community,
    on_toggle_tos,
    on_cancel_features,
    on_accept_features,
    on_toggle_extra_devices,
    on_toggle_transfers,
    on_open_auto_cleanup,
    on_toggle_auto_cleanup,
    on_toggle_auto_cleanup_notify,
    on_open_auto_cleanup_days,
    on_select_auto_cleanup_days,
    on_open_auto_cleanup_days_manual,
    on_auto_cleanup_days_manual_input,
    on_cancel_auto_cleanup,
    on_accept_auto_cleanup,
)


features_main = Window(
    Banner(),
    I18nFormat("msg-dashboard-features"),
    Column(
        Button(
            text=I18nFormat(
                "btn-feature-toggle",
                name=I18nFormat("feature-community"),
                enabled=F["community_enabled"],
            ),
            id="toggle_community",
            on_click=on_toggle_community,
        ),
        Button(
            text=I18nFormat(
                "btn-feature-toggle",
                name=I18nFormat("feature-tos"),
                enabled=F["tos_enabled"],
            ),
            id="toggle_tos",
            on_click=on_toggle_tos,
        ),
        Button(
            text=I18nFormat(
                "btn-feature-toggle",
                name=I18nFormat("feature-balance"),
                enabled=F["balance_enabled"],
            ),
            id="toggle_balance",
            on_click=on_toggle_balance,
        ),
        Button(
            text=I18nFormat(
                "btn-feature-toggle",
                name=I18nFormat("feature-extra-devices"),
                enabled=F["extra_devices_enabled"],
            ),
            id="toggle_extra_devices",
            on_click=on_toggle_extra_devices,
        ),
        Button(
            text=I18nFormat(
                "btn-feature-toggle",
                name=I18nFormat("feature-transfers"),
                enabled=F["transfers_enabled"],
            ),
            id="toggle_transfers",
            on_click=on_toggle_transfers,
        ),
        Button(
            text=I18nFormat(
                "btn-feature-toggle",
                name=I18nFormat("feature-auto-cleanup"),
                enabled=F["auto_cleanup_enabled"],
            ),
            id="toggle_auto_cleanup",
            on_click=on_toggle_auto_cleanup,
        ),
        Button(
            text=I18nFormat("btn-auto-cleanup-settings"),
            id="open_auto_cleanup",
            on_click=on_open_auto_cleanup,
        ),
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-cancel"),
            id="cancel",
            on_click=on_cancel_features,
            style="danger",
        ),
        ColoredButton(
            text=I18nFormat("btn-accept"),
            id="accept",
            on_click=on_accept_features,
            style="success",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardFeatures.MAIN,
    getter=features_getter,
)


# Окно настроек автоочистки
auto_cleanup_window = Window(
    Banner(),
    I18nFormat("msg-auto-cleanup"),
    Column(
        Button(
            text=I18nFormat(
                "btn-feature-toggle",
                name=I18nFormat("feature-auto-cleanup-notify"),
                enabled=F["auto_cleanup_notify"],
            ),
            id="toggle_auto_cleanup_notify",
            on_click=on_toggle_auto_cleanup_notify,
        ),
        Button(
            text=I18nFormat("btn-auto-cleanup-days", days=F["auto_cleanup_days"]),
            id="open_auto_cleanup_days",
            on_click=on_open_auto_cleanup_days,
        ),
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-cancel"),
            id="cancel_auto_cleanup",
            on_click=on_cancel_auto_cleanup,
            style="danger",
        ),
        ColoredButton(
            text=I18nFormat("btn-accept"),
            id="accept_auto_cleanup",
            on_click=on_accept_auto_cleanup,
            style="success",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardFeatures.AUTO_CLEANUP,
    getter=features_getter,
)


# Окно выбора количества дней
DAYS_PRESETS = [
    ("3", "3"),
    ("5", "5"),
    ("7", "7"),
    ("14", "14"),
    ("30", "30"),
]


auto_cleanup_days_window = Window(
    Banner(),
    I18nFormat("msg-auto-cleanup-days"),
    Group(
        Select(
            Format("{item[0]}"),
            id="select_days",
            item_id_getter=lambda x: x[1],
            items="days_presets",
            on_click=on_select_auto_cleanup_days,
        ),
        width=5,
    ),
    Button(
        text=I18nFormat("btn-manual-input"),
        id="manual_days",
        on_click=on_open_auto_cleanup_days_manual,
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-back"),
            id="back_to_auto_cleanup",
            on_click=lambda c, w, m: m.switch_to(DashboardFeatures.AUTO_CLEANUP),
            style="danger",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardFeatures.AUTO_CLEANUP_DAYS,
    getter=features_getter,
)


# Окно ручного ввода дней
auto_cleanup_days_manual_window = Window(
    Banner(),
    I18nFormat("msg-auto-cleanup-days-manual"),
    TextInput(
        id="auto_cleanup_days_input",
        on_success=on_auto_cleanup_days_manual_input,
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-back"),
            id="back_to_days",
            on_click=lambda c, w, m: m.switch_to(DashboardFeatures.AUTO_CLEANUP_DAYS),
            style="danger",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardFeatures.AUTO_CLEANUP_DAYS_MANUAL,
    getter=features_getter,
)


router = Dialog(
    features_main,
    auto_cleanup_window,
    auto_cleanup_days_window,
    auto_cleanup_days_manual_window,
)
