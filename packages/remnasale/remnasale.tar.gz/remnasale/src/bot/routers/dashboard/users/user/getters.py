from typing import Any, Optional, cast

import httpx
from aiogram_dialog import DialogManager
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from fluentogram import TranslatorRunner
from loguru import logger
from remnapy import RemnawaveSDK
from remnapy.exceptions import NotFoundError
from remnapy.models import GetOneNodeResponseDto

from src.core.config import AppConfig
from src.core.constants import DATETIME_FORMAT
from src.core.enums import UserRole
from src.core.i18n.keys import ByteUnitKey
from src.core.i18n.translator import get_translated_kwargs
from src.core.utils.formatters import (
    format_device_limit_number,
    format_price,
    i18n_format_bytes_to_unit,
    i18n_format_days,
    i18n_format_device_limit,
    i18n_format_expire_time,
    i18n_format_traffic_limit,
)
from src.infrastructure.database.models.dto import UserDto
from src.infrastructure.database.models.dto.subscription import RemnaSubscriptionDto
from src.services.extra_device import ExtraDeviceService
from src.services.plan import PlanService
from src.services.referral import ReferralService
from src.services.remnawave import RemnawaveService
from src.services.settings import SettingsService
from src.services.subscription import SubscriptionService
from src.services.transaction import TransactionService
from src.services.user import UserService


async def _get_plan_purchase_info(
    transaction_service: TransactionService,
    plan_service: PlanService,
    settings_service: SettingsService,
    telegram_id: int,
    plan_id: int,
    snapshot_duration: int,
) -> tuple[str, str]:
    """Get original purchase duration and price for subscription display.

    Returns (formatted_duration, formatted_price).
    """
    from src.core.enums import PurchaseType, TransactionStatus

    # 1. Ищем последнюю завершённую транзакцию покупки подписки
    transactions = await transaction_service.get_by_user(telegram_id)
    purchase_tx = None
    for tx in reversed(transactions):
        if (
            tx.status == TransactionStatus.COMPLETED
            and tx.purchase_type in (PurchaseType.NEW, PurchaseType.RENEW, PurchaseType.CHANGE)
        ):
            purchase_tx = tx
            break

    if purchase_tx:
        duration_days = purchase_tx.plan.duration
        formatted_duration = i18n_format_days(duration_days)
        formatted_price = format_price(purchase_tx.pricing.original_amount, purchase_tx.currency)
        return formatted_duration, formatted_price

    # 2. Fallback: пытаемся найти цену из текущего плана
    formatted_duration = i18n_format_days(snapshot_duration)
    plan = await plan_service.get(plan_id)
    if plan:
        duration = plan.get_duration(snapshot_duration)
        if duration and duration.prices:
            settings = await settings_service.get()
            currency = settings.default_currency
            rates = settings.features.currency_rates
            price = duration.get_price(
                currency,
                usd_rate=rates.usd_rate,
                eur_rate=rates.eur_rate,
                stars_rate=rates.stars_rate,
            )
            if price:
                return formatted_duration, format_price(price, currency)

    return formatted_duration, "—"


@inject
async def user_getter(
    dialog_manager: DialogManager,
    config: AppConfig,
    user: UserDto,
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
    settings_service: FromDishka[SettingsService],
    referral_service: FromDishka[ReferralService],
    **kwargs: Any,
) -> dict[str, Any]:
    from src.core.enums import BalanceMode, ReferralRewardType
    
    settings = await settings_service.get_referral_settings()
    dialog_manager.dialog_data.pop("payload", None)
    start_data = cast(dict[str, Any], dialog_manager.start_data)
    target_telegram_id = start_data["target_telegram_id"]
    dialog_manager.dialog_data["target_telegram_id"] = target_telegram_id
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    subscription = await subscription_service.get_current(target_telegram_id)
    
    # Получаем режим баланса
    balance_mode = await settings_service.get_balance_mode()
    
    # Получаем реферальный баланс
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=target_telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # В режиме COMBINED показываем общий баланс
    total_balance = target_user.balance + referral_balance if balance_mode == BalanceMode.COMBINED else target_user.balance

    # Получаем реферера (кто пригласил этого пользователя)
    referral = await referral_service.get_referral_by_referred(target_telegram_id)
    referrer = referral.referrer if referral else None

    data: dict[str, Any] = {
        "user_id": str(target_user.telegram_id),
        "username": target_user.username or False,
        "user_name": target_user.name,
        "role": target_user.role,
        "language": target_user.language,
        "show_points": settings.reward.is_points,
        "balance": str(total_balance),
        "referral_balance": str(referral_balance),
        "referral_code": target_user.referral_code,
        "personal_discount": target_user.personal_discount,
        "purchase_discount": target_user.purchase_discount,
        "is_blocked": target_user.is_blocked,
        "is_not_self": target_user.telegram_id != user.telegram_id,
        "can_edit": target_user.role <= user.role,
        "status": None,
        "is_trial": False,
        "has_subscription": subscription is not None,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        "is_balance_separate": 1 if balance_mode == BalanceMode.SEPARATE else 0,
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        # Реферер
        "has_referrer": 1 if referrer else 0,
        "referrer_name": referrer.name if referrer else "",
        "referrer_tg_id": str(referrer.telegram_id) if referrer else "0",
    }

    if subscription:
        extra_devices = subscription.extra_devices or 0
        device_limit_number = subscription.plan.device_limit
        device_limit_bonus = max(0, subscription.device_limit - device_limit_number - extra_devices) if device_limit_number > 0 else 0
        data.update(
            {
                "status": subscription.get_status,
                "is_trial": subscription.is_trial,
                "plan_name": subscription.plan.name,
                "current_plan_name": subscription.plan.name,
                "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
                "device_limit": i18n_format_device_limit(subscription.device_limit),
                "device_limit_number": format_device_limit_number(device_limit_number),
                "device_limit_bonus": device_limit_bonus,
                "extra_devices": extra_devices,
                "expire_time": i18n_format_expire_time(subscription.expire_at),
            }
        )

    return data


@inject
async def subscription_getter(
    dialog_manager: DialogManager,
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
    remnawave_service: FromDishka[RemnawaveService],
    remnawave: FromDishka[RemnawaveSDK],
    plan_service: FromDishka[PlanService],
    settings_service: FromDishka[SettingsService],
    transaction_service: FromDishka[TransactionService],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    subscription = await subscription_service.get_current(target_telegram_id)

    if not subscription:
        return {"has_subscription": False}

    try:
        remna_user = await remnawave_service.get_user(subscription.user_remna_id)
    except (httpx.ConnectError, httpx.TimeoutException) as e:
        logger.error(f"Remnawave unavailable for user '{target_telegram_id}': {e}")
        return {"has_subscription": False}

    if not remna_user:
        # Пытаемся создать пользователя в remnawave если его нет
        logger.warning(
            f"User Remnawave '{target_telegram_id}' not found. "
            f"Attempting to create with remna_id '{subscription.user_remna_id}'"
        )
        try:
            remna_user = await remnawave_service.create_user(
                user=target_user,
                subscription=subscription,
                force=True
            )
            logger.info(f"Successfully created user in Remnawave: '{target_telegram_id}'")
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            logger.error(f"Remnawave unavailable while creating user '{target_telegram_id}': {e}")
            return {"has_subscription": False}
        except Exception as e:
            logger.error(
                f"Failed to create user in Remnawave '{target_telegram_id}': {e}",
                exc_info=True
            )
            raise ValueError(
                f"User Remnawave '{target_telegram_id}' not found and creation failed: {e}"
            )

    squads = (
        ", ".join(squad.name for squad in remna_user.active_internal_squads)
        if remna_user.active_internal_squads
        else False
    )

    last_node: Optional[GetOneNodeResponseDto] = None
    if remna_user.last_connected_node_uuid:
        try:
            last_node = await remnawave.nodes.get_one_node(remna_user.last_connected_node_uuid)
        except Exception as e:
            logger.warning(
                f"Failed to get node info for uuid '{remna_user.last_connected_node_uuid}': {e}"
            )
    
    # Вычисляем лимиты устройств
    extra_devices = subscription.extra_devices or 0
    device_limit_number = subscription.plan.device_limit if subscription.plan else 0
    device_limit_bonus = max(0, subscription.device_limit - device_limit_number - extra_devices) if device_limit_number > 0 else 0

    # Получаем информацию о покупке (длительность и цену) из транзакции
    plan_duration_display, plan_price_display = await _get_plan_purchase_info(
        transaction_service, plan_service, settings_service,
        target_telegram_id, subscription.plan.id, subscription.plan.duration,
    )

    return {
        "has_subscription": True,
        "is_trial": subscription.is_trial,
        "is_active": subscription.is_active,
        "has_devices_limit": subscription.has_devices_limit,
        "has_traffic_limit": subscription.has_traffic_limit,
        "url": remna_user.subscription_url,
        #
        "subscription_id": str(subscription.user_remna_id),
        "subscription_status": subscription.get_status,
        "plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "traffic_used": i18n_format_bytes_to_unit(
            remna_user.used_traffic_bytes,
            min_unit=ByteUnitKey.MEGABYTE,
        ),
        "traffic_limit": (
            i18n_format_bytes_to_unit(remna_user.traffic_limit_bytes)
            if remna_user.traffic_limit_bytes and remna_user.traffic_limit_bytes > 0
            else i18n_format_traffic_limit(-1)
        ),
        "device_limit": i18n_format_device_limit(subscription.device_limit),
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at),
        #
        "squads": squads,
        "first_connected_at": (
            remna_user.first_connected.strftime(DATETIME_FORMAT)
            if remna_user.first_connected
            else False
        ),
        "last_connected_at": (
            remna_user.online_at.strftime(DATETIME_FORMAT)
            if remna_user.online_at
            else False
        ),
        "node_name": last_node.name if last_node else False,
        #
        "plan_name": subscription.plan.name,
        "plan_type": subscription.plan.type,
        "plan_traffic_limit": i18n_format_traffic_limit(subscription.plan.traffic_limit),
        "plan_device_limit": i18n_format_device_limit(subscription.plan.device_limit),
        "plan_duration": plan_duration_display,
        "plan_price": plan_price_display,
        "can_edit": not subscription.is_expired,
    }


@inject
async def devices_getter(
    dialog_manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
    remnawave_service: FromDishka[RemnawaveService],
    extra_device_service: FromDishka[ExtraDeviceService],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    subscription = await subscription_service.get_current(target_telegram_id)

    if not subscription:
        raise ValueError(f"Current subscription for user '{target_telegram_id}' not found")

    devices = await remnawave_service.get_devices_user(target_user) or []

    formatted_devices = [
        {
            "short_hwid": device.hwid[:32],
            "hwid": device.hwid,
            "platform": device.platform,
            "device_model": device.device_model,
            "user_agent": device.user_agent,
        }
        for device in devices
    ]

    # Сортируем устройства по hwid для стабильного порядка
    formatted_devices.sort(key=lambda d: d["hwid"])

    dialog_manager.dialog_data["hwid_map"] = formatted_devices

    # Вычисляем лимиты
    extra_devices = subscription.extra_devices or 0
    plan_device_limit = subscription.plan.device_limit if subscription.plan and subscription.plan.device_limit > 0 else 0
    actual_device_limit = subscription.device_limit
    device_limit_bonus = max(0, actual_device_limit - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0

    # Получаем активные покупки доп. устройств
    purchases = []
    try:
        purchases = await extra_device_service.get_active_by_subscription(subscription.id)
    except Exception:
        pass

    # Создаём объединённый список слотов устройств
    device_slots = []
    slot_hwid_map = {}
    slot_purchase_map = {}
    devices_copy = list(formatted_devices)
    slot_index = 0

    # Для безлимитных планов: показываем кол-во устройств + 1 базовый слот
    effective_plan_device_limit = plan_device_limit
    if plan_device_limit == 0:
        effective_plan_device_limit = len(devices_copy) + 1

    # 1. Базовые слоты подписки
    for i in range(effective_plan_device_limit):
        if devices_copy:
            device = devices_copy.pop(0)
            slot = {
                "id": str(slot_index),
                "slot_type": "base",
                "days_display": "∞",
                "show_days_display": False,
                "is_occupied": True,
                "show_delete_button": False,
                "show_trash_button": True,
                "show_pending_text": False,
                "show_delete_now_button": False,
                "platform_display": device["platform"],
                "device_info": i18n.get("frg-empty-slot"),
            }
            slot_hwid_map[str(slot_index)] = device["short_hwid"]
        else:
            slot = {
                "id": str(slot_index),
                "slot_type": "base",
                "days_display": "∞",
                "show_days_display": False,
                "is_occupied": False,
                "show_delete_button": False,
                "show_trash_button": False,
                "show_pending_text": False,
                "show_delete_now_button": False,
                "platform_display": "",
                "device_info": i18n.get("frg-empty-slot"),
            }
        device_slots.append(slot)
        slot_index += 1

    # 2. Бонусные слоты
    for i in range(device_limit_bonus):
        if devices_copy:
            device = devices_copy.pop(0)
            slot = {
                "id": str(slot_index),
                "slot_type": "bonus",
                "days_display": "∞",
                "show_days_display": False,
                "is_occupied": True,
                "show_delete_button": False,
                "show_trash_button": True,
                "show_pending_text": False,
                "show_delete_now_button": False,
                "platform_display": device["platform"],
                "device_info": i18n.get("frg-empty-slot"),
            }
            slot_hwid_map[str(slot_index)] = device["short_hwid"]
        else:
            slot = {
                "id": str(slot_index),
                "slot_type": "bonus",
                "days_display": "∞",
                "show_days_display": False,
                "is_occupied": False,
                "show_delete_button": False,
                "show_trash_button": False,
                "show_pending_text": False,
                "show_delete_now_button": False,
                "platform_display": "",
                "device_info": i18n.get("frg-empty-slot"),
            }
        device_slots.append(slot)
        slot_index += 1

    # 3. Слоты из покупок (с ограниченным сроком)
    for p in purchases:
        for j in range(p.device_count):
            if p.days_remaining > 1000:
                days_display = "∞"
            else:
                days_word = i18n.get("frg-day-plural", value=p.days_remaining)
                days_display = f"{p.days_remaining} {days_word}"
            if devices_copy:
                device = devices_copy.pop(0)
                slot = {
                    "id": str(slot_index),
                    "purchase_id": str(p.id),
                    "slot_type": "extra",
                    "days_display": days_display,
                    "show_days_display": True,
                    "is_occupied": True,
                    "pending_deletion": p.pending_deletion,
                    "show_delete_button": False,
                    "show_trash_button": True,
                    "show_pending_text": False,
                    "show_delete_now_button": False,
                    "platform_display": device["platform"],
                    "device_info": i18n.get("frg-empty-slot"),
                }
                slot_hwid_map[str(slot_index)] = device["short_hwid"]
                slot_purchase_map[str(slot_index)] = p.id
            else:
                slot = {
                    "id": str(slot_index),
                    "purchase_id": str(p.id),
                    "slot_type": "extra",
                    "days_display": days_display,
                    "show_days_display": True,
                    "is_occupied": False,
                    "pending_deletion": p.pending_deletion,
                    "show_delete_button": not p.pending_deletion,
                    "show_trash_button": False,
                    "show_pending_text": False,
                    "show_delete_now_button": p.pending_deletion,
                    "platform_display": "",
                    "device_info": i18n.get("frg-empty-slot"),
                }
                slot_purchase_map[str(slot_index)] = p.id
            device_slots.append(slot)
            slot_index += 1

    # Сохраняем данные для обработчиков
    dialog_manager.dialog_data["slot_hwid_map"] = slot_hwid_map
    dialog_manager.dialog_data["slot_purchase_map"] = slot_purchase_map

    return {
        "current_count": len(devices),
        "max_count": i18n_format_device_limit(subscription.device_limit),
        "devices": formatted_devices,
        "device_slots": device_slots,
        "has_device_slots": 1 if device_slots else 0,
        "devices_empty": len(device_slots) == 0,
    }


async def discount_getter(
    dialog_manager: DialogManager,
    **kwargs: Any,
) -> dict[str, Any]:
    return {"percentages": [0, 5, 10, 25, 40, 50, 70, 80, 100]}


@inject
async def points_getter(
    dialog_manager: DialogManager,
    user_service: FromDishka[UserService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    **kwargs: Any,
) -> dict[str, Any]:
    from src.core.enums import BalanceMode, ReferralRewardType
    
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    formatted_points = [
        {
            "operation": "+" if value > 0 else "",
            "balance": value,
        }
        for value in [5, -5, 25, -25, 50, -50, 100, -100]
    ]
    
    # Получаем настройки
    settings = await settings_service.get()
    balance_mode = settings.features.balance_mode
    is_balance_enabled = settings.features.balance_enabled
    
    # Get referral balance
    referral_balance = await referral_service.get_pending_rewards_amount(
        target_telegram_id,
        ReferralRewardType.MONEY,
    )

    is_referral_enable = await settings_service.is_referral_enable()

    return {
        "current_balance": str(target_user.balance),
        "referral_balance": str(referral_balance),
        "balance": formatted_points,
        "is_balance_separate": 1 if balance_mode == BalanceMode.SEPARATE else 0,
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_referral_enable": 1 if is_referral_enable else 0,
        "show_finance_details": 1 if (is_balance_enabled or is_referral_enable) else 0,
        "discount_value": target_user.purchase_discount or 0,
        "pending_balance_amount": dialog_manager.dialog_data.get("pending_balance_amount", None),
        "has_pending_balance": 1 if dialog_manager.dialog_data.get("pending_balance_amount") is not None else 0,
    }


@inject
async def referral_points_getter(
    dialog_manager: DialogManager,
    referral_service: FromDishka[ReferralService],
    **kwargs: Any,
) -> dict[str, Any]:
    from src.core.enums import ReferralRewardType
    
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]

    formatted_points = [
        {
            "operation": "+" if value > 0 else "",
            "balance": value,
        }
        for value in [5, -5, 25, -25, 50, -50, 100, -100]
    ]
    
    # Get referral balance
    referral_balance = await referral_service.get_pending_rewards_amount(
        target_telegram_id,
        ReferralRewardType.MONEY,
    )

    return {
        "current_referral_balance": str(referral_balance),
        "balance": formatted_points,
        "pending_referral_amount": dialog_manager.dialog_data.get("pending_referral_amount", None),
        "has_pending_referral": 1 if dialog_manager.dialog_data.get("pending_referral_amount") is not None else 0,
    }


async def traffic_limit_getter(
    dialog_manager: DialogManager,
    **kwargs: Any,
) -> dict[str, Any]:
    formatted_traffic = [
        {
            "traffic_limit": i18n_format_traffic_limit(value),
            "traffic": value,
        }
        for value in [100, 200, 300, 500, 1024, 2048, -1]
    ]

    return {"traffic_count": formatted_traffic}


async def device_limit_getter(
    dialog_manager: DialogManager,
    **kwargs: Any,
) -> dict[str, Any]:
    return {
        "devices_count": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0],
    }


@inject
async def squads_getter(
    dialog_manager: DialogManager,
    subscription_service: FromDishka[SubscriptionService],
    remnawave: FromDishka[RemnawaveSDK],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    subscription = await subscription_service.get_current(telegram_id=target_telegram_id)

    if not subscription:
        raise ValueError(f"Current subscription for user '{target_telegram_id}' not found")

    internal_response = await remnawave.internal_squads.get_internal_squads()
    internal_dict = {s.uuid: s.name for s in internal_response.internal_squads}
    internal_squads_names = ", ".join(
        internal_dict.get(squad, str(squad)) for squad in subscription.internal_squads
    )

    external_response = await remnawave.external_squads.get_external_squads()
    external_dict = {s.uuid: s.name for s in external_response.external_squads}
    external_squad_uuid = subscription.external_squad[0] if subscription.external_squad else None
    external_squad_name = (
        external_dict.get(external_squad_uuid) if external_squad_uuid else 0
    )

    return {
        "internal_squads": internal_squads_names or 0,
        "external_squad": external_squad_name or 0,
    }


@inject
async def internal_squads_getter(
    dialog_manager: DialogManager,
    subscription_service: FromDishka[SubscriptionService],
    remnawave: FromDishka[RemnawaveSDK],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    subscription = await subscription_service.get_current(telegram_id=target_telegram_id)

    if not subscription:
        raise ValueError(f"Current subscription for user '{target_telegram_id}' not found")

    result = await remnawave.internal_squads.get_internal_squads()

    squads = [
        {
            "uuid": squad.uuid,
            "name": squad.name,
            "selected": True if squad.uuid in subscription.internal_squads else False,
        }
        for squad in result.internal_squads
    ]

    return {"squads": squads}


@inject
async def external_squads_getter(
    dialog_manager: DialogManager,
    subscription_service: FromDishka[SubscriptionService],
    remnawave: FromDishka[RemnawaveSDK],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    subscription = await subscription_service.get_current(telegram_id=target_telegram_id)

    if not subscription:
        raise ValueError(f"Current subscription for user '{target_telegram_id}' not found")

    result = await remnawave.external_squads.get_external_squads()
    existing_squad_uuids = {squad.uuid for squad in result.external_squads}

    external_squad_uuid = subscription.external_squad[0] if subscription.external_squad else None
    if external_squad_uuid and external_squad_uuid not in existing_squad_uuids:
        subscription.external_squad = None
        external_squad_uuid = None

    squads = [
        {
            "uuid": squad.uuid,
            "name": squad.name,
            "selected": True if squad.uuid == external_squad_uuid else False,
        }
        for squad in result.external_squads
    ]

    return {"squads": squads}


@inject
async def expire_time_getter(
    dialog_manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    subscription = await subscription_service.get_current(target_telegram_id)

    if not subscription:
        raise ValueError(f"Current subscription for user '{target_telegram_id}' not found")

    formatted_durations = []
    for value in [1, -1, 3, -3, 7, -7, 14, -14, 30, -30]:
        key, kw = i18n_format_days(value)
        key2, kw2 = i18n_format_days(-value)
        formatted_durations.append(
            {
                "operation": "+" if value > 0 else "-",
                "duration": i18n.get(key, **kw) if value > 0 else i18n.get(key2, **kw2),
                "days": value,
            }
        )

    return {
        "expire_time": i18n_format_expire_time(subscription.expire_at),
        "durations": formatted_durations,
    }


@inject
async def transactions_getter(
    dialog_manager: DialogManager,
    transaction_service: FromDishka[TransactionService],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    transactions = await transaction_service.get_by_user(target_telegram_id)

    if not transactions:
        raise ValueError(f"Transactions not found for user '{target_telegram_id}'")

    formatted_transactions = [
        {
            "payment_id": transaction.payment_id,
            "status": transaction.status,
            "created_at": transaction.created_at.strftime(DATETIME_FORMAT),  # type: ignore[union-attr]
        }
        for transaction in transactions
    ]

    return {"transactions": list(reversed(formatted_transactions))}


@inject
async def transaction_getter(
    dialog_manager: DialogManager,
    transaction_service: FromDishka[TransactionService],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    selected_transaction = dialog_manager.dialog_data["selected_transaction"]
    transaction = await transaction_service.get(selected_transaction)

    if not transaction:
        raise ValueError(
            f"Transaction '{selected_transaction}' not found for user '{target_telegram_id}'"
        )

    return {
        "is_test": transaction.is_test,
        "payment_id": str(transaction.payment_id),
        "purchase_type": transaction.purchase_type,
        "transaction_status": transaction.status,
        "gateway_type": transaction.gateway_type,
        "final_amount": format_price(transaction.pricing.final_amount, transaction.currency),
        "discount_percent": transaction.pricing.discount_percent,
        "original_amount": format_price(transaction.pricing.original_amount, transaction.currency),
        "created_at": transaction.created_at.strftime(DATETIME_FORMAT),  # type: ignore[union-attr]
        "plan_name": transaction.plan.name,
        "plan_type": transaction.plan.type,
        "plan_traffic_limit": i18n_format_traffic_limit(transaction.plan.traffic_limit),
        "plan_device_limit": i18n_format_device_limit(transaction.plan.device_limit),
        "plan_duration": i18n_format_days(transaction.plan.duration),
        "plan_price": format_price(transaction.pricing.original_amount, transaction.currency),
    }


@inject
async def give_access_getter(
    dialog_manager: DialogManager,
    user_service: FromDishka[UserService],
    plan_service: FromDishka[PlanService],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    plans = await plan_service.get_allowed_plans()

    if not plans:
        raise ValueError("Allowed plans not found")

    formatted_plans = [
        {
            "plan_name": plan.name,
            "plan_id": plan.id,
            "selected": True if target_telegram_id in plan.allowed_user_ids else False,
        }
        for plan in plans
    ]

    return {"plans": formatted_plans}


@inject
async def give_subscription_getter(
    dialog_manager: DialogManager,
    plan_service: FromDishka[PlanService],
    **kwargs: Any,
) -> dict[str, Any]:
    plans = await plan_service.get_all()

    if not plans:
        raise ValueError("Plans not found")

    # Фильтруем только активные планы
    active_plans = [plan for plan in plans if plan.is_active]

    formatted_plans = [
        {
            "plan_name": plan.name,
            "plan_id": plan.id,
        }
        for plan in active_plans
    ]

    return {"plans": formatted_plans}


@inject
async def subscription_duration_getter(
    dialog_manager: DialogManager,
    plan_service: FromDishka[PlanService],
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
    **kwargs: Any,
) -> dict[str, Any]:
    selected_plan_id = dialog_manager.dialog_data["selected_plan_id"]
    plan = await plan_service.get(selected_plan_id)

    if not plan:
        raise ValueError(f"Plan '{selected_plan_id}' not found")

    durations = [duration.model_dump() for duration in plan.durations]
    
    # Получаем текущую подписку пользователя для отображения опции "Не изменять"
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    subscription = await subscription_service.get_current(target_telegram_id)
    
    # Вычисляем оставшееся время текущей подписки с точностью до часов и минут
    has_current_subscription = False
    current_remaining_display = ""
    if subscription and subscription.expire_at:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        remaining = subscription.expire_at - now
        if remaining.total_seconds() > 0:
            has_current_subscription = True
            # Форматируем оставшееся время (дни, часы, минуты)
            total_seconds = int(remaining.total_seconds())
            days = total_seconds // 86400
            hours = (total_seconds % 86400) // 3600
            minutes = (total_seconds % 3600) // 60
            
            parts = []
            if days > 0:
                if days == 1:
                    parts.append(f"{days} день")
                elif 2 <= days <= 4:
                    parts.append(f"{days} дня")
                else:
                    parts.append(f"{days} дней")
            if hours > 0 or (days > 0 and minutes > 0):
                if hours == 1:
                    parts.append(f"{hours} час")
                elif 2 <= hours <= 4:
                    parts.append(f"{hours} часа")
                else:
                    parts.append(f"{hours} часов")
            if days == 0 and hours == 0:
                parts.append(f"{minutes} минут")
            
            current_remaining_display = " ".join(parts) if parts else "менее минуты"
    
    return {
        "durations": durations,
        "has_current_subscription": has_current_subscription,
        "current_remaining_display": current_remaining_display,
    }


@inject
async def role_getter(
    dialog_manager: DialogManager,
    user_service: FromDishka[UserService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    # Проверяем, есть ли отложенная роль, иначе берём текущую
    selected_role = dialog_manager.dialog_data.get("pending_role", target_user.role)

    roles = [
        {
            "role": role,
            "name": i18n.get("role", role=role.value),
            "selected": 1 if role == selected_role else 0,
        }
        for role in UserRole
    ]
    return {"roles": roles}


@inject
async def sync_getter(  # noqa: C901
    dialog_manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
    remnawave: FromDishka[RemnawaveSDK],
    **kwargs: Any,
) -> dict[str, Any]:
    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]
    target_user = await user_service.get(telegram_id=target_telegram_id)

    if not target_user:
        raise ValueError(f"User '{target_telegram_id}' not found")

    bot_subscription = await subscription_service.get_current(target_telegram_id)

    remna_subscription: Optional[RemnaSubscriptionDto] = None

    try:
        result = await remnawave.users.get_users_by_telegram_id(telegram_id=str(target_telegram_id))
    except NotFoundError:
        result = None

    if result:
        remna_user = result[0]
        remna_subscription = RemnaSubscriptionDto.from_remna_user(remna_user)

    bot_info = ""
    remna_info = ""
    bot_version = ""
    remna_version = ""

    internal_response = await remnawave.internal_squads.get_internal_squads()
    internal_dict = {s.uuid: s.name for s in internal_response.internal_squads}

    if bot_subscription:
        internal_squads_names = ", ".join(
            internal_dict.get(squad, str(squad)) for squad in bot_subscription.internal_squads
        )
        bot_kwargs = {
            "id": str(bot_subscription.user_remna_id),
            "status": bot_subscription.status,
            "url": bot_subscription.url,
            "traffic_limit": i18n_format_traffic_limit(bot_subscription.traffic_limit),
            "device_limit": i18n_format_device_limit(bot_subscription.device_limit),
            "expire_time": i18n_format_expire_time(bot_subscription.expire_at),
            "internal_squads": internal_squads_names or 0,
            "external_squad": str(bot_subscription.external_squad)
            if bot_subscription.external_squad
            else 0,
            "traffic_limit_strategy": bot_subscription.traffic_limit_strategy,
            "tag": bot_subscription.tag or False,
            "updated_at": bot_subscription.updated_at,
        }
        bot_info = i18n.get(
            "msg-user-sync-subscription",
            **get_translated_kwargs(i18n, bot_kwargs),
        )

    if remna_subscription:
        internal_squads_names = ", ".join(
            internal_dict.get(squad, str(squad)) for squad in remna_subscription.internal_squads
        )
        remna_kwargs = {
            "id": str(remna_subscription.uuid),
            "status": remna_subscription.status,
            "url": remna_subscription.url,
            "traffic_limit": i18n_format_traffic_limit(remna_subscription.traffic_limit),
            "device_limit": i18n_format_device_limit(remna_subscription.device_limit),
            "expire_time": i18n_format_expire_time(remna_subscription.expire_at),
            "internal_squads": internal_squads_names or 0,
            "external_squad": str(remna_subscription.external_squad)
            if remna_subscription.external_squad
            else 0,
            "traffic_limit_strategy": remna_subscription.traffic_limit_strategy or False,
            "tag": remna_subscription.tag or False,
            "updated_at": remna_user.updated_at,
        }
        remna_info = i18n.get(
            "msg-user-sync-subscription",
            **get_translated_kwargs(i18n, remna_kwargs),
        )

    bot_time = bot_subscription.updated_at if bot_subscription else None
    remna_time = remna_user.updated_at if remna_subscription else None

    if bot_subscription and remna_subscription:
        bot_time = bot_subscription.updated_at
        remna_time = remna_user.updated_at

        if bot_time > remna_time:
            bot_version, remna_version = "NEWER", "OLDER"
        elif bot_time < remna_time:
            bot_version, remna_version = "OLDER", "NEWER"
        else:
            bot_version = remna_version = "UNKNOWN"
    else:
        bot_version = remna_version = "UNKNOWN"

    bot_version = i18n.get("msg-user-sync-version", version=bot_version)
    remna_version = i18n.get("msg-user-sync-version", version=remna_version)

    return {
        "has_bot_subscription": bool(bot_subscription),
        "has_remna_subscription": bool(remna_subscription),
        "bot_version": bot_version,
        "remna_version": remna_version,
        "bot_subscription": bot_info,
        "remna_subscription": remna_info,
    }


@inject
async def referrals_getter(
    dialog_manager: DialogManager,
    user_service: FromDishka[UserService],
    referral_service: FromDishka[ReferralService],
    **kwargs: Any,
) -> dict[str, Any]:
    from src.core.enums import ReferralRewardType

    target_telegram_id = dialog_manager.dialog_data["target_telegram_id"]

    referral_count = await referral_service.get_referral_count(target_telegram_id)
    bonus_money = await referral_service.get_bonus_rewards_amount(
        telegram_id=target_telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    bonus_days = await referral_service.get_bonus_rewards_amount(
        telegram_id=target_telegram_id,
        reward_type=ReferralRewardType.EXTRA_DAYS,
    )
    cashback_money = await referral_service.get_cashback_rewards_amount(
        telegram_id=target_telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    cashback_days = await referral_service.get_cashback_rewards_amount(
        telegram_id=target_telegram_id,
        reward_type=ReferralRewardType.EXTRA_DAYS,
    )

    bonus_parts = []
    if bonus_money > 0:
        bonus_parts.append(f"{bonus_money} ₽")
    if bonus_days > 0:
        bonus_parts.append(f"{bonus_days} дн.")
    total_bonus = " | ".join(bonus_parts) if bonus_parts else "0"

    cashback_parts = []
    if cashback_money > 0:
        cashback_parts.append(f"{cashback_money} ₽")
    if cashback_days > 0:
        cashback_parts.append(f"{cashback_days} дн.")
    total_cashback = " | ".join(cashback_parts) if cashback_parts else "0"

    return {
        "referral_count": referral_count,
        "total_bonus": total_bonus,
        "total_cashback": total_cashback,
    }


@inject
async def referrals_list_getter(
    dialog_manager: DialogManager,
    user_service: FromDishka[UserService],
    referral_service: FromDishka[ReferralService],
    **kwargs: Any,
) -> dict[str, Any]:
    from src.core.enums import ReferralRewardType

    target_telegram_id = dialog_manager.dialog_data.get("target_telegram_id")
    if not target_telegram_id:
        start_data = cast(dict[str, Any], dialog_manager.start_data)
        target_telegram_id = start_data["target_telegram_id"]
        dialog_manager.dialog_data["target_telegram_id"] = target_telegram_id

    referrals = await referral_service.get_referrals_by_referrer(target_telegram_id)

    referral_items = []
    for ref in referrals:
        referred_user = ref.referred
        total_earned_money = await referral_service.get_rewards_total_by_referral_id(
            ref.id, ReferralRewardType.MONEY
        )
        total_earned_days = await referral_service.get_rewards_total_by_referral_id(
            ref.id, ReferralRewardType.EXTRA_DAYS
        )
        name = referred_user.name or str(referred_user.telegram_id)

        parts = []
        if total_earned_money > 0:
            parts.append(f"{total_earned_money:.0f} ₽")
        if total_earned_days > 0:
            parts.append(f"{total_earned_days:.0f} дн.")
        total_display = " | ".join(parts) if parts else "0"

        referral_items.append({
            "telegram_id": str(referred_user.telegram_id),
            "name": name,
            "total_spent": total_display,
        })

    return {
        "referrals": referral_items,
        "referral_count": len(referral_items),
        "has_referrals": 1 if len(referral_items) > 0 else 0,
    }
