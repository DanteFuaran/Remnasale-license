import asyncio
import re
import subprocess
import time
from typing import Any

import httpx
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram_dialog import DialogManager
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from loguru import logger

from src.__version__ import __version__
from src.core.config import AppConfig
from src.core.constants import USER_KEY, CONFIG_KEY
from src.core.enums import BannerFormat
from src.core.storage.keys import UpdateMessageKey
from src.core.utils.formatters import format_user_log as log
from src.core.utils.license_host import get_license_host
from src.infrastructure.redis.repository import RedisRepository
from src.services.settings import SettingsService
from src.services.update_checker import (
    UPDATE_CLOSE,
    UPDATE_NOW,
    UpdateCheckerService,
)

_HOST_PROJECT_DIR = "/opt/remnasale"

# Track pending restart confirmations: {user_id: (timestamp, message_id)}
_restart_confirmations: dict[int, tuple[float, int]] = {}


def _parse_version(version_str: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in version_str.strip().split("."))
    except (ValueError, AttributeError):
        return (0, 0, 0)


@inject
async def bot_management_getter(
    dialog_manager: DialogManager,
    **kwargs: Any,
) -> dict[str, Any]:
    """Getter for bot management page."""
    return {
        "bot_version": __version__,
    }


@inject
async def on_check_update(
    callback: CallbackQuery,
    button: Any,
    manager: DialogManager,
    update_checker_service: FromDishka[UpdateCheckerService],
) -> None:
    """Check for updates. If available, send a notification with Update Now button."""
    user = manager.middleware_data.get(USER_KEY)
    logger.info(f"{log(user)} Checking for updates from bot management menu")

    try:
        license_server = await get_license_host(update_checker_service.redis_repository.client, update_checker_service.config)
        license_key = update_checker_service.config.build.license_key.get_secret_value()
        if not license_server or not license_key:
            raise ValueError("LICENSE_SERVER or LICENSE_KEY not configured")
        url = f"{license_server.rstrip('/')}/api/v1/version"
        logger.info(f"[update_check] Fetching version from license server")

        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(url, params={"key": license_key})
            response.raise_for_status()
            data = response.json()
            remote = data.get("version", "")
        logger.info(f"[update_check] local={__version__}, remote={remote}")

        if _parse_version(remote) > _parse_version(__version__):
            # Update available — send notification with action buttons
            await callback.answer()
            keyboard = InlineKeyboardBuilder()
            keyboard.row(
                InlineKeyboardButton(text="🔄 Обновить сейчас", callback_data=UPDATE_NOW, style="primary"),
            )
            keyboard.row(
                InlineKeyboardButton(text="❌ Закрыть", callback_data=UPDATE_CLOSE, style="danger"),
            )
            await callback.bot.send_message(
                chat_id=callback.from_user.id,
                text=(
                    f"✅ Текущая версия: <code>{__version__}</code>\n"
                    f"⬆️ Доступна версия: <code>{remote}</code>"
                ),
                parse_mode="HTML",
                reply_markup=keyboard.as_markup(),
            )
        else:
            await callback.answer()
            msg = await callback.bot.send_message(
                chat_id=callback.from_user.id,
                text=f"✅ Установлена последняя версия: <code>{__version__}</code>",
                parse_mode="HTML",
            )
            asyncio.create_task(_auto_delete_message(callback.bot, msg, 5))
    except Exception as e:
        logger.error(f"[bot_management] Update check failed: {e}")
        await callback.answer()
        msg = await callback.bot.send_message(
            chat_id=callback.from_user.id,
            text="❌ Не удалось проверить обновления",
        )
        asyncio.create_task(_auto_delete_message(callback.bot, msg, 5))


async def _auto_delete_message(bot, msg, delay: int = 5) -> None:
    """Auto-delete a message after a delay."""
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id=msg.chat.id, message_id=msg.message_id)
    except Exception:
        pass


async def _restart_bot_container() -> None:
    """Restart the bot container via Docker."""
    try:
        subprocess.Popen(
            ["docker", "restart", "-t", "30", "remnasale"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        logger.error(f"[restart] Failed to restart container: {e}")


@inject
async def on_restart_bot(
    callback: CallbackQuery,
    button: Any,
    manager: DialogManager,
    redis_repository: FromDishka[RedisRepository],
) -> None:
    """Restart the bot by stopping the container (docker will auto-restart)."""
    user = manager.middleware_data.get(USER_KEY)
    user_id = callback.from_user.id
    now = time.time()
    bot = callback.bot

    # Check if this is a confirmation (second click within 5 seconds)
    if user_id in _restart_confirmations:
        last_click, warning_msg_id = _restart_confirmations[user_id]
        if now - last_click < 5:
            # Second click within 5s — proceed with restart
            _restart_confirmations.pop(user_id, None)
            logger.info(f"{log(user)} Triggered bot restart from management menu")

            # Answer callback first
            try:
                await callback.answer()
            except Exception:
                pass

            # Delete the warning message before restarting
            try:
                await bot.delete_message(chat_id=user_id, message_id=warning_msg_id)
                logger.debug(f"Deleted restart warning message {warning_msg_id}")
            except Exception as e:
                logger.warning(f"Failed to delete restart warning {warning_msg_id}: {e}")

            # Small delay to ensure Telegram processes the deletion
            await asyncio.sleep(0.3)

            try:
                # Send restart message
                msg = await bot.send_message(
                    chat_id=user_id,
                    text="<b>🔄 Перезапуск бота...</b>\n<i>Бот будет доступен через несколько секунд.</i>",
                    parse_mode="HTML",
                )

                # Save message ref for deletion on startup
                # Format: "{bot_id}:{chat_id}:{message_id}" to support mirror bots
                msg_ref = f"{bot.id}:{msg.chat.id}:{msg.message_id}"
                await redis_repository.set(UpdateMessageKey(), msg_ref, ex=600)  # TTL 10 min

                # Give the message a moment to be sent, then restart
                asyncio.create_task(_restart_bot_container())
            except Exception as e:
                logger.error(f"[bot_management] Restart failed: {e}")
                msg = await bot.send_message(
                    chat_id=user_id,
                    text="❌ Не удалось перезагрузить бота",
                )
                asyncio.create_task(_auto_delete_message(bot, msg, 5))
            return
        else:
            # 5 seconds expired, remove old confirmation and start new one
            _restart_confirmations.pop(user_id, None)

    # First click — show warning notification
    await callback.answer()
    warning_msg = await bot.send_message(
        chat_id=user_id,
        text="⚠️ <b>При повторном нажатии сервер будет перезагружен.</b>",
        parse_mode="HTML",
    )
    _restart_confirmations[user_id] = (now, warning_msg.message_id)
    
    # Auto-delete warning message after 5 seconds if no second click
    async def _revert_restart_warning() -> None:
        await asyncio.sleep(5)
        if user_id in _restart_confirmations and _restart_confirmations[user_id][0] == now:
            _restart_confirmations.pop(user_id, None)
            try:
                await bot.delete_message(chat_id=user_id, message_id=warning_msg.message_id)
            except Exception:
                pass

    asyncio.create_task(_revert_restart_warning())


async def on_back_to_dashboard(callback: CallbackQuery, button: Any, manager: DialogManager):
    """Go back to the dashboard."""
    from src.bot.states import Dashboard
    await manager.start(Dashboard.MAIN)


@inject
async def support_settings_getter(
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Getter for support settings page."""
    current = dialog_manager.dialog_data.get("current_support")
    if not current:
        # Первый вход - загружаем из БД
        settings = await settings_service.get()
        support = settings.features.support
        current = {
            "enabled": support.enabled,
            "recipient": support.recipient,
            "faq_enabled": support.faq_enabled,
            "faq_text": support.faq_text,
        }

    recipient = current.get("recipient") or ""
    faq_text = current.get("faq_text") or ""

    # Форматируем FAQ для превью: разделяем по двойной пустой строке и оборачиваем в blockquote
    faq_preview = ""
    if faq_text.strip():
        blocks = [b.strip() for b in re.split(r'(?m)^\+{3}\s*$', faq_text) if b.strip()]
        faq_preview = "\n".join(f"<blockquote><i>{b}</i></blockquote>" for b in blocks)

    return {
        "support_enabled": 1 if current.get("enabled", True) else 0,
        "support_recipient": recipient,
        "support_has_recipient": 1 if recipient else 0,
        "faq_enabled": 1 if current.get("faq_enabled", False) else 0,
        "faq_text": faq_text,
        "faq_preview": faq_preview,
        "has_faq": 1 if faq_text.strip() else 0,
    }


@inject
async def on_support_click(
    callback: CallbackQuery,
    widget: Any,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Открыть меню настройки поддержки — инициализировать pending state."""
    from src.bot.states import DashboardBotManagement
    settings = await settings_service.get()
    support = settings.features.support
    recipient = support.recipient
    state = {
        "enabled": support.enabled,
        "recipient": recipient,
        "faq_enabled": support.faq_enabled,
        "faq_text": support.faq_text,
    }
    dialog_manager.dialog_data["initial_support"] = state.copy()
    dialog_manager.dialog_data["current_support"] = state.copy()
    await dialog_manager.switch_to(DashboardBotManagement.SUPPORT)


async def on_toggle_support(
    callback: CallbackQuery,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    """Переключить видимость кнопки поддержки (только в pending state)."""
    user = dialog_manager.middleware_data.get(USER_KEY)
    current = dialog_manager.dialog_data.get("current_support", {})
    current["enabled"] = not current.get("enabled", True)
    dialog_manager.dialog_data["current_support"] = current
    logger.info(f"{log(user)} Toggle support enabled (not saved yet) -> {current['enabled']}")


async def on_support_recipient_input(
    message: Message,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    """Ввод получателя поддержки — сохраняет в pending state."""
    from src.bot.states import DashboardBotManagement
    user = dialog_manager.middleware_data.get(USER_KEY)
    recipient = message.text.strip().lstrip("@")
    current = dialog_manager.dialog_data.get("current_support", {})
    current["recipient"] = recipient
    dialog_manager.dialog_data["current_support"] = current
    logger.info(f"{log(user)} Set support recipient (not saved yet) -> {recipient}")

    # Удаляем оба сообщения: пользователя и окно ввода получателя
    bot = dialog_manager.middleware_data.get("bot")
    try:
        await message.delete()
    except Exception:
        pass
    if bot:
        try:
            dlg_msg_id = dialog_manager.current_stack().last_message_id
            await bot.delete_message(chat_id=message.chat.id, message_id=dlg_msg_id)
        except Exception:
            pass

    await dialog_manager.switch_to(DashboardBotManagement.SUPPORT)


async def on_support_cancel(
    callback: CallbackQuery,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    """Отмена — сбросить изменения поддержки без сохранения."""
    from src.bot.states import DashboardBotManagement
    user = dialog_manager.middleware_data.get(USER_KEY)
    dialog_manager.dialog_data.pop("initial_support", None)
    dialog_manager.dialog_data.pop("current_support", None)
    logger.info(f"{log(user)} Cancelled support settings changes")
    await dialog_manager.switch_to(DashboardBotManagement.MAIN)


@inject
async def on_support_accept(
    callback: CallbackQuery,
    widget: Any,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Принять — сохранить изменения поддержки в БД."""
    from src.bot.states import DashboardBotManagement
    user = dialog_manager.middleware_data.get(USER_KEY)
    current = dialog_manager.dialog_data.get("current_support", {})
    if current:
        settings = await settings_service.get()
        settings.features.support.enabled = current.get("enabled", True)
        settings.features.support.recipient = current.get("recipient", "")
        settings.features.support.faq_enabled = current.get("faq_enabled", False)
        settings.features.support.faq_text = current.get("faq_text", "")
        settings.features = settings.features
        await settings_service.update(settings)
        logger.info(f"{log(user)} Accepted and saved support settings: enabled={current.get('enabled')}, recipient={current.get('recipient')}, faq_enabled={current.get('faq_enabled')}")
    dialog_manager.dialog_data.pop("initial_support", None)
    dialog_manager.dialog_data.pop("current_support", None)
    await dialog_manager.switch_to(DashboardBotManagement.MAIN)


async def on_toggle_support_enabled(
    callback: CallbackQuery,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    """Переключить видимость кнопки поддержки (toggle в строке)."""
    user = dialog_manager.middleware_data.get(USER_KEY)
    current = dialog_manager.dialog_data.get("current_support", {})
    current["enabled"] = not current.get("enabled", True)
    dialog_manager.dialog_data["current_support"] = current
    logger.info(f"{log(user)} Toggle support enabled (not saved yet) -> {current['enabled']}")


async def on_toggle_faq_enabled(
    callback: CallbackQuery,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    """Переключить видимость частых вопросов (toggle в строке)."""
    user = dialog_manager.middleware_data.get(USER_KEY)
    current = dialog_manager.dialog_data.get("current_support", {})
    current["faq_enabled"] = not current.get("faq_enabled", False)
    dialog_manager.dialog_data["current_support"] = current
    logger.info(f"{log(user)} Toggle FAQ enabled (not saved yet) -> {current['faq_enabled']}")


async def on_faq_text_input(
    message: Message,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    """Ввод текста FAQ — сохраняет в pending state."""
    from src.bot.states import DashboardBotManagement
    user = dialog_manager.middleware_data.get(USER_KEY)
    faq_text = message.text.strip()
    current = dialog_manager.dialog_data.get("current_support", {})
    current["faq_text"] = faq_text
    dialog_manager.dialog_data["current_support"] = current
    logger.info(f"{log(user)} Set FAQ text (not saved yet), length={len(faq_text)}")

    # Удаляем оба сообщения: пользователя и окно ввода FAQ
    bot = dialog_manager.middleware_data.get("bot")
    try:
        await message.delete()
    except Exception:
        pass
    if bot:
        try:
            dlg_msg_id = dialog_manager.current_stack().last_message_id
            await bot.delete_message(chat_id=message.chat.id, message_id=dlg_msg_id)
        except Exception:
            pass

    await dialog_manager.switch_to(DashboardBotManagement.SUPPORT)


# ── Брендирование ─────────────────────────────────────────────────────

async def _auto_delete(bot, chat_id: int, message_id: int, delay: int = 5) -> None:
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id, message_id)
    except Exception:
        pass


async def branding_getter(
    dialog_manager: DialogManager,
    **kwargs: Any,
) -> dict[str, Any]:
    config: AppConfig = dialog_manager.middleware_data[CONFIG_KEY]
    banners_dir = config.banners_dir
    has_banner = any((banners_dir / f"default.{fmt}").exists() for fmt in BannerFormat)
    return {"has_banner": 1 if has_banner else 0}


async def on_branding_click(
    callback: CallbackQuery,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    from src.bot.states import DashboardBotManagement
    await dialog_manager.switch_to(DashboardBotManagement.BRANDING)


async def on_banner_photo(
    message: Message,
    widget: Any,
    dialog_manager: DialogManager,
) -> None:
    from src.bot.states import DashboardBotManagement
    user = dialog_manager.middleware_data.get(USER_KEY)
    config: AppConfig = dialog_manager.middleware_data[CONFIG_KEY]
    bot = dialog_manager.middleware_data.get("bot")
    banners_dir = config.banners_dir
    banners_dir.mkdir(parents=True, exist_ok=True)

    photo = message.photo[-1] if message.photo else None
    if not photo:
        try:
            await message.delete()
        except Exception:
            pass
        note = await bot.send_message(
            chat_id=message.chat.id,
            text="⚠️ Необходимо отправить фото (JPG или PNG).",
        )
        asyncio.create_task(_auto_delete(bot, message.chat.id, note.message_id))
        return

    # Удаляем старые баннеры
    for fmt in BannerFormat:
        old = banners_dir / f"default.{fmt}"
        if old.exists():
            old.unlink()

    # Скачиваем новый
    dest = banners_dir / "default.jpg"
    await bot.download(photo, destination=dest)
    logger.info(f"{log(user)} Banner updated via Telegram")

    # Удаляем сообщение пользователя
    try:
        await message.delete()
    except Exception:
        pass

    # Удаляем диалоговое окно
    if bot:
        try:
            dlg_msg_id = dialog_manager.current_stack().last_message_id
            await bot.delete_message(chat_id=message.chat.id, message_id=dlg_msg_id)
        except Exception:
            pass

    # Переключаем состояние диалога на BRANDING
    # Рендер диалога произойдёт ПОСЛЕ завершения хендлера (aiogram-dialog middleware)
    await dialog_manager.switch_to(DashboardBotManagement.BRANDING)

    # Уведомление отправляем с задержкой, чтобы оно появилось ПОСЛЕ нового меню
    chat_id = message.chat.id

    async def _send_banner_success_notification():
        await asyncio.sleep(0.5)
        note = await bot.send_message(
            chat_id=chat_id,
            text="✅ Банер успешно установлен!",
        )
        asyncio.create_task(_auto_delete(bot, chat_id, note.message_id))

    asyncio.create_task(_send_banner_success_notification())
