from aiogram_dialog import DialogManager, StartMode, SubManager
from aiogram_dialog.widgets.kbd import Button
from aiogram.types import CallbackQuery, Message
from aiogram.exceptions import TelegramBadRequest
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from aiogram import Bot
from redis.asyncio import Redis
from fluentogram import TranslatorRunner
import asyncio
import os
import shutil
import json
import sqlite3
import urllib.request
import urllib.error
import subprocess
from datetime import datetime
from loguru import logger
from src.core.constants import USER_KEY
from src.core.utils.message_payload import MessagePayload
from src.core.utils.validators import is_double_click
from src.core.utils.formatters import format_user_log as log
from src.services.notification import NotificationService
from src.services.settings import SettingsService
from src.infrastructure.database.models.dto import UserDto
from src.infrastructure.taskiq.tasks.importer import sync_bot_to_panel_task
from src.infrastructure.redis.repository import RedisRepository


async def on_back_to_dashboard(callback: CallbackQuery, button, manager: DialogManager):
    """Обработчик для кнопки 'Назад' - возвращает в предыдущее состояние."""
    from src.bot.states import DashboardDB, Dashboard
    
    # Получаем текущее состояние
    current_state = manager.current_context().state
    
    # Если на странице загрузки, вернуться в главное меню БД
    if current_state == DashboardDB.LOAD:
        await manager.switch_to(DashboardDB.MAIN)
    # Если на главном меню БД, открыть Dashboard
    elif current_state == DashboardDB.MAIN:
        await manager.start(Dashboard.MAIN, mode=StartMode.RESET_STACK)


@inject
async def on_save_db(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
    settings_service: FromDishka[SettingsService],
    bot: FromDishka[Bot],
):
    """Сохранение бэкапа: в папку backups + отправка в Telegram (как force_backup)."""
    from src.infrastructure.taskiq.tasks.auto_backup import _do_backup, _send_to_telegram
    from datetime import timezone as _tz, timedelta as _td
    user = manager.middleware_data.get(USER_KEY)

    backup_dir = "/opt/remnasale/backups"
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%d-%m-%y_%H-%M")
    filepath = os.path.join(backup_dir, f"Remnasale_{timestamp}.sql.gz")

    loop = asyncio.get_event_loop()
    success = await loop.run_in_executor(None, _do_backup, filepath)

    if not success:
        if os.path.exists(filepath):
            os.remove(filepath)
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-db-save-failed"),
        )
        return

    # Отправка в Telegram (если настроен автобэкап)
    backup_settings = await settings_service.get_auto_backup_settings()
    if backup_settings.bot_token and backup_settings.chat_id:
        sent = await loop.run_in_executor(
            None, _send_to_telegram, backup_settings.bot_token, backup_settings.chat_id, filepath, True
        )
        if sent:
            now_iso = datetime.now(tz=_tz.utc).isoformat()
            await settings_service.set_auto_backup_last_run(now_iso)

    # Отправка DEV-пользователям
    from src.core.enums import UserRole
    from aiogram.types import FSInputFile, InlineKeyboardButton
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    devs = await notification_service.user_service.get_by_role(role=UserRole.DEV)
    size = os.path.getsize(filepath) if os.path.exists(filepath) else 0
    size_str = f"{size // 1024}K" if size < 1024 * 1024 else f"{size / 1024 / 1024:.1f}M"
    msk = _tz(_td(hours=3))
    date_str = datetime.now(tz=msk).strftime("%d.%m.%Y %H:%M МСК")
    dev_caption = (
        f"🤖 Система: Создание бэкапа!\n\n"
        f"📦 Приложение: Remnasale\n"
        f"📁 База данных\n"
        f"📏 Размер: {size_str}\n"
        f"📅 {date_str}\n\n"
        f"✅ Бекап создан вручную"
    )
    for dev in devs:
        try:
            close_btn = InlineKeyboardButton(text="✅ Закрыть", callback_data="Notification:CLOSE", style="success")
            kb = InlineKeyboardBuilder()
            kb.row(close_btn)
            await bot.send_document(
                chat_id=dev.telegram_id,
                document=FSInputFile(filepath),
                caption=dev_caption,
                reply_markup=kb.as_markup(),
            )
        except Exception as e:
            logger.warning(f"[save_db] Failed to send backup to dev {dev.telegram_id}: {e}")


async def on_load_db(callback: CallbackQuery, button, manager: DialogManager):
    from src.bot.states import DashboardDB
    await manager.switch_to(DashboardDB.LOAD)


@inject
async def on_export_db(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
):
    """Экспорт базы данных PostgreSQL в SQLite файл для просмотра в DB Browser."""
    user = manager.middleware_data.get(USER_KEY)
    
    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-db-export-start"),
    )
    
    export_dir = "/opt/remnasale/backups/db"
    os.makedirs(export_dir, exist_ok=True)
    sqlite_path = os.path.join(export_dir, "remnasale.db")
    
    # Удаляем старый файл если есть
    if os.path.exists(sqlite_path):
        os.remove(sqlite_path)
    
    loop = asyncio.get_event_loop()
    
    def export_to_sqlite():
        db_password = os.getenv('DATABASE_PASSWORD', 'remnasale')
        db_user = os.getenv('DATABASE_USER', 'remnasale')
        db_name = os.getenv('DATABASE_NAME', 'remnasale')
        db_host = os.getenv('DATABASE_HOST', 'remnasale-db')
        db_port = os.getenv('DATABASE_PORT', '5432')
        
        env = os.environ.copy()
        env['PGPASSWORD'] = db_password
        
        # Создаём SQLite базу данных
        sqlite_conn = sqlite3.connect(sqlite_path)
        sqlite_cursor = sqlite_conn.cursor()
        
        try:
            # Получаем список всех таблиц из PostgreSQL
            tables_cmd = [
                'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                '-t', '-c', "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;"
            ]
            result = subprocess.run(tables_cmd, capture_output=True, text=True, env=env)
            tables = [t.strip() for t in result.stdout.strip().split('\n') if t.strip()]
            
            logger.info(f"Found {len(tables)} tables to export: {tables}")
            
            for table in tables:
                if not table or table == 'alembic_version':
                    continue

                # Validate table name to prevent SQL injection
                import re as _re
                if not _re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', table):
                    logger.warning(f"Skipping invalid table name: {table}")
                    continue
                    
                # Получаем структуру таблицы
                columns_cmd = [
                    'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                    '-t', '-c', f"SELECT column_name, data_type FROM information_schema.columns WHERE table_name = '{table}' ORDER BY ordinal_position;"
                ]
                result = subprocess.run(columns_cmd, capture_output=True, text=True, env=env)
                
                columns = []
                sqlite_columns = []
                for line in result.stdout.strip().split('\n'):
                    if '|' in line:
                        parts = [p.strip() for p in line.split('|')]
                        if len(parts) >= 2:
                            col_name = parts[0]
                            col_type = parts[1]
                            columns.append(col_name)
                            # Преобразуем PostgreSQL типы в SQLite
                            if 'int' in col_type or 'serial' in col_type:
                                sqlite_type = 'INTEGER'
                            elif 'bool' in col_type:
                                sqlite_type = 'INTEGER'
                            elif 'timestamp' in col_type or 'date' in col_type:
                                sqlite_type = 'TEXT'
                            elif 'numeric' in col_type or 'decimal' in col_type or 'float' in col_type or 'double' in col_type:
                                sqlite_type = 'REAL'
                            elif 'uuid' in col_type:
                                sqlite_type = 'TEXT'
                            elif 'json' in col_type:
                                sqlite_type = 'TEXT'
                            elif 'ARRAY' in col_type:
                                sqlite_type = 'TEXT'
                            else:
                                sqlite_type = 'TEXT'
                            sqlite_columns.append(f'"{col_name}" {sqlite_type}')
                
                if not columns:
                    continue
                
                # Создаём таблицу в SQLite
                create_sql = f'CREATE TABLE IF NOT EXISTS "{table}" ({", ".join(sqlite_columns)})'
                sqlite_cursor.execute(create_sql)
                logger.debug(f"Created table: {table}")
                
                # Получаем данные из PostgreSQL в CSV формате
                columns_quoted = ", ".join([f'"{c}"' for c in columns])
                select_query = f'SELECT {columns_quoted} FROM "{table}";'
                data_cmd = [
                    'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                    '-t', '-A', '-F', '\t',
                    '-c', select_query
                ]
                result = subprocess.run(data_cmd, capture_output=True, text=True, env=env)
                
                # Вставляем данные в SQLite
                rows_inserted = 0
                for line in result.stdout.strip().split('\n'):
                    if not line:
                        continue
                    values = line.split('\t')
                    
                    # Дополняем недостающие поля None (когда последние колонки NULL, psql не выводит разделитель)
                    while len(values) < len(columns):
                        values.append('')
                    
                    # Пропускаем строки с избыточными полями
                    if len(values) > len(columns):
                        logger.warning(f"Row has {len(values)} fields, expected {len(columns)}, skipping")
                        continue
                    
                    # Преобразуем значения
                    processed_values = []
                    for v in values:
                        if v == '' or v == '\\N':
                            processed_values.append(None)
                        elif v == 't':
                            processed_values.append(1)
                        elif v == 'f':
                            processed_values.append(0)
                        else:
                            processed_values.append(v)
                    
                    placeholders = ', '.join(['?' for _ in columns])
                    insert_sql = f'INSERT INTO "{table}" VALUES ({placeholders})'
                    try:
                        sqlite_cursor.execute(insert_sql, processed_values)
                        rows_inserted += 1
                    except Exception as e:
                        logger.warning(f"Error inserting row into {table}: {e}")
                
                logger.info(f"Exported {rows_inserted} rows from table: {table}")
            
            sqlite_conn.commit()
            return True, None
            
        except Exception as e:
            logger.exception(f"Export error: {e}")
            return False, str(e)
        finally:
            sqlite_conn.close()
    
    try:
        success, error_msg = await loop.run_in_executor(None, export_to_sqlite)
        
        if success and os.path.exists(sqlite_path) and os.path.getsize(sqlite_path) > 0:
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-db-export-success",
                    i18n_kwargs={"path": sqlite_path},
                ),
            )
            logger.info(f"Database exported successfully to {sqlite_path}")
        else:
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-db-export-error",
                    i18n_kwargs={"error": error_msg or "Unknown error"},
                ),
            )
    except Exception as e:
        logger.exception(f"Export failed: {e}")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(
                i18n_key="ntf-db-export-error",
                i18n_kwargs={"error": str(e)},
            ),
        )


@inject
async def on_import_db(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
):
    await callback.answer(i18n.get("ntf-import-in-dev"), show_alert=True)


@inject
async def on_convert_db(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
):
    await callback.answer(i18n.get("ntf-convert-in-dev"), show_alert=True)


@inject
async def backups_getter(dialog_manager: DialogManager, **kwargs) -> dict:
    """Геттер списка последних бэкапов для меню загрузки."""
    backup_dir = "/opt/remnasale/backups"
    try:
        files = [f for f in os.listdir(backup_dir) if os.path.isfile(os.path.join(backup_dir, f))]
    except Exception:
        files = []

    # сортируем по времени модификации (новые первыми)
    files = sorted(files, key=lambda n: os.path.getmtime(os.path.join(backup_dir, n)), reverse=True)
    items = []
    for idx, name in enumerate(files[:10]):
        items.append({"index": str(idx), "name": name, "path": os.path.join(backup_dir, name)})

    dialog_manager.dialog_data["backups_map"] = {str(idx): item["path"] for idx, item in enumerate(items)}

    return {"backups": items, "has_backups": len(items) > 0}


def _fix_old_schema(db_host: str, db_port: str, db_user: str, db_name: str, env: dict):
    """Фиксит несовместимости схемы старых дампов перед миграциями.

    - external_squad uuid → uuid[] (plans, subscriptions)
    - plans.description, plans.tag, plans.traffic_limit_strategy — добавляет если нет
    - subscriptions.traffic_limit_strategy, subscriptions.tag — добавляет если нет
    """
    # Список фиксов: (table, column, old_type_prefix, conversion_sql)
    uuid_array_fixes = [
        ("plans", "external_squad"),
        ("subscriptions", "external_squad"),
    ]
    for table, col in uuid_array_fixes:
        # Проверяем тип колонки
        check_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-t', '-A', '-c',
            f"SELECT data_type FROM information_schema.columns "
            f"WHERE table_name = '{table}' AND column_name = '{col}'"
        ]
        result = subprocess.run(check_cmd, capture_output=True, text=True, env=env)
        col_type = result.stdout.strip().lower() if result.returncode == 0 else ""

        if col_type == 'uuid':
            # Конвертируем uuid → uuid[]
            fix_sql = (
                f"ALTER TABLE {table} ADD COLUMN {col}_new uuid[]; "
                f"UPDATE {table} SET {col}_new = CASE WHEN {col} IS NOT NULL THEN ARRAY[{col}] ELSE NULL END; "
                f"ALTER TABLE {table} DROP COLUMN {col}; "
                f"ALTER TABLE {table} RENAME COLUMN {col}_new TO {col};"
            )
            fix_cmd = [
                'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                '-c', fix_sql
            ]
            fix_result = subprocess.run(fix_cmd, capture_output=True, text=True, env=env)
            if fix_result.returncode == 0:
                logger.info(f"Fixed {table}.{col}: uuid → uuid[]")
            else:
                logger.warning(f"Failed to fix {table}.{col}: {fix_result.stderr}")
        elif col_type:
            logger.debug(f"{table}.{col} is already {col_type}, no fix needed")


def _ensure_dev_role(db_host: str, db_port: str, db_user: str, db_name: str, env: dict, dev_telegram_id: int):
    """Гарантирует что пользователь-разработчик имеет роль DEV после восстановления бэкапа."""
    check_cmd = [
        'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
        '-t', '-A', '-c',
        f"SELECT role FROM users WHERE telegram_id = {dev_telegram_id}"
    ]
    result = subprocess.run(check_cmd, capture_output=True, text=True, env=env)
    current_role = result.stdout.strip() if result.returncode == 0 else ""

    if current_role and current_role != 'DEV':
        update_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-c',
            f"UPDATE users SET role = 'DEV' WHERE telegram_id = {dev_telegram_id}"
        ]
        update_result = subprocess.run(update_cmd, capture_output=True, text=True, env=env)
        if update_result.returncode == 0:
            logger.info(f"Restored DEV role for telegram_id={dev_telegram_id} (was '{current_role}')")
        else:
            logger.warning(f"Failed to restore DEV role: {update_result.stderr}")
    elif current_role == 'DEV':
        logger.debug(f"DEV user {dev_telegram_id} already has role 'DEV'")
    else:
        logger.info(f"DEV user {dev_telegram_id} not found in restored backup, will be created on next startup")


def _cleanup_orphan_subscriptions(db_host: str, db_port: str, db_user: str, db_name: str, env: dict):
    """Удаляет орфанные подписки после восстановления бэкапа.
    
    У каждого пользователя должна быть ровно одна подписка (current_subscription_id).
    Все остальные — артефакты, которые могут вызвать некорректную синхронизацию тегов.
    """
    cleanup_cmd = [
        'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
        '-t', '-A', '-c',
        "DELETE FROM subscriptions s USING users u "
        "WHERE u.telegram_id = s.user_telegram_id AND s.id != u.current_subscription_id"
    ]
    result = subprocess.run(cleanup_cmd, capture_output=True, text=True, env=env)
    if result.returncode == 0:
        # Парсим количество удалённых строк
        output = result.stderr.strip() if result.stderr else ""
        deleted = 0
        for part in output.split():
            if part.isdigit():
                deleted = int(part)
                break
        if deleted > 0:
            logger.info(f"Cleaned up {deleted} orphan subscription(s) after backup restore")
        else:
            logger.debug("No orphan subscriptions found after backup restore")
    else:
        logger.warning(f"Failed to cleanup orphan subscriptions: {result.stderr}")


def _restore_db_from_file(file_path: str, db_password: str, db_user: str, db_name: str, db_host: str, db_port: str):
    """Общая функция восстановления БД из файла дампа.
    Используется обоими handler'ами: on_restore_backup и on_db_file_input.
    Возвращает (success: bool, error_msg: str | None).
    """
    import re
    import gzip
    import tempfile
    env = os.environ.copy()
    env['PGPASSWORD'] = db_password

    # Распаковываем .gz файлы во временный файл
    work_path = file_path
    temp_file = None
    if file_path.endswith('.gz'):
        try:
            tmp_fd, tmp_path = tempfile.mkstemp(suffix='.sql')
            os.close(tmp_fd)
            with gzip.open(file_path, 'rb') as gz_f:
                with open(tmp_path, 'wb') as out_f:
                    out_f.write(gz_f.read())
            work_path = tmp_path
            temp_file = tmp_path
            logger.info(f"Decompressed {file_path} -> {tmp_path}")
        except Exception as e:
            logger.error(f"Failed to decompress backup: {e}")
            return False, f"Decompression failed: {e}"

    try:
        # Предобработка дампа
        try:
            with open(work_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Удаление \restrict/\unrestrict строк
            content = re.sub(r'^\\restrict\s+.*$', '', content, flags=re.MULTILINE)
            content = re.sub(r'^\\unrestrict\s+.*$', '', content, flags=re.MULTILINE)

            # Обработка pg_dumpall формата (содержит \connect к другой БД)
            # Определяем имя чужой БД в дампе (например remnashop)
            foreign_db_names = set(re.findall(
                r'^\\connect\s+(\w+)\s*$', content, re.MULTILINE
            )) - {'template1', 'postgres', db_name}

            if foreign_db_names:
                foreign_db = next(iter(foreign_db_names))
                logger.info(f"Detected pg_dumpall format with foreign database '{foreign_db}', converting to single-db dump")

                # Извлекаем секцию от \connect <foreign_db> до конца дампа БД
                pattern = re.compile(
                    r'^\\connect\s+' + re.escape(foreign_db) + r'\s*$',
                    re.MULTILINE
                )
                match = pattern.search(content)
                if match:
                    db_section = content[match.end():]
                    # Обрезаем до маркера конца дампа БД (если есть)
                    end_match = re.search(
                        r'^--\s*PostgreSQL database cluster dump complete\s*$',
                        db_section, re.MULTILINE
                    )
                    if end_match:
                        db_section = db_section[:end_match.start()]
                    # Удаляем остаточные строки: \connect, DROP/CREATE DATABASE, DROP/CREATE/ALTER ROLE
                    db_section = re.sub(r'^\\connect\s+.*$', '', db_section, flags=re.MULTILINE)
                    db_section = re.sub(r'^(DROP|CREATE|ALTER)\s+(DATABASE|ROLE)\s+.*$', '', db_section, flags=re.MULTILINE)
                    content = db_section
                    logger.info(f"Extracted single-db section from pg_dumpall (foreign db: '{foreign_db}')")

            # Заменяем OWNER TO <любой_пользователь> на текущего
            content = re.sub(r'OWNER TO \w+;', f'OWNER TO {db_user};', content)

            with open(work_path, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info("Preprocessed dump: cleanup complete")
        except Exception as e:
            logger.warning(f"Failed to preprocess dump: {e}")

        # 0. Сохраняем текущие платёжные шлюзы перед восстановлением
        saved_gateways = []
        try:
            save_cmd = [
                'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                '-t', '-A', '-c',
                "SELECT json_agg(row_to_json(pg)) FROM payment_gateways pg"
            ]
            save_result = subprocess.run(save_cmd, capture_output=True, text=True, env=env)
            if save_result.returncode == 0 and save_result.stdout.strip():
                saved_gateways = json.loads(save_result.stdout.strip())
                if saved_gateways:
                    logger.info(f"Saved {len(saved_gateways)} payment gateways before restore")
                else:
                    saved_gateways = []
        except Exception as e:
            logger.warning(f"Failed to save payment gateways before restore: {e}")

        # 1. Завершаем все активные соединения к базе
        logger.info("Step 1: Terminating active connections")
        terminate_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', 'postgres',
            '-c', f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '{db_name}' AND pid <> pg_backend_pid();"
        ]
        subprocess.run(terminate_cmd, capture_output=True, text=True, env=env)

        # 2. Очистка базы - удаляем схему и создаём заново
        logger.info("Step 2: Dropping and recreating schema")
        drop_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-c', 'DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public; GRANT ALL ON SCHEMA public TO public;'
        ]
        result_drop = subprocess.run(drop_cmd, capture_output=True, text=True, env=env)
        if result_drop.returncode != 0:
            logger.error(f"Failed to drop schema: {result_drop.stderr}")
            return False, f"Drop schema failed: {result_drop.stderr}"

        # 3. Восстановление базы данных из дампа
        logger.info(f"Step 3: Restoring database from backup: {work_path}")
        restore_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-v', 'ON_ERROR_STOP=0',
            '-f', work_path
        ]
        result_restore = subprocess.run(restore_cmd, capture_output=True, text=True, env=env, timeout=300)
        if result_restore.returncode != 0:
            logger.warning(f"Restore completed with warnings (code {result_restore.returncode}): {result_restore.stderr}")
        logger.info("Database restored successfully")

        # 3.5. Фиксим схему старых дампов — uuid → uuid[] для external_squad
        _fix_old_schema(db_host, db_port, db_user, db_name, env)

        # 3.6. Восстанавливаем роль DEV для текущего разработчика
        dev_telegram_id = os.getenv('BOT_DEV_ID', '')
        if dev_telegram_id:
            _ensure_dev_role(db_host, db_port, db_user, db_name, env, int(dev_telegram_id))

        # 3.7. Удаляем дубликаты подписок — у каждого пользователя должна быть только одна (current)
        _cleanup_orphan_subscriptions(db_host, db_port, db_user, db_name, env)

        # 4. Восстанавливаем платёжные шлюзы
        if saved_gateways:
            try:
                check_cmd = [
                    'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                    '-t', '-A', '-c',
                    "SELECT type FROM payment_gateways"
                ]
                check_result = subprocess.run(check_cmd, capture_output=True, text=True, env=env)
                restored_types = set()
                if check_result.returncode == 0 and check_result.stdout.strip():
                    restored_types = set(check_result.stdout.strip().split('\n'))

                max_idx_cmd = [
                    'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                    '-t', '-A', '-c',
                    "SELECT COALESCE(MAX(order_index), 0) FROM payment_gateways"
                ]
                max_idx_result = subprocess.run(max_idx_cmd, capture_output=True, text=True, env=env)
                next_order = int(max_idx_result.stdout.strip()) + 1 if max_idx_result.returncode == 0 else 1

                restored_count = 0
                for gw in saved_gateways:
                    gw_type = gw.get('type')
                    if gw_type and gw_type not in restored_types:
                        settings_json = json.dumps(gw.get('settings')) if gw.get('settings') else 'null'
                        currency = gw.get('currency', 'USD')
                        insert_cmd = [
                            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                            '-c',
                            f"INSERT INTO payment_gateways (order_index, type, currency, is_active, settings) "
                            f"VALUES ({next_order}, '{gw_type}', '{currency}', false, '{settings_json}'::jsonb)"
                        ]
                        insert_result = subprocess.run(insert_cmd, capture_output=True, text=True, env=env)
                        if insert_result.returncode == 0:
                            logger.info(f"Restored missing payment gateway '{gw_type}' (inactive)")
                            restored_count += 1
                            next_order += 1
                        else:
                            logger.warning(f"Failed to restore gateway '{gw_type}': {insert_result.stderr}")
                    elif gw_type and gw_type in restored_types:
                        settings_json = json.dumps(gw.get('settings')) if gw.get('settings') else 'null'
                        is_active = 'true' if gw.get('is_active') else 'false'
                        currency = gw.get('currency', 'USD')
                        update_cmd = [
                            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                            '-c',
                            f"UPDATE payment_gateways SET settings = '{settings_json}'::jsonb, "
                            f"is_active = {is_active}, currency = '{currency}' "
                            f"WHERE type = '{gw_type}'"
                        ]
                        update_result = subprocess.run(update_cmd, capture_output=True, text=True, env=env)
                        if update_result.returncode == 0:
                            logger.info(f"Updated payment gateway '{gw_type}' with saved settings")
                        else:
                            logger.warning(f"Failed to update gateway '{gw_type}': {update_result.stderr}")

                if restored_count > 0:
                    seq_cmd = [
                        'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
                        '-c',
                        "SELECT setval('payment_gateways_id_seq', (SELECT COALESCE(MAX(id), 1) FROM payment_gateways))"
                    ]
                    subprocess.run(seq_cmd, capture_output=True, text=True, env=env)
                    logger.info(f"Restored {restored_count} missing payment gateway(s) after backup")
            except Exception as e:
                logger.warning(f"Failed to restore missing payment gateways: {e}")

        return True, None

    except Exception as e:
        logger.error(f"restore_db error: {e}")
        return False, str(e)

    finally:
        if temp_file and os.path.exists(temp_file):
            os.remove(temp_file)
            logger.debug(f"Removed temp file: {temp_file}")


async def _run_post_restore_sync(user, notification_service, i18n, manager):
    """Общая функция запуска синхронизации после восстановления из бэкапа."""
    sync_notification = await notification_service.notify_user(
        user=user,
        payload=MessagePayload.not_deleted(
            i18n_key="ntf-importer-sync-started",
            add_close_button=False,
        ),
    )

    try:
        task = await sync_bot_to_panel_task.kiq(True)
        result = await task.wait_result(timeout=300)
        sync_result = result.return_value

        if sync_notification:
            await sync_notification.delete()

        if sync_result:
            logger.info(f"Sync completed: {sync_result}")

            total = sync_result.get('total_bot_users', 0)
            deleted_from_bot = sync_result.get('deleted_from_bot', 0)
            created = sync_result.get('created', 0)
            updated = sync_result.get('updated', 0)
            skipped = sync_result.get('skipped', 0)
            errors = sync_result.get('errors', 0)
            error_users = sync_result.get('error_users', {})
            skipped_users = sync_result.get('skipped_users', [])

            sync_message = f"{i18n.get('ntf-db-sync-title')}\n\n"

            if deleted_from_bot > 0:
                sync_message += "🧹 <b>Очистка после восстановления:</b>\n"
                sync_message += "<blockquote>"
                sync_message += f"• Удалено из бота (без подписок): {deleted_from_bot}\n"
                sync_message += "</blockquote>\n"

            if skipped_users and skipped > 0:
                sync_message += f"{i18n.get('ntf-db-sync-skipped-title')}\n"
                sync_message += "<blockquote>"
                for user_info in skipped_users:
                    sync_message += f"• {user_info}\n"
                sync_message += "</blockquote>"

            if error_users:
                if skipped_users and skipped > 0:
                    sync_message += "\n"
                sync_message += f"{i18n.get('ntf-db-sync-errors-title')}\n"
                sync_message += "<blockquote>"
                for user_info, error_reason in error_users.items():
                    sync_message += f"• {user_info}\n  {error_reason}\n\n"
                sync_message += "</blockquote>"

            if error_users or (skipped_users and skipped > 0):
                sync_message += "\n"
            sync_message += f"{i18n.get('ntf-db-sync-stats-title')}\n"
            sync_message += "<blockquote>"
            sync_message += f"{i18n.get('ntf-db-sync-stats-total', total=total)}\n"
            sync_message += f"{i18n.get('ntf-db-sync-stats-created', created=created)}\n"
            sync_message += f"{i18n.get('ntf-db-sync-stats-updated', updated=updated)}\n"
            sync_message += f"{i18n.get('ntf-db-sync-stats-skipped', skipped=skipped)}\n"
            sync_message += f"{i18n.get('ntf-db-sync-stats-errors', errors=errors)}"
            sync_message += "</blockquote>"

            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    text=sync_message,
                    add_close_button=True,
                    close_button_style="success",
                    auto_delete_after=None,
                ),
            )
            logger.info("Sync report notification sent")
        else:
            logger.warning("Sync returned no results")
    except Exception as sync_error:
        logger.exception(f"Sync with panel failed: {sync_error}")
        if sync_notification:
            await sync_notification.delete()
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(
                i18n_key="ntf-db-sync-error",
                i18n_kwargs={"error": str(sync_error)},
                add_close_button=True,
                auto_delete_after=None,
            ),
        )

    from src.bot.states import Dashboard
    await manager.start(Dashboard.MAIN, mode=StartMode.RESET_STACK)


@inject
async def on_restore_backup(
    callback: CallbackQuery,
    widget: Button,
    sub_manager: SubManager,
    notification_service: FromDishka[NotificationService],
    i18n: FromDishka[TranslatorRunner],
    redis_client: FromDishka[Redis],
):
    selected_index = sub_manager.item_id
    logger.info(f"Selected backup index: {selected_index}")

    user = sub_manager.middleware_data.get(USER_KEY)
    manager = sub_manager.manager

    backups_map = manager.dialog_data.get("backups_map", {})
    local_path = backups_map.get(selected_index)
    if not local_path or not os.path.exists(local_path):
        logger.error(f"Backup file not found: {local_path}")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
        )
        return

    if is_double_click(manager, key=f"restore_backup_confirm_{selected_index}", cooldown=5):
        logger.info(f"Starting database restore from backup: {local_path}")
    else:
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-double-click-confirm"),
        )
        return

    db_password = os.getenv('DATABASE_PASSWORD', 'remnasale')
    db_user_name = os.getenv('DATABASE_USER', 'remnasale')
    db_name = os.getenv('DATABASE_NAME', 'remnasale')
    db_host = os.getenv('DATABASE_HOST', 'remnasale-db')
    db_port = os.getenv('DATABASE_PORT', '5432')

    loop = asyncio.get_event_loop()

    preparing_notification = await notification_service.notify_user(
        user=user,
        payload=MessagePayload.not_deleted(
            i18n_key="ntf-db-restore-preparing",
            add_close_button=False,
        ),
    )

    try:
        success, error_msg = await loop.run_in_executor(
            None, _restore_db_from_file, local_path, db_password, db_user_name, db_name, db_host, db_port
        )

        if success:
            # Очистка Redis кэша
            cache_keys = await redis_client.keys("cache:*")
            if cache_keys:
                await redis_client.delete(*cache_keys)
                logger.info(f"Cleared {len(cache_keys)} cache keys")

            # Применяем миграции
            def apply_migrations():
                result = subprocess.run(
                    ["alembic", "-c", "src/infrastructure/database/alembic.ini", "upgrade", "head"],
                    capture_output=True, text=True, cwd="/opt/remnasale"
                )
                if result.returncode != 0:
                    logger.error(f"Migration failed: {result.stderr}")
                    return False
                logger.info("Migrations applied successfully")
                return True

            migrations_success = await loop.run_in_executor(None, apply_migrations)
            if not migrations_success:
                if preparing_notification:
                    await preparing_notification.delete()
                await notification_service.notify_user(
                    user=user,
                    payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
                )
                return

            if preparing_notification:
                await preparing_notification.delete()

            # Запускаем синхронизацию с панелью
            await _run_post_restore_sync(
                user=user,
                notification_service=notification_service,
                i18n=i18n,
                manager=manager,
            )
        else:
            logger.error(f"Restore from backup failed: {error_msg}")
            if preparing_notification:
                await preparing_notification.delete()
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
            )
    except Exception as e:
        logger.exception(f"Restore from backup failed: {e}")
        if preparing_notification:
            await preparing_notification.delete()
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
        )


@inject
async def on_db_file_input(
    message: Message,
    widget,
    dialog_manager: DialogManager,
    bot: FromDishka[Bot],
    notification_service: FromDishka[NotificationService],
    redis_client: FromDishka[Redis],
    i18n: FromDishka[TranslatorRunner],
):
    # Обработка загруженного файла дампа: сохраняем в ./backups и восстанавливаем
    dialog_manager.show_mode = None
    user = dialog_manager.middleware_data.get(USER_KEY)

    document = message.document
    if not document:
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-importer-not-file"),
        )
        return

    backup_dir = "/opt/remnasale/backups"
    os.makedirs(backup_dir, exist_ok=True)
    safe_filename = os.path.basename(document.file_name)
    local_file_path = os.path.join(backup_dir, safe_filename)

    file = await bot.get_file(document.file_id)
    if not file.file_path:
        logger.error(f"File path not found for document '{document.file_name}'")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-importer-db-failed"),
        )
        return

    try:
        await bot.download_file(file.file_path, destination=local_file_path)
        logger.info(f"Received DB dump: {local_file_path}")

        db_password = os.getenv('DATABASE_PASSWORD', 'remnasale')
        db_user_name = os.getenv('DATABASE_USER', 'remnasale')
        db_name = os.getenv('DATABASE_NAME', 'remnasale')
        db_host = os.getenv('DATABASE_HOST', 'remnasale-db')
        db_port = os.getenv('DATABASE_PORT', '5432')

        loop = asyncio.get_event_loop()

        preparing_notification = await notification_service.notify_user(
            user=user,
            payload=MessagePayload.not_deleted(
                i18n_key="ntf-db-restore-preparing",
                add_close_button=False,
            ),
        )

        try:
            success, error_msg = await loop.run_in_executor(
                None, _restore_db_from_file, local_file_path, db_password, db_user_name, db_name, db_host, db_port
            )

            if success:
                # Очистка Redis кэша
                cache_keys = await redis_client.keys("cache:*")
                if cache_keys:
                    await redis_client.delete(*cache_keys)
                    logger.info(f"Cleared {len(cache_keys)} cache keys")

                # Применяем миграции
                def apply_migrations():
                    result = subprocess.run(
                        ["alembic", "-c", "src/infrastructure/database/alembic.ini", "upgrade", "head"],
                        capture_output=True, text=True, cwd="/opt/remnasale"
                    )
                    if result.returncode != 0:
                        logger.error(f"Migration failed: {result.stderr}")
                        return False
                    logger.info("Migrations applied successfully")
                    return True

                migrations_success = await loop.run_in_executor(None, apply_migrations)
                if not migrations_success:
                    if preparing_notification:
                        await preparing_notification.delete()
                    await notification_service.notify_user(
                        user=user,
                        payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
                    )
                    return

                if preparing_notification:
                    await preparing_notification.delete()

                # Запускаем синхронизацию с панелью
                await _run_post_restore_sync(
                    user=user,
                    notification_service=notification_service,
                    i18n=i18n,
                    manager=dialog_manager,
                )
            else:
                logger.error(f"Restore from file failed: {error_msg}")
                if preparing_notification:
                    await preparing_notification.delete()
                await notification_service.notify_user(
                    user=user,
                    payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
                )
        except Exception as e:
            logger.exception(f"Restore from file failed: {e}")
            if preparing_notification:
                await preparing_notification.delete()
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
            )
    except Exception as e:
        logger.exception(f"Failed to download file: {e}")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-db-restore-failed"),
        )


@inject
async def on_delete_backup(
    callback: CallbackQuery,
    widget: Button,
    sub_manager: SubManager,
    notification_service: FromDishka[NotificationService],
    i18n: FromDishka[TranslatorRunner],
):
    """Удаление выбранного файла бэкапа."""
    selected_index = sub_manager.item_id
    logger.info(f"Deleting backup with index: {selected_index}")

    user = sub_manager.middleware_data.get(USER_KEY)
    manager = sub_manager.manager

    backups_map = manager.dialog_data.get("backups_map", {})
    local_path = backups_map.get(selected_index)
    
    if not local_path or not os.path.exists(local_path):
        logger.error(f"Backup file not found: {local_path}")
        await callback.answer(i18n.get("ntf-file-not-found"), show_alert=True)
        return

    try:
        os.remove(local_path)
        logger.info(f"Backup file deleted: {local_path}")
        await callback.answer(i18n.get("ntf-backup-deleted"), show_alert=False)
        
        # Обновляем окно чтобы отобразить изменения
        from src.bot.states import DashboardDB
        await manager.switch_to(DashboardDB.LOAD)
    except Exception as e:
        logger.exception(f"Failed to delete backup: {e}")
        await callback.answer(i18n.get("ntf-delete-error"), show_alert=True)


@inject
async def on_export_backup_to_db(
    callback: CallbackQuery,
    widget: Button,
    sub_manager: SubManager,
    notification_service: FromDishka[NotificationService],
    bot: FromDishka[Bot],
    i18n: FromDishka[TranslatorRunner],
):
    """Конвертация выбранного бэкапа в SQLite и отправка в Telegram."""
    selected_index = sub_manager.item_id
    logger.info(f"Exporting backup with index: {selected_index}")

    user = sub_manager.middleware_data.get(USER_KEY)
    manager = sub_manager.manager

    backups_map = manager.dialog_data.get("backups_map", {})
    backup_path = backups_map.get(selected_index)
    
    if not backup_path or not os.path.exists(backup_path):
        logger.error(f"Backup file not found: {backup_path}")
        await callback.answer(i18n.get("ntf-file-not-found"), show_alert=True)
        return
    
    # Убираем всплывающее уведомление
    await callback.answer()
    
    # Отправляем сообщение о конвертации
    status_msg = await bot.send_message(
        chat_id=user.telegram_id,
        text=i18n.get("ntf-db-convert-in-progress"),
    )
    
    export_dir = "/opt/remnasale/backups/db"
    os.makedirs(export_dir, exist_ok=True)
    
    # Используем фиксированное имя для sqlite файла
    sqlite_path = os.path.join(export_dir, "sql_convert.db")
    
    # Удаляем старый файл если есть
    if os.path.exists(sqlite_path):
        os.remove(sqlite_path)
    
    loop = asyncio.get_event_loop()
    
    def export_backup_to_sqlite():
        db_password = os.getenv('DATABASE_PASSWORD', 'remnasale')
        db_user = os.getenv('DATABASE_USER', 'remnasale')
        db_name = os.getenv('DATABASE_NAME', 'remnasale')
        db_host = os.getenv('DATABASE_HOST', 'remnasale-db')
        db_port = os.getenv('DATABASE_PORT', '5432')
        
        env = os.environ.copy()
        env['PGPASSWORD'] = db_password
        
        # Создаём временную базу для восстановления бэкапа
        temp_db_name = f"temp_export_{selected_index}"
        
        try:
            # Создаём временную БД
            create_db_cmd = [
                'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', 'postgres',
                '-c', f'DROP DATABASE IF EXISTS {temp_db_name};'
            ]
            subprocess.run(create_db_cmd, capture_output=True, text=True, env=env)
            
            create_db_cmd = [
                'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', 'postgres',
                '-c', f'CREATE DATABASE {temp_db_name};'
            ]
            result = subprocess.run(create_db_cmd, capture_output=True, text=True, env=env)
            if result.returncode != 0:
                return False, f"Failed to create temp DB: {result.stderr}"
            
            # Восстанавливаем бэкап во временную БД
            work_path = backup_path
            temp_file = None
            if backup_path.endswith('.gz'):
                import gzip
                import tempfile
                tmp_fd, tmp_path = tempfile.mkstemp(suffix='.sql')
                os.close(tmp_fd)
                with gzip.open(backup_path, 'rb') as gz_f:
                    with open(tmp_path, 'wb') as out_f:
                        out_f.write(gz_f.read())
                work_path = tmp_path
                temp_file = tmp_path

            with open(work_path, 'r') as f:
                restore_cmd = [
                    'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', temp_db_name
                ]
                result = subprocess.run(restore_cmd, stdin=f, capture_output=True, text=True, env=env)
                if result.returncode != 0:
                    logger.warning(f"Restore warnings: {result.stderr}")

            if temp_file and os.path.exists(temp_file):
                os.remove(temp_file)
            
            # Создаём SQLite базу данных
            sqlite_conn = sqlite3.connect(sqlite_path)
            sqlite_cursor = sqlite_conn.cursor()
            
            try:
                # Получаем список всех таблиц
                tables_cmd = [
                    'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', temp_db_name,
                    '-t', '-c', "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;"
                ]
                result = subprocess.run(tables_cmd, capture_output=True, text=True, env=env)
                tables = [t.strip() for t in result.stdout.strip().split('\n') if t.strip()]
                
                for table in tables:
                    if not table or table == 'alembic_version':
                        continue
                        
                    # Получаем структуру таблицы
                    columns_cmd = [
                        'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', temp_db_name,
                        '-t', '-c', f"SELECT column_name, data_type FROM information_schema.columns WHERE table_name = '{table}' ORDER BY ordinal_position;"
                    ]
                    result = subprocess.run(columns_cmd, capture_output=True, text=True, env=env)
                    
                    columns = []
                    sqlite_columns = []
                    for line in result.stdout.strip().split('\n'):
                        if '|' in line:
                            parts = [p.strip() for p in line.split('|')]
                            if len(parts) >= 2:
                                col_name = parts[0]
                                col_type = parts[1]
                                columns.append(col_name)
                                # Преобразуем PostgreSQL типы в SQLite
                                if 'int' in col_type or 'serial' in col_type:
                                    sqlite_type = 'INTEGER'
                                elif 'bool' in col_type:
                                    sqlite_type = 'INTEGER'
                                elif 'timestamp' in col_type or 'date' in col_type:
                                    sqlite_type = 'TEXT'
                                elif 'numeric' in col_type or 'decimal' in col_type or 'float' in col_type or 'double' in col_type:
                                    sqlite_type = 'REAL'
                                elif 'uuid' in col_type:
                                    sqlite_type = 'TEXT'
                                elif 'json' in col_type:
                                    sqlite_type = 'TEXT'
                                elif 'ARRAY' in col_type:
                                    sqlite_type = 'TEXT'
                                else:
                                    sqlite_type = 'TEXT'
                                sqlite_columns.append(f'"{col_name}" {sqlite_type}')
                    
                    if not columns:
                        continue
                    
                    # Создаём таблицу в SQLite
                    create_sql = f'CREATE TABLE IF NOT EXISTS "{table}" ({", ".join(sqlite_columns)})'
                    sqlite_cursor.execute(create_sql)
                    
                    # Получаем данные из PostgreSQL
                    columns_quoted = ", ".join([f'"{c}"' for c in columns])
                    select_query = f'SELECT {columns_quoted} FROM "{table}";'
                    data_cmd = [
                        'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', temp_db_name,
                        '-t', '-A', '-F', '\t',
                        '-c', select_query
                    ]
                    result = subprocess.run(data_cmd, capture_output=True, text=True, env=env)
                    
                    # Вставляем данные в SQLite
                    for line in result.stdout.strip().split('\n'):
                        if not line:
                            continue
                        values = line.split('\t')
                        
                        # Дополняем недостающие поля None (когда последние колонки NULL, psql не выводит разделитель)
                        while len(values) < len(columns):
                            values.append('')
                        
                        # Пропускаем строки с избыточными полями
                        if len(values) > len(columns):
                            logger.warning(f"Row has {len(values)} fields, expected {len(columns)}, skipping")
                            continue
                        
                        processed_values = []
                        for v in values:
                            if v == '' or v == '\\N':
                                processed_values.append(None)
                            elif v == 't':
                                processed_values.append(1)
                            elif v == 'f':
                                processed_values.append(0)
                            else:
                                processed_values.append(v)
                        
                        placeholders = ', '.join(['?' for _ in columns])
                        insert_sql = f'INSERT INTO "{table}" VALUES ({placeholders})'
                        try:
                            sqlite_cursor.execute(insert_sql, processed_values)
                        except Exception as e:
                            logger.warning(f"Error inserting row into {table}: {e}")
                
                sqlite_conn.commit()
                return True, None
                
            finally:
                sqlite_conn.close()
                # Удаляем временную БД
                drop_db_cmd = [
                    'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', 'postgres',
                    '-c', f'DROP DATABASE IF EXISTS {temp_db_name};'
                ]
                subprocess.run(drop_db_cmd, capture_output=True, text=True, env=env)
                
        except Exception as e:
            logger.exception(f"Export backup error: {e}")
            # Очистка временной БД в случае ошибки
            drop_db_cmd = [
                'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', 'postgres',
                '-c', f'DROP DATABASE IF EXISTS {temp_db_name};'
            ]
            subprocess.run(drop_db_cmd, capture_output=True, text=True, env=env)
            return False, str(e)
    
    try:
        success, error_msg = await loop.run_in_executor(None, export_backup_to_sqlite)
        
        if success and os.path.exists(sqlite_path) and os.path.getsize(sqlite_path) > 0:
            # Удаляем сообщение о конвертации
            try:
                await status_msg.delete()
            except Exception:
                pass
            
            # Отправляем файл с кнопкой закрытия
            from aiogram.types import FSInputFile, InlineKeyboardMarkup, InlineKeyboardButton
            
            db_file = FSInputFile(sqlite_path, filename="sql_convert.db")
            
            # Создаем кнопку "Закрыть" с крестиком
            close_button = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=i18n.get("btn-db-close"), callback_data="delete_message", style="danger")]
            ])
            
            await bot.send_document(
                chat_id=user.telegram_id,
                document=db_file,
                caption=i18n.get("ntf-db-convert-success"),
                reply_markup=close_button
            )
            logger.info(f"Backup exported and sent to Telegram: {sqlite_path}")
        else:
            try:
                await status_msg.delete()
            except Exception:
                pass
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-db-export-error",
                    i18n_kwargs={"error": error_msg or "Unknown error"},
                ),
            )
    except Exception as e:
        logger.exception(f"Export backup failed: {e}")
        # Удаляем сообщение о конвертации в случае ошибки
        try:
            await status_msg.delete()
        except:
            pass
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(
                i18n_key="ntf-db-export-error",
                i18n_kwargs={"error": str(e)},
            ),
        )


async def sync_getter(dialog_manager: DialogManager, **kwargs):
    """Getter для окна процесса синхронизации."""
    return {
        "sync_status": dialog_manager.dialog_data.get("sync_status", "waiting"),
        "sync_result": dialog_manager.dialog_data.get("sync_result", ""),
    }


@inject
async def on_sync_manage(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
    i18n: FromDishka[TranslatorRunner],
):
    """
    Placeholder для функции управления синхронизацией.
    """
    await notification_service.notify_user(
        user=callback.from_user,
        payload=MessagePayload(text=i18n.get("ntf-in-development")),
    )


@inject
async def on_sync_from_bot(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
    redis_repository: FromDishka[RedisRepository],
):
    """
    Синхронизация: данные из бота -> панель Remnawave.
    - Создаёт новых пользователей в панели если их нет
    - Обновляет существующих с приоритетом данных из бота
    """
    from src.core.storage.keys import SyncRunningKey
    from src.infrastructure.taskiq.tasks.importer import sync_bot_to_panel_task
    from src.core.utils.validators import is_double_click
    
    user = manager.middleware_data.get(USER_KEY)
    key = SyncRunningKey()

    # Проверяем, не запущена ли уже синхронизация
    if await redis_repository.get(key, bool, False):
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-importer-sync-already-running"),
        )
        return

    # Требуем двойной клик для подтверждения
    if is_double_click(manager, key="sync_from_bot_confirm", cooldown=5):
        await redis_repository.set(key, value=True, ex=3600)

        # Шаг 1: Подготовка данных
        preparing_notification = await notification_service.notify_user(
            user=user,
            payload=MessagePayload.not_deleted(
                i18n_key="ntf-remnawave-sync-preparing",
                add_close_button=False,
            ),
        )

        try:
            # Удаляем уведомление о подготовке
            if preparing_notification:
                await preparing_notification.delete()
            
            # Шаг 2: Синхронизация данных
            sync_notification = await notification_service.notify_user(
                user=user,
                payload=MessagePayload.not_deleted(
                    i18n_key="ntf-remnawave-sync-started",
                    add_close_button=False,
                ),
            )

            # Запускаем задачу синхронизации и ждём результат
            task = await sync_bot_to_panel_task.kiq()
            result = await task.wait_result()
            sync_result = result.return_value

            # Удаляем уведомление о синхронизации
            if sync_notification:
                await sync_notification.delete()

            if not sync_result:
                await notification_service.notify_user(
                    user=user,
                    payload=MessagePayload(
                        i18n_key="ntf-remnawave-sync-no-users",
                        add_close_button=True,
                    ),
                )
                return

            # Шаг 3: Показываем уведомление с результатами и кнопкой "Закрыть"
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-remnawave-sync-bot-to-panel-completed",
                    i18n_kwargs={
                        "total_bot_users": sync_result.get("total_bot_users", 0),
                        "created": sync_result.get("created", 0),
                        "updated": sync_result.get("updated", 0),
                        "skipped": sync_result.get("skipped", 0),
                        "errors": sync_result.get("errors", 0),
                    },
                    add_close_button=True,
                ),
            )
            
            logger.info(f"{log(user)} Sync bot to panel completed: {sync_result}")
            
        except Exception as e:
            logger.exception(f"Sync bot to panel failed: {e}")
            if preparing_notification:
                try:
                    await preparing_notification.delete()
                except Exception:
                    pass
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-remnawave-sync-failed",
                    i18n_kwargs={"error": str(e)},
                    add_close_button=True,
                ),
            )
        finally:
            # Снимаем блокировку
            await redis_repository.delete(key)
        
        return

    # Первый клик - показываем уведомление с просьбой нажать еще раз
    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-remnawave-sync-confirm"),
    )


@inject
async def on_sync_from_panel(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
    redis_repository: FromDishka[RedisRepository],
):
    """
    Синхронизация: данные из панели Remnawave -> бот.
    - Создаёт новых пользователей в боте если их нет
    - Обновляет существующих с приоритетом данных из панели
    """
    from src.core.storage.keys import SyncRunningKey
    from src.infrastructure.taskiq.tasks.sync import sync_panel_to_bot_task
    from src.core.utils.validators import is_double_click
    
    user = manager.middleware_data.get(USER_KEY)
    key = SyncRunningKey()

    # Проверяем, не запущена ли уже синхронизация
    if await redis_repository.get(key, bool, False):
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-importer-sync-already-running"),
        )
        return

    # Требуем двойной клик для подтверждения
    if is_double_click(manager, key="sync_from_panel_confirm", cooldown=5):
        await redis_repository.set(key, value=True, ex=3600)

        # Шаг 1: Подготовка данных
        preparing_notification = await notification_service.notify_user(
            user=user,
            payload=MessagePayload.not_deleted(
                i18n_key="ntf-remnawave-sync-preparing",
                add_close_button=False,
            ),
        )

        try:
            # Удаляем уведомление о подготовке
            if preparing_notification:
                await preparing_notification.delete()
            
            # Шаг 2: Синхронизация данных
            sync_notification = await notification_service.notify_user(
                user=user,
                payload=MessagePayload.not_deleted(
                    i18n_key="ntf-remnawave-sync-started",
                    add_close_button=False,
                ),
            )

            # Запускаем задачу синхронизации и ждём результат
            task = await sync_panel_to_bot_task.kiq(user.telegram_id)
            result = await task.wait_result()
            sync_result = result.return_value

            # Удаляем уведомление о синхронизации
            if sync_notification:
                await sync_notification.delete()

            if not sync_result:
                await notification_service.notify_user(
                    user=user,
                    payload=MessagePayload(
                        i18n_key="ntf-remnawave-sync-no-users",
                        add_close_button=True,
                    ),
                )
                return

            # Шаг 3: Показываем уведомление с результатами и кнопкой "Закрыть"
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-remnawave-sync-panel-to-bot-completed",
                    i18n_kwargs={
                        "total_panel_users": sync_result.get("total_panel_users", 0),
                        "created": sync_result.get("created", 0),
                        "synced": sync_result.get("synced", 0),
                        "skipped": sync_result.get("skipped", 0),
                        "errors": sync_result.get("errors", 0),
                    },
                    add_close_button=True,
                ),
            )
            
            logger.info(f"{log(user)} Sync panel to bot completed: {sync_result}")
            
        except Exception as e:
            logger.exception(f"Sync panel to bot failed: {e}")
            if preparing_notification:
                try:
                    await preparing_notification.delete()
                except Exception:
                    pass
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-remnawave-sync-failed",
                    i18n_kwargs={"error": str(e)},
                    add_close_button=True,
                ),
            )
        finally:
            # Снимаем блокировку
            await redis_repository.delete(key)
        
        return

    # Первый клик - показываем уведомление с просьбой нажать еще раз
    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-remnawave-sync-confirm"),
    )


@inject
async def on_remnawave_import(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
    redis_repository: FromDishka[RedisRepository],
):
    """
    Импорт пользователей из панели Remnawave в бота.
    Проверяет всех пользователей в панели и создаёт/обновляет их в боте.
    """
    from src.core.storage.keys import SyncRunningKey
    from src.infrastructure.taskiq.tasks.importer import sync_all_users_from_panel_task
    from src.core.utils.validators import is_double_click

    user = manager.middleware_data.get(USER_KEY)
    key = SyncRunningKey()

    if await redis_repository.get(key, bool, False):
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-importer-sync-already-running"),
        )
        return

    if is_double_click(manager, key="remnawave_import_confirm", cooldown=10):
        await redis_repository.set(key, value=True, ex=3600)

        notification = await notification_service.notify_user(
            user=user,
            payload=MessagePayload.not_deleted(i18n_key="ntf-importer-sync-started"),
        )

        try:
            task = await sync_all_users_from_panel_task.kiq()
            result = await task.wait_result()
            import_result = result.return_value

            if notification:
                await notification.delete()

            if not import_result:
                await notification_service.notify_user(
                    user=user,
                    payload=MessagePayload(i18n_key="ntf-importer-users-not-found"),
                )
                return

            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-remnawave-import-completed",
                    i18n_kwargs={
                        "total_panel_users": import_result.get("total_panel_users", 0),
                        "total_bot_users": import_result.get("total_bot_users", 0),
                        "added_users": import_result.get("added_users", 0),
                        "added_subscription": import_result.get("added_subscription", 0),
                        "updated": import_result.get("updated", 0),
                        "missing_telegram": import_result.get("missing_telegram", 0),
                        "errors": import_result.get("errors", 0),
                    },
                    add_close_button=True,
                ),
            )

            logger.info(f"{log(user)} Remnawave import completed: {import_result}")

        except Exception as e:
            logger.exception(f"Remnawave import failed: {e}")
            if notification:
                try:
                    await notification.delete()
                except Exception:
                    pass
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-remnawave-sync-failed",
                    i18n_kwargs={"error": str(e)},
                    add_close_button=True,
                ),
            )
        finally:
            await redis_repository.delete(key)

        return

    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-double-click-confirm"),
    )


@inject
@inject
async def on_clear_all(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
    redis_client: FromDishka[Redis],
):
    """Обработчик нажатия на кнопку 'Очистить всё'."""
    user = manager.middleware_data.get(USER_KEY)
    
    # Проверяем флаг в dialog_data
    warning_shown = manager.dialog_data.get("clear_all_warning_shown", False)
    
    # Если первое нажатие - показываем предупреждение
    if not warning_shown:
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(
                i18n_key="ntf-db-clear-all-warning",
            ),
        )
        manager.dialog_data["clear_all_warning_shown"] = True
        return
    
    # Если второе нажатие - выполняем удаление
    manager.dialog_data["clear_all_warning_shown"] = False
    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-db-clear-all-start"),
    )
    
    loop = asyncio.get_event_loop()
    
    def clear_all_db():
        """Полная очистка базы данных."""
        import os as os_module
        
        db_password = os_module.getenv('DATABASE_PASSWORD', 'remnasale')
        db_user = os_module.getenv('DATABASE_USER', 'remnasale')
        db_name = os_module.getenv('DATABASE_NAME', 'remnasale')
        db_host = os_module.getenv('DATABASE_HOST', 'remnasale-db')
        db_port = os_module.getenv('DATABASE_PORT', '5432')
        
        env = os_module.environ.copy()
        env['PGPASSWORD'] = db_password
        
        # SQL запрос для подсчета записей перед удалением
        count_query = """
        SELECT 
            (SELECT COUNT(*) FROM users) as users,
            (SELECT COUNT(*) FROM subscriptions) as subscriptions,
            (SELECT COUNT(*) FROM transactions) as transactions,
            (SELECT COUNT(*) FROM promocodes) as promocodes,
            (SELECT COUNT(*) FROM promocode_activations) as activations,
            (SELECT COUNT(*) FROM referrals) as referrals,
            (SELECT COUNT(*) FROM referral_rewards) as rewards,
            (SELECT COUNT(*) FROM plans) as plans,
            (SELECT COUNT(*) FROM plan_durations) as plan_durations,
            (SELECT COUNT(*) FROM plan_prices) as plan_prices,
            (SELECT COUNT(*) FROM balance_transfers) as balance_transfers,
            (SELECT COUNT(*) FROM broadcast_messages) as broadcast_messages,
            (SELECT COUNT(*) FROM broadcasts) as broadcasts,
            (SELECT COUNT(*) FROM extra_device_purchases) as extra_device_purchases,
            (SELECT COUNT(*) FROM payment_gateways) as payment_gateways,
            (SELECT COUNT(*) FROM settings) as settings;
        """
        
        # Получаем количество записей до удаления
        count_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-t', '-c', count_query
        ]
        result = subprocess.run(count_cmd, capture_output=True, text=True, env=env)
        
        counts = {}
        if result.returncode == 0:
            values = result.stdout.strip().split('|')
            counts = {
                'users': int(values[0].strip()),
                'subscriptions': int(values[1].strip()),
                'transactions': int(values[2].strip()),
                'promocodes': int(values[3].strip()),
                'activations': int(values[4].strip()),
                'referrals': int(values[5].strip()),
                'rewards': int(values[6].strip()),
                'plans': int(values[7].strip()),
                'plan_durations': int(values[8].strip()),
                'plan_prices': int(values[9].strip()),
                'balance_transfers': int(values[10].strip()),
                'broadcast_messages': int(values[11].strip()),
                'broadcasts': int(values[12].strip()),
                'extra_device_purchases': int(values[13].strip()),
                'payment_gateways': int(values[14].strip()),
                'settings': int(values[15].strip()),
            }
        
        # SQL запрос для удаления всех данных
        # Порядок удаления важен из-за внешних ключей!
        # НЕ удаляем payment_gateways - они должны остаться!
        delete_query = """
        BEGIN;
        DELETE FROM plan_prices;
        DELETE FROM plan_durations;
        DELETE FROM balance_transfers;
        DELETE FROM broadcast_messages;
        DELETE FROM broadcasts;
        DELETE FROM extra_device_purchases;
        DELETE FROM referral_rewards;
        DELETE FROM referrals;
        DELETE FROM promocode_activations;
        DELETE FROM transactions;
        DELETE FROM subscriptions;
        DELETE FROM users;
        DELETE FROM promocodes;
        DELETE FROM plans;
        DELETE FROM settings;
        COMMIT;
        """
        
        # Выполняем очистку
        delete_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-c', delete_query
        ]
        result = subprocess.run(delete_cmd, capture_output=True, text=True, env=env)
        
        if result.returncode != 0:
            return False, result.stderr, counts
        
        return True, None, counts
    
    try:
        success, error, counts = await loop.run_in_executor(None, clear_all_db)
        
        if success:
            # Очищаем кэш Redis
            await redis_client.flushall()
            logger.info(f"{log(user)} Database cleared successfully")
            
            # Отправляем уведомление об успехе с статистикой и кнопкой закрытия
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload.not_deleted(
                    i18n_key="ntf-db-clear-all-success",
                    i18n_kwargs=counts,
                    add_close_button=True,
                ),
            )
        else:
            logger.error(f"{log(user)} Failed to clear database: {error}")
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-db-clear-all-failed",
                    i18n_kwargs={"error": error},
                ),
            )
    except Exception as e:
        logger.exception(f"{log(user)} Error clearing database: {e}")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(
                i18n_key="ntf-db-clear-all-failed",
                i18n_kwargs={"error": str(e)},
            ),
        )


@inject
async def on_clear_users(
    callback: CallbackQuery,
    button,
    manager: DialogManager,
    notification_service: FromDishka[NotificationService],
    redis_client: FromDishka[Redis],
):
    """Обработчик нажатия на кнопку 'Очистить пользователей'."""
    user = manager.middleware_data.get(USER_KEY)
    
    # Проверяем флаг в dialog_data
    warning_shown = manager.dialog_data.get("clear_users_warning_shown", False)
    
    # Если первое нажатие - показываем предупреждение
    if not warning_shown:
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(
                i18n_key="ntf-db-clear-users-warning",
            ),
        )
        manager.dialog_data["clear_users_warning_shown"] = True
        return
    
    # Если второе нажатие - выполняем удаление
    manager.dialog_data["clear_users_warning_shown"] = False
    await notification_service.notify_user(
        user=user,
        payload=MessagePayload(i18n_key="ntf-db-clear-users-start"),
    )
    
    loop = asyncio.get_event_loop()
    
    def clear_users_db():
        """Очистка пользователей из базы данных."""
        import os as os_module
        
        db_password = os_module.getenv('DATABASE_PASSWORD', 'remnasale')
        db_user = os_module.getenv('DATABASE_USER', 'remnasale')
        db_name = os_module.getenv('DATABASE_NAME', 'remnasale')
        db_host = os_module.getenv('DATABASE_HOST', 'remnasale-db')
        db_port = os_module.getenv('DATABASE_PORT', '5432')
        
        env = os_module.environ.copy()
        env['PGPASSWORD'] = db_password
        
        # SQL запрос для подсчета записей перед удалением
        count_query = """
        SELECT 
            (SELECT COUNT(*) FROM users) as users,
            (SELECT COUNT(*) FROM subscriptions) as subscriptions,
            (SELECT COUNT(*) FROM transactions) as transactions,
            (SELECT COUNT(*) FROM promocode_activations) as activations,
            (SELECT COUNT(*) FROM referrals) as referrals,
            (SELECT COUNT(*) FROM referral_rewards) as rewards;
        """
        
        # Получаем количество записей до удаления
        count_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-t', '-c', count_query
        ]
        result = subprocess.run(count_cmd, capture_output=True, text=True, env=env)
        
        counts = {}
        if result.returncode == 0:
            values = result.stdout.strip().split('|')
            counts = {
                'users': int(values[0].strip()),
                'subscriptions': int(values[1].strip()),
                'transactions': int(values[2].strip()),
                'activations': int(values[3].strip()),
                'referrals': int(values[4].strip()),
                'rewards': int(values[5].strip()),
            }
        
        # SQL запрос для удаления пользователей и связанных данных
        delete_query = """
        BEGIN;
        DELETE FROM referral_rewards;
        DELETE FROM referrals;
        DELETE FROM promocode_activations;
        DELETE FROM transactions;
        DELETE FROM subscriptions;
        DELETE FROM users;
        COMMIT;
        """
        
        # Выполняем очистку
        delete_cmd = [
            'psql', '-h', db_host, '-p', db_port, '-U', db_user, '-d', db_name,
            '-c', delete_query
        ]
        result = subprocess.run(delete_cmd, capture_output=True, text=True, env=env)
        
        if result.returncode != 0:
            return False, result.stderr, counts
        
        return True, None, counts
    
    try:
        success, error, counts = await loop.run_in_executor(None, clear_users_db)
        
        if success:
            # Очищаем кэш Redis
            await redis_client.flushall()
            logger.info(f"{log(user)} Users cleared successfully")
            
            # Отправляем уведомление об успехе с статистикой и кнопкой закрытия
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload.not_deleted(
                    i18n_key="ntf-db-clear-users-success",
                    i18n_kwargs={
                        "users": counts.get("users", 0),
                        "subscriptions": counts.get("subscriptions", 0),
                        "transactions": counts.get("transactions", 0),
                        "activations": counts.get("activations", 0),
                        "referrals": counts.get("referrals", 0),
                        "rewards": counts.get("rewards", 0),
                    },
                    add_close_button=True,
                ),
            )
        else:
            logger.error(f"{log(user)} Failed to clear users: {error}")
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(
                    i18n_key="ntf-db-clear-users-failed",
                    i18n_kwargs={"error": error},
                ),
            )
    except Exception as e:
        logger.exception(f"{log(user)} Error clearing users: {e}")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(
                i18n_key="ntf-db-clear-users-failed",
                i18n_kwargs={"error": str(e)},
            ),
        )


# === Autobackup Handlers ===


@inject
async def autobackup_getter(
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs,
):
    """Геттер для окон автобекапа."""
    backup_settings = await settings_service.get_auto_backup_settings()

    token = backup_settings.bot_token
    token_display = f"{token[:5]}..." if token else "Не назначено"
    chat_id_display = backup_settings.chat_id if backup_settings.chat_id else "Не назначено"

    last_backup = "Не производился"
    if backup_settings.last_backup_at:
        try:
            from datetime import datetime, timezone
            dt = datetime.fromisoformat(backup_settings.last_backup_at)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            last_backup = dt.strftime("%d.%m.%Y | %H:%M")
        except (ValueError, TypeError):
            last_backup = "—"

    freq_items = [
        (i18n.get("autobackup-freq-hourly"), "hourly"),
        (i18n.get("autobackup-freq-daily"), "daily"),
        (i18n.get("autobackup-freq-weekly"), "weekly"),
        (i18n.get("autobackup-freq-monthly"), "monthly"),
    ]

    freq_display = backup_settings.frequency
    for label, key in freq_items:
        if key == backup_settings.frequency:
            freq_display = label
            break

    return {
        "autobackup_enabled": 1 if backup_settings.enabled else 0,
        "autobackup_silent_mode": 1 if backup_settings.silent_mode else 0,
        "autobackup_token_display": token_display,
        "autobackup_chat_id_display": chat_id_display,
        "autobackup_frequency_display": freq_display,
        "autobackup_last_backup": last_backup,
        "frequency_items": freq_items,
        "current_frequency": backup_settings.frequency,
    }


@inject
async def on_toggle_autobackup(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
    notification_service: FromDishka[NotificationService],
) -> None:
    """Toggle автобекапа."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    backup_settings = await settings_service.get_auto_backup_settings()

    # Проверяем что токен и chat_id заданы перед включением
    if not backup_settings.enabled:
        if not backup_settings.bot_token or not backup_settings.chat_id:
            await notification_service.notify_user(
                user=user,
                payload=MessagePayload(i18n_key="ntf-autobackup-need-config"),
            )
            return

    new_value = await settings_service.toggle_auto_backup()
    logger.info(f"{log(user)} Toggled auto_backup -> {new_value}")


@inject
async def on_toggle_autobackup_silent(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle тихого режима автобекапа."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_auto_backup_silent_mode()
    logger.info(f"{log(user)} Toggled auto_backup silent_mode -> {new_value}")


@inject
async def on_autobackup_token_input(
    message: Message,
    widget,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Ввод токена бота для автобекапа."""
    from src.bot.states import DashboardDB
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    token = message.text.strip()
    await settings_service.set_auto_backup_token(token)
    logger.info(f"{log(user)} Set autobackup bot_token")
    try:
        await message.delete()
    except TelegramBadRequest:
        pass
    await dialog_manager.switch_to(DashboardDB.AUTOBACKUP)


@inject
async def on_autobackup_chat_id_input(
    message: Message,
    widget,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Ввод Chat ID для автобекапа."""
    from src.bot.states import DashboardDB
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    chat_id = message.text.strip()
    await settings_service.set_auto_backup_chat_id(chat_id)
    logger.info(f"{log(user)} Set autobackup chat_id -> {chat_id}")
    try:
        await message.delete()
    except TelegramBadRequest:
        pass
    await dialog_manager.switch_to(DashboardDB.AUTOBACKUP)


@inject
async def on_select_autobackup_frequency(
    callback: CallbackQuery,
    widget,
    dialog_manager: DialogManager,
    item_id: str,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Выбор частоты автобекапа."""
    from src.bot.states import DashboardDB
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    await settings_service.set_auto_backup_frequency(item_id)
    logger.info(f"{log(user)} Set autobackup frequency -> {item_id}")
    await dialog_manager.switch_to(DashboardDB.AUTOBACKUP)


@inject
async def on_force_backup(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
    notification_service: FromDishka[NotificationService],
    bot: FromDishka[Bot],
) -> None:
    """Принудительная отправка бекапа."""
    from src.infrastructure.taskiq.tasks.auto_backup import _do_backup, _send_to_telegram
    from datetime import datetime, timezone
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    backup_settings = await settings_service.get_auto_backup_settings()

    logger.info(f"{log(user)} Force backup triggered")

    backup_dir = "/opt/remnasale/backups"
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%d-%m-%y_%H-%M")
    filepath = os.path.join(backup_dir, f"Remnasale_{timestamp}.sql.gz")

    loop = asyncio.get_event_loop()
    success = await loop.run_in_executor(None, _do_backup, filepath)

    if not success:
        if os.path.exists(filepath):
            os.remove(filepath)
        logger.error(f"{log(user)} Force backup creation failed")
        await notification_service.notify_user(
            user=user,
            payload=MessagePayload(i18n_key="ntf-autobackup-force-failed"),
        )
        return

    # Отправляем получателю только если настроен автобекап
    if backup_settings.bot_token and backup_settings.chat_id:
        sent = await loop.run_in_executor(
            None, _send_to_telegram, backup_settings.bot_token, backup_settings.chat_id, filepath, True
        )
        if sent:
            now_iso = datetime.now(tz=timezone.utc).isoformat()
            await settings_service.set_auto_backup_last_run(now_iso)
            logger.info(f"{log(user)} Force backup sent to recipient successfully")

    # DEV-ы получают всегда, независимо от настроек
    from src.core.enums import UserRole
    from aiogram.types import FSInputFile, InlineKeyboardButton
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    devs = await notification_service.user_service.get_by_role(role=UserRole.DEV)
    size = os.path.getsize(filepath) if os.path.exists(filepath) else 0
    size_str = f"{size // 1024}K" if size < 1024 * 1024 else f"{size / 1024 / 1024:.1f}M"
    from datetime import timezone as _tz, timedelta as _td
    msk = _tz(_td(hours=3))
    from datetime import datetime as _dt
    date_str = _dt.now(tz=msk).strftime("%d.%m.%Y %H:%M МСК")
    recipient_line = f"👤 Получатель: <code>{backup_settings.chat_id}</code>\n" if backup_settings.chat_id else ""
    dev_caption = (
        f"🤖 Система: Создание бэкапа!\n\n"
        f"📦 Приложение: Remnasale\n"
        f"{recipient_line}"
        f"📁 База данных\n"
        f"📏 Размер: {size_str}\n"
        f"📅 {date_str}\n\n"
        f"✅ Бекап создан вручную"
    )
    for dev in devs:
        try:
            close_btn = InlineKeyboardButton(
                text="✅ Закрыть",
                callback_data="Notification:CLOSE",
                style="success",
            )
            kb = InlineKeyboardBuilder()
            kb.row(close_btn)
            await bot.send_document(
                chat_id=dev.telegram_id,
                document=FSInputFile(filepath),
                caption=dev_caption,
                reply_markup=kb.as_markup(),
            )
        except Exception as e:
            logger.warning(f"[force_backup] Failed to send backup to dev {dev.telegram_id}: {e}")
