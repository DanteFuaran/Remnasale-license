from aiogram.enums import ContentType
from aiogram_dialog import Dialog, StartMode, Window
from aiogram_dialog.widgets.input import MessageInput
from aiogram_dialog.widgets.kbd import Button, Row, Start, SwitchTo
from magic_filter import F

from src.bot.keyboards import main_menu_button
from src.bot.routers.dashboard.telegram.handlers import on_logs_request
from src.bot.states import Dashboard, DashboardAccess, DashboardBotManagement, DashboardMirrorBots, TelegramNotifications
from src.bot.widgets import Banner, ColoredButton, ColoredSwitchTo, I18nFormat, IgnoreUpdate
from src.bot.routers.dashboard.settings.getters import language_settings_getter
from src.bot.routers.dashboard.settings.handlers import (
    on_language_click,
    on_toggle_language,
    on_language_select,
    on_language_cancel,
    on_language_apply,
)
from .handlers import (
    bot_management_getter,
    on_check_update,
    on_restart_bot,
    on_back_to_dashboard,
    support_settings_getter,
    on_support_click,
    on_support_recipient_input,
    on_support_cancel,
    on_support_accept,
    on_toggle_support_enabled,
    on_toggle_faq_enabled,
    on_faq_text_input,
    branding_getter,
    on_branding_click,
    on_banner_photo,
)


bot_management_window = Window(
    Banner(),
    I18nFormat("msg-bot-management"),
    # 1. Режим доступа
    Start(
        text=I18nFormat("btn-settings-access"),
        id="access",
        state=DashboardAccess.MAIN,
        mode=StartMode.RESET_STACK,
    ),
    # 1.5. Брендирование
    Button(
        text=I18nFormat("btn-branding"),
        id="branding",
        on_click=on_branding_click,
    ),
    # 2. Зеркала | Уведомления
    Row(
        Start(
            text=I18nFormat("btn-mirror-bots"),
            id="mirror_bots",
            state=DashboardMirrorBots.MAIN,
            mode=StartMode.RESET_STACK,
        ),
        Start(
            text=I18nFormat("btn-settings-notifications"),
            id="notifications",
            state=TelegramNotifications.MAIN,
            mode=StartMode.RESET_STACK,
        ),
    ),
    # 3. Язык | Поддержка
    Row(
        Button(
            text=I18nFormat("btn-settings-language"),
            id="language",
            on_click=on_language_click,
        ),
        Button(
            text=I18nFormat("btn-settings-support"),
            id="support",
            on_click=on_support_click,
        ),
    ),
    # 4. Логи
    Row(
        Button(
            text=I18nFormat("btn-remnashop-logs"),
            id="logs",
            on_click=on_logs_request,
        ),
    ),
    # 5. Обновление | Перезапустить
    Row(
        Button(
            text=I18nFormat("btn-bot-check-update"),
            id="check_update",
            on_click=on_check_update,
        ),
        Button(
            text=I18nFormat("btn-bot-restart"),
            id="restart_bot",
            on_click=on_restart_bot,
        ),
    ),
    # 6. Назад | Главное меню
    Row(
        ColoredButton(
            text=I18nFormat("btn-back"),
            id="back",
            on_click=on_back_to_dashboard,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardBotManagement.MAIN,
    getter=bot_management_getter,
)

language_settings_window = Window(
    Banner(),
    I18nFormat("msg-dashboard-settings-language", enabled=F["enabled"], current_locale=F["current_locale"]),
    Row(
        Button(
            text=I18nFormat("btn-language-multilang", enabled=F["enabled"]),
            id="toggle_multilang",
            on_click=on_toggle_language,
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-language-ru"),
            id="lang_ru",
            on_click=on_language_select,
            when=F["show_ru"],
        ),
        Button(
            text=I18nFormat("btn-language-uk"),
            id="lang_uk",
            on_click=on_language_select,
            when=F["show_uk"],
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-language-en"),
            id="lang_en",
            on_click=on_language_select,
            when=F["show_en"],
        ),
        Button(
            text=I18nFormat("btn-language-de"),
            id="lang_de",
            on_click=on_language_select,
            when=F["show_de"],
        ),
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-language-cancel"),
            id="lang_cancel",
            on_click=on_language_cancel,
            style="danger",
        ),
        ColoredButton(
            text=I18nFormat("btn-language-apply"),
            id="lang_apply",
            on_click=on_language_apply,
            style="success",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardBotManagement.LANGUAGE,
    getter=language_settings_getter,
)

support_settings_window = Window(
    Banner(),
    I18nFormat(
        "msg-bot-support-settings",
        enabled=F["support_enabled"],
        recipient=F["support_recipient"],
        has_recipient=F["support_has_recipient"],
        faq_enabled=F["faq_enabled"],
    ),
    # Поддержка | 🟢/🔴
    Row(
        SwitchTo(
            text=I18nFormat("btn-support-recipient"),
            id="set_recipient",
            state=DashboardBotManagement.SUPPORT_RECIPIENT,
        ),
        Button(
            text=I18nFormat("btn-settings-toggle", enabled=F["support_enabled"]),
            id="toggle_support",
            on_click=on_toggle_support_enabled,
        ),
    ),
    # Частые вопросы | 🟢/🔴
    Row(
        SwitchTo(
            text=I18nFormat("btn-support-faq"),
            id="set_faq",
            state=DashboardBotManagement.SUPPORT_FAQ,
        ),
        Button(
            text=I18nFormat("btn-settings-toggle", enabled=F["faq_enabled"]),
            id="toggle_faq",
            on_click=on_toggle_faq_enabled,
        ),
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-support-cancel"),
            id="support_cancel",
            on_click=on_support_cancel,
            style="danger",
        ),
        ColoredButton(
            text=I18nFormat("btn-support-accept"),
            id="support_accept",
            on_click=on_support_accept,
            style="success",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardBotManagement.SUPPORT,
    getter=support_settings_getter,
)

support_recipient_window = Window(
    Banner(),
    I18nFormat("msg-bot-support-recipient", has_recipient=F["support_has_recipient"], recipient=F["support_recipient"]),
    MessageInput(func=on_support_recipient_input, content_types=ContentType.TEXT),
    ColoredSwitchTo(
        text=I18nFormat("btn-cancel"),
        id="back",
        state=DashboardBotManagement.SUPPORT,
        style="danger",
    ),
    IgnoreUpdate(),
    state=DashboardBotManagement.SUPPORT_RECIPIENT,
    getter=support_settings_getter,
)

support_faq_window = Window(
    Banner(),
    I18nFormat("msg-bot-support-faq", has_faq=F["has_faq"], faq_preview=F["faq_preview"]),
    MessageInput(func=on_faq_text_input, content_types=ContentType.TEXT),
    ColoredSwitchTo(
        text=I18nFormat("btn-cancel"),
        id="back_faq",
        state=DashboardBotManagement.SUPPORT,
        style="danger",
    ),
    IgnoreUpdate(),
    state=DashboardBotManagement.SUPPORT_FAQ,
    getter=support_settings_getter,
)

branding_window = Window(
    Banner(),
    I18nFormat("msg-branding"),
    SwitchTo(
        text=I18nFormat("btn-branding-change-banner", has_banner=F["has_banner"]),
        id="change_banner",
        state=DashboardBotManagement.BRANDING_BANNER,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back_branding",
            state=DashboardBotManagement.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardBotManagement.BRANDING,
    getter=branding_getter,
)

branding_banner_window = Window(
    Banner(),
    I18nFormat("msg-branding-upload-banner"),
    MessageInput(func=on_banner_photo, content_types=ContentType.PHOTO),
    ColoredSwitchTo(
        text=I18nFormat("btn-cancel"),
        id="cancel_banner",
        state=DashboardBotManagement.BRANDING,
        style="danger",
    ),
    IgnoreUpdate(),
    state=DashboardBotManagement.BRANDING_BANNER,
    getter=branding_getter,
)

dialog = Dialog(bot_management_window, branding_window, branding_banner_window, language_settings_window, support_settings_window, support_recipient_window, support_faq_window)
