from aiogram_dialog import Dialog, StartMode, Window, ShowMode
from aiogram_dialog.widgets.kbd import Button, Row, Start, Column, ListGroup, Group, SwitchTo, Select
from aiogram_dialog.widgets.input import MessageInput
from aiogram_dialog.widgets.text import Format, Const
from aiogram.enums import ContentType
from magic_filter import F

from src.bot.keyboards import main_menu_button
from src.bot.states import Dashboard, DashboardImporter
from src.bot.widgets import Banner, ColoredButton, ColoredSwitchTo, I18nFormat, IgnoreUpdate
from .handlers import (
    on_save_db,
    on_load_db,
    on_db_file_input,
    on_convert_db,
    backups_getter,
    on_restore_backup,
    on_export_db,
    on_import_db,
    on_back_to_dashboard,
    on_delete_backup,
    on_export_backup_to_db,
    on_sync_from_bot,
    on_sync_from_panel,
    on_sync_manage,
    on_remnawave_import,
    sync_getter,
    on_clear_all,
    on_clear_users,
    # Autobackup
    autobackup_getter,
    on_toggle_autobackup,
    on_toggle_autobackup_silent,
    on_autobackup_token_input,
    on_autobackup_chat_id_input,
    on_select_autobackup_frequency,
    on_force_backup,
)
from src.bot.states import DashboardDB
db_management = Window(
    Banner(),
    I18nFormat("msg-db-main"),
    SwitchTo(
        text=I18nFormat("btn-db-autobackup"),
        id="autobackup",
        state=DashboardDB.AUTOBACKUP,
    ),
    Row(
        Button(
            text=I18nFormat("btn-db-save"),
            id="save_db",
            on_click=on_save_db,
        ),
        Button(
            text=I18nFormat("btn-db-load"),
            id="load_db",
            on_click=on_load_db,
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-db-clear-all"),
            id="clear_all",
            on_click=on_clear_all,
        ),
        Button(
            text=I18nFormat("btn-db-clear-users"),
            id="clear_users",
            on_click=on_clear_users,
        ),
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-db-imports"),
            id="imports",
            state=DashboardDB.IMPORTS,
        ),
        SwitchTo(
            text=I18nFormat("btn-db-sync"),
            id="sync",
            state=DashboardDB.SYNC,
        ),
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-back"),
            id="back",
            on_click=on_back_to_dashboard,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardDB.MAIN,
)

# Window for uploading DB dump file
db_load_window = Window(
    Banner(),
    I18nFormat("msg-db-load"),
    SwitchTo(
        text=I18nFormat("btn-db-upload-file"),
        id="upload_file",
        state=DashboardDB.LOAD_UPLOAD,
    ),
    ListGroup(
        Row(
            Button(
                text=Format("📄"),
                id="export_to_db",
                on_click=on_export_backup_to_db,
            ),
            Button(
                text=Format("{item[name]}"),
                id="restore",
                on_click=on_restore_backup,
            ),
            Button(
                text=Format("❌"),
                id="delete",
                on_click=on_delete_backup,
            ),
        ),
        id="backups_list",
        item_id_getter=lambda item: item["index"],
        items="backups",
    ),
    Row(
        ColoredButton(
            text=I18nFormat("btn-back"),
            id="back",
            on_click=on_back_to_dashboard,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardDB.LOAD,
    getter=backups_getter,
)

# Окно загрузки файла бэкапа через Telegram
db_load_upload_window = Window(
    Banner(),
    I18nFormat("msg-db-load-upload"),
    MessageInput(func=on_db_file_input, content_types=ContentType.DOCUMENT),
    ColoredSwitchTo(
        text=I18nFormat("btn-cancel"),
        id="cancel_upload",
        state=DashboardDB.LOAD,
        style="danger",
    ),
    IgnoreUpdate(),
    state=DashboardDB.LOAD_UPLOAD,
)

# Окно выбора направления синхронизации
db_sync_window = Window(
    Banner(),
    I18nFormat("msg-db-sync"),
    Row(
        Button(
            text=I18nFormat("btn-db-sync-remnawave-to-bot"),
            id="sync_from_panel",
            on_click=on_sync_from_panel,
        ),
        Button(
            text=I18nFormat("btn-db-sync-bot-to-remnawave"),
            id="sync_from_bot",
            on_click=on_sync_from_bot,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardDB.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardDB.SYNC,
)

# Окно процесса синхронизации
db_sync_progress = Window(
    Banner(),
    I18nFormat("msg-db-sync-progress"),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardDB.SYNC,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardDB.SYNC_PROGRESS,
    getter=sync_getter,
)

# Окно подтверждения полной очистки базы

# Окно подтверждения очистки пользователей
clear_users_confirm = Window(
    Banner(),
    I18nFormat("msg-db-clear-users-confirm"),
    Row(
        Button(
            text=I18nFormat("btn-db-clear-users"),
            id="confirm_clear_users",
            on_click=on_clear_users,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-cancel"),
            id="cancel",
            state=DashboardDB.MAIN,
            style="danger",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardDB.CLEAR_USERS_CONFIRM,
)

# Меню импортов
imports_menu = Window(
    Banner(),
    I18nFormat("msg-db-imports"),
    Column(
        Button(
            text=I18nFormat("btn-db-remnawave-import"),
            id="remnawave_import",
            on_click=on_remnawave_import,
        ),
        Start(
            text=I18nFormat("btn-db-xui-import"),
            id="importer",
            state=DashboardImporter.MAIN,
        ),
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-back"),
            id="back",
            state=DashboardDB.MAIN,
            style="primary",
        ),
        *main_menu_button,
    ),
    IgnoreUpdate(),
    state=DashboardDB.IMPORTS,
)

# === Окна настройки автобекапа ===

autobackup_settings = Window(
    Banner(),
    I18nFormat(
        "msg-db-autobackup",
        token_display=F["autobackup_token_display"],
        chat_id_display=F["autobackup_chat_id_display"],
        frequency_display=F["autobackup_frequency_display"],
        last_backup=F["autobackup_last_backup"],
    ),
    Row(
        Button(
            text=I18nFormat("btn-db-autobackup-label"),
            id="autobackup_label",
            on_click=on_toggle_autobackup,
        ),
        Button(
            text=I18nFormat("btn-settings-toggle", enabled=F["autobackup_enabled"]),
            id="toggle_autobackup",
            on_click=on_toggle_autobackup,
        ),
    ),
    Row(
        Button(
            text=I18nFormat("btn-db-autobackup-silent"),
            id="silent_label",
            on_click=on_toggle_autobackup_silent,
        ),
        Button(
            text=I18nFormat("btn-settings-toggle", enabled=F["autobackup_silent_mode"]),
            id="toggle_silent",
            on_click=on_toggle_autobackup_silent,
        ),
    ),
    Row(
        SwitchTo(
            text=I18nFormat("btn-db-autobackup-token"),
            id="set_token",
            state=DashboardDB.AUTOBACKUP_TOKEN,
        ),
        SwitchTo(
            text=I18nFormat("btn-db-autobackup-chat-id"),
            id="set_chat_id",
            state=DashboardDB.AUTOBACKUP_CHAT_ID,
        ),
    ),
    SwitchTo(
        text=I18nFormat("btn-db-autobackup-frequency"),
        id="set_frequency",
        state=DashboardDB.AUTOBACKUP_FREQUENCY,
    ),
    Button(
        text=I18nFormat("btn-db-autobackup-force"),
        id="force_backup",
        on_click=on_force_backup,
    ),
    Row(
        ColoredSwitchTo(
            text=I18nFormat("btn-cancel"),
            id="back",
            state=DashboardDB.MAIN,
            style="danger",
        ),
        ColoredSwitchTo(
            text=I18nFormat("btn-accept"),
            id="accept",
            state=DashboardDB.MAIN,
            style="success",
        ),
    ),
    IgnoreUpdate(),
    state=DashboardDB.AUTOBACKUP,
    getter=autobackup_getter,
)

# Окно ввода токена бота для автобекапа
autobackup_token_window = Window(
    Banner(),
    I18nFormat("msg-db-autobackup-token"),
    MessageInput(func=on_autobackup_token_input, content_types=ContentType.TEXT),
    ColoredSwitchTo(
        text=I18nFormat("btn-cancel"),
        id="back",
        state=DashboardDB.AUTOBACKUP,
        style="danger",
    ),
    IgnoreUpdate(),
    state=DashboardDB.AUTOBACKUP_TOKEN,
    getter=autobackup_getter,
)

# Окно ввода Chat ID для автобекапа
autobackup_chat_id_window = Window(
    Banner(),
    I18nFormat("msg-db-autobackup-chat-id"),
    MessageInput(func=on_autobackup_chat_id_input, content_types=ContentType.TEXT),
    ColoredSwitchTo(
        text=I18nFormat("btn-cancel"),
        id="back",
        state=DashboardDB.AUTOBACKUP,
        style="danger",
    ),
    IgnoreUpdate(),
    state=DashboardDB.AUTOBACKUP_CHAT_ID,
    getter=autobackup_getter,
)

# Окно выбора частоты автобекапа
autobackup_frequency_window = Window(
    Banner(),
    I18nFormat("msg-db-autobackup-frequency"),
    Column(
        Select(
            Format("{item[0]}"),
            id="select_frequency",
            item_id_getter=lambda x: x[1],
            items="frequency_items",
            on_click=on_select_autobackup_frequency,
        ),
    ),
    ColoredSwitchTo(
        text=I18nFormat("btn-cancel"),
        id="back",
        state=DashboardDB.AUTOBACKUP,
        style="danger",
    ),
    IgnoreUpdate(),
    state=DashboardDB.AUTOBACKUP_FREQUENCY,
    getter=autobackup_getter,
)


dialog = Dialog(
    db_management,
    db_load_window,
    db_load_upload_window,
    db_sync_window,
    db_sync_progress,
    clear_users_confirm,
    imports_menu,
    autobackup_settings,
    autobackup_token_window,
    autobackup_chat_id_window,
    autobackup_frequency_window,
)
