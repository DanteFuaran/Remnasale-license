from aiogram.types import CallbackQuery, Message
from aiogram_dialog import DialogManager, StartMode
from aiogram_dialog.widgets.kbd import Button, Select
from aiogram_dialog.widgets.input import ManagedTextInput
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from loguru import logger

from src.bot.states import DashboardFeatures, DashboardTelegram
from src.core.constants import USER_KEY
from src.core.utils.formatters import format_user_log as log
from src.infrastructure.database.models.dto import UserDto
from src.services.settings import SettingsService


@inject
async def on_toggle_community(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle кнопки сообщества."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_feature("community_enabled")
    logger.info(f"{log(user)} Toggled community_enabled -> {new_value}")


@inject
async def on_toggle_tos(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle кнопки соглашения."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_feature("tos_enabled")
    logger.info(f"{log(user)} Toggled tos_enabled -> {new_value}")


@inject
async def on_toggle_balance(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle функционала баланса."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_feature("balance_enabled")
    logger.info(f"{log(user)} Toggled balance_enabled -> {new_value}")


@inject
async def on_toggle_extra_devices(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle функционала доп. устройств."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_extra_devices()
    logger.info(f"{log(user)} Toggled extra_devices_enabled -> {new_value}")


@inject
async def on_toggle_transfers(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle функционала переводов баланса."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_transfers()
    logger.info(f"{log(user)} Toggled transfers_enabled -> {new_value}")


@inject
async def on_cancel_features(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Отмена - восстановить начальные значения и вернуться назад."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    initial = dialog_manager.dialog_data.get("initial_features", {})
    
    if initial:
        # Восстанавливаем начальные значения
        current = await settings_service.get_feature_settings()
        
        if current.community_enabled != initial.get("community_enabled", current.community_enabled):
            await settings_service.toggle_feature("community_enabled")
        if current.tos_enabled != initial.get("tos_enabled", current.tos_enabled):
            await settings_service.toggle_feature("tos_enabled")
        if current.balance_enabled != initial.get("balance_enabled", current.balance_enabled):
            await settings_service.toggle_feature("balance_enabled")
        if current.extra_devices.enabled != initial.get("extra_devices_enabled", current.extra_devices.enabled):
            await settings_service.toggle_extra_devices()
        if current.transfers.enabled != initial.get("transfers_enabled", current.transfers.enabled):
            await settings_service.toggle_transfers()
        if current.auto_cleanup.enabled != initial.get("auto_cleanup_enabled", current.auto_cleanup.enabled):
            await settings_service.toggle_auto_cleanup()
        
        logger.info(f"{log(user)} Cancelled feature changes, restored initial values")
    
    # Возвращаемся на меню "Панель управления" -> "Телеграм"
    await dialog_manager.start(DashboardTelegram.MAIN, mode=StartMode.RESET_STACK)


@inject
async def on_accept_features(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Принять изменения и вернуться назад."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    logger.info(f"{log(user)} Accepted feature changes")
    # Возвращаемся на меню "Панель управления" -> "Телеграм"
    await dialog_manager.start(DashboardTelegram.MAIN, mode=StartMode.RESET_STACK)


# === Auto Cleanup Handlers ===


@inject
async def on_open_auto_cleanup(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Открыть настройки автоочистки."""
    cleanup = await settings_service.get_auto_cleanup_settings()
    dialog_manager.dialog_data["initial_auto_cleanup"] = {
        "notify_user": cleanup.notify_user,
        "days_threshold": cleanup.days_threshold,
    }
    await dialog_manager.switch_to(DashboardFeatures.AUTO_CLEANUP)


@inject
async def on_toggle_auto_cleanup(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle автоочистки EXPIRED пользователей."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_auto_cleanup()
    logger.info(f"{log(user)} Toggled auto_cleanup_enabled -> {new_value}")


@inject
async def on_toggle_auto_cleanup_notify(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Toggle уведомления пользователю при удалении."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    new_value = await settings_service.toggle_auto_cleanup_notify()
    logger.info(f"{log(user)} Toggled auto_cleanup notify_user -> {new_value}")


@inject
async def on_open_auto_cleanup_days(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Открыть выбор количества дней."""
    await dialog_manager.switch_to(DashboardFeatures.AUTO_CLEANUP_DAYS)


@inject
async def on_select_auto_cleanup_days(
    callback: CallbackQuery,
    widget: Select,
    dialog_manager: DialogManager,
    item_id: str,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Выбор количества дней из пресетов."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    days = int(item_id)
    await settings_service.set_auto_cleanup_days(days)
    logger.info(f"{log(user)} Set auto_cleanup days -> {days}")
    await dialog_manager.switch_to(DashboardFeatures.AUTO_CLEANUP)


@inject
async def on_open_auto_cleanup_days_manual(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Открыть ручной ввод количества дней."""
    await dialog_manager.switch_to(DashboardFeatures.AUTO_CLEANUP_DAYS_MANUAL)


@inject
async def on_auto_cleanup_days_manual_input(
    message: Message,
    widget: ManagedTextInput,
    dialog_manager: DialogManager,
    data: str,
) -> None:
    """Ручной ввод количества дней."""
    from dishka import AsyncContainer
    container: AsyncContainer = dialog_manager.middleware_data["dishka_container"]
    settings_service = await container.get(SettingsService)

    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    try:
        days = int(data.strip())
        if days < 1 or days > 365:
            return
        await settings_service.set_auto_cleanup_days(days)
        logger.info(f"{log(user)} Set auto_cleanup days (manual) -> {days}")
        await dialog_manager.switch_to(DashboardFeatures.AUTO_CLEANUP)
    except ValueError:
        pass


@inject
async def on_cancel_auto_cleanup(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
    settings_service: FromDishka[SettingsService],
) -> None:
    """Отмена изменений автоочистки — восстановить начальные значения."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    initial = dialog_manager.dialog_data.get("initial_auto_cleanup", {})

    if initial:
        current = await settings_service.get_auto_cleanup_settings()
        if current.notify_user != initial.get("notify_user", current.notify_user):
            await settings_service.toggle_auto_cleanup_notify()
        if current.days_threshold != initial.get("days_threshold", current.days_threshold):
            await settings_service.set_auto_cleanup_days(initial["days_threshold"])
        logger.info(f"{log(user)} Cancelled auto_cleanup settings, restored initial values")

    dialog_manager.dialog_data.pop("initial_auto_cleanup", None)
    await dialog_manager.switch_to(DashboardFeatures.MAIN)


async def on_accept_auto_cleanup(
    callback: CallbackQuery,
    widget: Button,
    dialog_manager: DialogManager,
) -> None:
    """Принять изменения автоочистки."""
    user: UserDto = dialog_manager.middleware_data[USER_KEY]
    logger.info(f"{log(user)} Accepted auto_cleanup settings")
    dialog_manager.dialog_data.pop("initial_auto_cleanup", None)
    await dialog_manager.switch_to(DashboardFeatures.MAIN)

