from typing import Any, Optional

import httpx
from aiogram_dialog import DialogManager
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from loguru import logger

from src.__version__ import __version__
from src.core.config import AppConfig
from src.core.constants import DEFAULT_BRANCH, get_update_branch
from src.core.utils.license_host import get_license_host
from src.infrastructure.redis.repository import RedisRepository


def _parse_version(version_str: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in version_str.strip().split("."))
    except (ValueError, AttributeError):
        return (0, 0, 0)


async def _check_remote_version(
    config: AppConfig,
    redis: Optional[RedisRepository] = None,
    branch: str = DEFAULT_BRANCH,
) -> tuple[bool, str]:
    """Check if a newer version is available via license server. Returns (is_available, remote_version)."""
    redis_client = redis.client if redis is not None else None
    license_server = await get_license_host(redis_client, config)
    license_key = config.build.license_key.get_secret_value()
    if not license_server or not license_key:
        return False, ""
    try:
        url = f"{license_server.rstrip('/')}/api/v1/version"
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(url, params={"key": license_key})
            response.raise_for_status()
            data = response.json()
            remote = data.get("version", "")
            if remote and _parse_version(remote) > _parse_version(__version__):
                return True, remote
    except Exception as e:
        logger.debug(f"[dashboard_getter] Failed to check remote version: {e}")
    return False, ""


@inject
async def dashboard_main_getter(
    dialog_manager: DialogManager,
    config: AppConfig,
    redis: FromDishka[RedisRepository],
    **kwargs: Any,
) -> dict[str, Any]:
    """Getter for dashboard main page."""
    branch = get_update_branch()
    update_available, new_version = await _check_remote_version(config=config, redis=redis, branch=branch)

    return {
        "bot_version": __version__,
        "update_available": "1" if update_available else "0",
        "new_version": new_version or __version__,
    }
