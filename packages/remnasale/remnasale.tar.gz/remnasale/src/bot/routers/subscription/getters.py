from decimal import Decimal
from math import ceil
from typing import Any, cast

from aiogram_dialog import DialogManager, ShowMode, StartMode
from dishka import FromDishka
from dishka.integrations.aiogram_dialog import inject
from fluentogram import TranslatorRunner
from loguru import logger

from src.core.config import AppConfig
from src.core.enums import Currency, PaymentGatewayType, PurchaseType, ReferralRewardType
from src.core.utils.adapter import DialogDataAdapter
from src.core.utils.balance import get_display_balance
from src.core.utils.discount import calculate_user_discount
from src.core.utils.formatters import (
    format_days_to_datetime,
    format_device_limit_number,
    format_price,
    i18n_format_days,
    i18n_format_device_limit,
    i18n_format_expire_time,
    i18n_format_traffic_limit,
)
from src.infrastructure.database.models.dto import PlanDto, PriceDetailsDto, UserDto
from src.services.extra_device import ExtraDeviceService
from src.services.payment_gateway import PaymentGatewayService
from src.services.plan import PlanService
from src.services.pricing import PricingService
from src.services.referral import ReferralService
from src.services.remnawave import RemnawaveService
from src.services.settings import SettingsService
from src.services.subscription import SubscriptionService
from src.services.user import UserService


@inject
async def referral_code_input_getter(
    dialog_manager: DialogManager,
    **kwargs: Any,
) -> dict[str, Any]:
    error_key = dialog_manager.dialog_data.get("referral_code_error", "none")
    return {
        "error_key": error_key,
    }


@inject
async def subscription_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    i18n: FromDishka[TranslatorRunner],
    referral_service: FromDishka[ReferralService],
    plan_service: FromDishka[PlanService],
    subscription_service: FromDishka[SubscriptionService],
    settings_service: FromDishka[SettingsService],
    **kwargs: Any,
) -> dict[str, Any]:
    currency = (await settings_service.get()).default_currency
    has_active = bool(user.current_subscription and not user.current_subscription.is_trial)
    is_unlimited = user.current_subscription.is_unlimited if user.current_subscription else False
    purchase_type = dialog_manager.dialog_data.get("purchase_type")
    is_topup_mode = purchase_type == "TOPUP"
    
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Определяем, является ли пользователь приглашённым
    # Проверяем напрямую через сервис, так как user.is_invited_user может быть не установлен корректно
    referral = await referral_service.get_referral_by_referred(user.telegram_id)
    is_invited = bool(referral)
    
    # Проверяем доступность пробной подписки
    # Приглашённые пользователи получают INVITED план, остальные - TRIAL план
    plan = await plan_service.get_appropriate_trial_plan(user, is_invited=is_invited)
    has_used_trial = await subscription_service.has_used_trial(user.telegram_id)
    trial_available = not has_used_trial and plan and not has_active
    
    # Определяем, является ли пробная подписка реферальной
    is_referral_trial = trial_available and is_invited
    
    # Определяем, может ли пользователь улучшить пробную подписку до реферальной
    # Условия: есть активная пробная подписка (по флагу или имени) и нет реферальной связи
    # и подписка НЕ реферальная
    is_trial_by_name = bool(
        user.current_subscription 
        and user.current_subscription.is_active
        and "пробн" in user.current_subscription.plan.name.lower()
    )
    is_referral_by_name = bool(
        user.current_subscription 
        and user.current_subscription.is_active
        and "реферал" in user.current_subscription.plan.name.lower()
    )
    
    can_upgrade_to_referral = bool(
        user.current_subscription 
        and user.current_subscription.is_active 
        and not referral
        and (user.current_subscription.is_trial or is_trial_by_name)
        and not is_referral_by_name
    )
    
    # Определяем, является ли текущая подписка реферальной (приглашённой)
    # Проверяем по is_trial ИЛИ по имени плана (для подписок выданных через панель)
    is_referral_subscription = bool(
        user.current_subscription 
        and user.current_subscription.is_active
        and (
            (user.current_subscription.is_trial and is_invited)
            or is_referral_by_name
        )
    )
    
    # Определяем, является ли текущая подписка пробной (любой - Пробный или Реферальный)
    # Используем уже вычисленные переменные is_trial_by_name и is_referral_by_name
    # Для пробных подписок скрываем кнопки "Продлить" и "Изменить"
    is_trial_subscription = bool(
        user.current_subscription 
        and user.current_subscription.is_active
        and (
            user.current_subscription.is_trial
            or is_trial_by_name
            or is_referral_by_name
        )
    )
    
    logger.debug(
        f"[subscription_getter] user={user.telegram_id}: "
        f"plan_name='{user.current_subscription.plan.name if user.current_subscription else None}', "
        f"is_trial_flag={user.current_subscription.is_trial if user.current_subscription else None}, "
        f"is_trial_by_name={is_trial_by_name}, "
        f"is_referral_by_name={is_referral_by_name}, "
        f"is_trial_subscription={is_trial_subscription}, "
        f"can_upgrade_to_referral={can_upgrade_to_referral}"
    )

    # Безопасное преобразование trial_available к int
    safe_trial_available = int(bool(trial_available)) if trial_available is not None else 0
    safe_is_referral_trial = int(bool(is_referral_trial)) if is_referral_trial is not None else 0
    safe_can_upgrade_to_referral = int(bool(can_upgrade_to_referral)) if can_upgrade_to_referral is not None else 0
    safe_is_referral_subscription = int(bool(is_referral_subscription)) if is_referral_subscription is not None else 0
    safe_is_trial_subscription = int(bool(is_trial_subscription)) if is_trial_subscription is not None else 0
    
    logger.debug(
        f"[subscription_getter] user={user.telegram_id}: "
        f"is_trial_subscription={is_trial_subscription}, "
        f"safe_is_trial_subscription={safe_is_trial_subscription}, "
        f"current_subscription={user.current_subscription}, "
        f"is_trial={user.current_subscription.is_trial if user.current_subscription else None}, "
        f"is_active={user.current_subscription.is_active if user.current_subscription else None}"
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Проверяем, включена ли реферальная система
    is_referral_enable = await settings_service.is_referral_enable()
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(user.balance, referral_balance, is_balance_combined)
    
    result = {
        "has_active_subscription": has_active,
        "is_not_unlimited": not is_unlimited,
        "is_topup_mode": is_topup_mode,
        "trial_available": safe_trial_available,
        "is_referral_trial": safe_is_referral_trial,
        "can_upgrade_to_referral": safe_can_upgrade_to_referral,
        "is_referral_subscription": safe_is_referral_subscription,
        "is_trial_subscription": safe_is_trial_subscription,
        # Данные пользователя для шапки
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if is_referral_enable else 0,
        # Для кнопки "Мои устройства"
        "has_device_limit": bool(
            user.current_subscription 
            and user.current_subscription.has_devices_limit 
            and user.current_subscription.is_active
        ),
    }
    
    # Данные о текущей подписке (если есть)
    subscription = user.current_subscription
    if subscription:
        extra_devices = subscription.extra_devices or 0
        
        # Вычисляем бонус устройств (разница между реальным лимитом из Remnawave и планом, БЕЗ купленных доп.)
        plan_device_limit = subscription.plan.device_limit if subscription.plan.device_limit > 0 else 0
        actual_device_limit = subscription.device_limit
        device_limit_bonus = max(0, actual_device_limit - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0
        
        result.update({
            "has_subscription": "true",
            "plan_name": subscription.plan.name,
            "current_plan_name": subscription.plan.name,
            "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
            "device_limit": i18n_format_device_limit(subscription.device_limit),
            "device_limit_number": format_device_limit_number(subscription.plan.device_limit),
            "device_limit_bonus": device_limit_bonus,
            "extra_devices": extra_devices,
            "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
        })
    else:
        result.update({
            "has_subscription": "false",
            "plan_name": "",
            "current_plan_name": "",
            "traffic_limit": "",
            "device_limit": "",
            "device_limit_number": 0,
            "device_limit_bonus": 0,
            "extra_devices": 0,
            "expire_time": "",
        })
    
    return result


@inject
async def plans_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    plan_service: FromDishka[PlanService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs: Any,
) -> dict[str, Any]:
    currency = (await settings_service.get()).default_currency
    plans = await plan_service.get_available_plans(user)

    # Если пользователь меняет подписку (CHANGE), исключаем текущий активный план из списка
    purchase_type = dialog_manager.dialog_data.get("purchase_type")
    if purchase_type == PurchaseType.CHANGE and user.current_subscription:
        current_plan_id = user.current_subscription.plan.id
        plans = [plan for plan in plans if plan.id != current_plan_id]

    formatted_plans = [
        {
            "id": plan.id,
            "name": plan.name,
        }
        for plan in plans
    ]

    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Проверяем, включена ли реферальная система
    is_referral_enable = await settings_service.is_referral_enable()
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(user.balance, referral_balance, is_balance_combined)
    
    result = {
        "plans": formatted_plans,
        # Данные пользователя для шапки
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if is_referral_enable else 0,
    }

    # Данные о текущей подписке (если есть)
    subscription = user.current_subscription
    if subscription:
        extra_devices = subscription.extra_devices or 0
        # Вычисляем бонус устройств (БЕЗ купленных доп.)
        plan_device_limit = subscription.plan.device_limit if subscription.plan.device_limit > 0 else 0
        actual_device_limit = subscription.device_limit
        device_limit_bonus = max(0, actual_device_limit - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0
        
        result.update({
            "has_subscription": "true",
            "current_plan_name": subscription.plan.name,
            "plan_name": subscription.plan.name,
            "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
            "device_limit": i18n_format_device_limit(subscription.device_limit),
            "device_limit_number": format_device_limit_number(subscription.plan.device_limit),
            "device_limit_bonus": device_limit_bonus,
            "extra_devices": extra_devices,
            "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
        })
    else:
        result.update({
            "has_subscription": "false",
            "current_plan_name": "",
            "plan_name": "",
            "traffic_limit": "",
            "device_limit": "",
            "device_limit_number": 0,
            "device_limit_bonus": 0,
            "extra_devices": 0,
            "expire_time": "",
        })

    return result


@inject
async def duration_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    i18n: FromDishka[TranslatorRunner],
    settings_service: FromDishka[SettingsService],
    pricing_service: FromDishka[PricingService],
    referral_service: FromDishka[ReferralService],
    extra_device_service: FromDishka[ExtraDeviceService],
    **kwargs: Any,
) -> dict[str, Any]:
    adapter = DialogDataAdapter(dialog_manager)
    plan = adapter.load(PlanDto)

    if not plan:
        raise ValueError("PlanDto not found in dialog data")

    currency = await settings_service.get_default_currency()
    only_single_plan = dialog_manager.dialog_data.get("only_single_plan", False)
    dialog_manager.dialog_data["is_free"] = False
    
    # Получаем настройки глобальной скидки
    global_discount = await settings_service.get_global_discount_settings()
    
    # Получаем курсы валют для конвертации
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    usd_rate = rates.usd_rate
    eur_rate = rates.eur_rate
    stars_rate = rates.stars_rate
    
    # Получаем стоимость дополнительных устройств для всех типов покупок
    purchase_type = dialog_manager.dialog_data.get("purchase_type")
    extra_devices_monthly_cost = 0
    is_extra_devices_one_time = await settings_service.is_extra_devices_one_time()
    active_extra_devices = 0
    
    # Для NEW, RENEW и CHANGE проверяем наличие активных доп. устройств
    # Для CHANGE не учитываем: доп. устройства удаляются при смене тарифа
    # Только если они не оплачиваются единоразово
    if user.current_subscription and not is_extra_devices_one_time and purchase_type != PurchaseType.CHANGE:
        # Получаем активные покупки дополнительных устройств
        active_purchases = await extra_device_service.get_active_by_subscription(
            user.current_subscription.id
        )
        
        # Подсчитываем устройства, исключая помеченные на удаление
        active_extra_devices = sum(
            p.device_count for p in active_purchases if not p.pending_deletion
        )
        
        # Получаем месячную цену за одно дополнительное устройство
        # Используем цену из нового тарифа (plan.device_price), иначе глобальную
        if active_extra_devices > 0:
            device_price_monthly = plan.device_price if plan.device_price and plan.device_price > 0 else await settings_service.get_extra_device_price()
            extra_devices_monthly_cost = device_price_monthly * active_extra_devices
    
    durations = []

    for duration in plan.durations:
        key, kw = i18n_format_days(duration.days)
        base_price = duration.get_price(currency, usd_rate, eur_rate, stars_rate)
        
        # Добавляем стоимость доп. устройств пропорционально периоду
        if extra_devices_monthly_cost > 0:
            # Рассчитываем стоимость доп. устройств за период (пропорционально дням)
            extra_devices_cost = int((extra_devices_monthly_cost * duration.days) / 30)
            total_price = base_price + extra_devices_cost
        else:
            total_price = base_price
            extra_devices_cost = 0
        
        price = pricing_service.calculate(user, total_price, currency, global_discount, context="subscription")
        has_discount = 1 if price.discount_percent > 0 or price.final_amount < price.original_amount else 0
        is_free = 1 if price.final_amount == 0 else 0
        durations.append(
            {
                "days": duration.days,
                "period": i18n.get(key, **kw),
                "final_amount": format_price(price.final_amount, currency),
                "discount_percent": price.discount_percent,
                "original_amount": format_price(price.original_amount, currency),
                "extra_devices_cost": extra_devices_cost,
                "has_discount": has_discount,
                "is_free": is_free,
            }
        )

    is_plan_free = all(d["is_free"] == 1 for d in durations) if durations else False
    single_duration = 1 if len(durations) == 1 else 0
    single_duration_days = durations[0]["days"] if single_duration else 0
    is_single_free = 1 if (single_duration and is_plan_free) else 0
    dialog_manager.dialog_data["single_duration_days"] = single_duration_days

    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(user.balance, referral_balance, is_balance_combined)
    
    # Получаем информацию о планируемых дополнительных устройствах (если выбраны)
    planned_extra_devices = dialog_manager.dialog_data.get("device_count", 0)
    
    # Базовые данные о плане
    result = {
        "plan": plan.name,
        "plan_name": plan.name,
        "description": plan.description or False,
        "type": plan.type,
        "devices": i18n_format_device_limit(plan.device_limit),
        "is_plan_device_unlimited": 1 if plan.device_limit <= 0 else 0,
        "traffic": i18n_format_traffic_limit(plan.traffic_limit),
        "durations": durations,
        "period": durations[0]["period"] if single_duration else 0,
        "original_amount": durations[0]["original_amount"] if single_duration else 0,
        "final_amount": 0,
        "currency": "",
        "only_single_plan": only_single_plan,
        "is_free": 1 if is_plan_free else 0,
        "single_duration": single_duration,
        "single_duration_days": single_duration_days,
        "is_single_free": is_single_free,
        # Данные пользователя для шапки
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные о стоимости доп. устройств
        "extra_devices_monthly_cost": extra_devices_monthly_cost,
        "has_extra_devices_cost": 1 if extra_devices_monthly_cost > 0 else 0,
        "purchase_type": purchase_type,
        # Планируемые дополнительные устройства
        "planned_extra_devices": planned_extra_devices,
        "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
        "renew_extra_devices": active_extra_devices,
    }

    # Данные о текущей подписке (если есть)
    subscription = user.current_subscription
    if subscription:
        extra_devices = subscription.extra_devices or 0
        # Вычисляем бонус устройств (БЕЗ купленных доп.)
        plan_device_limit = subscription.plan.device_limit if subscription.plan.device_limit > 0 else 0
        actual_device_limit = subscription.device_limit
        device_limit_bonus = max(0, actual_device_limit - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0
        
        result.update({
            "has_subscription": "true",
            "current_plan_name": subscription.plan.name,
            "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
            "device_limit": i18n_format_device_limit(subscription.device_limit),
            "device_limit_number": format_device_limit_number(subscription.plan.device_limit),
            "device_limit_bonus": device_limit_bonus,
            "extra_devices": extra_devices,
            "has_extra_devices": 1 if extra_devices > 0 else 0,
            "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
        })
    else:
        result.update({
            "has_subscription": "false",
            "current_plan_name": "",
            "traffic_limit": "",
            "device_limit": "",
            "device_limit_number": 0,
            "device_limit_bonus": 0,
            "extra_devices": 0,
            "has_extra_devices": 0,
            "expire_time": "",
        })

    return result


@inject
async def payment_method_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    payment_gateway_service: FromDishka[PaymentGatewayService],
    settings_service: FromDishka[SettingsService],
    pricing_service: FromDishka[PricingService],
    referral_service: FromDishka[ReferralService],
    extra_device_service: FromDishka[ExtraDeviceService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs: Any,
) -> dict[str, Any]:
    from src.core.enums import PaymentGatewayType
    
    adapter = DialogDataAdapter(dialog_manager)
    plan = adapter.load(PlanDto)

    if not plan:
        raise ValueError("PlanDto not found in dialog data")

    # Получаем настройки глобальной скидки
    global_discount = await settings_service.get_global_discount_settings()

    # Данные о текущей подписке (если есть)
    subscription = user.current_subscription
    device_limit_bonus = 0
    if subscription:
        has_subscription = "true"
        current_plan_name = subscription.plan.name
        traffic_limit = i18n_format_traffic_limit(subscription.traffic_limit)
        device_limit = i18n_format_device_limit(subscription.device_limit)
        device_limit_number = subscription.plan.device_limit
        # Получаем дополнительные устройства
        extra_devices = subscription.extra_devices or 0
        # Вычисляем бонус устройств (БЕЗ купленных доп.)
        plan_device_limit = subscription.plan.device_limit if subscription.plan.device_limit > 0 else 0
        actual_device_limit = subscription.device_limit
        device_limit_bonus = max(0, actual_device_limit - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0
        expire_time = i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited)
    else:
        has_subscription = "false"
        current_plan_name = ""
        traffic_limit = ""
        device_limit = ""
        device_limit_number = 0
        extra_devices = 0
        expire_time = ""

    gateways = await payment_gateway_service.filter_active()
    selected_duration = dialog_manager.dialog_data["selected_duration"]
    only_single_duration = dialog_manager.dialog_data.get("only_single_duration", False)
    only_single_plan = dialog_manager.dialog_data.get("only_single_plan", False)
    purchase_type = dialog_manager.dialog_data.get("purchase_type")
    duration = plan.get_duration(selected_duration)

    if not duration:
        raise ValueError(f"Duration '{selected_duration}' not found in plan '{plan.name}'")

    # Получаем стоимость дополнительных устройств
    # Для CHANGE не учитываем: доп. устройства удаляются при смене тарифа
    extra_devices_monthly_cost = 0
    is_extra_devices_one_time = await settings_service.is_extra_devices_one_time()
    active_extra_devices = 0
    
    if subscription and not is_extra_devices_one_time and purchase_type != PurchaseType.CHANGE:
        # Получаем активные покупки дополнительных устройств
        active_purchases = await extra_device_service.get_active_by_subscription(subscription.id)
        
        # Подсчитываем устройства, исключая помеченные на удаление
        active_extra_devices = sum(
            p.device_count for p in active_purchases if not p.pending_deletion
        )
        
        if active_extra_devices > 0:
            device_price_monthly = plan.device_price if plan.device_price and plan.device_price > 0 else await settings_service.get_extra_device_price()
            extra_devices_monthly_cost = device_price_monthly * active_extra_devices
    
    # Рассчитываем стоимость доп. устройств за период (пропорционально дням)
    extra_devices_cost = int((extra_devices_monthly_cost * duration.days) / 30) if extra_devices_monthly_cost > 0 else 0

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    payment_methods = []
    
    # Получаем бонусный баланс пользователя
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Получаем курсы валют для конвертации
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    usd_rate = rates.usd_rate
    eur_rate = rates.eur_rate
    stars_rate = rates.stars_rate
    
    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Добавляем оплату с баланса ПЕРВОЙ (если функционал включен, показываем ВСЕГДА даже при нулевом балансе)
    if is_balance_enabled:
        currency = await settings_service.get_default_currency()
        base_price = duration.get_price(currency, usd_rate, eur_rate, stars_rate)
        total_price = base_price + extra_devices_cost if extra_devices_cost > 0 else base_price
        price = pricing_service.calculate(user, total_price, currency, global_discount, context="subscription")
        
        # Вычисляем доступный баланс с учётом режима (COMBINED или SEPARATE)
        is_balance_combined = await settings_service.is_balance_combined()
        available_balance = user.balance + referral_balance if is_balance_combined else user.balance
        
        payment_methods.append(
            {
                "gateway_type": PaymentGatewayType.BALANCE,
                "price": format_price(price.final_amount, currency),
                "original_price": format_price(price.original_amount, currency),
                "user_balance": available_balance,
                "discount_percent": price.discount_percent,
                "has_discount": 1 if price.discount_percent > 0 else 0,
            }
        )
    
    for gateway in gateways:
        # Пропускаем BALANCE так как он уже добавлен выше
        if gateway.type == PaymentGatewayType.BALANCE:
            continue
            
        gateway_base_price = duration.get_price(gateway.currency, usd_rate, eur_rate, stars_rate)
        
        # Конвертируем стоимость доп. устройств в валюту шлюза (extra_devices_cost в рублях)
        gateway_extra_devices_cost = Decimal(0)
        if extra_devices_cost > 0:
            gateway_extra_devices_cost = pricing_service.convert_currency(
                Decimal(extra_devices_cost),
                gateway.currency,
                usd_rate,
                eur_rate,
                stars_rate,
            )
        
        # Добавляем стоимость доп. устройств (оба значения теперь в валюте шлюза)
        gateway_total_price = gateway_base_price + gateway_extra_devices_cost
        
        # Используем pricing_service для правильного расчёта с учётом всех скидок
        gateway_price = pricing_service.calculate(user, gateway_total_price, gateway.currency, global_discount, context="subscription")
        
        payment_methods.append(
            {
                "gateway_type": gateway.type,
                "price": format_price(gateway_price.final_amount, gateway.currency),
                "original_price": format_price(gateway_price.original_amount, gateway.currency),
                "discount_percent": gateway_price.discount_percent,
                "has_discount": 1 if gateway_price.discount_percent > 0 else 0,
            }
        )

    key, kw = i18n_format_days(duration.days)

    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Лимит устройств для покупаемой подписки
    # Не показываем (+X) так как дополнительные устройства выводятся отдельной строкой
    device_limit_display = str(format_device_limit_number(plan.device_limit))
    is_plan_device_unlimited = 1 if plan.device_limit <= 0 else 0
    
    # Получаем информацию о планируемых дополнительных устройствах (если выбраны на экране ADD_DEVICE_SELECT_COUNT)
    planned_extra_devices = dialog_manager.dialog_data.get("device_count", 0)
    
    return {
        "has_subscription": has_subscription,
        "current_plan_name": current_plan_name,
        "traffic_limit": traffic_limit,
        "device_limit": device_limit_display,
        "is_plan_device_unlimited": is_plan_device_unlimited,
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "has_extra_devices": 1 if extra_devices > 0 else 0,
        "expire_time": expire_time,
        "plan": plan.name,
        "plan_name": plan.name,
        "description": plan.description or False,
        "type": plan.type,
        "devices": i18n_format_device_limit(plan.device_limit),
        "traffic": i18n_format_traffic_limit(plan.traffic_limit),
        "period": i18n.get(key, **kw),
        "payment_methods": payment_methods,
        "final_amount": 0,
        "currency": "",
        "only_single_duration": only_single_duration,
        "only_single_plan": only_single_plan,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        # Данные пользователя для шапки
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "balance": format_price(int(get_display_balance(user.balance, referral_balance, is_balance_combined)), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные о стоимости доп. устройств
        "extra_devices_monthly_cost": extra_devices_monthly_cost,
        "extra_devices_cost": extra_devices_cost,
        "has_extra_devices_cost": 1 if extra_devices_monthly_cost > 0 else 0,
        "purchase_type": purchase_type,
        # Планируемые дополнительные устройства
        "planned_extra_devices": planned_extra_devices,
        "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
        "renew_extra_devices": active_extra_devices,
    }


@inject
async def confirm_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    i18n: FromDishka[TranslatorRunner],
    payment_gateway_service: FromDishka[PaymentGatewayService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    extra_device_service: FromDishka[ExtraDeviceService],
    pricing_service: FromDishka[PricingService],
    user_service: FromDishka["UserService"],
    **kwargs: Any,
) -> dict[str, Any]:
    adapter = DialogDataAdapter(dialog_manager)
    plan = adapter.load(PlanDto)

    if not plan:
        raise ValueError("PlanDto not found in dialog data")
    
    # Получаем свежие данные пользователя для проверки скидки
    fresh_user = await user_service.get_without_cache(user.telegram_id)
    if fresh_user:
        user = fresh_user
    
    # Логирование для отладки
    logger.info(
        f"[confirm_getter] Loaded plan: id={plan.id}, name={plan.name}, "
        f"current_subscription={user.current_subscription.plan.name if user.current_subscription else 'None'}, "
        f"discount={user.personal_discount}%"
    )

    selected_duration = dialog_manager.dialog_data["selected_duration"]
    only_single_duration = dialog_manager.dialog_data.get("only_single_duration", False)
    is_free = dialog_manager.dialog_data.get("is_free", False)
    selected_payment_method = dialog_manager.dialog_data["selected_payment_method"]
    purchase_type = dialog_manager.dialog_data["purchase_type"]
    duration = plan.get_duration(selected_duration)

    if not duration:
        raise ValueError(f"Duration '{selected_duration}' not found in plan '{plan.name}'")

    # Для бесплатных подписок не нужен платёжный шлюз
    if is_free:
        key, kw = i18n_format_days(duration.days)
        settings = await settings_service.get()
        currency = settings.default_currency
        is_balance_enabled = await settings_service.is_balance_enabled()
        is_balance_combined = await settings_service.is_balance_combined()
        referral_balance = await referral_service.get_pending_rewards_amount(
            telegram_id=user.telegram_id,
            reward_type=ReferralRewardType.MONEY,
        )
        discount_info = calculate_user_discount(user)
        gateways = await payment_gateway_service.filter_active()
        subscription = user.current_subscription
        planned_extra_devices = dialog_manager.dialog_data.get("device_count", 0)

        return {
            "purchase_type": purchase_type,
            "plan": plan.name,
            "plan_name": plan.name,
            "description": plan.description or False,
            "type": plan.type,
            "devices": i18n_format_device_limit(plan.device_limit),
            "is_plan_device_unlimited": 1 if plan.device_limit <= 0 else 0,
            "traffic": i18n_format_traffic_limit(plan.traffic_limit),
            "period": i18n.get(key, **kw),
            "payment_method": selected_payment_method,
            "gateway_type": PaymentGatewayType.BALANCE,
            "currency": currency.value,
            "discount_percent": 0,
            "original_amount": format_price(Decimal(0), currency),
            "final_amount": format_price(Decimal(0), currency),
            "url": None,
            "only_single_gateway": len(gateways) <= 1,
            "only_single_duration": only_single_duration,
            "is_free": 1,
            "is_telegram_stars": 0,
            "is_yoomoney": 0,
            "is_heleket": 0,
            "user_id": str(user.telegram_id),
            "user_name": user.name,
            "balance": format_price(int(get_display_balance(user.balance, referral_balance, is_balance_combined)), currency),
            "referral_balance": format_price(int(referral_balance), currency),
            "referral_code": user.referral_code,
            "discount_value": discount_info.value,
            "discount_is_temporary": 1 if discount_info.is_temporary else 0,
            "discount_is_permanent": 1 if discount_info.is_permanent else 0,
            "discount_remaining": discount_info.remaining_days,
            "has_subscription": "true" if subscription else "false",
            "current_plan_name": subscription.plan.name if subscription else "",
            "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit) if subscription else "",
            "device_limit_current": i18n_format_device_limit(subscription.device_limit) if subscription else "",
            "device_limit_number": format_device_limit_number(subscription.plan.device_limit if subscription else 0),
            "device_limit_bonus": max(0, subscription.device_limit - subscription.plan.device_limit - (subscription.extra_devices or 0)) if subscription and subscription.plan.device_limit > 0 else 0,
            "extra_devices": subscription.extra_devices or 0 if subscription else 0,
            "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited) if subscription else "",
            "is_balance_enabled": 1 if is_balance_enabled else 0,
            "is_balance_separate": 0 if is_balance_combined else 1,
            "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
            "extra_devices_monthly_cost": "0",
            "extra_devices_cost": "0",
            "has_extra_devices_cost": 0,
            "total_payment": format_price(Decimal(0), currency),
            "planned_extra_devices": planned_extra_devices,
            "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
            "renew_extra_devices": subscription.extra_devices or 0 if subscription else 0,
        }

    payment_gateway = await payment_gateway_service.get_by_type(selected_payment_method)

    if not payment_gateway:
        raise ValueError(f"Not found PaymentGateway by selected type '{selected_payment_method}'")

    result_url = dialog_manager.dialog_data["payment_url"]
    pricing_data = dialog_manager.dialog_data["final_pricing"]
    pricing = PriceDetailsDto.model_validate_json(pricing_data)
    
    # Получаем курсы валют и настройки для пересчёта цены
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    usd_rate = rates.usd_rate
    eur_rate = rates.eur_rate
    stars_rate = rates.stars_rate
    
    # Пересчитываем цену с учётом актуальной скидки пользователя
    global_discount = await settings_service.get_global_discount_settings()
    base_price = duration.get_price(payment_gateway.currency, usd_rate, eur_rate, stars_rate)
    extra_devices_cost_rub = float(dialog_manager.dialog_data.get("extra_devices_cost", 0) or 0)
    total_price = base_price + Decimal(extra_devices_cost_rub)
    pricing = pricing_service.calculate(user, total_price, payment_gateway.currency, global_discount, context="subscription")
    
    logger.info(f"[confirm_getter] Price recalculated: original={pricing.original_amount}, final={pricing.final_amount}, discount={pricing.discount_percent}%")

    key, kw = i18n_format_days(duration.days)
    gateways = await payment_gateway_service.filter_active()

    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Получаем стоимость доп. устройств из dialog_data (уже определена выше)
    base_subscription_price = float(dialog_manager.dialog_data.get("base_subscription_price", 0) or 0)
    
    # Рассчитываем месячную стоимость для отображения
    # Для CHANGE не учитываем: доп. устройства удаляются при смене тарифа
    from src.core.enums import PurchaseType
    extra_devices_monthly_cost_rub = 0
    is_extra_devices_one_time = await settings_service.is_extra_devices_one_time()
    active_extra_devices = 0
    
    if user.current_subscription and not is_extra_devices_one_time and purchase_type != PurchaseType.CHANGE:
        # Получаем количество активных доп. устройств и цену из тарифа
        active_extra_devices = await extra_device_service.get_total_active_devices(user.current_subscription.id)
        if active_extra_devices > 0:
            device_price_monthly = plan.device_price if plan.device_price and plan.device_price > 0 else await settings_service.get_extra_device_price()
            extra_devices_monthly_cost_rub = device_price_monthly * active_extra_devices
    
    # Получаем информацию о планируемых дополнительных устройствах (если выбраны)
    planned_extra_devices = dialog_manager.dialog_data.get("device_count", 0)
    
    # Данные о текущей подписке (если есть)
    subscription = user.current_subscription
    if subscription:
        has_subscription = "true"
        current_plan_name = subscription.plan.name
        traffic_limit = i18n_format_traffic_limit(subscription.traffic_limit)
        device_limit_current = i18n_format_device_limit(subscription.device_limit)
        device_limit_number = subscription.plan.device_limit
        extra_devices = subscription.extra_devices or 0
        device_limit_bonus = max(0, subscription.device_limit - device_limit_number - extra_devices) if device_limit_number > 0 else 0
        expire_time = i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited)
    else:
        has_subscription = "false"
        current_plan_name = ""
        traffic_limit = ""
        device_limit_current = ""
        device_limit_number = 0
        extra_devices = 0
        device_limit_bonus = 0
        expire_time = ""
    
    final_amount_for_display = pricing.final_amount
    
    # base_subscription_price и extra_devices_cost_rub уже в валюте шлюза (не нужно конвертировать)
    # Для отображения "Подписка: ..." всегда используем цену БЕЗ скидки
    base_subscription_price_converted = format_price(pricing.original_amount, payment_gateway.currency)
    
    # Логирование для проверки правильности данных покупаемого плана
    logger.info(
        f"[confirm_getter] Returning data - "
        f"plan_name={plan.name}, traffic={i18n_format_traffic_limit(plan.traffic_limit)}, "
        f"devices={i18n_format_device_limit(plan.device_limit)}, "
        f"current_plan_name={current_plan_name}"
    )
    
    # DEBUG: Проверяем значения перед return
    logger.info(
        f"[confirm_getter] DEBUG VALUES: "
        f"pricing.final_amount={pricing.final_amount}, "
        f"pricing.original_amount={pricing.original_amount}, "
        f"payment_gateway.currency={payment_gateway.currency}, "
        f"total_payment_formatted={format_price(pricing.final_amount, payment_gateway.currency)}, "
        f"base_subscription_price={base_subscription_price}, "
        f"extra_devices_cost_rub={extra_devices_cost_rub}"
    )
    
    return {
        "purchase_type": purchase_type,
        "plan": plan.name,
        "plan_name": plan.name,
        "description": plan.description or False,
        "type": plan.type,
        "devices": i18n_format_device_limit(plan.device_limit),
        "is_plan_device_unlimited": 1 if plan.device_limit <= 0 else 0,
        "traffic": i18n_format_traffic_limit(plan.traffic_limit),
        "period": i18n.get(key, **kw),
        "payment_method": selected_payment_method,
        "gateway_type": payment_gateway.type,
        "currency": payment_gateway.currency.value,
        "discount_percent": pricing.discount_percent,
        "original_amount": base_subscription_price_converted,
        "final_amount": format_price(pricing.final_amount, payment_gateway.currency),
        "url": result_url,
        "only_single_gateway": len(gateways) == 1,
        "only_single_duration": only_single_duration,
        "is_free": 1 if is_free else 0,
        "is_telegram_stars": selected_payment_method == PaymentGatewayType.TELEGRAM_STARS,
        "is_yoomoney": selected_payment_method == PaymentGatewayType.YOOMONEY,
        "is_heleket": selected_payment_method == PaymentGatewayType.HELEKET,
        # Данные пользователя для шапки
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "balance": format_price(int(get_display_balance(user.balance, referral_balance, is_balance_combined)), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        # Данные о текущей подписке
        "has_subscription": has_subscription,
        "current_plan_name": current_plan_name,
        "traffic_limit": traffic_limit,
        "device_limit_current": device_limit_current,
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": expire_time,
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные о стоимости доп. устройств
        # extra_devices_monthly_cost_rub - рассчитано в рублях, конвертируем
        # extra_devices_cost_rub - уже в валюте шлюза (не конвертируем)
        "extra_devices_monthly_cost": format_price(
            pricing_service.convert_currency(Decimal(extra_devices_monthly_cost_rub), payment_gateway.currency, usd_rate, eur_rate, stars_rate),
            payment_gateway.currency
        ) if extra_devices_monthly_cost_rub > 0 else "0",
        "extra_devices_cost": format_price(
            Decimal(str(extra_devices_cost_rub)),
            payment_gateway.currency
        ) if extra_devices_cost_rub > 0 else "0",
        "has_extra_devices_cost": 1 if extra_devices_cost_rub > 0 else 0,
        "total_payment": format_price(pricing.final_amount, payment_gateway.currency),
        # Планируемые дополнительные устройства
        "planned_extra_devices": planned_extra_devices,
        "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
        "renew_extra_devices": active_extra_devices,
    }


@inject
async def confirm_balance_getter(
    dialog_manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
    user: UserDto,
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    extra_device_service: FromDishka[ExtraDeviceService],
    pricing_service: FromDishka[PricingService],
    user_service: FromDishka["UserService"],
    **kwargs: Any,
) -> dict[str, Any]:
    """Getter for balance payment confirmation page."""
    adapter = DialogDataAdapter(dialog_manager)
    plan = adapter.load(PlanDto)

    if not plan:
        raise ValueError("PlanDto not found in dialog data")
    
    # Получаем свежие данные пользователя для проверки скидки
    fresh_user = await user_service.get_without_cache(user.telegram_id)
    if fresh_user:
        user = fresh_user

    selected_duration = dialog_manager.dialog_data["selected_duration"]
    only_single_duration = dialog_manager.dialog_data.get("only_single_duration", False)
    purchase_type = dialog_manager.dialog_data["purchase_type"]
    duration = plan.get_duration(selected_duration)

    if not duration:
        raise ValueError(f"Duration '{selected_duration}' not found in plan '{plan.name}'")

    pricing_data = dialog_manager.dialog_data["final_pricing"]
    pricing = PriceDetailsDto.model_validate_json(pricing_data)
    currency = dialog_manager.dialog_data["balance_currency"]
    
    # Пересчитываем цену с учётом актуальной скидки пользователя
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    global_discount = await settings_service.get_global_discount_settings()
    base_price = duration.get_price(currency, rates.usd_rate, rates.eur_rate, rates.stars_rate)
    extra_devices_cost = float(dialog_manager.dialog_data.get("extra_devices_cost", 0) or 0)
    total_price = base_price + Decimal(extra_devices_cost)
    pricing = pricing_service.calculate(user, total_price, currency, global_discount, context="subscription")

    # Рассчитываем цену только подписки (без доп. устройств) для отображения в Итого
    subscription_only_pricing = pricing_service.calculate(user, base_price, currency, global_discount, context="subscription")

    key, kw = i18n_format_days(duration.days)

    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Вычисляем доступный баланс с учётом режима (COMBINED или SEPARATE)
    is_balance_combined = await settings_service.is_balance_combined()
    available_balance = user.balance + referral_balance if is_balance_combined else user.balance

    result = {
        "purchase_type": purchase_type,
        "plan": plan.name,
        "plan_name": plan.name,
        "description": plan.description or False,
        "type": plan.type,
        "devices": i18n_format_device_limit(plan.device_limit),
        "is_plan_device_unlimited": 1 if plan.device_limit <= 0 else 0,
        "traffic": i18n_format_traffic_limit(plan.traffic_limit),
        "period": i18n.get(key, **kw),
        "final_amount": format_price(int(pricing.final_amount), currency),
        "discount_percent": pricing.discount_percent,
        "original_amount": format_price(int(pricing.original_amount), currency),
        "subscription_price": format_price(int(subscription_only_pricing.final_amount), currency),
        "original_subscription_price": format_price(int(subscription_only_pricing.original_amount), currency),
        "currency": currency,
        "user_balance": format_price(int(available_balance), currency),
        "balance_after": format_price(int(available_balance - pricing.final_amount), currency),
        "only_single_duration": only_single_duration,
        "is_free": 0,
        # Данные пользователя для профиля
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "balance": format_price(int(available_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
    }

    # DEBUG: Логируем значения для отладки
    from src.core.logger import logger
    logger.info(
        f"[confirm_balance_getter] user={user.telegram_id}: "
        f"user_balance={user.balance}, "
        f"final_amount={pricing.final_amount}, "
        f"original_amount={pricing.original_amount}, "
        f"balance_after={user.balance - pricing.final_amount}"
    )

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    result["is_balance_enabled"] = 1 if is_balance_enabled else 0
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_separate = not is_balance_combined
    result["is_balance_separate"] = 1 if is_balance_separate else 0
    
    # Проверяем, включен ли функционал рефералов
    result["is_referral_enable"] = 1 if await settings_service.is_referral_enable() else 0

    # Получаем информацию о планируемых дополнительных устройствах (если выбраны)
    planned_extra_devices = dialog_manager.dialog_data.get("device_count", 0)
    
    # Получаем сохранённые данные о стоимости из dialog_data
    base_subscription_price = dialog_manager.dialog_data.get("base_subscription_price", int(pricing.original_amount))
    saved_extra_devices_cost = dialog_manager.dialog_data.get("extra_devices_cost", 0)

    # Данные о текущей подписке (если есть)
    subscription = user.current_subscription
    if subscription:
        extra_devices = subscription.extra_devices or 0
        device_limit_number = subscription.plan.device_limit
        device_limit_bonus = max(0, subscription.device_limit - device_limit_number - extra_devices) if device_limit_number > 0 else 0
        
        # Получаем месячную стоимость для отображения
        # Для CHANGE не учитываем: доп. устройства удаляются при смене тарифа
        extra_devices_monthly_cost = 0
        is_extra_devices_one_time = await settings_service.is_extra_devices_one_time()
        
        if not is_extra_devices_one_time and purchase_type != PurchaseType.CHANGE:
            active_extra_devices = await extra_device_service.get_total_active_devices(subscription.id)
            if active_extra_devices > 0:
                device_price_monthly = plan.device_price if plan.device_price and plan.device_price > 0 else await settings_service.get_extra_device_price()
                extra_devices_monthly_cost = device_price_monthly * active_extra_devices
        else:
            active_extra_devices = 0
        
        # total_payment = pricing.final_amount (уже включает доп. устройства и скидку)
        total_payment = pricing.final_amount
        
        result.update({
            "has_subscription": "true",
            "current_plan_name": subscription.plan.name,
            "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
            "device_limit": i18n_format_device_limit(subscription.device_limit),
            "device_limit_number": format_device_limit_number(device_limit_number),
            "device_limit_bonus": device_limit_bonus,
            "extra_devices": extra_devices,
            "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
            "extra_devices_monthly_cost": format_price(int(extra_devices_monthly_cost), currency) if extra_devices_monthly_cost > 0 else "0",
            "extra_devices_cost": format_price(int(saved_extra_devices_cost), currency) if saved_extra_devices_cost > 0 else "0",
            "has_extra_devices_cost": 1 if saved_extra_devices_cost > 0 else 0,
            "total_payment": format_price(pricing.final_amount, currency),
            "balance_after": format_price(int(available_balance - pricing.final_amount), currency),
            "original_amount": format_price(int(base_subscription_price), currency),  # Цена подписки БЕЗ доп. устройств
            "original_total": format_price(int(pricing.original_amount), currency),  # Полная цена (подписка + доп. устройства)
            "user_balance": format_price(int(available_balance), currency),
            "planned_extra_devices": planned_extra_devices,
            "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
            "renew_extra_devices": active_extra_devices,
        })
    else:
        result.update({
            "has_subscription": "false",
            "current_plan_name": "",
            "plan_name": "",
            "traffic_limit": "",
            "device_limit": "",
            "device_limit_number": 0,
            "device_limit_bonus": 0,
            "extra_devices": 0,
            "expire_time": "",
            "extra_devices_monthly_cost": "0",
            "extra_devices_cost": "0",
            "has_extra_devices_cost": 0,
            "total_payment": format_price(int(pricing.final_amount), currency),
            "planned_extra_devices": planned_extra_devices,
            "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
            "renew_extra_devices": 0,
        })

    return result


@inject
async def confirm_yoomoney_getter(
    dialog_manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
    user: UserDto,
    extra_device_service: FromDishka[ExtraDeviceService],
    settings_service: FromDishka[SettingsService],
    referral_service: FromDishka[ReferralService],
    pricing_service: FromDishka[PricingService],
    user_service: FromDishka["UserService"],
    **kwargs: Any,
) -> dict[str, Any]:
    """Getter for Yoomoney/Bank card payment confirmation page."""
    adapter = DialogDataAdapter(dialog_manager)
    plan = adapter.load(PlanDto)

    if not plan:
        raise ValueError("PlanDto not found in dialog data")
    
    # Получаем свежие данные пользователя для проверки скидки
    fresh_user = await user_service.get_without_cache(user.telegram_id)
    if fresh_user:
        user = fresh_user

    selected_duration = dialog_manager.dialog_data["selected_duration"]
    purchase_type = dialog_manager.dialog_data["purchase_type"]
    duration = plan.get_duration(selected_duration)

    if not duration:
        raise ValueError(f"Duration '{selected_duration}' not found in plan '{plan.name}'")

    pricing_data = dialog_manager.dialog_data["final_pricing"]
    pricing = PriceDetailsDto.model_validate_json(pricing_data)
    currency = dialog_manager.dialog_data.get("selected_currency", "RUB")
    result_url = dialog_manager.dialog_data["payment_url"]
    
    # Пересчитываем цену с учётом актуальной скидки пользователя
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    global_discount = await settings_service.get_global_discount_settings()
    base_price = duration.get_price(currency, rates.usd_rate, rates.eur_rate, rates.stars_rate)
    extra_devices_cost = float(dialog_manager.dialog_data.get("extra_devices_cost", 0) or 0)
    total_price = base_price + Decimal(extra_devices_cost)
    pricing = pricing_service.calculate(user, total_price, currency, global_discount, context="subscription")

    key, kw = i18n_format_days(duration.days)
    
    # Получаем информацию о планируемых дополнительных устройствах (если выбраны)
    planned_extra_devices = dialog_manager.dialog_data.get("device_count", 0)
    
    # Получаем сохранённые данные о стоимости из dialog_data
    base_subscription_price = dialog_manager.dialog_data.get("base_subscription_price", int(pricing.original_amount))
    saved_extra_devices_cost = dialog_manager.dialog_data.get("extra_devices_cost", 0)
    
    # Получаем месячную стоимость для отображения
    # Для CHANGE не учитываем: доп. устройства удаляются при смене тарифа
    from src.core.enums import PurchaseType
    extra_devices_monthly_cost = 0
    is_extra_devices_one_time = await settings_service.is_extra_devices_one_time()
    
    active_extra_devices_yoomoney = 0
    if user.current_subscription and not is_extra_devices_one_time and purchase_type != PurchaseType.CHANGE:
        active_extra_devices_yoomoney = await extra_device_service.get_total_active_devices(user.current_subscription.id)
        if active_extra_devices_yoomoney > 0:
            device_price_monthly = plan.device_price if plan.device_price and plan.device_price > 0 else await settings_service.get_extra_device_price()
            extra_devices_monthly_cost = device_price_monthly * active_extra_devices_yoomoney

    # Получаем реферальный баланс
    from src.core.enums import ReferralRewardType
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    return {
        "purchase_type": purchase_type,
        "plan": plan.name,
        "plan_name": plan.name,
        "description": plan.description or False,
        "type": plan.type,
        "devices": i18n_format_device_limit(plan.device_limit),
        "is_plan_device_unlimited": 1 if plan.device_limit <= 0 else 0,
        "traffic": i18n_format_traffic_limit(plan.traffic_limit),
        "period": i18n.get(key, **kw),
        "final_amount": format_price(int(pricing.final_amount), currency),
        "discount_percent": pricing.discount_percent,
        "original_amount": format_price(int(base_subscription_price), currency),  # Цена подписки БЕЗ доп. устройств
        "original_total": format_price(int(pricing.original_amount), currency),  # Полная цена (подписка + доп. устройства)
        "currency": currency,
        "url": result_url,
        "is_free": 0,
        # Данные о стоимости доп. устройств
        "extra_devices_monthly_cost": format_price(int(extra_devices_monthly_cost), currency) if extra_devices_monthly_cost > 0 else "0",
        "extra_devices_cost": format_price(int(saved_extra_devices_cost), currency) if saved_extra_devices_cost > 0 else "0",
        "has_extra_devices_cost": 1 if saved_extra_devices_cost > 0 else 0,
        "total_payment": format_price(int(pricing.final_amount), currency),
        # Планируемые дополнительные устройства
        "planned_extra_devices": planned_extra_devices,
        "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
        "renew_extra_devices": active_extra_devices_yoomoney,
        # User profile data
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "balance": format_price(int(user.balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        # Discount data
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        # Subscription data
        "has_subscription": "true" if user.current_subscription else "false",
        "current_plan_name": user.current_subscription.plan.name if user.current_subscription else "",
        "traffic_limit": i18n_format_traffic_limit(user.current_subscription.traffic_limit) if user.current_subscription else "",
        "device_limit_current": i18n_format_device_limit(user.current_subscription.device_limit) if user.current_subscription else "",
        "device_limit_number": format_device_limit_number(user.current_subscription.plan.device_limit) if user.current_subscription else 0,
        "device_limit_bonus": max(0, user.current_subscription.device_limit - user.current_subscription.plan.device_limit - (user.current_subscription.extra_devices or 0)) if user.current_subscription and user.current_subscription.plan.device_limit > 0 else 0,
        "extra_devices": user.current_subscription.extra_devices or 0 if user.current_subscription else 0,
        "expire_time": i18n_format_expire_time(user.current_subscription.expire_at, is_unlimited=user.current_subscription.is_unlimited) if user.current_subscription else "",
        # Balance settings
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        "is_balance_separate": 0 if await settings_service.is_balance_combined() else 1,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
    }


@inject
async def confirm_yookassa_getter(
    dialog_manager: DialogManager,
    i18n: FromDishka[TranslatorRunner],
    user: UserDto,
    extra_device_service: FromDishka[ExtraDeviceService],
    settings_service: FromDishka[SettingsService],
    referral_service: FromDishka[ReferralService],
    pricing_service: FromDishka[PricingService],
    user_service: FromDishka["UserService"],
    **kwargs: Any,
) -> dict[str, Any]:
    """Getter for Yookassa payment confirmation page."""
    adapter = DialogDataAdapter(dialog_manager)
    plan = adapter.load(PlanDto)

    if not plan:
        raise ValueError("PlanDto not found in dialog data")
    
    # Получаем свежие данные пользователя для проверки скидки
    fresh_user = await user_service.get_without_cache(user.telegram_id)
    if fresh_user:
        user = fresh_user

    selected_duration = dialog_manager.dialog_data["selected_duration"]
    purchase_type = dialog_manager.dialog_data["purchase_type"]
    duration = plan.get_duration(selected_duration)

    if not duration:
        raise ValueError(f"Duration '{selected_duration}' not found in plan '{plan.name}'")

    pricing_data = dialog_manager.dialog_data["final_pricing"]
    pricing = PriceDetailsDto.model_validate_json(pricing_data)
    currency = dialog_manager.dialog_data.get("selected_currency", "RUB")
    result_url = dialog_manager.dialog_data["payment_url"]
    
    # Пересчитываем цену с учётом актуальной скидки пользователя
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    global_discount = await settings_service.get_global_discount_settings()
    base_price = duration.get_price(currency, rates.usd_rate, rates.eur_rate, rates.stars_rate)
    extra_devices_cost = float(dialog_manager.dialog_data.get("extra_devices_cost", 0) or 0)
    total_price = base_price + Decimal(extra_devices_cost)
    pricing = pricing_service.calculate(user, total_price, currency, global_discount, context="subscription")

    key, kw = i18n_format_days(duration.days)
    
    # Получаем информацию о планируемых дополнительных устройствах (если выбраны)
    planned_extra_devices = dialog_manager.dialog_data.get("device_count", 0)
    
    # Получаем сохранённые данные о стоимости из dialog_data
    base_subscription_price = dialog_manager.dialog_data.get("base_subscription_price", int(pricing.original_amount))
    saved_extra_devices_cost = dialog_manager.dialog_data.get("extra_devices_cost", 0)
    
    # Получаем месячную стоимость для отображения
    # Используем цену из настроек * количество активных устройств
    from src.core.enums import PurchaseType
    extra_devices_monthly_cost = 0
    is_extra_devices_one_time = await settings_service.is_extra_devices_one_time()
    
    active_extra_devices_yookassa = 0
    if user.current_subscription and not is_extra_devices_one_time:
        active_extra_devices_yookassa = await extra_device_service.get_total_active_devices(user.current_subscription.id)
        if active_extra_devices_yookassa > 0:
            device_price_monthly = plan.device_price if plan.device_price and plan.device_price > 0 else await settings_service.get_extra_device_price()
            extra_devices_monthly_cost = device_price_monthly * active_extra_devices_yookassa

    # Получаем реферальный баланс
    from src.core.enums import ReferralRewardType
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    return {
        "purchase_type": purchase_type,
        "plan": plan.name,
        "plan_name": plan.name,
        "description": plan.description or False,
        "type": plan.type,
        "devices": i18n_format_device_limit(plan.device_limit),
        "is_plan_device_unlimited": 1 if plan.device_limit <= 0 else 0,
        "traffic": i18n_format_traffic_limit(plan.traffic_limit),
        "period": i18n.get(key, **kw),
        "final_amount": format_price(int(pricing.final_amount), currency),
        "discount_percent": pricing.discount_percent,
        "original_amount": format_price(int(base_subscription_price), currency),  # Цена подписки БЕЗ доп. устройств
        "original_total": format_price(int(pricing.original_amount), currency),  # Полная цена (подписка + доп. устройства)
        "currency": currency,
        "url": result_url,
        "is_free": 0,
        # Данные о стоимости доп. устройств
        "extra_devices_monthly_cost": format_price(int(extra_devices_monthly_cost), currency) if extra_devices_monthly_cost > 0 else "0",
        "extra_devices_cost": format_price(int(saved_extra_devices_cost), currency) if saved_extra_devices_cost > 0 else "0",
        "has_extra_devices_cost": 1 if saved_extra_devices_cost > 0 else 0,
        "total_payment": format_price(int(pricing.final_amount), currency),
        # Планируемые дополнительные устройства
        "planned_extra_devices": planned_extra_devices,
        "has_planned_extra_devices": 1 if planned_extra_devices > 0 else 0,
        "renew_extra_devices": active_extra_devices_yookassa,
        # User profile data
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "balance": format_price(int(user.balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": user.referral_code,
        # Discount data
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        # Subscription data
        "has_subscription": "true" if user.current_subscription else "false",
        "current_plan_name": user.current_subscription.plan.name if user.current_subscription else "",
        "traffic_limit": i18n_format_traffic_limit(user.current_subscription.traffic_limit) if user.current_subscription else "",
        "device_limit_current": i18n_format_device_limit(user.current_subscription.device_limit) if user.current_subscription else "",
        "device_limit_number": format_device_limit_number(user.current_subscription.plan.device_limit) if user.current_subscription else 0,
        "device_limit_bonus": max(0, user.current_subscription.device_limit - user.current_subscription.plan.device_limit - (user.current_subscription.extra_devices or 0)) if user.current_subscription and user.current_subscription.plan.device_limit > 0 else 0,
        "extra_devices": user.current_subscription.extra_devices or 0 if user.current_subscription else 0,
        "expire_time": i18n_format_expire_time(user.current_subscription.expire_at, is_unlimited=user.current_subscription.is_unlimited) if user.current_subscription else "",
        # Balance settings
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        "is_balance_separate": 0 if await settings_service.is_balance_combined() else 1,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
    }


@inject
async def getter_connect(
    dialog_manager: DialogManager,
    config: AppConfig,
    user: UserDto,
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    user_service: FromDishka[UserService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs: Any,
) -> dict[str, Any]:
    """
    Getter для экрана подключения после успешного создания пробной подписки.
    Безопасно работает даже если подписка не найдена сразу (может быть задержка БД).
    """
    currency = (await settings_service.get()).default_currency
    
    # Пытаемся получить подписку
    subscription = user.current_subscription
    
    # Если нет подписки в текущих данных, пытаемся перезагрузить
    if not subscription:
        try:
            fresh_user = await user_service.get(user.telegram_id)
            if fresh_user and fresh_user.current_subscription:
                subscription = fresh_user.current_subscription
                user = fresh_user
                logger.debug(f"getter_connect: Loaded subscription from fresh user data for {user.telegram_id}")
        except Exception as e:
            logger.warning(f"getter_connect: Failed to reload user: {e}")
    
    # Если всё ещё нет подписки - это нормально, показываем что можем
    # (она была только что создана, может быть задержка)
    if not subscription:
        logger.warning(
            f"getter_connect: No subscription found for user '{user.telegram_id}' "
            f"(but it should have been just created)"
        )
        
        domain = config.domain.get_secret_value()
        download_url = f"https://{domain}/api/v1/download"
        
        # Возвращаем безопасные данные для рендеринга
        # Пользователь увидит экран с общей информацией
        return {
            "has_subscription": 0,
            "download_url": download_url,
            "happ_add_url": "",
            "plan_name": i18n.get("settings-subscription-activated"),
            "current_plan_name": i18n.get("settings-subscription-activated"),
            "traffic_limit": "...",
            "device_limit": "...",
            "expire_time": "...",
            "user_id": str(user.telegram_id),
            "user_name": user.name,
            "balance": format_price(int(user.balance), currency),
            "referral_balance": 0,
            "referral_code": user.referral_code,
            "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
            "is_balance_separate": 1 if not await settings_service.is_balance_combined() else 0,
            "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        }
    
    # Есть подписка - показываем её данные
    # Get referral balance
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Format subscription data safely
    try:
        plan_name = subscription.plan.name if subscription.plan else "Unknown"
    except Exception as e:
        plan_name = "Unknown"
    
    try:
        traffic_limit = i18n_format_traffic_limit(subscription.traffic_limit)
    except Exception as e:
        traffic_limit = "Unknown"
    
    try:
        device_limit = i18n_format_device_limit(subscription.device_limit)
    except Exception as e:
        device_limit = "Unknown"
    
    try:
        expire_time = i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited)
    except Exception as e:
        expire_time = "Unknown"

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Get extra devices and device limit number
    extra_devices = subscription.extra_devices or 0
    device_limit_number = subscription.plan.device_limit if subscription.plan else 0
    
    # Get balance mode
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # URL для скачивания и подключения через Happ
    domain = config.domain.get_secret_value()
    download_url = f"https://{domain}/api/v1/download"
    subscription_url_value = subscription.url if subscription else ""
    happ_add_url = f"https://{domain}/api/v1/connect/{subscription_url_value}" if subscription_url_value else ""
    
    return {
        "is_app": config.bot.is_mini_app,
        "url": config.bot.mini_app_url or subscription.url,
        "connectable": True,
        "download_url": download_url,
        "happ_add_url": happ_add_url,
        "has_subscription": 1 if subscription else 0,
        # User data
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code or "—",
        "referral_balance": format_price(int(referral_balance), currency),
        "balance": format_price(int(user.balance), currency),
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        # Subscription data
        "plan_name": plan_name,
        "current_plan_name": plan_name,  # For frg-subscription fragment
        "traffic_limit": traffic_limit,
        "device_limit": device_limit,
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": max(0, subscription.device_limit - device_limit_number) if device_limit_number > 0 else 0,
        "extra_devices": extra_devices,
        "expire_time": expire_time,
    }


@inject
async def success_payment_getter(
    dialog_manager: DialogManager,
    config: AppConfig,
    user: UserDto,
    user_service: FromDishka[UserService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs: Any,
) -> dict[str, Any]:
    currency = (await settings_service.get()).default_currency
    # Try to get purchase_type from dialog_data first, then from start_data
    purchase_type: PurchaseType = dialog_manager.dialog_data.get("purchase_type")
    if not purchase_type:
        start_data = cast(dict[str, Any], dialog_manager.start_data)
        if start_data:
            purchase_type = start_data.get("purchase_type", PurchaseType.NEW)
        else:
            purchase_type = PurchaseType.NEW
    
    # Очищаем кэш и получаем свежие данные пользователя
    await user_service.clear_user_cache(user.telegram_id)
    fresh_user = await user_service.get(user.telegram_id)
    if not fresh_user:
        fresh_user = user
    
    # Получаем реферальный баланс
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=fresh_user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(fresh_user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Получаем device_count из dialog_data для ADD_DEVICE
    device_count = dialog_manager.dialog_data.get("device_count", 0)
    
    # ВАЖНО: Показываем данные купленного плана из dialog_data, а не текущей подписки
    # Т.к. обновление подписки происходит асинхронно через purchase_subscription_task
    adapter = DialogDataAdapter(dialog_manager)
    plan = adapter.load(PlanDto)
    
    # Если plan есть в dialog_data - используем его (NEW/RENEW/CHANGE)
    if plan and purchase_type in (PurchaseType.NEW, PurchaseType.RENEW, PurchaseType.CHANGE):
        selected_duration = dialog_manager.dialog_data.get("selected_duration")
        duration = plan.get_duration(selected_duration) if selected_duration else None
        
        # Рассчитываем параметры на основе купленного плана
        plan_name = plan.name
        traffic_limit = i18n_format_traffic_limit(plan.traffic_limit)
        device_limit_display = i18n_format_device_limit(plan.device_limit)
        device_limit_number = plan.device_limit
        
        # Для extra_devices берем данные из текущей подписки (если есть)
        subscription = fresh_user.current_subscription
        if subscription:
            extra_devices = subscription.extra_devices or 0
            device_limit_bonus = max(0, subscription.device_limit - device_limit_number - extra_devices) if device_limit_number > 0 else 0
            
            # Вычисляем новое время окончания в зависимости от типа покупки
            if duration and purchase_type == PurchaseType.NEW:
                # Новая подписка - устанавливаем срок от текущего момента
                if duration.is_unlimited:
                    expire_time = i18n_format_expire_time(format_days_to_datetime(-1), is_unlimited=True)
                else:
                    from datetime import datetime, timedelta, timezone
                    new_expire_at = datetime.now(timezone.utc) + timedelta(days=duration.days)
                    expire_time = i18n_format_expire_time(new_expire_at)
            elif duration and purchase_type == PurchaseType.RENEW:
                # При продлении используем актуальный expire_at из БД (он уже обновлен в subscriptions.py)
                expire_time = i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited)
            elif duration and purchase_type == PurchaseType.CHANGE:
                # При смене плана устанавливаем новый срок
                if duration.is_unlimited:
                    expire_time = i18n_format_expire_time(format_days_to_datetime(-1), is_unlimited=True)
                else:
                    from datetime import datetime, timedelta, timezone
                    new_expire_at = datetime.now(timezone.utc) + timedelta(days=duration.days)
                    expire_time = i18n_format_expire_time(new_expire_at)
            else:
                expire_time = i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited)
        else:
            # Новая подписка
            extra_devices = 0
            device_limit_bonus = 0
            if duration:
                if duration.is_unlimited:
                    expire_time = i18n_format_expire_time(format_days_to_datetime(-1), is_unlimited=True)
                else:
                    from datetime import datetime, timedelta, timezone
                    new_expire_at = datetime.now(timezone.utc) + timedelta(days=duration.days)
                    expire_time = i18n_format_expire_time(new_expire_at)
            else:
                expire_time = "N/A"
        
        added_duration_key, added_duration_kw = i18n_format_days(duration.days) if duration else ("", {})
        
        # Определяем URL и возможность подключения
        subscription_url = ""
        connectable = False
        
        # Пытаемся получить URL подписки из текущей подписки
        if fresh_user.current_subscription and fresh_user.current_subscription.url:
            subscription_url = fresh_user.current_subscription.url
            connectable = True
        elif config.bot.mini_app_url:
            subscription_url = config.bot.mini_app_url
            connectable = True
        
        # Вычисляем отображаемый баланс (с учётом режима объединения)
        display_balance = get_display_balance(fresh_user.balance, referral_balance, is_balance_combined)
        
        return {
            "purchase_type": purchase_type,
            "plan_name": plan_name,
            "current_plan_name": plan_name,
            "is_trial": 0,  # Купленные подписки не триальные
            "traffic_limit": traffic_limit,
            "device_limit": device_limit_display,
            "device_limit_number": format_device_limit_number(device_limit_number),
            "device_limit_bonus": device_limit_bonus,
            "extra_devices": extra_devices,
            "expire_time": expire_time,
            "added_duration": i18n.get(added_duration_key, **added_duration_kw) if duration else "N/A",
            "is_app": config.bot.is_mini_app,
            "url": subscription_url,
            "connectable": connectable,
            "download_url": f"https://{config.domain.get_secret_value()}/api/v1/download",
            "happ_add_url": f"https://{config.domain.get_secret_value()}/api/v1/connect/{fresh_user.current_subscription.url}" if fresh_user.current_subscription and fresh_user.current_subscription.url else "",
            "has_subscription": 1 if fresh_user.current_subscription else 0,
            # Данные профиля пользователя
            "user_id": str(fresh_user.telegram_id),
            "user_name": fresh_user.name,
            "balance": format_price(int(display_balance), currency),
            "referral_balance": format_price(int(referral_balance), currency),
            "referral_code": fresh_user.referral_code,
            "discount_value": discount_info.value,
            "discount_is_temporary": 1 if discount_info.is_temporary else 0,
            "discount_is_permanent": 1 if discount_info.is_permanent else 0,
            "discount_remaining": discount_info.remaining_days,
            "is_balance_enabled": 1 if is_balance_enabled else 0,
            "is_balance_separate": 1 if is_balance_separate else 0,
            "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
            # Для ADD_DEVICE
            "device_count": device_count,
        }
    
    # Fallback: если plan нет в dialog_data или это ADD_DEVICE, используем текущую подписку
    subscription = fresh_user.current_subscription

    if not subscription:
        # Возвращаем безопасные дефолтные значения вместо ошибки
        logger.error(f"User '{fresh_user.telegram_id}' has no active subscription after purchase")
        return {
            "purchase_type": purchase_type,
            "plan_name": "N/A",
            "is_trial": 0,
            "traffic_limit": "N/A",
            "device_limit": "N/A",
            "device_limit_number": 0,
            "device_limit_bonus": 0,
            "extra_devices": 0,
            "expire_time": "N/A",
            "added_duration": "N/A",
            "is_app": config.bot.is_mini_app,
            "url": config.bot.mini_app_url or "",
            "connectable": False,
            "download_url": f"https://{config.domain.get_secret_value()}/api/v1/download",
            "happ_add_url": "",
            "has_subscription": 0,
            "referral_balance": 0,
            "purchase_discount": 0,
            "personal_discount": 0,
            "discount_value": 0,
            "discount_remaining": 0,
            "is_temporary_discount": 0,
            "is_permanent_discount": 0,
            "is_balance_enabled": 0,
            "is_balance_separate": 0,
            "device_count": 0,
            "subscription_days_left": 0,
            "subscription_price": 0,
            "payment_sum": 0,
            "extra_devices_count": 0,
            "extra_devices_price": 0,
        }
    
    # Вычисляем лимиты устройств
    extra_devices = subscription.extra_devices or 0
    # device_limit_number - базовый лимит из тарифа
    device_limit_number = subscription.plan.device_limit
    device_limit_bonus = max(0, subscription.device_limit - device_limit_number - extra_devices) if device_limit_number > 0 else 0
    
    # Вычисляем отображаемый баланс для fallback
    fallback_display_balance = get_display_balance(fresh_user.balance, referral_balance, is_balance_combined)
    
    return {
        "purchase_type": purchase_type,
        "plan_name": subscription.plan.name,
        "current_plan_name": subscription.plan.name,
        "is_trial": 1 if subscription.is_trial else 0,
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
        "device_limit": i18n_format_device_limit(subscription.device_limit),
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
        "added_duration": i18n_format_days(subscription.plan.duration),
        "is_app": config.bot.is_mini_app,
        "url": config.bot.mini_app_url or subscription.url,
        "connectable": True,
        "download_url": f"https://{config.domain.get_secret_value()}/api/v1/download",
        "happ_add_url": f"https://{config.domain.get_secret_value()}/api/v1/connect/{subscription.url}" if subscription.url else "",
        "has_subscription": 1,
        # Данные профиля пользователя
        "user_id": str(fresh_user.telegram_id),
        "user_name": fresh_user.name,
        "balance": format_price(int(fallback_display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "referral_code": fresh_user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Для ADD_DEVICE
        "device_count": device_count,
    }


@inject
async def referral_success_getter(
    dialog_manager: DialogManager,
    config: AppConfig,
    user: UserDto,
    referral_service: FromDishka[ReferralService],
    user_service: FromDishka[UserService],
    settings_service: FromDishka[SettingsService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для экрана успеха реферальной подписки.
    
    ВАЖНО: Получает СВЕЖИЕ данные пользователя из базы, так как
    user из middleware может быть устаревшим после обновления подписки.
    """
    currency = (await settings_service.get()).default_currency
    # Получаем свежие данные пользователя
    await user_service.clear_user_cache(user.telegram_id)
    fresh_user = await user_service.get(user.telegram_id)
    
    if not fresh_user or not fresh_user.current_subscription:
        raise ValueError(f"User '{user.telegram_id}' has no active subscription after referral upgrade")

    subscription = fresh_user.current_subscription
    
    # Get referral balance
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=fresh_user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(fresh_user.balance, referral_balance, is_balance_combined)
    
    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(fresh_user)

    return {
        "is_app": config.bot.is_mini_app,
        "url": config.bot.mini_app_url or subscription.url,
        "connectable": True,
        # User data (свежие данные)
        "user_id": str(fresh_user.telegram_id),
        "user_name": fresh_user.name,
        "referral_code": fresh_user.referral_code or "—",
        "referral_balance": format_price(int(referral_balance), currency),
        "balance": format_price(int(display_balance), currency),
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Subscription data (свежие данные)
        "plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "current_plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
        "device_limit": i18n_format_device_limit(subscription.device_limit),
        "device_limit_number": format_device_limit_number(subscription.plan.device_limit),
        "device_limit_bonus": max(0, subscription.device_limit - subscription.plan.device_limit - (subscription.extra_devices or 0)) if subscription.plan.device_limit > 0 else 0,
        "extra_devices": subscription.extra_devices or 0,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
    }


@inject
async def add_device_select_count_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    pricing_service: FromDishka[PricingService],
    plan_service: FromDishka[PlanService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для окна выбора количества дополнительных устройств."""
    from decimal import Decimal
    currency = (await settings_service.get()).default_currency
    
    # Проверяем наличие активной подписки
    subscription = user.current_subscription
    if not subscription or not subscription.is_active:
        logger.warning(f"User {user.telegram_id} tried to access add_device_select_count without active subscription")
        # Возвращаем минимальные данные для предотвращения ошибки рендеринга
        return {
            "user_id": str(user.telegram_id),
            "user_name": user.name,
            "referral_code": user.referral_code,
            "discount_value": 0,
            "discount_is_temporary": 0,
            "discount_is_permanent": 0,
            "discount_remaining": 0,
            "balance": format_price(0, currency),
            "referral_balance": format_price(0, currency),
            "is_balance_enabled": 0,
            "is_balance_separate": 0,
            "is_referral_enable": 0,
            "plan_name": "",
            "current_plan_name": "",
            "traffic_limit": "",
            "device_limit": "",
            "device_limit_number": 0,
            "device_limit_bonus": 0,
            "extra_devices": 0,
            "expire_time": "",
            "device_price": 0,
            "device_price_original": 0,
            "has_discount": 0,
        }
    
    # Получаем цену дополнительного устройства из АКТУАЛЬНОГО тарифного плана (не из снапшота подписки)
    plan_device_price = None
    if subscription and subscription.plan and subscription.plan.id:
        live_plan = await plan_service.get(subscription.plan.id)
        if live_plan:
            plan_device_price = live_plan.device_price
    
    if plan_device_price and plan_device_price > 0:
        device_price_monthly = plan_device_price
    else:
        device_price_monthly = await settings_service.get_extra_device_price()
    
    # Получаем реферальный баланс
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Получаем глобальную скидку
    global_discount = await settings_service.get_global_discount_settings()
    
    # Вычисляем цену со скидкой используя PricingService (для месячной цены)
    price_details = pricing_service.calculate(
        user=user,
        price=Decimal(device_price_monthly),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    discounted_device_price = int(price_details.final_amount)
    has_discount = price_details.discount_percent > 0
    
    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(user.balance, referral_balance, is_balance_combined)
    
    # Вычисляем лимиты устройств
    extra_devices = subscription.extra_devices or 0
    # device_limit_number - это лимит из тарифного плана
    plan_device_limit = 0
    if subscription.plan and hasattr(subscription.plan, 'device_limit'):
        plan_device_limit = subscription.plan.device_limit if subscription.plan.device_limit > 0 else 0
    device_limit_number = plan_device_limit if plan_device_limit > 0 else subscription.device_limit
    # device_limit_bonus - добавлено админом (общий лимит - план - купленные)
    device_limit_bonus = max(0, subscription.device_limit - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0
    
    return {
        # Данные пользователя
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные подписки
        "plan_name": subscription.plan.name if subscription and subscription.plan else "",
        "current_plan_name": subscription.plan.name if subscription and subscription.plan else "",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit) if subscription else "",
        "device_limit": i18n_format_device_limit(subscription.device_limit) if subscription else "",
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited) if subscription else "",
        # Цена за МЕСЯЦ (из настроек, со скидкой)
        "device_price": discounted_device_price,
        "device_price_original": device_price_monthly,
        "has_discount": 1 if has_discount else 0,
    }


@inject
async def add_device_duration_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    pricing_service: FromDishka[PricingService],
    plan_service: FromDishka[PlanService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для окна выбора типа покупки дополнительных устройств."""
    from decimal import Decimal
    from src.core.utils.pricing import (
        calculate_device_price_until_subscription_end,
        calculate_device_price_until_month_end,
    )
    currency = (await settings_service.get()).default_currency
    
    # Проверяем наличие активной подписки
    subscription = user.current_subscription
    if not subscription or not subscription.is_active:
        logger.warning(f"User {user.telegram_id} tried to access add_device_duration without active subscription")
        # Возвращаем минимальные данные для предотвращения ошибки рендеринга
        return {
            "device_count": 1,
            "price_full": 0,
            "days_full": 0,
            "price_full_month": 0,
            "days_full_month": 0,
            "price_month": 0,
            "days_month": 0,
            "price_months_1": 0,
            "price_months_3": 0,
            "price_months_6": 0,
            "price_months_12": 0,
            "has_discount": 0,
            "is_unlimited_subscription": 0,
            "show_full_option": 0,
            "show_regular_options": 0,
            "show_unlimited_options": 0,
            "show_month_option": 0,
        }
    
    # Получаем количество устройств из dialog_data
    device_count = dialog_manager.dialog_data.get("device_count", 1)
    
    # Получаем цену дополнительного устройства из АКТУАЛЬНОГО тарифного плана (не из снапшота подписки)
    plan_device_price = None
    if subscription and subscription.plan and subscription.plan.id:
        live_plan = await plan_service.get(subscription.plan.id)
        if live_plan:
            plan_device_price = live_plan.device_price
    
    if plan_device_price and plan_device_price > 0:
        device_price_monthly = plan_device_price
    else:
        device_price_monthly = await settings_service.get_extra_device_price()
    
    # Получаем минимальное количество дней из настроек
    min_days = await settings_service.get_extra_device_min_days()
    
    # Получаем реферальный баланс
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Получаем глобальную скидку
    global_discount = await settings_service.get_global_discount_settings()
    
    # Рассчитываем стоимость для всех вариантов
    # Вариант 1: До конца подписки
    price_full, days_full = calculate_device_price_until_subscription_end(
        monthly_price=device_price_monthly,
        subscription_expire_at=subscription.expire_at,
        min_days=min_days,
    )
    
    # Вариант 2: Полный месяц (30 дней)
    price_full_month = device_price_monthly
    days_full_month = 30
    
    # Вариант 3: До конца месяца подписки
    price_month, days_month = calculate_device_price_until_month_end(
        monthly_price=device_price_monthly,
        subscription_expire_at=subscription.expire_at,
        subscription_plan_duration=subscription.plan.duration,
        min_days=min_days,
        plan_activated_at=subscription.plan.activated_at if subscription.plan else None,
    )
    
    # Умножаем на количество устройств
    total_price_full = price_full * device_count
    total_price_full_month = price_full_month * device_count
    total_price_month = price_month * device_count
    
    # Вычисляем цены для месячных вариантов (для безлимитных подписок)
    # 1 месяц = 30 дней
    price_months_1 = device_price_monthly
    total_price_months_1 = price_months_1 * device_count
    
    # 3 месяца = 90 дней
    price_months_3 = device_price_monthly * 3
    total_price_months_3 = price_months_3 * device_count
    
    # 6 месяцев = 180 дней
    price_months_6 = device_price_monthly * 6
    total_price_months_6 = price_months_6 * device_count
    
    # 12 месяцев = 365 дней
    price_months_12 = device_price_monthly * 12
    total_price_months_12 = price_months_12 * device_count
    
    # Применяем скидки через PricingService
    price_details_full = pricing_service.calculate(
        user=user,
        price=Decimal(total_price_full),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    price_details_full_month = pricing_service.calculate(
        user=user,
        price=Decimal(total_price_full_month),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    price_details_month = pricing_service.calculate(
        user=user,
        price=Decimal(total_price_month),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    price_details_months_1 = pricing_service.calculate(
        user=user,
        price=Decimal(total_price_months_1),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    price_details_months_3 = pricing_service.calculate(
        user=user,
        price=Decimal(total_price_months_3),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    price_details_months_6 = pricing_service.calculate(
        user=user,
        price=Decimal(total_price_months_6),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    price_details_months_12 = pricing_service.calculate(
        user=user,
        price=Decimal(total_price_months_12),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    discounted_price_full = int(price_details_full.final_amount)
    discounted_price_full_month = int(price_details_full_month.final_amount)
    discounted_price_month = int(price_details_month.final_amount)
    discounted_price_months_1 = int(price_details_months_1.final_amount)
    discounted_price_months_3 = int(price_details_months_3.final_amount)
    discounted_price_months_6 = int(price_details_months_6.final_amount)
    discounted_price_months_12 = int(price_details_months_12.final_amount)
    has_discount = price_details_full.discount_percent > 0
    
    # Проверяем, безлимитная ли подписка (год = 2099)
    is_unlimited_subscription = subscription.expire_at.year == 2099
    
    # Если безлимитная подписка, не показываем вариант "до конца подписки"
    show_full_option = not is_unlimited_subscription
    
    # Показываем обычные варианты (месяц и до конца цикла) только для обычных подписок
    show_regular_options = not is_unlimited_subscription
    
    # Показываем месячные варианты (1, 3, 6, 12 месяцев) для всех типов подписок
    show_unlimited_options = True
    
    # Проверяем, совпадают ли варианты "до конца подписки" и "до конца периода"
    # Если совпадают по количеству дней и цене, показываем только "до конца подписки"
    show_month_option = show_regular_options and not (
        days_full == days_month and discounted_price_full == discounted_price_month
    )
    
    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(user.balance, referral_balance, is_balance_combined)
    
    # Вычисляем лимиты устройств
    extra_devices = subscription.extra_devices or 0
    plan_device_limit = 0
    if subscription.plan and hasattr(subscription.plan, 'device_limit'):
        plan_device_limit = subscription.plan.device_limit if subscription.plan.device_limit > 0 else 0
    device_limit_number = plan_device_limit if plan_device_limit > 0 else subscription.device_limit
    device_limit_bonus = max(0, subscription.device_limit - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0
    
    return {
        # Данные пользователя
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные подписки
        "plan_name": subscription.plan.name if subscription and subscription.plan else "",
        "current_plan_name": subscription.plan.name if subscription and subscription.plan else "",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
        "device_limit": i18n_format_device_limit(subscription.device_limit),
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
        # Данные о покупке
        "device_count": device_count,
        # Вариант 1: До конца подписки
        "price_full": discounted_price_full,
        "price_full_original": total_price_full,
        "days_full": days_full,
        # Вариант 2: Полный месяц
        "price_full_month": discounted_price_full_month,
        "price_full_month_original": total_price_full_month,
        "days_full_month": days_full_month,
        # Вариант 3: До конца месяца
        "price_month": discounted_price_month,
        "price_month_original": total_price_month,
        "days_month": days_month,
        # Варианты месячных подписок (для безлимитных)
        "price_months_1": discounted_price_months_1,
        "price_months_1_original": total_price_months_1,
        "price_months_3": discounted_price_months_3,
        "price_months_3_original": total_price_months_3,
        "price_months_6": discounted_price_months_6,
        "price_months_6_original": total_price_months_6,
        "price_months_12": discounted_price_months_12,
        "price_months_12_original": total_price_months_12,
        # Общие данные о скидке
        "has_discount": 1 if has_discount else 0,
        # Флаги для отображения вариантов
        "show_full_option": 1 if show_full_option else 0,
        "show_month_option": 1 if show_month_option else 0,
        "show_regular_options": 1 if show_regular_options else 0,
        "show_unlimited_options": 1 if show_unlimited_options else 0,
        "is_unlimited_subscription": 1 if is_unlimited_subscription else 0,
        # Месячная цена для информации
        "device_price_monthly": device_price_monthly,
    }


@inject
async def add_device_payment_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    payment_gateway_service: FromDishka[PaymentGatewayService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    pricing_service: FromDishka[PricingService],
    plan_service: FromDishka[PlanService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для окна выбора способа оплаты при добавлении устройств."""
    from decimal import Decimal
    
    # Получаем количество устройств и тип покупки из dialog_data
    device_count = dialog_manager.dialog_data.get("device_count", 1)
    duration_type = dialog_manager.dialog_data.get("duration_type", "full")  # "full", "full_month", "month", "months_1", "months_3", "months_6", "months_12"
    
    # Получаем уже рассчитанную цену из dialog_data (установлена на шаге выбора типа)
    # Если не установлена - рассчитываем заново
    device_price_rub = dialog_manager.dialog_data.get("calculated_price")
    duration_days = dialog_manager.dialog_data.get("duration_days", 30)
    
    if device_price_rub is None:
        from src.core.utils.pricing import (
            calculate_device_price_until_subscription_end,
            calculate_device_price_until_month_end,
        )
        
        # Получаем цену из АКТУАЛЬНОГО тарифного плана (не из снапшота подписки)
        plan_device_price = None
        if user.current_subscription and user.current_subscription.plan and user.current_subscription.plan.id:
            live_plan = await plan_service.get(user.current_subscription.plan.id)
            if live_plan:
                plan_device_price = live_plan.device_price
        
        if plan_device_price and plan_device_price > 0:
            device_price_monthly = plan_device_price
        else:
            device_price_monthly = await settings_service.get_extra_device_price()
        min_days = await settings_service.get_extra_device_min_days()
        
        if user.current_subscription:
            if duration_type == "month":
                price_per_device, duration_days = calculate_device_price_until_month_end(
                    monthly_price=device_price_monthly,
                    subscription_expire_at=user.current_subscription.expire_at,
                    subscription_plan_duration=user.current_subscription.plan.duration,
                    min_days=min_days,
                    plan_activated_at=user.current_subscription.plan.activated_at if user.current_subscription.plan else None,
                )
            elif duration_type == "full_month":
                price_per_device = device_price_monthly
                duration_days = 30
            elif duration_type == "months_1":
                price_per_device = device_price_monthly
                duration_days = 30
            elif duration_type == "months_3":
                price_per_device = device_price_monthly * 3
                duration_days = 90
            elif duration_type == "months_6":
                price_per_device = device_price_monthly * 6
                duration_days = 180
            elif duration_type == "months_12":
                price_per_device = device_price_monthly * 12
                duration_days = 365
            else:
                price_per_device, duration_days = calculate_device_price_until_subscription_end(
                    monthly_price=device_price_monthly,
                    subscription_expire_at=user.current_subscription.expire_at,
                    min_days=min_days,
                )
            device_price_rub = price_per_device * device_count
        else:
            device_price_rub = device_price_monthly * device_count
    
    # Получаем реферальный баланс
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Получаем глобальную скидку
    global_discount = await settings_service.get_global_discount_settings()
    
    # Получаем курсы валют для конвертации
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    usd_rate = rates.usd_rate
    eur_rate = rates.eur_rate
    stars_rate = rates.stars_rate
    
    # Вычисляем цену со скидкой используя PricingService
    original_price = device_price_rub
    price_details = pricing_service.calculate(
        user=user,
        price=Decimal(original_price),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )
    
    # Результат в рублях (не умножаем на 100, цены хранятся в рублях)
    total_price_rub = int(price_details.final_amount)
    original_price_rub = int(price_details.original_amount)
    has_discount = price_details.discount_percent > 0
    
    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(user.balance, referral_balance, is_balance_combined)
    
    # Вычисляем лимиты устройств
    subscription = user.current_subscription
    extra_devices = subscription.extra_devices or 0 if subscription else 0
    # device_limit_number - это лимит из тарифного плана
    plan_device_limit = subscription.plan.device_limit if subscription and subscription.plan and subscription.plan.device_limit > 0 else 0
    device_limit_number = plan_device_limit if plan_device_limit > 0 else (subscription.device_limit if subscription else 0)
    # device_limit_bonus - добавлено админом (общий лимит - план - купленные)
    device_limit_bonus = max(0, subscription.device_limit - plan_device_limit - extra_devices) if subscription and plan_device_limit > 0 else 0
    
    gateways = await payment_gateway_service.filter_active()
    currency = await settings_service.get_default_currency()
    
    payment_methods = []
    
    # Добавляем оплату с баланса ПЕРВОЙ (если функционал включен)
    # Сохраняем цены для возвращения в результате (в валюте по умолчанию - RUB)
    total_price = total_price_rub
    original_price = original_price_rub
    
    if is_balance_enabled:
        payment_methods.append({
            "gateway_type": PaymentGatewayType.BALANCE,
            "price": format_price(total_price_rub, currency),
            "original_price": format_price(original_price_rub, currency),
            "has_discount": 1 if has_discount else 0,
            "discount_percent": price_details.discount_percent,
        })
    
    # Добавляем другие способы оплаты
    for gateway in gateways:
        # Пропускаем BALANCE так как он уже добавлен выше
        if gateway.type == PaymentGatewayType.BALANCE:
            continue
            
        # Получаем валюту для конкретного шлюза
        gateway_currency = Currency.from_gateway_type(gateway.type)
        
        # Конвертируем цену в валюту способа оплаты
        # total_price_rub и original_price_rub уже в рублях
        # Результат convert_currency в целевой валюте (Decimal)
        converted_original_decimal = pricing_service.convert_currency(
            Decimal(original_price_rub),
            gateway_currency,
            usd_rate,
            eur_rate,
            stars_rate,
        )
        converted_total_decimal = pricing_service.convert_currency(
            Decimal(total_price_rub),
            gateway_currency,
            usd_rate,
            eur_rate,
            stars_rate,
        )
        
        # Возвращаем цены в базовых единицах валюты (не центы)
        # для согласованности с payment_method_getter
        payment_methods.append({
            "gateway_type": gateway.type,
            "price": format_price(converted_total_decimal, gateway_currency),
            "original_price": format_price(converted_original_decimal, gateway_currency),
            "has_discount": 1 if has_discount else 0,
            "discount_percent": price_details.discount_percent,
        })
    
    # Формируем текст типа покупки
    duration_type_text = "до конца месяца подписки" if duration_type == "month" else "до конца подписки"
    
    # Формируем период для отображения
    period_key, period_kw = i18n_format_days(duration_days)
    period = i18n.get(period_key, **period_kw)
    
    return {
        # Данные пользователя
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные подписки
        "plan_name": subscription.plan.name if subscription else "",
        "current_plan_name": subscription.plan.name if subscription else "",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit) if subscription else "",
        "device_limit": i18n_format_device_limit(subscription.device_limit) if subscription else "",
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited) if subscription else "",
        # Данные покупки (со скидкой)
        "device_count": device_count,
        "duration_days": duration_days,
        "duration_type": duration_type,
        "duration_type_text": duration_type_text,
        "total_price": format_price(total_price, currency),
        "original_price": format_price(original_price, currency),
        "period": period,
        "payment_methods": payment_methods,
    }


@inject
async def add_device_confirm_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    pricing_service: FromDishka[PricingService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для окна подтверждения покупки устройств."""
    from decimal import Decimal
    
    # Получаем данные из dialog_data
    device_count = dialog_manager.dialog_data.get("device_count", 1)
    selected_method = dialog_manager.dialog_data.get("selected_payment_method")
    duration_type = dialog_manager.dialog_data.get("duration_type", "full")
    duration_days = dialog_manager.dialog_data.get("duration_days", 30)
    
    # Получаем уже рассчитанную цену из dialog_data
    device_price_rub = dialog_manager.dialog_data.get("calculated_price")
    
    if device_price_rub is None:
        from src.core.utils.pricing import (
            calculate_device_price_until_subscription_end,
            calculate_device_price_until_month_end,
        )
        
        device_price_monthly = await settings_service.get_extra_device_price()
        min_days = await settings_service.get_extra_device_min_days()
        
        if user.current_subscription:
            if duration_type == "month":
                price_per_device, duration_days = calculate_device_price_until_month_end(
                    monthly_price=device_price_monthly,
                    subscription_expire_at=user.current_subscription.expire_at,
                    min_days=min_days,
                    plan_activated_at=user.current_subscription.plan.activated_at if user.current_subscription.plan else None,
                )
            elif duration_type == "full_month":
                price_per_device = device_price_monthly
                duration_days = 30
            elif duration_type == "months_1":
                price_per_device = device_price_monthly
                duration_days = 30
            elif duration_type == "months_3":
                price_per_device = device_price_monthly * 3
                duration_days = 90
            elif duration_type == "months_6":
                price_per_device = device_price_monthly * 6
                duration_days = 180
            elif duration_type == "months_12":
                price_per_device = device_price_monthly * 12
                duration_days = 365
            else:
                price_per_device, duration_days = calculate_device_price_until_subscription_end(
                    monthly_price=device_price_monthly,
                    subscription_expire_at=user.current_subscription.expire_at,
                    min_days=min_days,
                )
            device_price_rub = price_per_device * device_count
        else:
            device_price_rub = device_price_monthly * device_count
    
    # Определяем валюту в зависимости от выбранного метода оплаты
    if selected_method:
        currency = Currency.from_gateway_type(selected_method)
    else:
        currency = await settings_service.get_default_currency()
    
    # Получаем курсы валют для конвертации
    settings = await settings_service.get()
    rates = settings.features.currency_rates
    usd_rate = rates.usd_rate
    eur_rate = rates.eur_rate
    stars_rate = rates.stars_rate
    
    # Форматируем название способа оплаты используя переводы
    selected_method_formatted = selected_method
    
    # Получаем реферальный баланс
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Получаем глобальную скидку
    global_discount = await settings_service.get_global_discount_settings()

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)

    # Используем PricingService для расчета цены с учетом глобальной скидки
    original_price_rub = device_price_rub
    price_details = pricing_service.calculate(
        user=user,
        price=Decimal(original_price_rub),
        currency=currency,
        global_discount=global_discount,
        context="extra_devices",
    )

    # Вычисляем итоговую цену за все устройства (в рублях)
    total_price_rub_amount = int(price_details.final_amount)
    original_price_rub_amount = int(price_details.original_amount)
    
    # Конвертируем цену в валюту выбранного способа оплаты
    # Результат convert_currency в целевой валюте (Decimal)
    original_price_decimal = pricing_service.convert_currency(
        Decimal(original_price_rub_amount),
        currency,
        usd_rate,
        eur_rate,
        stars_rate,
    )
    total_price_decimal = pricing_service.convert_currency(
        Decimal(total_price_rub_amount),
        currency,
        usd_rate,
        eur_rate,
        stars_rate,
    )
    # Keep Decimal for proper fractional display (USD supports cents)
    original_price = original_price_decimal
    total_price = total_price_decimal
    has_discount = price_details.discount_percent > 0

    # Флаг для условного отображения баланса (показываем только при оплате с баланса)
    is_balance_payment = 1 if selected_method == PaymentGatewayType.BALANCE else 0

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(user.balance, referral_balance, is_balance_combined)
    
    # Вычисляем лимиты устройств
    subscription = user.current_subscription
    extra_devices = subscription.extra_devices or 0 if subscription else 0
    # device_limit_number - это лимит из тарифного плана
    plan_device_limit = subscription.plan.device_limit if subscription and subscription.plan and subscription.plan.device_limit > 0 else 0
    device_limit_number = plan_device_limit if plan_device_limit > 0 else (subscription.device_limit if subscription else 0)
    # device_limit_bonus - добавлено админом (общий лимит - план - купленные)
    device_limit_bonus = max(0, subscription.device_limit - plan_device_limit - extra_devices) if subscription and plan_device_limit > 0 else 0
    
    # Вычисляем баланс после оплаты (если баланс) - для баланса нужен int
    if selected_method == PaymentGatewayType.BALANCE:
        new_balance = display_balance - int(total_price)
    else:
        new_balance = display_balance
    
    # Формируем текст типа покупки
    duration_type_text = "до конца месяца подписки" if duration_type == "month" else "до конца подписки"
    
    return {
        # Заголовок
        "title": "🛒 Подтверждение покупки",
        # Данные пользователя
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "new_balance": format_price(int(new_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные подписки
        "plan_name": subscription.plan.name if subscription else "",
        "current_plan_name": subscription.plan.name if subscription else "",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit) if subscription else "",
        "device_limit": i18n_format_device_limit(subscription.device_limit) if subscription else "",
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited) if subscription else "",
        # Данные покупки (со скидкой)
        "device_count": device_count,
        "duration_days": duration_days,
        "duration_type": duration_type,
        "duration_type_text": duration_type_text,
        "total_price": format_price(total_price, currency),
        "original_price": format_price(original_price, currency),
        "gateway_type": selected_method_formatted,
        "currency": currency.symbol,
        "is_balance_payment": is_balance_payment,
        "has_discount": 1 if has_discount else 0,
        # Данные о платеже (если не баланс)
        "payment_url": dialog_manager.dialog_data.get("payment_url", "") if selected_method != PaymentGatewayType.BALANCE else "",
    }


@inject
async def devices_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    remnawave_service: FromDishka[RemnawaveService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    extra_device_service: FromDishka[ExtraDeviceService],
    i18n: FromDishka[TranslatorRunner],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для окна управления устройствами в меню подписки."""
    currency = (await settings_service.get()).default_currency
    
    if not user.current_subscription:
        raise ValueError(f"Current subscription for user '{user.telegram_id}' not found")

    devices = await remnawave_service.get_devices_user(user)

    formatted_devices = [
        {
            "short_hwid": device.hwid[:32],
            "hwid": device.hwid,
            "platform": device.platform,
            "device_model": device.device_model,
            "user_agent": device.user_agent,
        }
        for device in devices
    ]
    
    # Сортируем устройства по hwid для стабильного порядка
    # Это предотвращает сдвиг списка при добавлении новых устройств
    formatted_devices.sort(key=lambda d: d["hwid"])

    dialog_manager.dialog_data["hwid_map"] = formatted_devices
    
    # Получаем текущий и максимальный лимит устройств
    subscription = user.current_subscription
    current_count = len(devices)
    max_count = subscription.device_limit
    plan_device_limit = subscription.plan.device_limit
    
    # Докупленные устройства
    extra_devices = getattr(subscription, 'extra_devices', 0) or 0
    
    # Бонусные устройства (добавленные через админ-панель)
    device_limit_bonus = max(0, max_count - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0
    
    # Определяем, является ли подписка пробной или реферальной
    plan_name_lower = subscription.plan.name.lower() if subscription.plan else ""
    is_trial_subscription = subscription.is_trial or "пробн" in plan_name_lower
    is_referral_subscription = "реферал" in plan_name_lower
    is_import_subscription = "import" in plan_name_lower or (subscription.tag and "import" in subscription.tag.lower())
    is_trial_or_referral = is_trial_subscription or is_referral_subscription
    
    # Проверяем включён ли функционал доп. устройств
    is_extra_devices_enabled = await settings_service.is_extra_devices_enabled()
    
    # Получаем активные покупки доп. устройств
    purchases = []
    try:
        purchases = await extra_device_service.get_active_by_subscription(subscription.id)
    except Exception:
        pass
    
    # Создаём объединённый список слотов устройств
    # Порядок: базовые (из плана) → бонусные (из админки) → купленные (extra)
    device_slots = []
    slot_hwid_map = {}  # Маппинг slot_index -> hwid для удаления устройств
    slot_purchase_map = {}  # Маппинг slot_index -> purchase_id для удаления пустых extra слотов
    devices_copy = list(formatted_devices)  # Копия для распределения
    slot_index = 0
    
    # 1. Базовые слоты подписки (из плана, срок = срок подписки)
    for i in range(plan_device_limit):
        # Пытаемся занять слот устройством
        if devices_copy:
            device = devices_copy.pop(0)
            slot = {
                "id": str(slot_index),  # Короткий индекс для callback_data
                "slot_type": "base",
                "days_display": "∞",
                "is_occupied": True,
                "show_delete_button": False,  # Нет ❌ для занятых слотов
                "show_trash_button": True,  # 🗑 для освобождения слота
                "show_pending_text": False,
                "platform_display": device["platform"],
                "device_info": f"{device['platform']} - {device['device_model']}",
            }
            slot_hwid_map[str(slot_index)] = device["short_hwid"]
        else:
            slot = {
                "id": str(slot_index),
                "slot_type": "base",
                "days_display": "∞",
                "is_occupied": False,
                "show_delete_button": False,  # Нет ❌ для пустых базовых слотов
                "show_trash_button": False,
                "show_pending_text": False,
                "platform_display": "",
                "device_info": i18n.get("frg-empty-slot"),
            }
        device_slots.append(slot)
        slot_index += 1
    
    # 2. Бонусные слоты (добавленные через админ-панель, срок = срок подписки)
    for i in range(device_limit_bonus):
        # Пытаемся занять слот устройством
        if devices_copy:
            device = devices_copy.pop(0)
            slot = {
                "id": str(slot_index),
                "slot_type": "bonus",
                "days_display": "∞",
                "is_occupied": True,
                "show_delete_button": False,  # Нет ❌ для занятых слотов
                "show_trash_button": True,  # 🗑 для освобождения слота
                "show_pending_text": False,
                "platform_display": device["platform"],
                "device_info": f"{device['platform']} - {device['device_model']}",
            }
            slot_hwid_map[str(slot_index)] = device["short_hwid"]
        else:
            slot = {
                "id": str(slot_index),
                "slot_type": "bonus",
                "days_display": "∞",
                "is_occupied": False,
                "show_delete_button": False,  # Нет ❌ для пустых бонусных слотов
                "show_trash_button": False,
                "show_pending_text": False,
                "platform_display": "",
                "device_info": i18n.get("frg-empty-slot"),
            }
        device_slots.append(slot)
        slot_index += 1
    
    # 3. Слоты из покупок (с ограниченным сроком)
    for p in purchases:
        for j in range(p.device_count):
            # Пытаемся занять слот устройством
            if devices_copy:
                device = devices_copy.pop(0)
                from src.core.utils.formatters import pluralize_days
                days_word = pluralize_days(p.days_remaining)
                slot = {
                    "id": str(slot_index),  # Короткий индекс для callback_data
                    "purchase_id": str(p.id),
                    "slot_type": "extra",
                    "days_display": f"{p.days_remaining} {days_word}",
                    "is_occupied": True,
                    "pending_deletion": p.pending_deletion,
                    "show_delete_button": not p.pending_deletion,  # ❌ помечает слот на удаление
                    "show_trash_button": not p.pending_deletion,  # 🗑 для освобождения слота
                    "show_extra_trash_button": False,
                    "show_pending_text": p.pending_deletion,  # "На удалении" если pending
                    "platform_display": device["platform"],
                    "device_info": f"{device['platform']} - {device['device_model']}",
                }
                slot_hwid_map[str(slot_index)] = device["short_hwid"]
                # Сохраняем purchase_id для занятых extra слотов тоже
                slot_purchase_map[str(slot_index)] = p.id
            else:
                from src.core.utils.formatters import pluralize_days
                days_word = pluralize_days(p.days_remaining)
                slot = {
                    "id": str(slot_index),
                    "purchase_id": str(p.id),
                    "slot_type": "extra",
                    "days_display": f"{p.days_remaining} {days_word}",
                    "is_occupied": False,
                    "pending_deletion": p.pending_deletion,
                    "show_delete_button": not p.pending_deletion,  # ❌ только если НЕ на удалении
                    "show_trash_button": False,  # Нет 🗑 для пустых слотов
                    "show_pending_text": p.pending_deletion,  # "Удаляется" если на удалении
                    "platform_display": "",
                    "device_info": i18n.get("frg-empty-slot"),
                }
                # Сохраняем purchase_id для удаления пустого слота
                slot_purchase_map[str(slot_index)] = p.id
            device_slots.append(slot)
            slot_index += 1
    
    # Сохраняем для обработчика удаления
    dialog_manager.dialog_data["slot_hwid_map"] = slot_hwid_map
    dialog_manager.dialog_data["slot_purchase_map"] = slot_purchase_map
    dialog_manager.dialog_data["extra_device_purchases"] = [
        {"id": p.id, "device_count": p.device_count}
        for p in purchases
    ]
    
    has_extra_device_purchases = len(purchases) > 0
    
    # Проверяем, можно ли добавить устройство
    # Запрещаем для пробных, реферальных и импорт подписок
    # Запрещаем если функционал доп. устройств отключён
    can_add_device = (
        max_count is not None 
        and max_count > 0 
        and not is_trial_or_referral
        and not is_import_subscription
        and is_extra_devices_enabled
    )
    
    # Показываем кнопку добавления устройств (видна и для trial — handler покажет предупреждение)
    can_add_extra_device = (
        is_extra_devices_enabled 
        and subscription.is_active
        and not is_import_subscription
    )

    # Данные профиля
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)
    
    # Режим баланса
    is_balance_combined = await settings_service.is_balance_combined()
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(
        user.balance,
        referral_balance,
        is_balance_combined,
    )
    
    return {
        # Данные устройств
        "current_count": current_count,
        "max_count": i18n_format_device_limit(max_count),
        "devices": formatted_devices,
        "devices_empty": len(device_slots) == 0,
        "can_add_device": can_add_device,
        "extra_devices": extra_devices,
        # Слоты устройств (базовые + купленные)
        "device_slots": device_slots,
        "has_device_slots": 1 if device_slots else 0,
        "has_extra_device_purchases": 1 if has_extra_device_purchases else 0,
        "can_add_extra_device": 1 if can_add_extra_device else 0,
        # Данные профиля
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "referral_balance": format_price(int(referral_balance), currency),
        "balance": format_price(int(display_balance), currency),
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        "is_balance_separate": 1 if not is_balance_combined else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные подписки
        "is_trial": 1 if subscription.is_trial else 0,
        "plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
        "device_limit": i18n_format_device_limit(max_count),
        "device_limit_number": format_device_limit_number(plan_device_limit),
        "device_limit_bonus": max(0, max_count - plan_device_limit - extra_devices) if plan_device_limit > 0 else 0,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
    }


@inject
async def add_device_success_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    user_service: FromDishka[UserService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для окна успешного добавления устройств."""
    currency = (await settings_service.get()).default_currency
    # Очищаем кэш и получаем свежие данные пользователя из БД
    await user_service.clear_user_cache(user.telegram_id)
    fresh_user = await user_service.get(user.telegram_id)
    if not fresh_user:
        fresh_user = user
    
    # Получаем данные из dialog_data
    device_count = dialog_manager.dialog_data.get("device_count", 1)
    
    # Получаем реферальный баланс
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=fresh_user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )

    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(fresh_user)

    # Проверяем, включен ли функционал баланса
    is_balance_enabled = await settings_service.is_balance_enabled()
    
    # Проверяем режим баланса (раздельный или объединённый)
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Вычисляем лимиты устройств (получаем обновленные данные)
    subscription = fresh_user.current_subscription
    extra_devices = subscription.extra_devices or 0 if subscription else 0
    device_limit_number = (subscription.plan.device_limit) if subscription else 0
    
    # Определяем склонение слова "устройство"
    device_count_word = "устройство" if device_count % 10 == 1 and device_count != 11 else \
                       "устройства" if device_count % 10 in [2, 3, 4] and device_count not in [12, 13, 14] else \
                       "устройств"
    
    # Вычисляем отображаемый баланс
    display_balance = get_display_balance(
        fresh_user.balance,
        referral_balance,
        is_balance_combined,
    )
    
    return {
        # Данные пользователя
        "user_id": str(fresh_user.telegram_id),
        "user_name": fresh_user.name,
        "referral_code": fresh_user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "balance": format_price(int(display_balance), currency),
        "referral_balance": format_price(int(referral_balance), currency),
        "is_balance_enabled": 1 if is_balance_enabled else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if await settings_service.is_referral_enable() else 0,
        # Данные подписки
        "plan_name": subscription.plan.name if subscription else "",
        "current_plan_name": subscription.plan.name if subscription else "",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit) if subscription else "",
        "device_limit": i18n_format_device_limit(subscription.device_limit) if subscription else "",
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": max(0, subscription.device_limit - device_limit_number - extra_devices) if subscription and device_limit_number > 0 else 0,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited) if subscription else "",
        # Данные покупки
        "device_count": device_count,
        "device_count_word": device_count_word,
    }


@inject
async def extra_devices_list_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    extra_device_service: FromDishka[ExtraDeviceService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    pricing_service: FromDishka[PricingService],
    plan_service: FromDishka[PlanService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для списка купленных дополнительных устройств."""
    
    if not user.current_subscription:
        raise ValueError(f"Current subscription for user '{user.telegram_id}' not found")
    
    subscription = user.current_subscription
    
    # Получаем активные покупки дополнительных устройств
    purchases = await extra_device_service.get_active_by_subscription(subscription.id)
    
    # Получаем курсы валют для конвертации
    settings = await settings_service.get()
    currency = settings.default_currency
    rates = settings.features.currency_rates
    usd_rate = rates.usd_rate
    eur_rate = rates.eur_rate
    stars_rate = rates.stars_rate
    
    # Получаем валюту по умолчанию
    default_currency = await settings_service.get_default_currency()
    
    # Форматируем для отображения
    formatted_purchases = []
    for p in purchases:
        # Конвертируем цену в валюту по умолчанию
        converted_price = int(pricing_service.convert_currency(
            Decimal(p.price),
            default_currency,
            usd_rate,
            eur_rate,
            stars_rate,
        ))
        formatted_purchases.append({
            "id": p.id,
            "device_count": p.device_count,
            "price": format_price(converted_price, default_currency),
            "auto_renew": p.auto_renew,
            "pending_deletion": p.pending_deletion,
            "expires_at": i18n_format_expire_time(p.expires_at),
            "days_remaining": p.days_remaining,
        })
    
    # Сохраняем в dialog_data для использования в обработчиках
    dialog_manager.dialog_data["extra_device_purchases"] = [
        {"id": p.id, "device_count": p.device_count}
        for p in purchases
    ]
    
    # Общая месячная стоимость дополнительных устройств
    # Используем цену из тарифа подписки
    total_extra_devices = await extra_device_service.get_total_active_devices(subscription.id)
    live_plan = await plan_service.get(subscription.plan.id)
    device_price_monthly = live_plan.device_price if live_plan and live_plan.device_price and live_plan.device_price > 0 else await settings_service.get_extra_device_price()
    total_monthly_cost_rub = device_price_monthly * total_extra_devices
    total_monthly_cost = int(pricing_service.convert_currency(
        Decimal(total_monthly_cost_rub),
        default_currency,
        usd_rate,
        eur_rate,
        stars_rate,
    ))  # Конвертируем в валюту по умолчанию
    
    # Данные профиля
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)
    
    # Данные подписки
    extra_devices = subscription.extra_devices or 0
    device_limit_number = subscription.plan.device_limit if subscription.plan else 0
    # device_limit_bonus - устройства добавленные администратором через панель (не extra_devices)
    device_limit_bonus = max(0, subscription.device_limit - device_limit_number - extra_devices) if device_limit_number > 0 else 0
    
    # Режим баланса
    is_balance_combined = await settings_service.is_balance_combined()
    is_balance_separate = not is_balance_combined
    
    # Проверяем, включена ли реферальная система
    is_referral_enable = await settings_service.is_referral_enable()
    
    return {
        # Список покупок
        "purchases": formatted_purchases,
        "purchases_empty": len(formatted_purchases) == 0,
        "total_monthly_cost": format_price(total_monthly_cost, default_currency),
        "total_extra_devices": total_extra_devices,
        # Данные профиля
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "referral_balance": format_price(int(referral_balance), currency),
        "balance": format_price(int(get_display_balance(user.balance, referral_balance, is_balance_combined)), currency),
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        "is_balance_separate": 1 if is_balance_separate else 0,
        "is_referral_enable": 1 if is_referral_enable else 0,
        # Данные подписки
        "is_trial": 1 if subscription.is_trial else 0,
        "plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "current_plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
        "device_limit": i18n_format_device_limit(subscription.device_limit),
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": device_limit_bonus,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
        # Флаги для кнопок
        "can_add_device": subscription.is_active and subscription.has_devices_limit,
    }


@inject
async def extra_device_manage_getter(
    dialog_manager: DialogManager,
    user: UserDto,
    extra_device_service: FromDishka[ExtraDeviceService],
    referral_service: FromDishka[ReferralService],
    settings_service: FromDishka[SettingsService],
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для управления конкретной покупкой дополнительных устройств."""
    currency = (await settings_service.get()).default_currency
    
    purchase_id = dialog_manager.dialog_data.get("selected_purchase_id")
    if not purchase_id:
        raise ValueError("No purchase_id in dialog_data")
    
    purchase = await extra_device_service.get(purchase_id)
    if not purchase:
        raise ValueError(f"Purchase '{purchase_id}' not found")
    
    subscription = user.current_subscription
    if not subscription:
        raise ValueError(f"Current subscription for user '{user.telegram_id}' not found")
    
    # Данные профиля
    referral_balance = await referral_service.get_pending_rewards_amount(
        telegram_id=user.telegram_id,
        reward_type=ReferralRewardType.MONEY,
    )
    
    # Вычисляем данные о скидке пользователя
    discount_info = calculate_user_discount(user)
    
    # Данные подписки
    extra_devices = subscription.extra_devices or 0
    device_limit_number = subscription.plan.device_limit if subscription.plan else 0
    
    # Режим баланса
    is_balance_combined = await settings_service.is_balance_combined()
    
    return {
        # Данные покупки
        "purchase_id": purchase.id,
        "purchase_device_count": purchase.device_count,
        "purchase_price": purchase.price,
        "purchase_auto_renew": 1 if purchase.auto_renew else 0,
        "purchase_expires_at": i18n_format_expire_time(purchase.expires_at),
        "purchase_days_remaining": purchase.days_remaining,
        # Данные профиля
        "user_id": str(user.telegram_id),
        "user_name": user.name,
        "referral_code": user.referral_code,
        "discount_value": discount_info.value,
        "discount_is_temporary": 1 if discount_info.is_temporary else 0,
        "discount_is_permanent": 1 if discount_info.is_permanent else 0,
        "discount_remaining": discount_info.remaining_days,
        "referral_balance": format_price(int(referral_balance), currency),
        "balance": format_price(int(get_display_balance(user.balance, referral_balance, is_balance_combined)), currency),
        "is_balance_enabled": 1 if await settings_service.is_balance_enabled() else 0,
        # Данные подписки
        "is_trial": 1 if subscription.is_trial else 0,
        "plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "current_plan_name": subscription.plan.name if subscription.plan else "Unknown",
        "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
        "device_limit": i18n_format_device_limit(subscription.device_limit),
        "device_limit_number": format_device_limit_number(device_limit_number),
        "device_limit_bonus": max(0, subscription.device_limit - device_limit_number) if device_limit_number > 0 else 0,
        "extra_devices": extra_devices,
        "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
    }


@inject
async def add_device_payment_link_getter(
    dialog_manager: DialogManager,
    **kwargs: Any,
) -> dict[str, Any]:
    """Геттер для экрана ссылки платежа доп. устройств."""
    payment_url = dialog_manager.dialog_data.get("payment_url", "")
    
    return {
        "payment_url": payment_url,
    }
