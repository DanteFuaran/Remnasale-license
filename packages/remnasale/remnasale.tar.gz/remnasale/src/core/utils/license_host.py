"""Утилита для получения актуального хоста лицензионного сервера.

Приоритет: Redis (сохранённый override) → значение из .env (config).
Это позволяет администратору изменить домен в настройках лиц. сервера,
и он автоматически распространится на всех клиентов при следующей проверке.
"""
from typing import Optional

from src.core.config import AppConfig

LICENSE_HOST_REDIS_KEY = "license:host_override"


async def get_license_host(redis_client, config: AppConfig) -> Optional[str]:
    """Возвращает актуальный хост лицензионного сервера.

    Сначала проверяет Redis (override, полученный от сервера),
    затем возвращает значение из конфига (.env).
    """
    if redis_client is not None:
        try:
            override = await redis_client.get(LICENSE_HOST_REDIS_KEY)
            if override:
                return override.decode() if isinstance(override, bytes) else override
        except Exception:
            pass
    return config.build.license_server or None
