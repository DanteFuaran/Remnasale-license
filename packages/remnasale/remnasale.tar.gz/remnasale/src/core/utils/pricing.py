"""Pricing utility functions for subscription calculations."""

import math
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from typing import Optional, Tuple

# Минимальное количество дней для оплаты дополнительных устройств
MIN_EXTRA_DEVICE_DAYS = 10


def calculate_prorated_device_price(
    monthly_price: int,
    subscription_expire_at: datetime,
    min_days: int = MIN_EXTRA_DEVICE_DAYS,
) -> int:
    """
    Вычисляет пропорциональную стоимость дополнительного устройства
    на основе оставшихся дней до окончания подписки.
    
    Args:
        monthly_price: Полная месячная стоимость устройства в рублях
        subscription_expire_at: Дата окончания текущей подписки
        min_days: Минимальное количество дней для оплаты (по умолчанию 10)
    
    Returns:
        Пропорциональная стоимость за оставшиеся дни (минимум за min_days дней)
    
    Formula:
        (monthly_price / 30) * max(remaining_days, min_days)
    """
    now = datetime.now(timezone.utc)
    
    # Если подписка уже истекла, возвращаем полную цену
    if subscription_expire_at <= now:
        return monthly_price
    
    # Вычисляем оставшиеся дни (округляем вверх)
    remaining_delta = subscription_expire_at - now
    remaining_days = remaining_delta.days + (1 if remaining_delta.seconds > 0 else 0)
    
    # Если меньше дня - считаем как 1 день
    if remaining_days < 1:
        remaining_days = 1
    
    # Применяем минимум дней
    billable_days = max(remaining_days, min_days)
    
    # Вычисляем пропорциональную стоимость
    # Используем Decimal для точных вычислений
    daily_price = Decimal(monthly_price) / Decimal(30)
    prorated_price = daily_price * Decimal(billable_days)
    
    # Округляем вверх, чтобы не терять копейки
    return math.ceil(float(prorated_price))


def calculate_device_price_until_subscription_end(
    monthly_price: int,
    subscription_expire_at: datetime,
    min_days: int = MIN_EXTRA_DEVICE_DAYS,
) -> Tuple[int, int]:
    """
    Вычисляет стоимость дополнительного устройства до конца подписки.
    
    Args:
        monthly_price: Полная месячная стоимость устройства в рублях
        subscription_expire_at: Дата окончания текущей подписки
        min_days: Минимальное количество дней для оплаты
    
    Returns:
        Tuple[int, int]: (стоимость, количество дней)
    """
    now = datetime.now(timezone.utc)
    
    # Если подписка уже истекла
    if subscription_expire_at <= now:
        return monthly_price, 30
    
    # Вычисляем оставшиеся дни
    remaining_delta = subscription_expire_at - now
    remaining_days = remaining_delta.days + (1 if remaining_delta.seconds > 0 else 0)
    
    if remaining_days < 1:
        remaining_days = 1
    
    # Применяем минимум дней
    billable_days = max(remaining_days, min_days)
    
    # Вычисляем стоимость
    daily_price = Decimal(monthly_price) / Decimal(30)
    price = daily_price * Decimal(billable_days)
    
    return math.ceil(float(price)), billable_days


def calculate_device_price_until_month_end(
    monthly_price: int,
    subscription_expire_at: datetime,
    subscription_plan_duration: int = 30,
    min_days: int = MIN_EXTRA_DEVICE_DAYS,
    plan_activated_at: Optional[datetime] = None,
) -> Tuple[int, int]:
    """
    Вычисляет стоимость дополнительного устройства до конца текущего месяца подписки.
    
    "Месяц подписки" - это 30-дневный период, отсчитываемый от момента
    покупки/изменения плана.  Момент покупки восстанавливается как
    plan_activated_at (если задан) или expire_at - plan_duration.
    
    Args:
        monthly_price: Полная месячная стоимость устройства в рублях
        subscription_expire_at: Дата окончания текущей подписки
        subscription_plan_duration: Длительность тарифного плана в днях (plan.duration)
        min_days: Минимальное количество дней для оплаты
        plan_activated_at: Дата последней активации плана (CHANGE/RENEW/NEW).
                           Если задана, используется как якорь периода вместо
                           expire_at - plan_duration, что исключает смещение при
                           RENEW с переносом остатка старой подписки.
    
    Returns:
        Tuple[int, int]: (стоимость, количество дней до конца месяца)
    """
    now = datetime.now(timezone.utc)
    
    # Если подписка уже истекла
    if subscription_expire_at <= now:
        return monthly_price, 30
    
    # Для безлимитных планов (duration == -1) — отдаём полный период
    if subscription_plan_duration <= 0:
        return monthly_price, 30
    
    # Определяем якорь периода (начало первого периода)
    if plan_activated_at and plan_activated_at <= now:
        # Используем фактическую дату активации — корректно работает
        # как для CHANGE (now + plan_duration → plan_start = now),
        # так и для RENEW с переносом остатка (plan_start = old_expire).
        period_start = plan_activated_at
    else:
        # Fallback для старых подписок без activated_at:
        # Восстанавливаем момент начала текущей подписки как expire_at - plan_duration
        period_start = subscription_expire_at - timedelta(days=subscription_plan_duration)
    
    # Количество дней, прошедших с начала подписки
    days_elapsed = max(0, (now - period_start).days)
    
    # Позиция в текущем 30-дневном периоде
    days_into_period = days_elapsed % 30
    
    # Дней до конца текущего периода
    days_in_current_month = 30 - days_into_period
    if days_in_current_month == 0:
        days_in_current_month = 30
    
    # Применяем минимум дней
    billable_days = max(days_in_current_month, min_days)
    
    # Вычисляем стоимость
    daily_price = Decimal(monthly_price) / Decimal(30)
    price = daily_price * Decimal(billable_days)
    
    return math.ceil(float(price)), billable_days


def get_remaining_days(expire_at: datetime) -> int:
    """
    Возвращает количество оставшихся дней до истечения срока.
    
    Args:
        expire_at: Дата истечения
    
    Returns:
        Количество дней (минимум 0)
    """
    now = datetime.now(timezone.utc)
    
    if expire_at <= now:
        return 0
    
    remaining_delta = expire_at - now
    remaining_days = remaining_delta.days + (1 if remaining_delta.seconds > 0 else 0)
    
    return max(0, remaining_days)
