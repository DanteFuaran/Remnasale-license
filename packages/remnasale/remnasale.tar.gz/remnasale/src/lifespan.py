import asyncio
import traceback
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, Optional

from aiogram import Bot, Dispatcher
from aiogram.types import WebhookInfo, User as AiogramUser, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.formatting import Text
from dishka import AsyncContainer, Scope
from fastapi import FastAPI
from fluentogram import TranslatorHub
from loguru import logger
from redis.asyncio import Redis, from_url
from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker, create_async_engine

from src.__version__ import __version__
from src.api.endpoints import TelegramWebhookEndpoint
from src.core.config.app import AppConfig
from src.core.enums import SystemNotificationType, UserRole
from src.core.storage.keys import ShutdownMessagesKey, UpdateInProgressKey, UpdateMessageKey
from src.core.utils.message_payload import MessagePayload
from src.infrastructure.database import UnitOfWork
from src.infrastructure.redis.repository import RedisRepository
from src.core.keepalive import keepalive_loop
from src.services.command import CommandService
from src.services.mirror_bot import MirrorBotService
from src.services.mirror_bot_manager import MirrorBotManager
from src.services.notification import NotificationService
from src.services.payment_gateway import PaymentGatewayService
from src.services.remnawave import RemnawaveService
from src.services.settings import SettingsService
from src.services.user import UserService
from src.services.webhook import WebhookService


async def send_shutdown_notifications(container: AsyncContainer) -> None:
    """Send shutdown notifications to all DEV users."""
    logger.info("Shutdown: sending shutdown notifications...")
    
    try:
        async with container(scope=Scope.REQUEST) as shutdown_container:
            notification_service: NotificationService = await shutdown_container.get(NotificationService)
            redis_repository: RedisRepository = await shutdown_container.get(RedisRepository)
            user_service: UserService = await shutdown_container.get(UserService)
            settings_service: SettingsService = await shutdown_container.get(SettingsService)

            # Skip shutdown notification if shutdown is caused by an update
            update_in_progress = await redis_repository.get(UpdateInProgressKey(), str)
            logger.info(f"Shutdown: UpdateInProgressKey = {update_in_progress}")
            if update_in_progress:
                logger.info("Shutdown caused by update — skipping shutdown notification")
                return

            devs = await user_service.get_by_role(role=UserRole.DEV)
            settings = await settings_service.get()
            
            logger.info(f"Shutdown: found {len(devs) if devs else 0} DEV users")

            shutdown_key = ShutdownMessagesKey()

            for dev in devs:
                try:
                    if settings.features.language_enabled:
                        locale = dev.language
                    else:
                        locale = settings.bot_locale

                    logger.info(f"Shutdown: sending notification to DEV user {dev.telegram_id} (locale: {locale})")
                    mirror_sent_out: list[tuple[int, Any]] = []
                    msg = await notification_service._send_message(
                        user=dev,
                        payload=MessagePayload.not_deleted(
                            i18n_key="ntf-event-bot-shutdown",
                            add_close_button=False,
                        ),
                        locale_override=locale,
                        mirror_sent_out=mirror_sent_out,
                    )
                    if msg:
                        # Format: "main:{chat_id}:{msg_id}" for main bot
                        await redis_repository.list_push(shutdown_key, f"main:{dev.telegram_id}:{msg.message_id}")
                        logger.info(f"Shutdown: sent message {msg.message_id} for chat {dev.telegram_id}")
                    else:
                        logger.warning(f"Shutdown: _send_message returned None for {dev.telegram_id}")
                    # Store mirror bot message IDs for cleanup on startup
                    # Format: "{mirror_db_id}:{chat_id}:{msg_id}"
                    for mirror_db_id, mirror_msg in mirror_sent_out:
                        await redis_repository.list_push(
                            shutdown_key,
                            f"{mirror_db_id}:{dev.telegram_id}:{mirror_msg.message_id}",
                        )
                        logger.debug(f"Shutdown: stored mirror[{mirror_db_id}] message {mirror_msg.message_id}")
                except Exception as e:
                    logger.error(f"Shutdown: Failed to send notification to {dev.telegram_id}: {e}", exc_info=True)

            await redis_repository.expire(shutdown_key, 86400)
            logger.info("Shutdown: notifications sent successfully")
    except Exception as e:
        logger.error(f"Shutdown: Failed to send notifications: {e}", exc_info=True)


async def ensure_dev_user_exists(
    config: AppConfig,
    bot: Bot,
    max_retries: int = 5,
    retry_delay: float = 2.0,
) -> bool:
    """
    Create DEV user if not exists using a separate database connection.
    Uses retry logic to handle transient database issues during startup.
    Returns True if user exists or was created, False otherwise.
    """
    dev_telegram_id = config.bot.dev_id
    
    for attempt in range(1, max_retries + 1):
        engine = None
        try:
            # Create a separate lightweight connection for this operation
            engine = create_async_engine(
                url=config.database.dsn,
                pool_size=1,
                max_overflow=0,
                pool_timeout=5,
                pool_pre_ping=True,
                connect_args={
                    "timeout": 10,
                    "command_timeout": 15,
                },
            )
            
            async_session = async_sessionmaker(bind=engine, expire_on_commit=False)
            
            async with async_session() as session:
                uow = UnitOfWork(session)
                # Check if DEV user exists
                existing_user = await uow.repository.users.get(dev_telegram_id)
                
                if existing_user:
                    logger.debug(f"DEV user {dev_telegram_id} already exists")
                    return True
                
                # Get Telegram user info
                try:
                    dev_chat = await bot.get_chat(dev_telegram_id)
                except Exception as e:
                    logger.warning(f"Failed to get Telegram info for DEV user {dev_telegram_id}: {e}")
                    return False
                
                # Create AiogramUser object
                aiogram_user = AiogramUser(
                    id=dev_telegram_id,
                    is_bot=False,
                    first_name=dev_chat.first_name or "DEV",
                    last_name=dev_chat.last_name,
                    username=dev_chat.username,
                    language_code=config.default_locale.value,
                )
                
                # Create user using service logic
                from src.core.utils.generators import generate_referral_code
                from src.infrastructure.database.models.sql import User
                from src.infrastructure.database.models.dto import UserDto
                
                user_dto = UserDto(
                    telegram_id=aiogram_user.id,
                    username=aiogram_user.username,
                    referral_code=generate_referral_code(
                        aiogram_user.id,
                        secret=config.crypt_key.get_secret_value(),
                    ),
                    name=aiogram_user.full_name,
                    role=UserRole.DEV,
                    language=config.default_locale,
                )
                
                db_user = User(**user_dto.model_dump())
                await uow.repository.users.create(db_user)
                await uow.commit()
                
                logger.success(f"DEV user {dev_telegram_id} created automatically on first startup")
                return True
                
        except Exception as e:
            logger.warning(f"Attempt {attempt}/{max_retries} to create DEV user failed: {e}")
            if attempt < max_retries:
                await asyncio.sleep(retry_delay * attempt)  # Exponential backoff
        finally:
            if engine:
                await engine.dispose()
    
    logger.error(f"Failed to create DEV user after {max_retries} attempts")
    return False


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    dispatcher: Dispatcher = app.state.dispatcher
    telegram_webhook_endpoint: TelegramWebhookEndpoint = app.state.telegram_webhook_endpoint
    container: AsyncContainer = app.state.dishka_container

    update_completed = False

    async with container(scope=Scope.REQUEST) as startup_container:
        config: AppConfig = await startup_container.get(AppConfig)
        webhook_service: WebhookService = await startup_container.get(WebhookService)
        command_service: CommandService = await startup_container.get(CommandService)
        settings_service: SettingsService = await startup_container.get(SettingsService)
        gateway_service: PaymentGatewayService = await startup_container.get(PaymentGatewayService)
        remnawave_service: RemnawaveService = await startup_container.get(RemnawaveService)
        notification_service: NotificationService = await startup_container.get(NotificationService)
        redis_repository: RedisRepository = await startup_container.get(RedisRepository)
        user_service: UserService = await startup_container.get(UserService)
        bot: Bot = await startup_container.get(Bot)

        # Ensure web_credentials table exists (auto-create on first run)
        try:
            from sqlalchemy.ext.asyncio import AsyncEngine as _AE
            _engine: _AE = await startup_container.get(_AE)
            from src.infrastructure.database.models.sql.web_credential import WebCredential
            async with _engine.begin() as conn:
                await conn.run_sync(
                    WebCredential.__table__.create,
                    checkfirst=True,
                )
            logger.debug("web_credentials table ensured")
        except Exception as _e:
            logger.debug(f"web_credentials table check: {_e}")

        await gateway_service.create_default()
        settings = await settings_service.get()
        
        # Check if this startup is after an update (UpdateInProgressKey is only set during updates, not restarts)
        try:
            update_in_progress_key = UpdateInProgressKey()
            update_flag = await redis_repository.get(update_in_progress_key, str)
            if update_flag:
                update_completed = True
                await redis_repository.delete(update_in_progress_key)
                logger.info("Detected post-update startup")
        except Exception as e:
            logger.warning(f"Failed to check update flag: {e}")

        # NOTE: Shutdown/update messages are NOT deleted here.
        # They stay visible until the bot is fully started (after yield).
        # Deletion happens in _send_startup_notifications() right before
        # sending the main menu, so the user always sees either
        # "Bot stopped" or "Updating..." until the bot is ready.
        
        # Initialize Redis consumer group for taskiq
        try:
            redis = await from_url(config.redis.dsn)
            await redis.xgroup_create(name="taskiq", groupname="taskiq", id="0", mkstream=True)
            await redis.close()
        except Exception as exc:
            # Consumer group might already exist, which is fine
            if "BUSYGROUP" not in str(exc):
                logger.warning(f"Failed to initialize consumer group: {exc}")

    await startup_container.close()

    allowed_updates = dispatcher.resolve_used_update_types()

    # ── Webhook setup ─────────────────────────────────────────────────
    try:
        webhook_info: WebhookInfo = await webhook_service.setup(allowed_updates)

        if webhook_service.has_error(webhook_info):
            if update_completed:
                # 502 during bot restart/update is expected — Telegram retried while bot was down.
                # Suppress the alert to avoid false alarms, but force-reset the webhook so
                # Telegram clears its error state and reliably delivers new updates.
                logger.warning(
                    f"Webhook had a transient error during update restart "
                    f"(expected): '{webhook_info.last_error_message}'"
                )
                try:
                    await webhook_service._clear(bot_id=bot.id)
                    refreshed_info = await webhook_service.setup(allowed_updates)
                    if not webhook_service.has_error(refreshed_info):
                        logger.info("Webhook re-registered after update restart — error cleared")
                    else:
                        logger.warning(
                            f"Webhook still has error after re-registration: '{refreshed_info.last_error_message}'"
                        )
                except Exception as _re_err:
                    logger.warning(f"Webhook re-registration after update failed: {_re_err}")
            else:
                # 502 Bad Gateway — всегда вызвана перезагрузкой бота (Telegram пытался
                # доставить update, пока бот был недоступен). Перерегистрируем webhook.
                if "502" in str(webhook_info.last_error_message):
                    logger.warning(
                        f"Webhook had a transient 502 error during restart "
                        f"(expected): '{webhook_info.last_error_message}'"
                    )
                    try:
                        await webhook_service._clear(bot_id=bot.id)
                        refreshed_info = await webhook_service.setup(allowed_updates)
                        if not webhook_service.has_error(refreshed_info):
                            logger.info("Webhook re-registered after restart — 502 error cleared")
                        else:
                            logger.warning(
                                f"Webhook still has error after re-registration: '{refreshed_info.last_error_message}'"
                            )
                    except Exception as _re_err:
                        logger.warning(f"Webhook re-registration after 502 failed: {_re_err}")
                else:
                    logger.critical(f"Webhook has a last error message: '{webhook_info.last_error_message}'")
                    await notification_service.system_notify(
                        ntf_type=SystemNotificationType.BOT_LIFETIME,
                        payload=MessagePayload.not_deleted(
                            i18n_key="ntf-event-error-webhook",
                            i18n_kwargs={"error": webhook_info.last_error_message},
                        ),
                    )
    except Exception as e:
        logger.critical(f"Webhook setup failed: {e}")

    await command_service.setup()
    await telegram_webhook_endpoint.startup()

    # ── Start mirror (additional) bots ──────────────────────────────────
    mirror_bot_manager: MirrorBotManager = app.state.mirror_bot_manager
    try:
        async with container(scope=Scope.REQUEST) as mirror_container:
            mirror_service: MirrorBotService = await mirror_container.get(MirrorBotService)
            active_mirrors = await mirror_service.get_active()

        if active_mirrors:
            logger.info(f"Starting {len(active_mirrors)} mirror bot(s)...")
            for mirror in active_mirrors:
                started = await mirror_bot_manager.start_mirror_bot(mirror, allowed_updates)
                if not started:
                    logger.warning(f"Failed to start mirror bot @{mirror.username} (id={mirror.id})")
            logger.info(f"Mirror bots running: {len(mirror_bot_manager.active_bots)}")

            # Set up bot commands for each mirror bot (same as main bot)
            for mirror_db_id, mirror_bot in mirror_bot_manager.active_bots.items():
                try:
                    await command_service.setup_for_bot(mirror_bot)
                except Exception as e:
                    logger.warning(f"Failed to set commands for mirror bot {mirror_db_id}: {e}")
        else:
            logger.debug("No active mirror bots to start")
    except Exception as e:
        logger.debug(f"Mirror bots not started: {e}")

    # Register mirror bot manager in NotificationService so all notifications
    # are automatically forwarded to mirror bots as well.
    from src.services.notification import NotificationService as _NtfSvc
    _NtfSvc.set_mirror_bot_manager(mirror_bot_manager)

    bot: Bot = await container.get(Bot)
    bot_info = await bot.get_me()

    # Отправляем report на лицензионный сервер (версия, бот, dev_ids)
    try:
        _report_config: AppConfig = await container.get(AppConfig)
        from src.infrastructure.redis.repository import RedisRepository as _RedisRepo
        from src.core.utils.license_host import get_license_host as _get_license_host
        _redis_repo: _RedisRepo = await container.get(_RedisRepo)
        _license_server = await _get_license_host(_redis_repo.client, _report_config)
        _license_key = _report_config.build.license_key.get_secret_value()
        if _license_server and _license_key:
            async with container(scope=Scope.REQUEST) as _report_container:
                _report_user_svc: UserService = await _report_container.get(UserService)
                _devs = await _report_user_svc.get_by_role(role=UserRole.DEV)
            _dev_ids = ",".join(str(d.telegram_id) for d in _devs)
            import aiohttp
            async with aiohttp.ClientSession() as _sess:
                await _sess.post(
                    f"{_license_server.rstrip('/')}/api/v1/license/report",
                    json={
                        "license_key": _license_key,
                        "bot_token": _report_config.bot.token.get_secret_value(),
                        "bot_username": bot_info.username or "",
                        "dev_ids": _dev_ids,
                        "remnasale_version": __version__,
                        "owner_telegram_id": str(_report_config.bot.dev_id),
                    },
                    timeout=aiohttp.ClientTimeout(total=10),
                )
            logger.info(f"[license] Report sent: version={__version__}, bot=@{bot_info.username}")
    except Exception as _report_err:
        logger.debug(f"[license] Report failed: {_report_err}")

    # Верифицируем лицензию при старте и сохраняем настройки (check_interval, grace_days)
    # Результат сохраняется в _startup_license_notification и используется в
    # _send_startup_notifications() сразу после уведомления с реквизитами.
    _startup_license_notification: dict | None = None
    _verify_config = None
    _verify_redis = None
    _verify_server = None
    try:
        _verify_config: AppConfig = await container.get(AppConfig)
        from src.infrastructure.redis.repository import RedisRepository as _VerifyRedisRepo
        from src.core.utils.license_host import get_license_host as _verify_get_host
        _verify_redis: _VerifyRedisRepo = await container.get(_VerifyRedisRepo)
        _verify_server = await _verify_get_host(_verify_redis.client, _verify_config)
    except Exception as _ve:
        logger.debug(f"[license] Startup verify init failed: {_ve}")

    if _verify_server and _verify_config and _verify_redis:
        _verify_key = _verify_config.build.license_key.get_secret_value()
        if _verify_key:
            try:
                import aiohttp as _verify_aiohttp
                async with _verify_aiohttp.ClientSession() as _vs:
                    async with _vs.post(
                        f"{_verify_server.rstrip('/')}/api/v1/license/verify",
                        json={"license_key": _verify_key, "server_domain": _verify_config.domain.get_secret_value()},
                        timeout=_verify_aiohttp.ClientTimeout(total=15),
                    ) as _vr:
                        _vdata = await _vr.json()
                        from src.infrastructure.taskiq.tasks.license_check import (
                            _save_settings, _mark_ok, _cache_license_banner,
                            _DEFAULT_CHECK_INTERVAL_MIN, _DEFAULT_GRACE_DAYS,
                            _REDIS_NOTIFIED, _REDIS_NOTIFIED_AT,                            _REDIS_RESTRICTED_MODE,                            _make_startup_invalid_text,
                        )
                        _ci = _vdata.get("check_interval", _DEFAULT_CHECK_INTERVAL_MIN)
                        _gd = _vdata.get("offline_grace_days", _DEFAULT_GRACE_DAYS)
                        await _save_settings(_verify_redis.client, int(_ci), int(_gd))

                        # Кешируем support_url
                        from src.infrastructure.taskiq.tasks.license_check import _REDIS_SUPPORT_URL
                        _sup = _vdata.get("support_url", "")
                        if _sup:
                            await _verify_redis.client.set(_REDIS_SUPPORT_URL, _sup)

                        # Кешируем настройки донатов
                        import json as _json_mod
                        _donate_data = _vdata.get("donate")
                        if _donate_data is not None:
                            await _verify_redis.client.set("license:donate", _json_mod.dumps(_donate_data))

                        if _vdata.get("valid"):
                            await _mark_ok(_verify_redis.client)
                            await _cache_license_banner(_verify_server, _verify_config.banners_dir)
                            logger.info(f"[license] Startup verify OK (interval={_ci}m, grace={_gd}d)")
                        else:
                            # Лицензия невалидна — подготовить уведомление для _send_startup_notifications
                            _reason = _vdata.get("reason", "unknown")
                            if _reason == "suspended":
                                _notify_type = "suspended"
                            elif _reason == "blacklisted":
                                _notify_type = "blacklisted"
                            else:
                                _notify_type = "invalid"
                            _notified_at_raw = await _verify_redis.client.get(_REDIS_NOTIFIED_AT)
                            if isinstance(_notified_at_raw, bytes):
                                _notified_at_raw = _notified_at_raw.decode()
                            _notified_at = int(_notified_at_raw) if _notified_at_raw else None
                            _startup_license_notification = {
                                "type": _notify_type,
                                "text": _make_startup_invalid_text(_notify_type, _notified_at),
                            }
                            # Устанавливаем флаг notified если ещё не стоит
                            if not await _verify_redis.client.get(_REDIS_NOTIFIED):
                                await _verify_redis.client.set(_REDIS_NOTIFIED, _notify_type)
                            if not await _verify_redis.client.get(_REDIS_NOTIFIED_AT):
                                import time as _time_mod
                                await _verify_redis.client.set(_REDIS_NOTIFIED_AT, str(int(_time_mod.time())))
                            # Активируем ограниченный режим
                            await _verify_redis.client.set(_REDIS_RESTRICTED_MODE, "1")
                            logger.warning(f"[license] Startup verify: license INVALID ({_reason}). Restricted mode activated.")
            except Exception as _ve:
                logger.debug(f"[license] Startup verify failed: {_ve}")
                # Сервер лицензий недоступен при старте — подготовить уведомление
                try:
                    from src.infrastructure.taskiq.tasks.license_check import (
                        _get_grace_days, _get_elapsed_sec, _make_offline_text,
                        _REDIS_LAST_OK, _REDIS_NOTIFIED, _REDIS_NOTIFIED_AT,
                    )
                    import time as _time_mod
                    if not await _verify_redis.client.get(_REDIS_LAST_OK):
                        await _verify_redis.client.set(_REDIS_LAST_OK, str(int(_time_mod.time())))
                    _startup_grace = await _get_grace_days(_verify_redis.client)
                    _startup_elapsed = await _get_elapsed_sec(_verify_redis.client)
                    _startup_remaining = max(0, _startup_grace * 86400 - _startup_elapsed) / 86400
                    # Отправляем только если ещё не уведомляли (предотвращает дубль при рестарте)
                    if not await _verify_redis.client.get(_REDIS_NOTIFIED):
                        _startup_license_notification = {
                            "type": "offline",
                            "text": _make_offline_text(_startup_remaining),
                        }
                        await _verify_redis.client.set(_REDIS_NOTIFIED, "offline")
                        if not await _verify_redis.client.get(_REDIS_NOTIFIED_AT):
                            await _verify_redis.client.set(_REDIS_NOTIFIED_AT, str(int(_time_mod.time())))
                        logger.warning("[license] Startup: server unreachable, will notify users")
                    else:
                        logger.debug("[license] Startup: server unreachable but users already notified, skip")
                except Exception as _se:
                    logger.debug(f"[license] Startup notification prepare failed: {_se}")

    # Кэшируем username один раз, чтобы ReferralService не вызывал get_me() на каждый рендер
    from src.services.referral import ReferralService as _RefSvc
    _RefSvc._bot_username = bot_info.username
    states: dict[Optional[bool], str] = {True: "Enabled", False: "Disabled", None: "Unknown"}
    mirror_count = len(mirror_bot_manager.active_bots)
    mirror_status = f"Enabled ({mirror_count})" if mirror_count else "Disabled"

    logger.opt(colors=True).info(
        rf"""
        
    <cyan>██████╗   ███████╗  ██████╗</>
    <cyan>██╔══██╗  ██╔════╝ ██╔════╝</>
    <cyan>██║  ██║  █████╗   ██║     </>
    <cyan>██║  ██║  ██╔══╝   ██║     </>
    <cyan>██████╔╝  ██║      ╚██████╗</>
    <cyan>╚═════╝   ╚═╝       ╚═════╝</>
    <cyan> Digital  Freedom   Core</>

        <green>Version: {__version__}</>
        <cyan>------------------------</>
        Groups Mode  - {states[bot_info.can_join_groups]}
        Inline Mode  - {states[bot_info.supports_inline_queries]}
        Privacy Mode - {states[not bot_info.can_read_all_group_messages]}
        Mirror bots  - {mirror_status}
        <cyan>------------------------</>
        <yellow>Bot in access mode: '{settings.access_mode}'</>
        <yellow>Purchases allowed: '{settings.purchases_allowed}'</>
        <yellow>Registration allowed: '{settings.registration_allowed}'</>
        """  # noqa: W605
    )
    await asyncio.sleep(2)

    # ── Prepare data for startup notifications ──────────────────────────
    # Do all DB/cache work BEFORE sending any messages to avoid timing issues
    startup_devs = None
    startup_settings_ok = False
    startup_i18n_data = {}
    try:
        from src.core.i18n.translator import get_translated_kwargs
        from src.core.utils.formatters import i18n_postprocess_text
        from fluentogram import TranslatorHub
        from src.bot.states import Notification

        translator_hub: TranslatorHub = await container.get(TranslatorHub)

        # Ensure DEV user exists (creates if not)
        dev_user_created = await ensure_dev_user_exists(config, bot)

        # Clear user cache if we just created DEV user
        if dev_user_created:
            try:
                await redis_repository.delete_pattern("cache:get_by_role:*")
                await redis_repository.delete_pattern("cache:get_user:*")
            except Exception as e:
                logger.debug(f"Failed to clear cache after DEV user creation: {e}")

        # DB-запросы через отдельный scope, т.к. startup_container уже закрыт
        # и его UoW.session = None (commit будет no-op)
        async with container(scope=Scope.REQUEST) as prep_container:
            prep_user_svc: UserService = await prep_container.get(UserService)
            prep_settings_svc: SettingsService = await prep_container.get(SettingsService)
            startup_devs = await prep_user_svc.get_by_role(role=UserRole.DEV)
            startup_settings_ok = await prep_settings_svc.is_notification_enabled(SystemNotificationType.BOT_LIFETIME)

        if not startup_devs:
            logger.warning(f"DEV user creation failed. Please send /start to the bot from Telegram ID: {config.bot.dev_id}")

        # Pre-render i18n texts per user
        if startup_devs and startup_settings_ok:
            for dev in startup_devs:
                try:
                    locale = dev.language if settings.features.language_enabled else settings.bot_locale
                    i18n = translator_hub.get_translator_by_locale(locale=locale)
                    kwargs = get_translated_kwargs(i18n, {
                        "mode": settings.access_mode,
                        "purchases_allowed": settings.purchases_allowed,
                        "registration_allowed": settings.registration_allowed,
                    })
                    text = i18n_postprocess_text(i18n.get("ntf-event-bot-startup", **kwargs))
                    close_btn_text = i18n.get("btn-notification-close-success")
                    startup_i18n_data[dev.telegram_id] = (text, close_btn_text)
                except Exception as e:
                    logger.warning(f"Failed to prepare startup text for {dev.telegram_id}: {e}")
    except Exception as e:
        logger.warning(f"Failed to prepare startup notification data: {e}")

    # ── 0. Remnawave connection & DEV user subscription sync ───────────
    # Выполняем ДО показа главного меню, чтобы DEV-пользователь видел подписку.
    # ВАЖНО: используем отдельный DI-scope с ЖИВЫМ UoW/сессией.
    # startup_container уже закрыт → его UoW.session = None → commit() = no-op
    # → INSERT/UPDATE отправляются через flush(), но НИКОГДА не коммитятся
    # → при завершении сессии транзакция откатывается → данные теряются.
    try:
        async with container(scope=Scope.REQUEST) as sync_container:
            sync_remnawave: RemnawaveService = await sync_container.get(RemnawaveService)
            sync_user_svc: UserService = await sync_container.get(UserService)
            sync_redis: RedisRepository = await sync_container.get(RedisRepository)

            await sync_remnawave.try_connection()

            # Синхронизация DEV-пользователя: он создаётся в ensure_dev_user_exists
            # напрямую в БД без проверки Remnawave, поэтому при первом запуске
            # у него может не быть подписки. Проверяем и синхронизируем.
            try:
                dev_user = await sync_user_svc.get_without_cache(telegram_id=config.bot.dev_id)
                if dev_user and not dev_user.current_subscription:
                    existing_remna_users = await sync_remnawave.remnawave.users.get_users_by_telegram_id(
                        telegram_id=str(config.bot.dev_id)
                    )
                    if existing_remna_users:
                        await sync_remnawave.sync_user(existing_remna_users[0], creating=False)
                        # Очищаем ВСЕ кеши чтобы главное меню увидело подписку
                        await sync_user_svc.clear_user_cache(config.bot.dev_id)
                        await sync_redis.delete_pattern("cache:get_user:*")
                        await sync_redis.delete_pattern("cache:get_by_role:*")
                        await sync_redis.delete_pattern("cache:get_subscription:*")
                        await sync_redis.delete_pattern("cache:get_current_subscription:*")
                        logger.info(f"Synced DEV user {config.bot.dev_id} subscription from Remnawave")
                    else:
                        logger.debug(f"DEV user {config.bot.dev_id} not found in Remnawave, skipping sync")
            except Exception as e:
                logger.warning(f"Failed to sync DEV user subscription from Remnawave: {e}")

        # Remnawave is reachable at startup
        from src.core.utils.remnawave_status import set_remnawave_status
        await set_remnawave_status(redis_repository.client, True)

    except Exception as exception:
        logger.exception(f"Remnawave connection failed: {exception}")

        # Mark remnawave as unavailable at startup
        from src.core.utils.remnawave_status import set_remnawave_status
        try:
            await set_remnawave_status(redis_repository.client, False)
        except Exception:
            pass

        error_type_name = type(exception).__name__
        error_message = Text(str(exception)[:512])

        try:
            await notification_service.error_notify(
                traceback_str=traceback.format_exc(),
                payload=MessagePayload.not_deleted(
                    i18n_key="ntf-event-error-remnawave",
                    i18n_kwargs={
                        "error": f"{error_type_name}: {error_message.as_html()}",
                    },
                ),
            )
        except Exception:
            logger.warning("Failed to send Remnawave error notification")

    # ── Startup notifications (deferred until after server is ready) ──
    # All notifications are sent AFTER yield (Application startup complete)
    # so that the user can interact with menus immediately.
    async def _send_startup_notifications() -> None:
        """Send all startup notifications after the server starts accepting webhooks."""

        async def _send_all(chat_id: int, **kwargs) -> None:
            """Send a message via main bot and all active mirror bots."""
            for _b in [bot] + list(mirror_bot_manager.active_bots.values()):
                try:
                    await _b.send_message(chat_id=chat_id, **kwargs)
                except Exception as _e:
                    logger.debug(f"Bot {_b.id} failed to send startup message to {chat_id}: {_e}")

        await asyncio.sleep(2)  # Wait for uvicorn to fully start accepting requests
        logger.debug("Sending deferred startup notifications...")

        # ── 0. Delete previous shutdown/update messages ─────────────────
        # These messages stayed visible until now to indicate the bot is not ready.
        # Now that the server is accepting webhooks, we can safely remove them.
        try:
            async with container(scope=Scope.REQUEST) as cleanup_container:
                cleanup_redis: RedisRepository = await cleanup_container.get(RedisRepository)

                # Delete shutdown messages ("Bot stopped" notifications)
                try:
                    shutdown_key = ShutdownMessagesKey()
                    shutdown_messages = await cleanup_redis.list_range(shutdown_key, 0, -1)
                    for msg_data in shutdown_messages:
                        try:
                            parts = msg_data.split(":")
                            if len(parts) == 3:
                                bot_key, chat_id_str, msg_id_str = parts
                                chat_id = int(chat_id_str)
                                message_id = int(msg_id_str)
                                if bot_key == "main":
                                    delete_bot = bot
                                else:
                                    # Look up mirror bot by DB id
                                    db_id = int(bot_key)
                                    delete_bot = mirror_bot_manager.active_bots.get(db_id)
                                    if not delete_bot:
                                        logger.debug(f"Mirror bot {db_id} not active, skipping deletion of msg {message_id}")
                                        continue
                            elif len(parts) == 2:
                                # Legacy format: "{chat_id}:{msg_id}" — use main bot
                                chat_id = int(parts[0])
                                message_id = int(parts[1])
                                delete_bot = bot
                            else:
                                logger.warning(f"Unknown shutdown message format: {msg_data}")
                                continue
                            await delete_bot.delete_message(chat_id=chat_id, message_id=message_id)
                            logger.debug(f"Deleted shutdown message {message_id} in chat {chat_id}")
                        except Exception as e:
                            logger.warning(f"Failed to delete shutdown message '{msg_data}': {e}")
                    await cleanup_redis.delete(shutdown_key)
                except Exception as e:
                    logger.warning(f"Failed to cleanup shutdown messages: {e}")

                # Delete update message ("Updating..." / "Restarting..." notification)
                try:
                    update_msg_key = UpdateMessageKey()
                    update_msg_data = await cleanup_redis.get(update_msg_key, str)
                    if update_msg_data:
                        parts = update_msg_data.split(":")
                        if len(parts) == 3:
                            # New format: "{telegram_bot_id}:{chat_id}:{message_id}"
                            upd_bot_id, upd_chat_id, upd_msg_id = int(parts[0]), int(parts[1]), int(parts[2])
                            # Find the right bot instance (active_bots is keyed by DB id,
                            # so we must search by Telegram bot id via .id attribute)
                            if upd_bot_id == bot.id:
                                delete_upd_bot = bot
                            else:
                                delete_upd_bot = next(
                                    (b for b in mirror_bot_manager.active_bots.values() if b.id == upd_bot_id),
                                    None,
                                )
                            if delete_upd_bot:
                                try:
                                    await delete_upd_bot.delete_message(chat_id=upd_chat_id, message_id=upd_msg_id)
                                    logger.debug(f"Deleted update message {upd_msg_id} in chat {upd_chat_id}")
                                except Exception as e:
                                    logger.warning(f"Failed to delete update message: {e}")
                            else:
                                logger.debug(f"Bot {upd_bot_id} not active, skipping update message deletion")
                        elif len(parts) == 2:
                            # Legacy format: "{chat_id}:{message_id}" — use main bot
                            try:
                                await bot.delete_message(chat_id=int(parts[0]), message_id=int(parts[1]))
                                logger.debug(f"Deleted update message {parts[1]} in chat {parts[0]}")
                            except Exception as e:
                                logger.warning(f"Failed to delete update message: {e}")
                        await cleanup_redis.delete(update_msg_key)
                except Exception as e:
                    logger.warning(f"Failed to cleanup update message: {e}")
        except Exception as e:
            logger.warning(f"Failed to cleanup startup messages: {e}")

        # ── 1. Main menu (FIRST — will appear at the TOP) ──────────────
        _bot_id_token = None
        try:
            from aiogram_dialog import BgManagerFactory, StartMode, ShowMode
            from src.bot.states import MainMenu
            from src.bot.storage import current_bot_id_var

            _bot_id_token = current_bot_id_var.set(bot.id)

            bg_manager_factory: BgManagerFactory = await container.get(BgManagerFactory)
            menu_targets = startup_devs or []
            if not menu_targets:
                # Fallback to super dev only
                from src.core.dto.user import UserDto
                menu_targets = [UserDto(telegram_id=config.bot.dev_id)]  # type: ignore[call-arg]
            for _dev in menu_targets:
                try:
                    bg_manager = bg_manager_factory.bg(
                        bot=bot,
                        user_id=_dev.telegram_id,
                        chat_id=_dev.telegram_id,
                    )
                    await bg_manager.start(
                        state=MainMenu.MAIN,
                        mode=StartMode.RESET_STACK,
                        show_mode=ShowMode.DELETE_AND_SEND,
                    )
                    logger.debug(f"Redirected DEV user {_dev.telegram_id} to main menu on startup")
                except Exception as e:
                    logger.warning(f"Failed to redirect DEV user {_dev.telegram_id} to main menu: {e}")
            await asyncio.sleep(3)  # Wait for aiogram-dialog to fully render
            logger.info(f"Redirected {len(menu_targets)} DEV user(s) to main menu on startup")
        except Exception as e:
            logger.warning(f"Failed to redirect DEV users to main menu: {e}")
        finally:
            if _bot_id_token is not None:
                current_bot_id_var.reset(_bot_id_token)

        # ── 2. Donation notification (SECOND — middle) ─────────────────
        try:
            devs_for_donate = startup_devs
            if devs_for_donate:
                # Читаем настройки донатов из Redis (кешировано при startup verify)
                import json as _json_donate
                _donate_raw = await _verify_redis.client.get("license:donate") if _verify_redis else None
                _donate_cfg = None
                if _donate_raw:
                    try:
                        _dr = _donate_raw.decode() if isinstance(_donate_raw, bytes) else _donate_raw
                        _donate_cfg = _json_donate.loads(_dr)
                    except Exception:
                        pass

                # Если донаты выключены на лиц-сервере — не отправлять
                _donate_enabled = _donate_cfg.get("enabled", True) if _donate_cfg else True

                if _donate_enabled:
                    # Текст сообщения: из настроек лиц-сервера или дефолт
                    _custom_msg = (_donate_cfg or {}).get("message", "")
                    if _custom_msg:
                        donate_text = _custom_msg
                    else:
                        donate_text = (
                            "💝 <b>Поддержать проект</b>\n\n"
                            "Вы можете поддержать разработку проекта финансово.\n"
                            "Это помогает выпускать обновления чаще и добавлять новые возможности.\n\n"
                            "🔹 <b>ЮMoney:</b>\n<code>4100118836481809</code>\n\n"
                            "🔹 <b>USDT (TRC-20):</b>\n<code>THqJQsgbWY7Tw1BxdLA6SQAkBGVmMhzeLZ</code>\n\n"
                            "🔹 <b>BTC (BEP-20):</b>\n<code>0x657685922d7a9c50e3e90cae3ba9905985349fbb</code>\n\n"
                            "<i>Благодарю за доверие и участие! 💪</i>"
                        )

                    # Кнопки: из настроек или дефолт
                    _custom_btns = (_donate_cfg or {}).get("buttons")
                    if _custom_btns:
                        _btn_row = [
                            InlineKeyboardButton(text=b["label"], url=b["url"], style="primary")
                            for b in _custom_btns
                        ]
                        donate_keyboard = InlineKeyboardMarkup(inline_keyboard=[
                            _btn_row,
                            [InlineKeyboardButton(text="✅ Закрыть", callback_data="donate_close", style="success")]
                        ])
                    else:
                        donate_keyboard = InlineKeyboardMarkup(inline_keyboard=[
                            [
                                InlineKeyboardButton(text="⭐ GitHub", url="https://github.com/DanteFuaran", style="primary"),
                                InlineKeyboardButton(text="💬 Telegram", url="https://t.me/dfc_soft", style="primary")
                            ],
                            [InlineKeyboardButton(text="✅ Закрыть", callback_data="donate_close", style="success")]
                        ])

                    for dev in devs_for_donate:
                        try:
                            await _send_all(
                                dev.telegram_id,
                                text=donate_text,
                                reply_markup=donate_keyboard,
                                disable_web_page_preview=True,
                            )
                        except Exception as e:
                            logger.warning(f"Failed to send donation notification to {dev.telegram_id}: {e}")
        except Exception as e:
            logger.warning(f"Failed to send donation notification: {e}")

        await asyncio.sleep(0.3)  # Ensure ordering

        # ── 2.5. License notification (after donation, if license has issues) ──
        if _startup_license_notification and startup_devs:
            try:
                from src.infrastructure.taskiq.tasks.license_check import (
                    _send_notification, _get_support_url, _REDIS_SUPPORT_URL,
                )
                async with container(scope=Scope.REQUEST) as _lic_ntf_scope:
                    _lic_ntf_svc: _NtfSvc = await _lic_ntf_scope.get(_NtfSvc)
                    _startup_sup_url = await _get_support_url(_verify_redis.client)
                    await _send_notification(
                        bot, _verify_config, _lic_ntf_svc,
                        _startup_license_notification["text"],
                        _startup_sup_url,
                    )
                logger.warning(
                    f"[license] Startup license alert sent: {_startup_license_notification['type']}"
                )
            except Exception as _lic_e:
                logger.warning(f"[license] Failed to send startup license notification: {_lic_e}")

        await asyncio.sleep(0.3)  # Ensure ordering

        # ── 3. Startup status notification (THIRD — bottom) ────────────
        try:
            from src.bot.states import Notification

            if startup_devs and startup_settings_ok:
                for dev in startup_devs:
                    try:
                        data = startup_i18n_data.get(dev.telegram_id)
                        if not data:
                            continue
                        text, close_btn_text = data
                        keyboard = InlineKeyboardMarkup(inline_keyboard=[
                            [InlineKeyboardButton(text=close_btn_text, callback_data=Notification.CLOSE.state, style="success")]
                        ])
                        await _send_all(
                            dev.telegram_id,
                            text=text,
                            reply_markup=keyboard,
                        )
                        logger.debug(f"Sent startup notification to {dev.telegram_id}")
                    except Exception as e:
                        logger.warning(f"Failed to send startup notification to {dev.telegram_id}: {e}")
        except Exception as e:
            logger.warning(f"Failed to send startup notification: {e}")

        # Check for updates on startup
        try:
            from src.services.update_checker import UpdateCheckerService
            async with container(scope=Scope.REQUEST) as update_container:
                update_checker: UpdateCheckerService = await update_container.get(UpdateCheckerService)
                await update_checker.check_for_updates()
        except Exception as e:
            logger.warning(f"Failed to check for updates on startup: {e}")

        # Post-update: show success notification (LAST, after all other notifications)
        if update_completed:
            notify_targets = startup_devs or []
            if not notify_targets:
                from src.core.dto.user import UserDto
                notify_targets = [UserDto(telegram_id=config.bot.dev_id)]  # type: ignore[call-arg]
            all_bots = [bot] + list(mirror_bot_manager.active_bots.values())
            for _dev in notify_targets:
                try:
                    sent_messages = []
                    for _b in all_bots:
                        try:
                            msg = await _b.send_message(
                                chat_id=_dev.telegram_id,
                                text="✅ <b>Бот успешно обновлен!</b>",
                                parse_mode="HTML",
                            )
                            sent_messages.append((_b, msg))
                        except Exception:
                            pass

                    async def _auto_delete_success(messages: list) -> None:
                        await asyncio.sleep(5)
                        for _b, _msg in messages:
                            try:
                                await _b.delete_message(
                                    chat_id=_msg.chat.id,
                                    message_id=_msg.message_id,
                                )
                            except Exception:
                                pass

                    asyncio.create_task(_auto_delete_success(sent_messages))
                except Exception as e:
                    logger.warning(f"Failed to send post-update success notification to {_dev.telegram_id}: {e}")

    # Schedule notifications to be sent after server starts
    asyncio.create_task(_send_startup_notifications())

    # ── Start connection keepalive task ─────────────────────────────────
    # Keeps DB pool, Redis connections, and Telegram API aiohttp sessions warm.
    # Without this, the first request after idle suffers reconnection delays.
    try:
        _engine: AsyncEngine = await container.get(AsyncEngine)
        _redis: Redis = await container.get(Redis)
        _all_bots = [bot] + list(mirror_bot_manager.active_bots.values())
        _keepalive_task = asyncio.create_task(
            keepalive_loop(engine=_engine, redis_client=_redis, bots=_all_bots)
        )
        app.state.keepalive_task = _keepalive_task
        logger.info(f"Connection keepalive started ({len(_all_bots)} bot(s))")
    except Exception as e:
        logger.warning(f"Failed to start keepalive task: {e}")

    # ── Remnawave health monitor ────────────────────────────────────────
    # Periodically checks remnawave panel availability and stores status
    # in Redis so subscription operations know if panel is reachable.
    # Also logs webhook errors for diagnostics (without switching to polling).

    async def _check_remnawave_reachable() -> bool:
        """Quick lightweight check if remnawave panel is reachable."""
        import httpx as _httpx
        try:
            _host = config.remnawave.host.get_secret_value()
            _metrics_port = 3001
            _url = f"http://{_host}:{_metrics_port}/health"
            async with _httpx.AsyncClient(timeout=_httpx.Timeout(5.0), verify=False) as _client:
                _resp = await _client.get(_url)
                return _resp.is_success
        except Exception:
            return False

    async def _health_monitor() -> None:
        """Background task: monitors remnawave reachability and webhook status."""
        check_interval = 60  # seconds between health checks
        startup_grace = 120  # extra wait on first check to let server fully stabilize

        await asyncio.sleep(startup_grace)

        while True:
            await asyncio.sleep(check_interval)
            try:
                # Check remnawave panel availability and store in Redis
                remnawave_ok = await _check_remnawave_reachable()
                from src.core.utils.remnawave_status import set_remnawave_status
                await set_remnawave_status(_redis, remnawave_ok)

                # Log webhook errors for diagnostics only
                try:
                    wh_info = await bot.get_webhook_info()
                    if wh_info.last_error_message and webhook_service.has_error(wh_info):
                        logger.warning(f"Webhook error detected: {wh_info.last_error_message}")
                except Exception:
                    pass
            except asyncio.CancelledError:
                raise
            except Exception as monitor_err:
                logger.debug(f"Health monitor check failed: {monitor_err}")

    _health_monitor_task = asyncio.create_task(_health_monitor())
    app.state.webhook_monitor_task = _health_monitor_task
    logger.info("Webhook health monitor started")

    # ── Fast HWID check loop (every 10 seconds) ────────────────────────
    # Remnawave не эмитирует user_hwid_devices.added для безлимитных планов,
    # поэтому опрашиваем API каждые 10 секунд для мгновенного обнаружения.

    async def _hwid_check_loop() -> None:
        from src.infrastructure.taskiq.tasks.hwid_checker import run_hwid_check

        await asyncio.sleep(30)  # grace period: дождаться полного запуска

        while True:
            try:
                async with container(scope=Scope.REQUEST) as _hwid_scope:
                    _hwid_user_svc = await _hwid_scope.get(UserService)
                    _hwid_remna_svc = await _hwid_scope.get(RemnawaveService)
                    _hwid_ntf_svc = await _hwid_scope.get(NotificationService)
                    _hwid_redis = await _hwid_scope.get(Redis)
                    await run_hwid_check(
                        _hwid_user_svc, _hwid_remna_svc, _hwid_ntf_svc, _hwid_redis,
                    )
            except asyncio.CancelledError:
                raise
            except Exception as _hwid_err:
                logger.debug(f"HWID check loop error: {_hwid_err}")
            await asyncio.sleep(5)

    _hwid_check_task = asyncio.create_task(_hwid_check_loop())
    app.state.hwid_check_task = _hwid_check_task
    logger.info("HWID check loop started (interval=5s)")

    yield

    # ── Cancel HWID check loop ────────────────────────────────────────
    _hwid_task = getattr(app.state, "hwid_check_task", None)
    if _hwid_task and not _hwid_task.done():
        _hwid_task.cancel()
        try:
            await _hwid_task
        except asyncio.CancelledError:
            pass

    # ── Cancel webhook monitor task ─────────────────────────────────────
    _wh_monitor = getattr(app.state, "webhook_monitor_task", None)
    if _wh_monitor and not _wh_monitor.done():
        _wh_monitor.cancel()
        try:
            await _wh_monitor
        except asyncio.CancelledError:
            pass

    # ── Cancel keepalive task ───────────────────────────────────────────
    keepalive_task = getattr(app.state, "keepalive_task", None)
    if keepalive_task and not keepalive_task.done():
        keepalive_task.cancel()
        try:
            await keepalive_task
        except asyncio.CancelledError:
            pass

    # Send shutdown notifications
    logger.info("Lifespan shutdown: starting shutdown notifications")
    await send_shutdown_notifications(container)

    # Stop mirror bots
    try:
        mirror_bot_manager: MirrorBotManager = app.state.mirror_bot_manager
        await mirror_bot_manager.stop_all()
        logger.info("All mirror bots stopped")
    except Exception as e:
        logger.warning(f"Failed to stop mirror bots: {e}")

    await telegram_webhook_endpoint.shutdown()
    await command_service.delete()
    await webhook_service.delete()

    await container.close()
