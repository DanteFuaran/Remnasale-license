import uvicorn
from functools import partial

from dishka.integrations.aiogram import ContainerMiddleware, inject_router
from dishka.integrations.fastapi import setup_dishka as setup_fastapi_dishka
from fastapi import FastAPI

from src.api.app import create_app
from src.bot.dispatcher import create_bg_manager_factory, create_dispatcher, setup_dispatcher
from src.core.config import AppConfig
from src.core.logger import setup_logger
from src.infrastructure.di import create_container


def application() -> FastAPI:
    setup_logger()

    config = AppConfig.get()
    dispatcher = create_dispatcher(config=config)
    bg_manager_factory = create_bg_manager_factory(dispatcher=dispatcher)
    setup_dispatcher(dispatcher)

    app = create_app(config=config, dispatcher=dispatcher)
    container = create_container(config=config, bg_manager_factory=bg_manager_factory)

    # Register ContainerMiddleware ONLY on the 'update' observer
    # to avoid creating multiple REQUEST scopes per update.
    # Default setup_dishka registers on ALL observers, causing
    # 2 sessions per request (update + callback_query/message).
    middleware = ContainerMiddleware(container)
    dispatcher.update.outer_middleware(middleware)

    # auto_inject: wrap handlers with dependency injection
    callback = partial(inject_router, router=dispatcher)
    dispatcher.startup.register(callback)

    setup_fastapi_dishka(container=container, app=app)
    return app


if __name__ == "__main__":
    uvicorn.run(
        app=application,
        host="0.0.0.0",
        port=8000,
        factory=True,
    )
