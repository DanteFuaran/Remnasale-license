import uuid
from decimal import Decimal, ROUND_DOWN
from typing import Optional
from uuid import UUID

from aiogram import Bot
from fluentogram import TranslatorHub
from loguru import logger
from redis.asyncio import Redis

from src.bot.keyboards import get_user_keyboard
from src.core.config import AppConfig
from src.core.enums import (
    Currency,
    PaymentGatewayType,
    PurchaseType,
    SystemNotificationType,
    TransactionStatus,
)
from src.core.utils.formatters import (
    format_device_limit_number,
    format_price,
    i18n_format_days,
    i18n_format_device_limit,
    i18n_format_traffic_limit,
    i18n_format_expire_time,
    i18n_format_bytes_to_unit,
)
from src.core.utils.message_payload import MessagePayload
from src.infrastructure.database import UnitOfWork
from src.infrastructure.database.models.dto import (
    AnyGatewaySettingsDto,
    CryptomusGatewaySettingsDto,
    CryptopayGatewaySettingsDto,
    FreekassaGatewaySettingsDto,
    HeleketGatewaySettingsDto,
    LavaGatewaySettingsDto,
    MulenpayGatewaySettingsDto,
    PaymasterGatewaySettingsDto,
    PaymentGatewayDto,
    PaymentResult,
    PlategaGatewaySettingsDto,
    PlanSnapshotDto,
    PriceDetailsDto,
    RobokassaGatewaySettingsDto,
    TransactionDto,
    UrlpayGatewaySettingsDto,
    UserDto,
    WataGatewaySettingsDto,
    YookassaGatewaySettingsDto,
    YoomoneyGatewaySettingsDto,
)
from src.infrastructure.database.models.sql import PaymentGateway
from src.infrastructure.payment_gateways import BasePaymentGateway, PaymentGatewayFactory
from src.infrastructure.redis import RedisRepository
from src.infrastructure.taskiq.tasks.redirects import (
    redirect_to_main_menu_task,
    send_balance_topup_notification_task,
)
from src.infrastructure.taskiq.tasks.subscriptions import purchase_subscription_task
from src.services.extra_device import ExtraDeviceService
from src.services.notification import NotificationService
from src.services.referral import ReferralService
from src.services.settings import SettingsService
from src.services.subscription import SubscriptionService
from src.services.user import UserService

from remnapy import RemnawaveSDK

from .base import BaseService
from .transaction import TransactionService


class PaymentGatewayService(BaseService):
    uow: UnitOfWork
    transaction_service: TransactionService
    subscription_service: SubscriptionService
    payment_gateway_factory: PaymentGatewayFactory
    referral_service: ReferralService
    user_service: UserService
    settings_service: SettingsService
    extra_device_service: ExtraDeviceService
    remnawave: RemnawaveSDK

    def __init__(
        self,
        config: AppConfig,
        bot: Bot,
        redis_client: Redis,
        redis_repository: RedisRepository,
        translator_hub: TranslatorHub,
        #
        uow: UnitOfWork,
        transaction_service: TransactionService,
        subscription_service: SubscriptionService,
        payment_gateway_factory: PaymentGatewayFactory,
        referral_service: ReferralService,
        user_service: UserService,
        notification_service: NotificationService,
        settings_service: SettingsService,
        extra_device_service: ExtraDeviceService,
        remnawave: RemnawaveSDK,
    ) -> None:
        super().__init__(config, redis_client, redis_repository, translator_hub)
        self.bot = bot
        self.uow = uow
        self.transaction_service = transaction_service
        self.subscription_service = subscription_service
        self.payment_gateway_factory = payment_gateway_factory
        self.referral_service = referral_service
        self.user_service = user_service
        self.notification_service = notification_service
        self.settings_service = settings_service
        self.extra_device_service = extra_device_service
        self.remnawave = remnawave

    async def create_default(self) -> None:
        for gateway_type in PaymentGatewayType:
            settings: Optional[AnyGatewaySettingsDto]

            if await self.get_by_type(gateway_type):
                continue

            match gateway_type:
                case PaymentGatewayType.TELEGRAM_STARS:
                    is_active = False
                    settings = None
                case PaymentGatewayType.YOOKASSA:
                    is_active = False
                    settings = YookassaGatewaySettingsDto()
                case PaymentGatewayType.YOOMONEY:
                    is_active = False
                    settings = YoomoneyGatewaySettingsDto()
                case PaymentGatewayType.CRYPTOMUS:
                    is_active = False
                    settings = CryptomusGatewaySettingsDto()
                case PaymentGatewayType.HELEKET:
                    is_active = False
                    settings = HeleketGatewaySettingsDto()
                case PaymentGatewayType.LAVA:
                    is_active = False
                    settings = LavaGatewaySettingsDto()
                case PaymentGatewayType.PLATEGA:
                    is_active = False
                    settings = PlategaGatewaySettingsDto()
                case PaymentGatewayType.CRYPTOPAY:
                    is_active = False
                    settings = CryptopayGatewaySettingsDto()
                case PaymentGatewayType.ROBOKASSA:
                    is_active = False
                    settings = RobokassaGatewaySettingsDto()
                case PaymentGatewayType.FREEKASSA:
                    is_active = False
                    settings = FreekassaGatewaySettingsDto()
                case PaymentGatewayType.MULENPAY:
                    is_active = False
                    settings = MulenpayGatewaySettingsDto()
                case PaymentGatewayType.PAYMASTER:
                    is_active = False
                    settings = PaymasterGatewaySettingsDto()
                case PaymentGatewayType.URLPAY:
                    is_active = False
                    settings = UrlpayGatewaySettingsDto()
                case PaymentGatewayType.WATA:
                    is_active = False
                    settings = WataGatewaySettingsDto()
                case PaymentGatewayType.BALANCE:
                    # Internal balance payment type — no external gateway settings needed
                    continue
                case _:
                    logger.debug(f"Unhandled payment gateway type '{gateway_type}' - skipping")
                    continue

            order_index = await self.uow.repository.gateways.get_max_index()
            order_index = (order_index or 0) + 1

            payment_gateway = PaymentGatewayDto(
                order_index=order_index,
                type=gateway_type,
                currency=Currency.from_gateway_type(gateway_type),
                is_active=is_active,
                settings=settings,
            )

            db_payment_gateway = PaymentGateway(**payment_gateway.model_dump())
            db_payment_gateway = await self.uow.repository.gateways.create(db_payment_gateway)

            logger.info(f"Payment gateway '{gateway_type}' created")

        # Persist all newly created gateways in a single commit.
        # Without this, the rows are only flushed to the session and are
        # rolled back when the DI startup scope closes.
        await self.uow.commit()

    async def get(self, gateway_id: int) -> Optional[PaymentGatewayDto]:
        db_gateway = await self.uow.repository.gateways.get(gateway_id)

        if not db_gateway:
            logger.warning(f"Payment gateway '{gateway_id}' not found")
            return None

        logger.debug(f"Retrieved payment gateway '{gateway_id}'")
        return PaymentGatewayDto.from_model(db_gateway, decrypt=True)

    async def get_by_type(self, gateway_type: PaymentGatewayType) -> Optional[PaymentGatewayDto]:
        db_gateway = await self.uow.repository.gateways.get_by_type(gateway_type)

        if not db_gateway:
            logger.debug(f"Payment gateway of type '{gateway_type}' not found")
            return None

        logger.debug(f"Retrieved payment gateway of type '{gateway_type}'")
        return PaymentGatewayDto.from_model(db_gateway, decrypt=True)

    async def get_all(self, order_by_priority: bool = False) -> list[PaymentGatewayDto]:
        db_gateways = await self.uow.repository.gateways.get_all(order_by_priority)
        logger.debug(f"Retrieved '{len(db_gateways)}' payment gateways")
        return PaymentGatewayDto.from_model_list(db_gateways, decrypt=False)

    async def update(self, gateway: PaymentGatewayDto) -> Optional[PaymentGatewayDto]:
        updated_data = gateway.changed_data

        if gateway.settings and gateway.settings.changed_data:
            updated_data["settings"] = gateway.settings.prepare_init_data(encrypt=True)

        db_updated_gateway = await self.uow.repository.gateways.update(
            gateway_id=gateway.id,  # type: ignore[arg-type]
            **updated_data,
        )

        if db_updated_gateway:
            await self.uow.commit()
            logger.info(f"Payment gateway '{gateway.type}' updated successfully")
            return PaymentGatewayDto.from_model(db_updated_gateway, decrypt=True)

        logger.warning(
            f"Attempted to update gateway '{gateway.type}' (ID: '{gateway.id}'), "
            f"but gateway was not found or update failed"
        )
        return None

    async def filter_active(self, is_active: bool = True) -> list[PaymentGatewayDto]:
        db_gateways = await self.uow.repository.gateways.filter_active(is_active)
        logger.debug(f"Filtered active gateways: '{is_active}', found '{len(db_gateways)}'")
        return PaymentGatewayDto.from_model_list(db_gateways, decrypt=False)

    async def move_gateway_up(self, gateway_id: int) -> bool:
        db_gateways = await self.uow.repository.gateways.get_all()
        db_gateways.sort(key=lambda p: p.order_index)

        index = next((i for i, p in enumerate(db_gateways) if p.id == gateway_id), None)
        if index is None:
            logger.warning(f"Payment gateway with ID '{gateway_id}' not found for move operation")
            return False

        if index == 0:
            gateway = db_gateways.pop(0)
            db_gateways.append(gateway)
            logger.debug(f"Payment gateway '{gateway_id}' moved from top to bottom")
        else:
            db_gateways[index - 1], db_gateways[index] = db_gateways[index], db_gateways[index - 1]
            logger.debug(f"Payment gateway '{gateway_id}' moved up one position")

        for i, gateway in enumerate(db_gateways, start=1):
            gateway.order_index = i

        await self.uow.commit()
        logger.info(f"Payment gateway '{gateway_id}' reorder successfully")
        return True

    #

    async def create_topup_payment(
        self,
        user: UserDto,
        amount: int,
        gateway_type: PaymentGatewayType,
    ) -> PaymentResult:
        """Create a payment for topping up user balance.
        
        Amount is in the default currency (RUB). It will be converted 
        to the gateway's currency for the payment API call.
        Balance credit uses the original RUB amount.
        """
        # Minimum topup amount is 5 rubles
        MIN_TOPUP_AMOUNT = 5
        if amount < MIN_TOPUP_AMOUNT:
            raise ValueError(f"Minimum topup amount is {MIN_TOPUP_AMOUNT}")
        
        gateway_instance = await self._get_gateway_instance(gateway_type)

        i18n = self.translator_hub.get_translator_by_locale(locale=user.language)
        details = i18n.get("payment-invoice-topup", amount=amount)

        # pricing хранит сумму в дефолтной валюте (RUB) — используется для зачисления баланса
        pricing = PriceDetailsDto(original_amount=amount)
        plan = PlanSnapshotDto.test()  # Используем test plan как заглушку

        # Конвертируем сумму в валюту шлюза для оплаты
        gateway_currency = gateway_instance.data.currency
        payment_amount = Decimal(str(amount))
        if gateway_currency != Currency.RUB:
            settings = await self.settings_service.get()
            rates = settings.features.currency_rates
            match gateway_currency:
                case Currency.USD:
                    payment_amount = Decimal(str(amount)) / Decimal(str(rates.usd_rate))
                case Currency.EUR:
                    payment_amount = Decimal(str(amount)) / Decimal(str(rates.eur_rate))
                case Currency.XTR:
                    payment_amount = Decimal(str(amount)) / Decimal(str(rates.stars_rate))
            # Округляем по правилам валюты
            if gateway_currency in (Currency.XTR, Currency.RUB):
                payment_amount = payment_amount.to_integral_value(rounding=ROUND_DOWN)
                if payment_amount < 1:
                    payment_amount = Decimal(1)
            else:
                payment_amount = payment_amount.quantize(Decimal("0.01"))
                if payment_amount < Decimal("0.01"):
                    payment_amount = Decimal("0.01")

        transaction_data = {
            "status": TransactionStatus.PENDING,
            "purchase_type": PurchaseType.TOPUP,
            "gateway_type": gateway_instance.data.type,
            "pricing": pricing,
            "currency": Currency.RUB,
            "plan": plan,
            "user": user,
        }

        payment: PaymentResult = await gateway_instance.handle_create_payment(
            amount=payment_amount,
            details=details,
        )
        transaction = TransactionDto(payment_id=payment.id, **transaction_data)
        await self.transaction_service.create(user, transaction)

        logger.info(f"Created topup transaction '{payment.id}' for user '{user.telegram_id}', "
                     f"amount_rub={amount}, payment_amount={payment_amount} {gateway_currency}")
        logger.info(f"Topup payment link: '{payment.url}' for user '{user.telegram_id}'")
        return payment

    async def create_extra_devices_payment(
        self,
        user: UserDto,
        device_count: int,
        amount: Decimal,
        gateway_type: PaymentGatewayType,
        duration_days: int = 30,
    ) -> PaymentResult:
        """Create a payment for buying extra devices."""
        gateway_instance = await self._get_gateway_instance(gateway_type)

        i18n = self.translator_hub.get_translator_by_locale(locale=user.language)
        details = i18n.get("payment-invoice-extra-devices", device_count=device_count)

        pricing = PriceDetailsDto(original_amount=amount)
        plan = PlanSnapshotDto.test()  # Используем test plan как заглушку
        plan.name = i18n.get("frg-extra-devices-name", count=device_count)
        plan.duration = duration_days

        transaction_data = {
            "status": TransactionStatus.PENDING,
            "purchase_type": PurchaseType.EXTRA_DEVICES,
            "gateway_type": gateway_instance.data.type,
            "pricing": pricing,
            "currency": gateway_instance.data.currency,
            "plan": plan,
            "user": user,
        }

        payment: PaymentResult = await gateway_instance.handle_create_payment(
            amount=pricing.final_amount,
            details=details,
        )
        transaction = TransactionDto(payment_id=payment.id, **transaction_data)
        await self.transaction_service.create(user, transaction)

        logger.info(f"Created extra devices transaction '{payment.id}' for user '{user.telegram_id}'")
        logger.info(f"Extra devices payment link: '{payment.url}' for user '{user.telegram_id}'")
        return payment

    async def create_payment(
        self,
        user: UserDto,
        plan: PlanSnapshotDto,
        pricing: PriceDetailsDto,
        purchase_type: PurchaseType,
        gateway_type: PaymentGatewayType,
    ) -> PaymentResult:
        gateway_instance = await self._get_gateway_instance(gateway_type)

        i18n = self.translator_hub.get_translator_by_locale(locale=user.language)
        key, kw = i18n_format_days(plan.duration)
        details = i18n.get(
            "payment-invoice-description",
            purchase_type=purchase_type,
            name=plan.name,
            duration=i18n.get(key, **kw),
        )

        transaction_data = {
            "status": TransactionStatus.PENDING,
            "purchase_type": purchase_type,
            "gateway_type": gateway_instance.data.type,
            "pricing": pricing,
            "currency": gateway_instance.data.currency,
            "plan": plan,
            "user": user,
        }

        if pricing.is_free:
            payment_id = uuid.uuid4()

            transaction = TransactionDto(payment_id=payment_id, **transaction_data)
            await self.transaction_service.create(user, transaction)

            logger.info(f"Payment for user '{user.telegram_id}' not created. Pricing is free")
            return PaymentResult(id=payment_id, url=None)

        payment: PaymentResult = await gateway_instance.handle_create_payment(
            amount=pricing.final_amount,
            details=details,
        )
        transaction = TransactionDto(payment_id=payment.id, **transaction_data)
        await self.transaction_service.create(user, transaction)

        logger.info(f"Created transaction '{payment.id}' for user '{user.telegram_id}'")
        logger.info(f"Payment link: '{payment.url}' for user '{user.telegram_id}'")
        return payment

    async def create_balance_payment(
        self,
        user: UserDto,
        plan: PlanSnapshotDto,
        pricing: PriceDetailsDto,
        purchase_type: PurchaseType,
    ) -> PaymentResult:
        """Create a payment using user balance (no external gateway)."""
        payment_id = uuid.uuid4()
        
        # Get default currency for balance payments
        settings = await self.settings_service.get()
        currency = settings.default_currency
        
        transaction_data = {
            "status": TransactionStatus.PENDING,
            "purchase_type": purchase_type,
            "gateway_type": PaymentGatewayType.BALANCE,
            "pricing": pricing,
            "currency": currency,
            "plan": plan,
            "user": user,
        }
        
        transaction = TransactionDto(payment_id=payment_id, **transaction_data)
        await self.transaction_service.create(user, transaction)
        
        logger.info(f"Created balance payment '{payment_id}' for user '{user.telegram_id}'")
        return PaymentResult(id=payment_id, url=None)

    async def create_test_payment(
        self,
        user: UserDto,
        gateway_type: PaymentGatewayType,
    ) -> PaymentResult:
        gateway_instance = await self._get_gateway_instance(gateway_type)
        i18n = self.translator_hub.get_translator_by_locale(locale=user.language)
        test_details = i18n.get("test-payment")

        test_pricing = PriceDetailsDto(original_amount=2)
        test_plan = PlanSnapshotDto.test()

        test_payment: PaymentResult = await gateway_instance.handle_create_payment(
            amount=test_pricing.final_amount,
            details=test_details,
        )
        test_transaction = TransactionDto(
            payment_id=test_payment.id,
            status=TransactionStatus.PENDING,
            purchase_type=PurchaseType.NEW,
            gateway_type=gateway_instance.data.type,
            is_test=True,
            pricing=test_pricing,
            currency=gateway_instance.data.currency,
            plan=test_plan,
            user=user,
        )
        await self.transaction_service.create(user, test_transaction)

        logger.info(f"Created test transaction '{test_payment.id}' for user '{user.telegram_id}'")
        logger.info(
            f"Created test payment '{test_payment.id}' for gateway '{gateway_type}', "
            f"link: '{test_payment.url}'"
        )
        return test_payment

    async def handle_payment_succeeded(self, payment_id: UUID, run_sync: bool = False) -> None:
        """Обрабатывает успешную оплату.
        
        Args:
            payment_id: ID транзакции
            run_sync: Если True, задача purchase_subscription_task выполняется синхронно
                      (без отправки в очередь). Используется для оплаты с баланса,
                      чтобы данные были актуальны сразу после оплаты.
        """
        transaction = await self.transaction_service.get(payment_id)

        if not transaction or not transaction.user:
            logger.critical(f"Transaction or user not found for '{payment_id}'")
            return

        if transaction.is_completed:
            logger.warning(
                f"Transaction '{payment_id}' for user "
                f"'{transaction.user.telegram_id}' already completed"
            )
            return

        transaction.status = TransactionStatus.COMPLETED
        await self.transaction_service.update(transaction)

        logger.info(f"Payment succeeded '{payment_id}' for user '{transaction.user.telegram_id}'")

        if transaction.is_test:
            await self.notification_service.notify_user(
                user=transaction.user,
                payload=MessagePayload(
                    i18n_key="ntf-gateway-test-payment-confirmed",
                ),
            )
            return

        i18n_keys = {
            PurchaseType.NEW: "ntf-event-subscription-new",
            PurchaseType.RENEW: "ntf-event-subscription-renew",
            PurchaseType.CHANGE: "ntf-event-subscription-change",
            PurchaseType.TOPUP: "ntf-event-balance-topup",
            PurchaseType.EXTRA_DEVICES: "ntf-event-extra-devices",
        }
        i18n_key = i18n_keys.get(transaction.purchase_type)
        
        # Для покупки дополнительных устройств
        if transaction.purchase_type == PurchaseType.EXTRA_DEVICES:
            from src.services.extra_device import ExtraDeviceService
            from src.services.subscription import SubscriptionService
            from src.services.remnawave import RemnawaveService
            from src.services.plan import PlanService
            from src.services.plan import PlanService
            
            # Получаем сервисы из DI
            # Используем self.user_service и self.notification_service вместо создания новых
            
            extra_device_service = ExtraDeviceService(
                config=self.config,
                redis_client=self.redis_client,
                redis_repository=self.redis_repository,
                translator_hub=self.translator_hub,
                uow=self.uow,
            )
            subscription_service = SubscriptionService(
                config=self.config,
                redis_client=self.redis_client,
                redis_repository=self.redis_repository,
                translator_hub=self.translator_hub,
                uow=self.uow,
                user_service=self.user_service,
            )
            plan_service = PlanService(
                config=self.config,
                redis_client=self.redis_client,
                redis_repository=self.redis_repository,
                translator_hub=self.translator_hub,
                uow=self.uow,
            )
            remnawave_service = RemnawaveService(
                config=self.config,
                redis_client=self.redis_client,
                redis_repository=self.redis_repository,
                translator_hub=self.translator_hub,
                remnawave=self.remnawave,
                user_service=self.user_service,
                subscription_service=subscription_service,
                notification_service=self.notification_service,
                plan_service=plan_service,
            )
            
            # Получаем количество устройств из имени плана
            device_count = 1
            if "x" in transaction.plan.name:
                try:
                    device_count = int(transaction.plan.name.split("x")[1].split(")")[0])
                except (ValueError, IndexError, AttributeError):
                    device_count = 1
            
            # Получаем текущую подписку пользователя
            fresh_user = await self.user_service.get(transaction.user.telegram_id)
            if not fresh_user or not fresh_user.current_subscription:
                logger.error(f"No active subscription for user '{transaction.user.telegram_id}' to add devices")
                return
            
            subscription = fresh_user.current_subscription
            
            # Увеличиваем лимит устройств (только для подписок с фиксированным лимитом)
            new_extra_devices = (subscription.extra_devices or 0) + device_count
            subscription.extra_devices = new_extra_devices
            if subscription.device_limit and subscription.device_limit > 0:
                subscription.device_limit = subscription.device_limit + device_count
            # Для безлимитных подписок (device_limit <= 0) hwid_device_limit остаётся 0 (unlimited)
            
            # Обновляем в БД
            await subscription_service.update(subscription)
            
            # Создаём запись о покупке дополнительных устройств
            await extra_device_service.create_purchase(
                user=fresh_user,
                subscription=subscription,
                device_count=device_count,
                price=int(transaction.pricing.final_amount),
                duration_days=transaction.plan.duration,
            )
            
            # Обновляем в RemnaWave
            await remnawave_service.updated_user(
                user=fresh_user,
                uuid=subscription.user_remna_id,
                subscription=subscription,
            )
            
            # Очищаем кеш
            await self.user_service.clear_user_cache(fresh_user.telegram_id)
            
            logger.info(f"Added {device_count} extra devices for user '{transaction.user.telegram_id}'")
            
            # Вычисляем device_limit_number и device_limit_bonus
            plan_device_limit = (
                subscription.plan.device_limit 
                if subscription.plan and subscription.plan.device_limit > 0 
                else 0
            )
            device_limit_number = (
                plan_device_limit 
                if plan_device_limit > 0 
                else subscription.device_limit
            )
            device_limit_bonus = max(
                0, 
                subscription.device_limit - plan_device_limit - subscription.extra_devices
            ) if plan_device_limit > 0 else 0
            
            # Отправляем системное уведомление (Event)
            i18n_kwargs = {
                "payment_id": str(transaction.payment_id),
                "gateway_type": transaction.gateway_type,
                "final_amount": format_price(transaction.pricing.final_amount, transaction.currency),
                "original_price": format_price(transaction.pricing.original_amount, transaction.currency),
                "duration_days": transaction.plan.duration,
                "discount_percent": transaction.pricing.discount_percent,
                "user_id": str(transaction.user.telegram_id),
                "user_name": transaction.user.name,
                "username": transaction.user.username or False,
                "device_count": device_count,
                # Параметры для frg-subscription-details
                "subscription_id": str(subscription.user_remna_id),
                "subscription_status": subscription.status,
                "plan_name": subscription.plan.name,
                "traffic_used": i18n_format_bytes_to_unit(0),  # TODO: получить real traffic used
                "traffic_limit": i18n_format_traffic_limit(subscription.traffic_limit),
                "device_limit_number": format_device_limit_number(device_limit_number),
                "device_limit_bonus": device_limit_bonus,
                "extra_devices": subscription.extra_devices,
                "expire_time": i18n_format_expire_time(subscription.expire_at, is_unlimited=subscription.is_unlimited),
            }
            
            await self.notification_service.system_notify(
                ntf_type=SystemNotificationType.EXTRA_DEVICES,
                payload=MessagePayload.not_deleted(
                    i18n_key=i18n_key,
                    i18n_kwargs=i18n_kwargs,
                    reply_markup=get_user_keyboard(transaction.user.telegram_id),
                    close_button_style="success",
                ),
            )
            
            # Assign referral rewards (для любого способа оплаты, включая баланс)
            if not transaction.pricing.is_free:
                await self.referral_service.assign_referral_rewards(transaction=transaction)
            
            # Перенаправляем на экран успеха добавления устройств
            from src.infrastructure.taskiq.tasks.redirects import redirect_to_extra_devices_success_task
            await redirect_to_extra_devices_success_task.kiq(
                user=fresh_user,
                device_count=device_count,
            )
            
            return
        
        # Для пополнения баланса не создаём подписку, только добавляем деньги
        if transaction.purchase_type == PurchaseType.TOPUP:
            i18n_kwargs = {
                "payment_id": str(transaction.payment_id),
                "gateway_type": transaction.gateway_type,
                "final_amount": format_price(transaction.pricing.final_amount, transaction.currency),
                "user_id": str(transaction.user.telegram_id),
                "user_name": transaction.user.name,
                "username": transaction.user.username or False,
            }
            
            await self.notification_service.system_notify(
                ntf_type=SystemNotificationType.BILLING,
                payload=MessagePayload.not_deleted(
                    i18n_key=i18n_key,
                    i18n_kwargs=i18n_kwargs,
                    reply_markup=get_user_keyboard(transaction.user.telegram_id),
                    close_button_style="success",
                ),
            )
            
            if not transaction.pricing.is_free:
                await self.user_service.add_to_balance(
                    user=transaction.user,
                    amount=int(transaction.pricing.final_amount),
                )
            
            # Пополнение баланса НЕ начисляет реферальные награды
            # Награды начисляются только при покупке/продлении подписки
            
            # Redirect user to main menu
            await redirect_to_main_menu_task.kiq(telegram_id=transaction.user.telegram_id)
            
            # Send success notification with close button (appears below main menu)
            await send_balance_topup_notification_task.kiq(
                telegram_id=transaction.user.telegram_id,
                amount=transaction.pricing.final_amount,
                currency_symbol=transaction.currency.symbol,
            )
            
            logger.debug(f"Balance topped up for user '{transaction.user.telegram_id}'")
            return

        subscription = await self.subscription_service.get_current(transaction.user.telegram_id)
        extra_i18n_kwargs = {}
        
        # Для продления подписки добавляем информацию о доп. устройствах
        extra_devices_cost_value = 0
        if transaction.purchase_type == PurchaseType.RENEW:
            if subscription:
                # Получаем количество активных extra устройств (не на удалении)
                extra_devices = await self.extra_device_service.get_total_active_devices(subscription.id)
                if extra_devices > 0:
                    # Получаем стоимость доп. устройств
                    device_price_monthly = await self.settings_service.get_extra_device_price()
                    extra_devices_monthly_cost = device_price_monthly * extra_devices
                    # Рассчитываем стоимость за период
                    extra_devices_cost_value = int((extra_devices_monthly_cost * transaction.plan.duration) / 30)
                    extra_i18n_kwargs = {
                        "has_extra_devices": 1,
                        "extra_devices_count": extra_devices,
                        "extra_devices_cost": format_price(extra_devices_cost_value, transaction.currency),
                    }
                else:
                    extra_i18n_kwargs = {
                        "has_extra_devices": 0,
                        "extra_devices_count": 0,
                        "extra_devices_cost": format_price(0, transaction.currency),
                    }
            else:
                extra_i18n_kwargs = {
                    "has_extra_devices": 0,
                    "extra_devices_count": 0,
                    "extra_devices_cost": format_price(0, transaction.currency),
                }

        if transaction.purchase_type == PurchaseType.CHANGE:
            plan = subscription.plan if subscription else None

            # Для CHANGE не учитываем стоимость доп. устройств:
            # они все удаляются при смене тарифа
            extra_devices_cost_value = 0

            # Получаем количество купленных доп. слотов устройств, которые будут удалены
            devices_to_remove = 0
            if subscription:
                try:
                    devices_to_remove = await self.extra_device_service.get_total_active_devices(subscription.id)
                    logger.info(
                        f"[CHANGE] Extra device slots for '{transaction.user.telegram_id}': "
                        f"devices_to_remove={devices_to_remove}"
                    )
                except Exception as e:
                    logger.warning(f"[CHANGE] Failed to get extra device slots: {e}")
                    devices_to_remove = 0

            extra_i18n_kwargs = {
                "previous_plan_name": plan.name if plan else "N/A",
                "previous_plan_type": {
                    "key": "plan-type",
                    "plan_type": plan.type if plan else "N/A",
                },
                "previous_plan_traffic_limit": (
                    i18n_format_traffic_limit(plan.traffic_limit) if plan else "N/A"
                ),
                "previous_plan_device_limit": (
                    i18n_format_device_limit(plan.device_limit) if plan else "N/A"
                ),
                "previous_plan_duration": (i18n_format_days(plan.duration) if plan else "N/A"),
                "has_extra_devices_cost": 1 if extra_devices_cost_value > 0 else 0,
                "devices_removed": devices_to_remove,
            }

        # Вычисляем стоимость только подписки (без доп. устройств)
        plan_only_price = transaction.pricing.original_amount - extra_devices_cost_value

        i18n_kwargs = {
            "payment_id": str(transaction.payment_id),
            "gateway_type": transaction.gateway_type,
            "final_amount": format_price(transaction.pricing.final_amount, transaction.currency),
            "discount_percent": transaction.pricing.discount_percent,
            "original_amount": format_price(transaction.pricing.original_amount, transaction.currency),
            "user_id": str(transaction.user.telegram_id),
            "user_name": transaction.user.name,
            "username": transaction.user.username or False,
            "plan_name": transaction.plan.name,
            "plan_type": transaction.plan.type,
            "plan_traffic_limit": i18n_format_traffic_limit(transaction.plan.traffic_limit),
            "plan_device_limit": i18n_format_device_limit(transaction.plan.device_limit),
            "plan_duration": i18n_format_days(transaction.plan.duration),
            "plan_price": format_price(plan_only_price, transaction.currency),
            "is_free": 1 if transaction.pricing.is_free else 0,
        }

        await self.notification_service.system_notify(
            ntf_type=SystemNotificationType.SUBSCRIPTION,
            payload=MessagePayload.not_deleted(
                i18n_key=i18n_key,
                i18n_kwargs={**i18n_kwargs, **extra_i18n_kwargs},
                reply_markup=get_user_keyboard(transaction.user.telegram_id),
                close_button_style="success",
            ),
        )

        # Для run_sync=True (оплата с баланса) выполняем синхронно
        # Это позволяет показать актуальные данные сразу после оплаты
        if run_sync:
            logger.info(f"Running purchase_subscription_task synchronously for '{transaction.payment_id}'")
            
            # Создаём необходимые сервисы для синхронного выполнения
            from src.services.remnawave import RemnawaveService
            from src.services.plan import PlanService
            
            plan_service = PlanService(
                config=self.config,
                redis_client=self.redis_client,
                redis_repository=self.redis_repository,
                translator_hub=self.translator_hub,
                uow=self.uow,
            )
            
            remnawave_service = RemnawaveService(
                config=self.config,
                redis_client=self.redis_client,
                redis_repository=self.redis_repository,
                translator_hub=self.translator_hub,
                remnawave=self.remnawave,
                user_service=self.user_service,
                subscription_service=self.subscription_service,
                notification_service=self.notification_service,
                plan_service=plan_service,
            )
            
            from src.infrastructure.taskiq.tasks.subscriptions import process_subscription_purchase
            await process_subscription_purchase(
                transaction=transaction,
                subscription=subscription,
                remnawave_service=remnawave_service,
                subscription_service=self.subscription_service,
                transaction_service=self.transaction_service,
                notification_service=self.notification_service,
                user_service=self.user_service,
                extra_device_service=self.extra_device_service,
                redis_client=self.redis_client,
                skip_redirect=True,
                referral_service=self.referral_service,
            )
        else:
            logger.info(f"Sending purchase_subscription_task for transaction '{transaction.payment_id}', subscription={subscription is not None}")
            await purchase_subscription_task.kiq(transaction, subscription)
            logger.info(f"purchase_subscription_task sent successfully")

        # Сбросить одноразовую скидку после успешной покупки
        if transaction.user.purchase_discount > 0 and transaction.pricing.discount_percent > 0:
            logger.info(
                f"Resetting one-time discount for user '{transaction.user.telegram_id}' "
                f"(was {transaction.user.purchase_discount}%)"
            )
            transaction.user.purchase_discount = 0
            transaction.user.purchase_discount_expires_at = None
            await self.user_service.update(transaction.user)

        logger.debug(f"Called tasks payment for user '{transaction.user.telegram_id}'")

    async def handle_payment_canceled(self, payment_id: UUID) -> None:
        transaction = await self.transaction_service.get(payment_id)

        if not transaction or not transaction.user:
            logger.critical(f"Transaction or user not found for '{payment_id}'")
            return

        transaction.status = TransactionStatus.CANCELED
        await self.transaction_service.update(transaction)
        logger.info(f"Payment canceled '{payment_id}' for user '{transaction.user.telegram_id}'")

    #

    async def _get_gateway_instance(self, gateway_type: PaymentGatewayType) -> BasePaymentGateway:
        logger.debug(f"Creating gateway instance for type '{gateway_type}'")
        gateway = await self.get_by_type(gateway_type)

        if not gateway:
            raise ValueError(f"Payment gateway of type '{gateway_type}' not found")

        return self.payment_gateway_factory(gateway)
