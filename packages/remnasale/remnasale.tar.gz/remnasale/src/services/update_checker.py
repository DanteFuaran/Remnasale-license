from typing import Any, Optional

import httpx
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from loguru import logger

from src.__version__ import __version__
from src.core.constants import DEFAULT_BRANCH, REPOSITORY, get_update_branch
from src.core.enums import SystemNotificationType
from src.core.storage.keys import LastNotifiedVersionKey, UpdateSnoozeKey
from src.core.utils.message_payload import MessagePayload
from src.infrastructure.redis.repository import RedisRepository
from src.services.notification import NotificationService
from src.services.settings import SettingsService

from .base import BaseService

from fluentogram import TranslatorHub
from redis.asyncio import Redis
from src.core.config import AppConfig
from src.core.utils.license_host import get_license_host

# Callback data prefixes for update snooze buttons
UPDATE_SNOOZE_PREFIX = "update_snooze:"
UPDATE_SNOOZE_1D = f"{UPDATE_SNOOZE_PREFIX}1"
UPDATE_SNOOZE_3D = f"{UPDATE_SNOOZE_PREFIX}3"
UPDATE_SNOOZE_7D = f"{UPDATE_SNOOZE_PREFIX}7"
UPDATE_SNOOZE_OFF = f"{UPDATE_SNOOZE_PREFIX}off"
UPDATE_NOW = "update_now"
UPDATE_CLOSE = "update_close"


def _parse_version(version_str: str) -> tuple[int, ...]:
    """Parse version string like '0.4.6' into tuple (0, 4, 6) for comparison."""
    try:
        return tuple(int(x) for x in version_str.strip().split("."))
    except (ValueError, AttributeError):
        return (0, 0, 0)


class UpdateCheckerService(BaseService):
    notification_service: NotificationService
    settings_service: SettingsService

    def __init__(
        self,
        config: AppConfig,
        redis_client: Redis,
        redis_repository: RedisRepository,
        translator_hub: TranslatorHub,
        #
        notification_service: NotificationService,
        settings_service: SettingsService,
    ) -> None:
        super().__init__(config, redis_client, redis_repository, translator_hub)
        self.notification_service = notification_service
        self.settings_service = settings_service

    async def _fetch_remote_version(self, branch: str = DEFAULT_BRANCH) -> Optional[str]:
        """Fetch the latest version from the license server."""
        license_server = await get_license_host(self.redis_repository.client, self.config)
        license_key = self.config.build.license_key.get_secret_value()
        if not license_server or not license_key:
            return None
        url = f"{license_server.rstrip('/')}/api/v1/version"
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.get(url, params={"key": license_key})
                response.raise_for_status()
                data = response.json()
                return data.get("version")
        except Exception as e:
            logger.warning(f"[update_checker] Failed to fetch remote version: {e}")
            return None

    async def _get_last_notified_version(self) -> Optional[str]:
        """Get the last version we already notified about from Redis."""
        key = LastNotifiedVersionKey()
        return await self.redis_repository.get(key, str)

    async def _set_last_notified_version(self, version: str) -> None:
        """Save the last notified version to Redis."""
        key = LastNotifiedVersionKey()
        await self.redis_repository.set(key, version)

    async def is_snoozed(self) -> bool:
        """Check if update notifications are currently snoozed."""
        key = UpdateSnoozeKey()
        value = await self.redis_repository.get(key, str)
        return value is not None

    async def set_snooze(self, days: int) -> None:
        """Snooze update notifications for N days."""
        key = UpdateSnoozeKey()
        ex = days * 86400  # days to seconds
        await self.redis_repository.set(key, "1", ex=ex)
        logger.info(f"[update_checker] Snoozed update notifications for {days} day(s)")

    async def disable_notifications(self) -> None:
        """Disable update notifications permanently (until new version appears)."""
        key = UpdateSnoozeKey()
        # Set for 365 days — effectively permanent until a new version resets it
        await self.redis_repository.set(key, "permanent", ex=365 * 86400)
        logger.info("[update_checker] Update notifications disabled permanently")

    async def _clear_snooze_for_new_version(self, version: str) -> None:
        """Clear snooze if a newer version than the snoozed one appeared."""
        last_notified = await self._get_last_notified_version()
        if last_notified and _parse_version(version) > _parse_version(last_notified):
            # New version appeared — reset snooze
            key = UpdateSnoozeKey()
            await self.redis_repository.delete(key)
            logger.info(f"[update_checker] Cleared snooze — new version {version} detected")

    def _build_snooze_keyboard(self) -> InlineKeyboardMarkup:
        """Build inline keyboard with update/snooze/dismiss buttons."""
        builder = InlineKeyboardBuilder()
        builder.row(
            InlineKeyboardButton(text="btn-update-now", callback_data=UPDATE_NOW, style="primary"),
        )
        builder.row(
            InlineKeyboardButton(text="btn-update-remind-1d", callback_data=UPDATE_SNOOZE_1D),
            InlineKeyboardButton(text="btn-update-remind-3d", callback_data=UPDATE_SNOOZE_3D),
            InlineKeyboardButton(text="btn-update-remind-7d", callback_data=UPDATE_SNOOZE_7D),
        )
        builder.row(
            InlineKeyboardButton(text="btn-update-remind-off", callback_data=UPDATE_SNOOZE_OFF),
            InlineKeyboardButton(text="btn-update-close", callback_data=UPDATE_CLOSE, style="danger"),
        )
        return builder.as_markup()

    async def _delete_stored_update_notifications(self) -> None:
        """Delete previously sent update notification messages and remove from Redis."""
        from src.core.storage.keys import UpdateNotificationsKey
        key = UpdateNotificationsKey()
        entries = await self.redis_repository.list_range(key, 0, -1)
        if not entries:
            return
        for entry in entries:
            try:
                parts = entry.split(":")
                if len(parts) == 2:
                    chat_id, message_id = int(parts[0]), int(parts[1])
                    bot = self.notification_service.bot
                elif len(parts) == 3 and parts[2].startswith("b"):
                    chat_id, message_id = int(parts[0]), int(parts[1])
                    bot_id = int(parts[2][1:])
                    mgr = self.notification_service._mirror_bot_manager
                    bot = next(
                        (b for b in mgr.active_bots.values() if b.id == bot_id),
                        None,
                    ) if mgr else None
                else:
                    continue
                if bot:
                    try:
                        await bot.delete_message(chat_id=chat_id, message_id=message_id)
                    except Exception:
                        pass  # Already deleted — fine
            except Exception as e:
                logger.debug(f"[update_checker] Failed to delete old notification '{entry}': {e}")
        await self.redis_repository.delete(key)

    async def _store_update_notifications(
        self,
        sent: list[tuple[int, Any]],
    ) -> None:
        """Store sent update notification message IDs in Redis."""
        from src.core.storage.keys import UpdateNotificationsKey
        key = UpdateNotificationsKey()
        await self.redis_repository.delete(key)
        for chat_id, msg in sent:
            if msg is None:
                continue
            # msg is the main-bot message; mirror messages are not individually accessible here
            entry = f"{chat_id}:{msg.message_id}"
            await self.redis_repository.list_push(key, entry)
        await self.redis_repository.expire(key, 7 * 86400)  # 7 days TTL

    async def check_for_updates(self) -> None:
        """Check if a new version is available and notify the developer."""
        local_version = __version__
        branch = get_update_branch()
        remote_version = await self._fetch_remote_version(branch=branch)

        if not remote_version:
            logger.debug("[update_checker] Could not fetch remote version, skipping check")
            return

        local_parsed = _parse_version(local_version)
        remote_parsed = _parse_version(remote_version)

        if remote_parsed <= local_parsed:
            logger.debug(
                f"[update_checker] Bot is up to date (local={local_version}, remote={remote_version})"
            )
            return

        last_notified = await self._get_last_notified_version()

        # If we already notified about this exact version and no newer one appeared — skip
        if last_notified and _parse_version(last_notified) >= remote_parsed:
            logger.debug(
                f"[update_checker] Already notified about {remote_version}, skipping duplicate"
            )
            return

        # Clear snooze if this is a brand-new version
        await self._clear_snooze_for_new_version(remote_version)

        # Check if notifications are snoozed
        if await self.is_snoozed():
            logger.debug("[update_checker] Update notifications are snoozed, skipping")
            return

        # Delete previous update notification messages (they show an outdated version)
        await self._delete_stored_update_notifications()

        # Send notification to developer with snooze buttons
        logger.info(
            f"[update_checker] New version available: {remote_version} (current: {local_version})"
        )

        sent_messages: list[tuple[int, Any]] = []
        await self.notification_service.system_notify(
            payload=MessagePayload(
                i18n_key="ntf-system-update-available",
                i18n_kwargs={
                    "current_version": local_version,
                    "new_version": remote_version,
                },
                auto_delete_after=None,
                add_close_button=False,
                reply_markup=self._build_snooze_keyboard(),
            ),
            ntf_type=SystemNotificationType.BOT_UPDATE,
            out_messages=sent_messages,
        )

        await self._store_update_notifications(sent_messages)
        await self._set_last_notified_version(remote_version)
