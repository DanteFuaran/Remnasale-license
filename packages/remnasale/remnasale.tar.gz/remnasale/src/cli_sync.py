#!/usr/bin/env python3
"""CLI-утилита для запуска синхронизации бота с панелью Remnawave.
Используется скриптом dfc-remna-install после восстановления из бэкапа.

Использование:
    python3 /opt/remnasale/src/cli_sync.py
"""
import asyncio
import json


async def main():
    from src.infrastructure.taskiq.broker import broker
    await broker.startup()

    from src.infrastructure.taskiq.tasks.importer import sync_bot_to_panel_task

    task = await sync_bot_to_panel_task.kiq(True)
    result = await task.wait_result(timeout=300)
    sync_result = result.return_value

    if sync_result:
        print(json.dumps(sync_result, ensure_ascii=False))
    else:
        print("{}")

    await broker.shutdown()


if __name__ == '__main__':
    asyncio.run(main())
