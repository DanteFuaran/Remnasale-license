import hashlib
import hmac
import json
import uuid
from decimal import Decimal
from typing import Any, Final, Optional
from uuid import UUID

import orjson
from aiogram import Bot
from fastapi import Request
from httpx import AsyncClient, HTTPStatusError
from loguru import logger

from src.core.config import AppConfig
from src.core.enums import TransactionStatus
from src.infrastructure.database.models.dto import (
    LavaGatewaySettingsDto,
    PaymentGatewayDto,
    PaymentResult,
)

from .base import BasePaymentGateway


class LavaGateway(BasePaymentGateway):
    _client: AsyncClient

    API_BASE: Final[str] = "https://api.lava.ru"

    def __init__(self, gateway: PaymentGatewayDto, bot: Bot, config: AppConfig) -> None:
        super().__init__(gateway, bot, config)

        if not isinstance(self.data.settings, LavaGatewaySettingsDto):
            raise TypeError(
                f"Invalid settings type: expected {LavaGatewaySettingsDto.__name__}, "
                f"got {type(self.data.settings).__name__}"
            )

        self._client = self._make_client(
            base_url=self.API_BASE,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
        )

    async def handle_create_payment(self, amount: Decimal, details: str) -> PaymentResult:
        order_id = str(uuid.uuid4())
        payload = await self._create_payment_payload(str(amount), order_id, details)

        json_body = json.dumps(payload, ensure_ascii=False)
        signature = self._generate_signature(json_body)

        try:
            response = await self._client.post(
                "/business/invoice/create",
                content=json_body.encode("utf-8"),
                headers={"Signature": signature},
            )
            response.raise_for_status()
            data = orjson.loads(response.content).get("data", {})
            return self._get_payment_data(data, order_id)

        except HTTPStatusError as exception:
            logger.error(
                f"HTTP error creating Lava payment. "
                f"Status: '{exception.response.status_code}', Body: {exception.response.text}"
            )
            raise
        except (KeyError, orjson.JSONDecodeError) as exception:
            logger.error(f"Failed to parse Lava response. Error: {exception}")
            raise
        except Exception as exception:
            logger.exception(f"An unexpected error occurred while creating Lava payment: {exception}")
            raise

    async def handle_webhook(self, request: Request) -> tuple[UUID, TransactionStatus]:
        logger.debug("Received Lava webhook request")
        raw_body = await request.body()
        webhook_data = await self._get_webhook_data(request)

        authorization = request.headers.get("Authorization")
        if not authorization:
            raise PermissionError("Missing Authorization header")

        if not self._verify_webhook(raw_body, authorization):
            raise PermissionError("Lava webhook verification failed")

        order_id = webhook_data.get("order_id")
        if not order_id:
            raise ValueError("Required field 'order_id' is missing")

        status = webhook_data.get("status")
        payment_id = UUID(order_id)

        match status:
            case "success":
                transaction_status = TransactionStatus.COMPLETED
            case "cancel" | "expired":
                transaction_status = TransactionStatus.CANCELED
            case _:
                raise ValueError(f"Unsupported Lava status: {status}")

        return payment_id, transaction_status

    async def _create_payment_payload(self, amount: str, order_id: str, details: str) -> dict[str, Any]:
        return {
            "sum": float(amount),
            "orderId": order_id,
            "shopId": self.data.settings.shop_id,  # type: ignore[union-attr]
            "hookUrl": self.config.get_webhook(self.data.type),
            "successUrl": await self._get_bot_redirect_url(),
            "failUrl": await self._get_bot_redirect_url(),
            "expire": 30,
            "comment": details,
        }

    def _generate_signature(self, json_string: str) -> str:
        """Generate HMAC-SHA256 signature for Lava API."""
        secret = self.data.settings.secret_key.get_secret_value()  # type: ignore[union-attr]
        return hmac.new(
            secret.encode("utf-8"),
            json_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _get_payment_data(self, data: dict[str, Any], order_id: str) -> PaymentResult:
        payment_url = data.get("url")

        if not payment_url:
            raise KeyError("Invalid response from Lava API: missing 'url'")

        return PaymentResult(id=UUID(order_id), url=str(payment_url))

    async def check_payment_status(self, payment_id: UUID) -> Optional[TransactionStatus]:
        try:
            payload = {
                "shopId": self.data.settings.shop_id,  # type: ignore[union-attr]
                "orderId": str(payment_id),
            }
            json_body = json.dumps(payload, ensure_ascii=False)
            signature = self._generate_signature(json_body)
            response = await self._client.post(
                "/business/invoice/status",
                content=json_body.encode("utf-8"),
                headers={"Signature": signature},
            )
            response.raise_for_status()
            data = orjson.loads(response.content).get("data", {})
            status = data.get("status")
            match status:
                case "success":
                    return TransactionStatus.COMPLETED
                case "cancel" | "expired":
                    return TransactionStatus.CANCELED
                case _:
                    return None
        except Exception as exc:
            logger.warning(f"Lava status check failed for {payment_id}: {exc}")
            return None

    @staticmethod
    def _normalize_for_php_json(value: Any) -> Any:
        """Normalize Python values to match PHP json_encode() output.

        PHP json_encode serializes whole-number floats without the decimal
        (e.g., 95.0 → 95), while Python includes it (95.0 → "95.0").
        """
        if isinstance(value, float) and value.is_integer():
            return int(value)
        if isinstance(value, dict):
            return {k: LavaGateway._normalize_for_php_json(v) for k, v in value.items()}
        if isinstance(value, list):
            return [LavaGateway._normalize_for_php_json(v) for v in value]
        return value

    def _verify_webhook(self, raw_body: bytes, authorization: str) -> bool:
        """Verify Lava webhook signature using the additional (webhook) key.

        Lava SDK computes the signature as:
          json_decode → ksort → json_encode → HMAC-SHA256(additional_key, ...)
        We replicate this in Python, normalizing floats to match PHP's json_encode.
        """
        settings = self.data.settings  # type: ignore[union-attr]
        if not settings.additional_key:
            logger.warning("Lava additional_key is not configured, cannot verify webhook")
            return False

        secret = settings.additional_key.get_secret_value()

        try:
            data = json.loads(raw_body)
            sorted_data = dict(sorted(data.items()))
            normalized = self._normalize_for_php_json(sorted_data)
            serialized = json.dumps(normalized, separators=(",", ":"), ensure_ascii=True)

            computed = hmac.new(
                secret.encode("utf-8"),
                serialized.encode("utf-8"),
                hashlib.sha256,
            ).hexdigest()
        except Exception as exc:
            logger.error(f"Failed to compute Lava webhook signature: {exc}")
            return False

        if not hmac.compare_digest(computed, authorization):
            logger.warning(
                f"Invalid Lava webhook signature. Computed: {computed}, Received: {authorization}"
            )
            return False

        return True
