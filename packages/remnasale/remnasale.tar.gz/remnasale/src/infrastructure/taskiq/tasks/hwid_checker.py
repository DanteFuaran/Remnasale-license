"""Задача проверки новых HWID-устройств для всех пользователей с подпиской.

Remnawave не всегда эмитирует событие user_hwid_devices.added через webhook:
- Для безлимитных планов (hwidDeviceLimit=0) устройства регистрируются через очередь БЕЗ события
- Для обычных планов webhook может быть нестабильным

Основная проверка происходит каждые 5 секунд в lifespan (_hwid_check_loop).
Cron-задача каждые 5 минут — резервная сверка.

Дедупликация через атомарные маркеры hwid_notified:{tid}:{hwid} (SET NX, 30 дней TTL).
Один и тот же HWID уведомляется ОДНОКРАТНО, пока маркер не истечёт.
Уведомления об удалении устройств не отправляются.
"""

from dishka.integrations.taskiq import FromDishka, inject
from loguru import logger
from redis.asyncio import Redis

from src.bot.keyboards import get_user_keyboard
from src.core.enums import SystemNotificationType
from src.core.utils.message_payload import MessagePayload
from src.infrastructure.taskiq.broker import broker
from src.services.notification import NotificationService
from src.services.remnawave import RemnawaveService
from src.services.user import UserService


async def run_hwid_check(
    user_service: UserService,
    remnawave_service: RemnawaveService,
    notification_service: NotificationService,
    redis_client: Redis,
) -> None:
    """
    Ядро проверки HWID. Вызывается из lifespan-цикла (каждые 5 сек)
    и из cron-задачи (каждые 5 мин, резерв).
    """
    users = await user_service.get_all()
    checked = 0
    notified = 0

    for user in users:
        try:
            sub = user.current_subscription
            if not sub or not sub.is_active:
                continue

            devices = await remnawave_service.get_devices_user(user)
            if not devices:
                checked += 1
                continue

            checked += 1

            for device in devices:
                # Атомарная проверка: SET NX устанавливает ключ только если его нет.
                # Если ключ уже есть — устройство уже было уведомлено, пропускаем.
                marker_key = f"hwid_notified:{user.telegram_id}:{device.hwid}"
                was_new = await redis_client.set(marker_key, "1", nx=True, ex=30 * 24 * 3600)

                if not was_new:
                    continue

                logger.info(
                    f"[hwid_checker] New device detected for user {user.telegram_id}: {device.hwid}"
                )

                try:
                    await notification_service.system_notify(
                        ntf_type=SystemNotificationType.USER_HWID,
                        payload=MessagePayload.not_deleted(
                            i18n_key="ntf-event-user-hwid-added",
                            i18n_kwargs={
                                "user_id": str(user.telegram_id),
                                "user_name": user.name,
                                "username": user.username or False,
                                "hwid": device.hwid,
                                "platform": device.platform,
                                "device_model": device.device_model,
                                "os_version": device.os_version,
                                "user_agent": device.user_agent,
                            },
                            reply_markup=get_user_keyboard(user.telegram_id),
                            close_button_style="success",
                        ),
                    )
                    notified += 1
                except Exception as e:
                    logger.warning(
                        f"[hwid_checker] Failed to send notification for {user.telegram_id}: {e}"
                    )

        except Exception as e:
            logger.warning(f"[hwid_checker] Error processing user {user.telegram_id}: {e}")

    if notified > 0:
        logger.info(f"[hwid_checker] Done: checked={checked}, notified={notified}")
    else:
        logger.debug(f"[hwid_checker] Done: checked={checked}, notified={notified}")


@broker.task(schedule=[{"cron": "*/5 * * * *"}])  # Резервная сверка каждые 5 мин
@inject
async def check_new_hwid_devices_task(
    user_service: FromDishka[UserService],
    remnawave_service: FromDishka[RemnawaveService],
    notification_service: FromDishka[NotificationService],
    redis_client: FromDishka[Redis],
) -> None:
    await run_hwid_check(user_service, remnawave_service, notification_service, redis_client)
