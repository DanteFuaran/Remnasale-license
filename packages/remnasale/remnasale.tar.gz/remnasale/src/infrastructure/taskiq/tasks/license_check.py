"""Периодическая проверка лицензии.

Cron запускается каждую минуту, но фактическая проверка выполняется
только если прошло достаточно времени (license:check_interval из настроек
лиц-сервера, по умолчанию 1 мин).  Это позволяет менять частоту
проверки на стороне сервера без обновления клиента.

Redis-ключи:
  license:last_ok           — timestamp последнего успешного контакта
  license:last_check        — timestamp последней фактической проверки
  license:check_interval    — частота проверки (мин), из настроек сервера
  license:offline_grace_days — дни автономной работы (default 7)
  license:notified          — тип отправленного уведомления:
                              suspended / blacklisted / invalid / offline
  license:expiry_warned_day  — дата последнего предупреждения об истечении
  license:offline_ticks     — счётчик циклов без связи (защита от
                              перевода часов клиентом)
  license:restricted_mode   — флаг ограниченного режима

4 сценария уведомлений (каждый — пара «проблема / восстановление»):
  1. Лицензия приостановлена  →  Лицензия возобновлена
  2. Лицензия отозвана        →  Лицензия восстановлена
  3. Связь с сервером потеряна →  Связь восстановлена
  4. Лицензия заканчивается   →  Лицензия продлена
"""
import math
import time
from datetime import datetime, timezone
from pathlib import Path

import aiohttp
from aiogram import Bot
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, FSInputFile
from dishka.integrations.taskiq import FromDishka, inject
from loguru import logger

from src.core.config import AppConfig
from src.core.utils.license_host import LICENSE_HOST_REDIS_KEY, get_license_host
from src.infrastructure.redis import RedisRepository
from src.infrastructure.taskiq.broker import broker
from src.services.notification import NotificationService

_REDIS_LAST_OK = "license:last_ok"
_REDIS_LAST_CHECK = "license:last_check"  # timestamp последней фактической проверки
_REDIS_CHECK_INTERVAL = "license:check_interval"
_REDIS_GRACE_DAYS = "license:offline_grace_days"
_REDIS_NOTIFIED = "license:notified"
_REDIS_NOTIFIED_AT = "license:notified_at"  # timestamp первого обнаружения проблемы
_REDIS_EXPIRY_WARNED = "license:expiry_warned_day"
_REDIS_OFFLINE_TICKS = "license:offline_ticks"
_REDIS_OFFLINE_SINCE = "license:offline_since"  # timestamp первого сбоя связи
_REDIS_RESTRICTED_MODE = "license:restricted_mode"  # ограниченный режим при невалидной лицензии
_REDIS_SUPPORT_URL = "license:support_url"  # URL помощи с лицензионного сервера

_DEFAULT_CHECK_INTERVAL_MIN = 1  # 1 мин (из настроек лиц-сервера)
_DEFAULT_GRACE_DAYS = 7
_EXPIRY_WARN_DAYS = 3  # предупреждать за N дней до истечения
_LICENSE_BANNER_NAME = "license_banner.jpg"


async def _save_settings(redis_client, check_interval_min: int, grace_days: int) -> None:
    """Сохранить настройки из ответа лиц-сервера."""
    await redis_client.set(_REDIS_CHECK_INTERVAL, str(check_interval_min))
    await redis_client.set(_REDIS_GRACE_DAYS, str(grace_days))


async def _mark_ok(redis_client) -> None:
    """Зафиксировать успешный контакт и сбросить всё оффлайн-состояние."""
    await redis_client.set(_REDIS_LAST_OK, str(int(time.time())))
    await redis_client.delete(_REDIS_NOTIFIED)
    await redis_client.delete(_REDIS_NOTIFIED_AT)
    await redis_client.delete(_REDIS_OFFLINE_TICKS)
    await redis_client.delete(_REDIS_OFFLINE_SINCE)
    await redis_client.delete(_REDIS_RESTRICTED_MODE)


async def _get_check_interval(redis_client) -> int:
    """Порог (в минутах) — после стольки минут без связи отправлять уведомление."""
    val = await redis_client.get(_REDIS_CHECK_INTERVAL)
    try:
        return int(val) if val else _DEFAULT_CHECK_INTERVAL_MIN
    except (ValueError, TypeError):
        return _DEFAULT_CHECK_INTERVAL_MIN


async def _get_grace_days(redis_client) -> int:
    val = await redis_client.get(_REDIS_GRACE_DAYS)
    try:
        return int(val) if val else _DEFAULT_GRACE_DAYS
    except (ValueError, TypeError):
        return _DEFAULT_GRACE_DAYS


async def _get_support_url(redis_client) -> str | None:
    """Возвращает кешированный support_url (Telegram username) или None."""
    val = await redis_client.get(_REDIS_SUPPORT_URL)
    if not val:
        return None
    return val.decode() if isinstance(val, bytes) else val


async def _get_elapsed_sec(redis_client) -> int:
    """Время оффлайн — max(по тикам, по часам). Защита от перевода часов."""
    check_interval_min = await _get_check_interval(redis_client)
    tick_sec = max(60, check_interval_min * 60)  # длительность одного тика

    ticks_raw = await redis_client.get(_REDIS_OFFLINE_TICKS)
    ticks = int(ticks_raw) if ticks_raw else 0
    elapsed_ticks = ticks * tick_sec

    last_ok_raw = await redis_client.get(_REDIS_LAST_OK)
    if last_ok_raw:
        elapsed_clock = max(0, int(time.time()) - int(last_ok_raw))
    else:
        elapsed_clock = 0

    return max(elapsed_ticks, elapsed_clock)


def _format_days(days: int) -> str:
    """Русское склонение: 1 день / 2 дня / 5 дней."""
    if days <= 0:
        return "менее суток"
    if 11 <= days % 100 <= 19:
        return f"{days} дней"
    r = days % 10
    if r == 1:
        return f"{days} день"
    elif 2 <= r <= 4:
        return f"{days} дня"
    return f"{days} дней"


async def _cache_license_banner(license_server: str, banners_dir) -> None:
    """Скачать и закешировать баннер лиц-сервера (не чаще раза в сутки)."""
    path = Path(banners_dir) / _LICENSE_BANNER_NAME
    if path.exists():
        age = time.time() - path.stat().st_mtime
        if age < 86400:
            return
    try:
        url = f"{license_server.rstrip('/')}/api/v1/license/banner"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    data = await resp.read()
                    path.write_bytes(data)
                    logger.debug("[license] License banner cached")
    except Exception:
        pass


def _make_offline_text(remaining_days: float) -> str:
    """Формирование текста уведомления о потере связи."""
    days_text = _format_days(math.ceil(remaining_days))
    return (
        f"🔴 <b>Связь с сервером лицензии потеряна!</b>\n\n"
        f"Если связь не восстановится через <b>{days_text}</b>, "
        f"бот будет отключен.\n\n"
        f"Обратитесь к администратору если проблема сохраняется."
    )


# ── Тексты уведомлений по сценариям ────────────────────────────────────────────

_PROBLEM_TEXTS = {
    "suspended": (
        "🔴 <b>Лицензия приостановлена!</b>\n\n"
        "Бот работает в ограниченном режиме "
        "в связи с отсутствием активной лицензии.\n\n"
        "Обратитесь к администратору для решения проблемы."
    ),
    "blacklisted": (
        "🔴 <b>Лицензия отозвана!</b>\n\n"
        "Бот работает в ограниченном режиме "
        "в связи с отсутствием активной лицензии.\n\n"
        "Обратитесь к администратору для решения проблемы."
    ),
}

_RECOVERY_TEXTS = {
    "suspended": (
        "🟢 <b>Лицензия возобновлена!</b>\n\n"
        "Бот работает в штатном режиме."
    ),
    "blacklisted": (
        "🟢 <b>Лицензия восстановлена!</b>\n\n"
        "Бот работает в штатном режиме."
    ),
    "invalid": (
        "🟢 <b>Лицензия восстановлена!</b>\n\n"
        "Бот работает в штатном режиме."
    ),
    "offline": (
        "🟢 <b>Связь с сервером лицензии восстановлена!</b>\n\n"
        "<b>Remnasale</b> продолжит работать в штатном режиме."
    ),
}

_RENEWED_TEXT = (
    "🟢 <b>Ваша лицензия была продлена!</b>\n\n"
    "Бот работает в штатном режиме."
)


def _format_minutes(minutes: int) -> str:
    """Русское склонение для минут."""
    if minutes <= 0:
        return "менее минуты"
    if 11 <= minutes % 100 <= 19:
        return f"{minutes} минут"
    r = minutes % 10
    if r == 1:
        return f"{minutes} минуту"
    elif 2 <= r <= 4:
        return f"{minutes} минуты"
    return f"{minutes} минут"


def _make_startup_invalid_text(notify_type: str, notified_at_sec: int | None = None) -> str:
    """Текст уведомления при старте бота если лицензия невалидна."""
    if notify_type == "suspended":
        title = "Лицензия приостановлена!"
    elif notify_type == "blacklisted":
        title = "Лицензия отозвана!"
    else:
        title = "Лицензия не действительна!"
    return (
        f"🔴 <b>{title}</b>\n\n"
        f"Бот работает в ограниченном режиме "
        f"в связи с отсутствием активной лицензии.\n\n"
        f"Обратитесь к администратору для решения проблемы."
    )


async def _send_notification(bot: Bot, config: AppConfig, notification_service: NotificationService,
                             text: str, support_url: str | None = None,
                             is_recovery: bool = False) -> None:
    from src.core.enums import UserRole
    devs = await notification_service.user_service.get_by_role(role=UserRole.DEV)

    if is_recovery:
        buttons = [
            [InlineKeyboardButton(text="✉️ Написать администратору", callback_data="license_reply_admin")],
            [InlineKeyboardButton(text="✅ Закрыть", callback_data="license_warning_close", style="success")],
        ]
    else:
        buttons = []
        if support_url:
            buttons.append([InlineKeyboardButton(text="🆘 Помощь", url=f"https://t.me/{support_url}")])
        buttons.append([InlineKeyboardButton(text="❌ Закрыть", callback_data="license_warning_close", style="danger")])
    keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)

    # Баннер лиц-сервера (если скачан), иначе фоллбэк на клиентский
    license_banner = Path(config.banners_dir) / _LICENSE_BANNER_NAME
    if license_banner.exists():
        banner_result = (license_banner, None)
    else:
        from src.bot.widgets.banner import get_banner
        banner_result = get_banner(config.banners_dir)

    for dev in devs:
        try:
            if banner_result:
                banner_path, _ = banner_result
                await bot.send_photo(
                    chat_id=dev.telegram_id,
                    photo=FSInputFile(banner_path),
                    caption=text,
                    reply_markup=keyboard,
                )
            else:
                await bot.send_message(
                    chat_id=dev.telegram_id,
                    text=text,
                    reply_markup=keyboard,
                )
        except Exception:
            pass


@broker.task(schedule=[{"cron": "* * * * *"}])  # Каждую минуту (фактический интервал из настроек сервера)
@inject
async def license_check_task(
    bot: FromDishka[Bot],
    config: FromDishka[AppConfig],
    notification_service: FromDishka[NotificationService],
    redis: FromDishka[RedisRepository],
) -> None:
    """Проверяет действительность лицензии через лицензионный сервер."""
    license_key = config.build.license_key.get_secret_value()
    if not license_key:
        return

    # Проверяем, прошёл ли интервал с момента последней фактической проверки
    check_interval_min = await _get_check_interval(redis.client)
    last_check_raw = await redis.client.get(_REDIS_LAST_CHECK)
    if last_check_raw:
        last_check_ts = int(last_check_raw)
        elapsed_since_check = int(time.time()) - last_check_ts
        if elapsed_since_check < check_interval_min * 60:
            return  # Интервал ещё не прошёл — пропускаем

    # Фиксируем время начала этой проверки
    await redis.client.set(_REDIS_LAST_CHECK, str(int(time.time())))

    license_server = await get_license_host(redis.client, config)
    if not license_server:
        return

    server_domain = config.domain.get_secret_value()

    # ── Попытка связаться с лиц-сервером ────────────────────────────
    try:
        url = f"{license_server.rstrip('/')}/api/v1/license/verify"
        payload = {"license_key": license_key, "server_domain": server_domain}

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                data = await resp.json()

                # Сохраняем настройки с сервера
                ci = data.get("check_interval", _DEFAULT_CHECK_INTERVAL_MIN)
                gd = data.get("offline_grace_days", _DEFAULT_GRACE_DAYS)
                await _save_settings(redis.client, int(ci), int(gd))

                # Кешируем support_url
                _sup = data.get("support_url", "")
                if _sup:
                    await redis.client.set(_REDIS_SUPPORT_URL, _sup)
                else:
                    await redis.client.delete(_REDIS_SUPPORT_URL)

                _support_url = _sup or None

                # Кешируем настройки донатов
                import json as _json_mod
                _donate_data = data.get("donate")
                if _donate_data is not None:
                    await redis.client.set("license:donate", _json_mod.dumps(_donate_data))

                # Кешируем баннер лиц-сервера
                await _cache_license_banner(license_server, config.banners_dir)

                # Обновить license_host если изменился
                new_host = data.get("license_host")
                if new_host and new_host != license_server:
                    await redis.client.set(LICENSE_HOST_REDIS_KEY, new_host)
                    logger.info(f"[license] License host updated: {license_server} → {new_host}")

                if data.get("valid"):
                    # ── Проверяем, было ли ранее уведомление — отправляем recovery ──
                    _raw_notified = await redis.client.get(_REDIS_NOTIFIED)
                    was_notified = _raw_notified.decode() if isinstance(_raw_notified, bytes) else _raw_notified
                    await _mark_ok(redis.client)
                    logger.info("[license] License valid")

                    if was_notified:
                        recovery = _RECOVERY_TEXTS.get(was_notified)
                        if recovery:
                            await _send_notification(bot, config, notification_service, recovery, _support_url, is_recovery=True)
                            logger.info(f"[license] Recovery notification sent (was: {was_notified})")

                    # ── Предупреждение об истечении лицензии ──────────
                    expires_str = data.get("expires_at")
                    if expires_str:
                        try:
                            expires_dt = datetime.fromisoformat(expires_str)
                            if expires_dt.tzinfo is None:
                                expires_dt = expires_dt.replace(tzinfo=timezone.utc)
                            remaining = expires_dt - datetime.now(timezone.utc)
                            remaining_sec = remaining.total_seconds()

                            last_warned_raw = await redis.client.get(_REDIS_EXPIRY_WARNED)
                            last_warned = last_warned_raw.decode() if isinstance(last_warned_raw, bytes) else last_warned_raw

                            if 0 < remaining_sec < _EXPIRY_WARN_DAYS * 86400:
                                today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
                                if last_warned != today_str:
                                    days_text = _format_days(remaining.days)
                                    text = (
                                        f"⚠️ <b>Ваша лицензия заканчивается "
                                        f"через {days_text}!</b>\n\n"
                                        f"Необходимо продлить подписку."
                                    )
                                    await _send_notification(bot, config, notification_service, text, _support_url)
                                    await redis.client.set(_REDIS_EXPIRY_WARNED, today_str)
                                    logger.warning(f"[license] License expires in {days_text}")
                            elif last_warned:
                                # Лицензия продлена (было предупреждение, а теперь > 3 дней)
                                await _send_notification(bot, config, notification_service, _RENEWED_TEXT, _support_url)
                                await redis.client.delete(_REDIS_EXPIRY_WARNED)
                                logger.info("[license] License renewed notification sent")
                        except Exception as exc:
                            logger.warning(f"[license] Failed to parse expires_at: {exc}")

                    return

                # ── Лицензия невалидна (явный отказ) ─────────────────
                reason = data.get("reason", "unknown")
                logger.error(f"[license] License INVALID: {reason}")

                already_notified = await redis.client.get(_REDIS_NOTIFIED)
                if already_notified:
                    return

                # Определяем категорию уведомления
                if reason == "suspended":
                    notify_type = "suspended"
                elif reason == "blacklisted":
                    notify_type = "blacklisted"
                else:
                    notify_type = "invalid"

                text = _PROBLEM_TEXTS.get(notify_type)
                if not text:
                    reason_text = {
                        "not_found": "Лицензионный ключ не найден",
                        "expired": "Срок лицензии истёк",
                        "domain_mismatch": "Домен сервера не совпадает",
                        "ip_mismatch": "Лицензионный ключ зафиксирован на другом сервере",
                    }.get(reason, reason)
                    text = (
                        f"🔴 <b>Лицензия не действительна!</b>\n\n"
                        f"Причина: {reason_text}\n"
                        f"Бот работает в ограниченном режиме "
                        f"в связи с отсутствием активной лицензии.\n\n"
                        f"Обратитесь к администратору для решения проблемы."
                    )

                await _send_notification(bot, config, notification_service, text, _support_url)
                await redis.client.set(_REDIS_NOTIFIED, notify_type)
                await redis.client.set(_REDIS_RESTRICTED_MODE, "1")
                if not await redis.client.get(_REDIS_NOTIFIED_AT):
                    await redis.client.set(_REDIS_NOTIFIED_AT, str(int(time.time())))
                logger.warning(f"[license] License invalid ({notify_type}: {reason}). Restricted mode activated.")
                return

    except Exception as e:
        logger.warning(f"[license] Failed to check license: {e}")

    # ── Сервер не ответил — трекинг оффлайн-времени ─────────────────

    # Инкрементировать счётчик тиков (защита от перевода часов)
    ticks_raw = await redis.client.get(_REDIS_OFFLINE_TICKS)
    ticks = (int(ticks_raw) + 1) if ticks_raw else 1
    await redis.client.set(_REDIS_OFFLINE_TICKS, str(ticks))

    # Фиксируем момент первого сбоя (offline_since) — именно от него считаем таймаут
    offline_since_raw = await redis.client.get(_REDIS_OFFLINE_SINCE)
    if not offline_since_raw:
        now_ts = int(time.time())
        await redis.client.set(_REDIS_OFFLINE_SINCE, str(now_ts))
        offline_since_ts = now_ts
    else:
        offline_since_ts = int(offline_since_raw.decode() if isinstance(offline_since_raw, bytes) else offline_since_raw)

    # Инициализировать last_ok если ещё не было ни одного успеха
    last_ok_raw = await redis.client.get(_REDIS_LAST_OK)
    if not last_ok_raw:
        await redis.client.set(_REDIS_LAST_OK, str(int(time.time())))

    # Ждём ровно один check_interval после первого сбоя, затем шлём уведомление
    check_interval_min = await _get_check_interval(redis.client)
    threshold_sec = check_interval_min * 60
    elapsed_since_offline = int(time.time()) - offline_since_ts

    if elapsed_since_offline < threshold_sec:
        logger.debug(f"[license] Server unreachable {elapsed_since_offline}s < threshold {threshold_sec}s — skip")
        return

    # Уже уведомляли?
    if await redis.client.get(_REDIS_NOTIFIED):
        return

    # Вычислить оставшееся время и уведомить
    grace_days = await _get_grace_days(redis.client)
    remaining_sec = max(0, grace_days * 86400 - elapsed_since_offline)
    remaining_days = remaining_sec / 86400

    text = _make_offline_text(remaining_days)
    _offline_support_url = await _get_support_url(redis.client)
    await _send_notification(bot, config, notification_service, text, _offline_support_url)
    await redis.client.set(_REDIS_NOTIFIED, "offline")
    if not await redis.client.get(_REDIS_NOTIFIED_AT):
        await redis.client.set(_REDIS_NOTIFIED_AT, str(int(time.time())))
    logger.warning(
        f"[license] Server unreachable for {elapsed_since_offline // 60}m "
        f"(threshold {check_interval_min}m). Remaining: {_format_days(math.ceil(remaining_days))}"
    )
