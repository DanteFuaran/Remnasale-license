"""Задачи синхронизации данных между ботом и панелью Remnawave."""
import asyncio

from aiogram import Bot
from dishka.integrations.taskiq import FromDishka, inject
from loguru import logger
from remnapy import RemnawaveSDK
from remnapy.models import UpdateUserRequestDto

from src.core.utils.message_payload import MessagePayload
from src.core.utils.time import datetime_now
from src.infrastructure.taskiq.broker import broker
from src.services.notification import NotificationService
from src.services.plan import PlanService
from src.services.remnawave import RemnawaveService
from src.services.subscription import SubscriptionService
from src.services.user import UserService


@broker.task
@inject
async def sync_panel_to_bot_task(
    admin_telegram_id: int,
    remnawave: FromDishka[RemnawaveSDK],
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
    plan_service: FromDishka[PlanService],
    remnawave_service: FromDishka[RemnawaveService],
) -> dict | None:
    """
    Синхронизация данных из панели Remnawave в бота.
    Создает новых пользователей в боте если их нет.
    Обновляет данные подписок в боте данными из панели.
    
    Возвращает dict с результатами синхронизации.
    """
    logger.info(f"Starting panel to bot sync, initiated by admin {admin_telegram_id}")
    
    try:
        # Получаем всех пользователей из панели с пагинацией
        all_panel_users = []
        start = 0
        size = 50
        
        # Сначала получаем общую статистику чтобы узнать количество пользователей
        stats = await remnawave.system.get_stats()
        total_users = stats.users.total_users
        
        logger.info(f"Total users in panel: {total_users}")
        
        # Получаем всех пользователей с пагинацией
        for start in range(0, total_users, size):
            response = await remnawave.users.get_all_users(start=start, size=size)
            if not response.users:
                break
            
            all_panel_users.extend(response.users)
            
            if len(response.users) < size:
                break
        
        logger.info(f"Retrieved {len(all_panel_users)} users from panel")
        
        synced_count = 0
        created_count = 0
        errors_count = 0
        skipped_count = 0
        
        for panel_user in all_panel_users:
            try:
                # Проверяем, есть ли telegram_id у пользователя панели
                if not panel_user.telegram_id:
                    skipped_count += 1
                    logger.debug(f"Skipping panel user {panel_user.uuid} - no telegram_id")
                    continue
                    
                telegram_id = int(panel_user.telegram_id)
                
                # Проверяем, есть ли пользователь в боте
                bot_user = await user_service.get(telegram_id)
                
                if bot_user:
                    # Обновляем имя и username пользователя из панели
                    # description содержит "name: Имя\nusername: @username"
                    new_name = str(panel_user.telegram_id)
                    new_username = None
                    if panel_user.description:
                        # Извлекаем имя и username из description
                        for line in panel_user.description.split('\n'):
                            if line.startswith('name:'):
                                extracted_name = line.replace('name:', '').strip()
                                if extracted_name:
                                    new_name = extracted_name
                            elif line.startswith('username:'):
                                extracted_username = line.replace('username:', '').strip()
                                if extracted_username:
                                    new_username = extracted_username
                    
                    needs_update = False
                    if bot_user.name != new_name:
                        bot_user.name = new_name
                        needs_update = True
                    if bot_user.username != new_username:
                        bot_user.username = new_username
                        needs_update = True
                    
                    if needs_update:
                        await user_service.update(bot_user)
                        logger.debug(f"Updated user {telegram_id}: name={new_name}, username={new_username}")
                    
                    # Пользователь существует - синхронизируем
                    await remnawave_service.sync_user(panel_user, creating=False)
                    synced_count += 1
                    logger.debug(f"Synced user {telegram_id}")
                else:
                    # Создаём нового пользователя и синхронизируем
                    await remnawave_service.sync_user(panel_user, creating=True)
                    created_count += 1
                    logger.debug(f"Created user {telegram_id}")
                    
            except Exception as e:
                if "Validation failed" in str(e) or "validation" in str(e).lower():
                    logger.debug(f"Skipping panel user {panel_user.uuid} - validation error")
                else:
                    logger.error(f"Error processing panel user {panel_user.uuid}: {e}")
                    logger.exception(e)
                    errors_count += 1
        
        logger.info(
            f"Panel to bot sync completed: total={len(all_panel_users)}, "
            f"created={created_count}, synced={synced_count}, "
            f"skipped={skipped_count}, errors={errors_count}"
        )
        
        return {
            "total_panel_users": len(all_panel_users),
            "created": created_count,
            "synced": synced_count,
            "skipped": skipped_count,
            "errors": errors_count,
        }
        
    except Exception as e:
        logger.exception(f"Panel to bot sync failed: {e}")
        raise


@broker.task
@inject
async def sync_plan_to_remnawave_task(
    plan_id: int,
    admin_telegram_id: int,
    progress_message_id: int,
    subscription_service: FromDishka[SubscriptionService],
    user_service: FromDishka[UserService],
    remnawave_service: FromDishka[RemnawaveService],
    plan_service: FromDishka[PlanService],
    bot: FromDishka[Bot],
    notification_service: FromDishka[NotificationService],
) -> dict:
    """Массовая синхронизация всех активных подписок плана в Remnawave.

    Запускается в фоне после сохранения плана, чтобы не блокировать
    основной пул соединений во время шторма входящих webhook-событий.
    """
    logger.info(f"[plan_sync] Starting sync for plan_id={plan_id}, initiated by admin={admin_telegram_id}")

    try:
        plan = await plan_service.get(plan_id)
        if not plan:
            logger.warning(f"[plan_sync] Plan {plan_id} not found, aborting")
            return {"synced": 0, "failed": 0, "skipped": 0}

        from src.core.enums import SubscriptionStatus

        # Загружаем ТОЛЬКО текущие подписки пользователей для данного плана.
        # Это исключает орфанные подписки (у пользователя сменился план,
        # но старая подписка осталась в БД) — их обновлять в Remnawave нельзя.
        all_subscriptions = await subscription_service.get_current_by_plan_id(plan_id)
        synced = failed = 0

        for subscription in all_subscriptions:

            # Для всех подписок (кроме ACTIVE) — обновляем только тег в БД и минимальный запрос в Remnawave
            if not subscription.is_active:
                try:
                    subscription.tag = plan.tag
                    subscription.plan.tag = plan.tag
                    await subscription_service.update(subscription)
                    if subscription.user_remna_id:
                        await remnawave_service.remnawave.users.update_user(
                            UpdateUserRequestDto(
                                uuid=subscription.user_remna_id,
                                tag=plan.tag,
                            )
                        )
                except Exception as e:
                    logger.warning(f"[plan_sync] Failed to update tag for subscription {subscription.id}: {e}")
                continue

            # ACTIVE — полный синк: обновляем все поля в БД и синхронизируем с Remnawave
            try:
                target_user = subscription.user
                if not target_user:
                    target_user = await user_service.get(telegram_id=subscription.user_telegram_id)
                if not target_user:
                    logger.warning(f"[plan_sync] User not found for subscription {subscription.id}, skipping")
                    failed += 1
                    continue

                # Применяем snapshot плана
                subscription.plan.name = plan.name
                subscription.plan.type = plan.type
                subscription.plan.internal_squads = list(plan.internal_squads) if plan.internal_squads else []
                if plan.external_squad:
                    subscription.plan.external_squad = list(plan.external_squad)
                subscription.plan.traffic_limit = plan.traffic_limit
                subscription.plan.device_limit = plan.device_limit
                subscription.plan.tag = plan.tag
                subscription.plan.traffic_limit_strategy = plan.traffic_limit_strategy

                subscription.internal_squads = list(plan.internal_squads) if plan.internal_squads else []
                if plan.external_squad:
                    subscription.external_squad = list(plan.external_squad)
                subscription.traffic_limit = plan.traffic_limit
                _extra = subscription.extra_devices or 0
                _old_base = subscription.plan.device_limit if subscription.plan else plan.device_limit
                _bonus = max(0, (subscription.device_limit or 0) - _old_base - _extra)
                subscription.device_limit = plan.device_limit + _extra + _bonus
                subscription.tag = plan.tag
                subscription.traffic_limit_strategy = plan.traffic_limit_strategy

                await subscription_service.update(subscription)

                if subscription.user_remna_id:
                    await remnawave_service.updated_user(
                        user=target_user,
                        uuid=subscription.user_remna_id,
                        subscription=subscription,
                        reset_traffic=False,
                    )
                    synced += 1
                else:
                    failed += 1

                # Пауза между пользователями чтобы не заваливать Remnawave
                await asyncio.sleep(0.05)

            except Exception as e:
                failed += 1
                logger.error(f"[plan_sync] Failed to sync subscription {subscription.id}: {e}", exc_info=True)

        logger.info(f"[plan_sync] Completed: plan_id={plan_id}, synced={synced}, failed={failed}")
        return {"synced": synced, "failed": failed}

    finally:
        # Удаляем уведомление о прогрессе и отправляем уведомление о завершении
        try:
            if progress_message_id:
                await bot.delete_message(chat_id=admin_telegram_id, message_id=progress_message_id)
        except Exception as e:
            logger.debug(f"[plan_sync] Failed to delete progress message: {e}")

        try:
            admin_user = await user_service.get(telegram_id=admin_telegram_id)
            if admin_user:
                await notification_service.notify_user(
                    user=admin_user,
                    payload=MessagePayload(i18n_key="ntf-plan-sync-completed", auto_delete_after=5),
                )
        except Exception as e:
            logger.warning(f"[plan_sync] Failed to send completion notification: {e}")
