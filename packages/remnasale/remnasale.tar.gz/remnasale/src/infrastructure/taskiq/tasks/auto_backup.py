"""Задача автоматического бекапа БД."""
import asyncio
import gzip
import os
import subprocess
from datetime import datetime, timedelta, timezone

from aiogram import Bot
from aiogram.types import FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from dishka.integrations.taskiq import FromDishka, inject
from loguru import logger

from src.infrastructure.taskiq.broker import broker
from src.services.notification import NotificationService
from src.services.settings import SettingsService


def _should_run(frequency: str, last_backup_at: str | None) -> bool:
    """Определяет, нужно ли выполнить бекап прямо сейчас."""
    now = datetime.now(tz=timezone.utc)

    if last_backup_at is None:
        return True

    try:
        last = datetime.fromisoformat(last_backup_at)
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return True

    thresholds = {
        "hourly": timedelta(minutes=55),
        "daily": timedelta(hours=23),
        "weekly": timedelta(days=6, hours=23),
        "monthly": timedelta(days=28),
    }
    threshold = thresholds.get(frequency, timedelta(hours=23))
    return (now - last) >= threshold


def _do_backup(filepath: str) -> bool:
    """Выполняет pg_dump и сохраняет в gzip-файл. Возвращает True при успехе."""
    db_password = os.getenv("DATABASE_PASSWORD", "remnasale")
    db_user = os.getenv("DATABASE_USER", "remnasale")
    db_name = os.getenv("DATABASE_NAME", "remnasale")
    db_host = os.getenv("DATABASE_HOST", "remnasale-db")
    db_port = os.getenv("DATABASE_PORT", "5432")

    cmd = [
        "pg_dump",
        "-h", db_host,
        "-p", db_port,
        "-U", db_user,
        "--clean",
        "--if-exists",
        "--no-owner",
        "--no-acl",
        db_name,
    ]
    env = os.environ.copy()
    env["PGPASSWORD"] = db_password

    result = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if result.returncode != 0 or not result.stdout:
        logger.error(f"[auto_backup] pg_dump failed: {result.stderr[:200]}")
        return False

    with gzip.open(filepath, "wt", compresslevel=9) as f:
        f.write(result.stdout)

    return os.path.getsize(filepath) > 0


def _send_to_telegram(
    bot_token: str, chat_id: str, filepath: str, manual: bool = False, recipient: str = "",
) -> bool:
    """Отправляет файл бекапа в Telegram. Возвращает True при успехе."""
    import urllib.request
    import urllib.parse

    size = os.path.getsize(filepath)
    if size < 1024 * 1024:
        size_str = f"{size // 1024}K"
    else:
        size_str = f"{size / 1024 / 1024:.1f}M"

    msk = timezone(timedelta(hours=3))
    date_str = datetime.now(tz=msk).strftime("%d.%m.%Y %H:%M МСК")
    method = "вручную" if manual else "автоматически"

    recipient_line = f"👤 Получатель: <code>{recipient}</code>\n" if recipient else ""
    caption = (
        f"📦 Приложение: Remnasale\n"
        f"{recipient_line}"
        f"📁 База данных\n"
        f"📏 Размер: {size_str}\n"
        f"📅 {date_str}\n\n"
        f"✅ Бекап создан {method}"
    )

    url = f"https://api.telegram.org/bot{bot_token}/sendDocument"

    import urllib.request as req
    import io

    boundary = "----TaskiqBackupBoundary"
    filename = os.path.basename(filepath)

    with open(filepath, "rb") as f:
        file_data = f.read()

    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="chat_id"\r\n\r\n'
        f"{chat_id}\r\n"
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="caption"\r\n\r\n'
        f"{caption}\r\n"
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="document"; filename="{filename}"\r\n'
        f"Content-Type: application/octet-stream\r\n\r\n"
    ).encode() + file_data + f"\r\n--{boundary}--\r\n".encode()

    request = req.Request(
        url,
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST",
    )

    try:
        with req.urlopen(request, timeout=60) as resp:
            return resp.status == 200
    except Exception as e:
        logger.error(f"[auto_backup] Telegram send failed: {e}")
        return False


@broker.task(schedule=[{"cron": "0 * * * *"}])  # Каждый час в :00
@inject
async def auto_backup_task(
    settings_service: FromDishka[SettingsService],
    notification_service: FromDishka[NotificationService],
    bot: FromDishka[Bot],
) -> None:
    """
    Автоматически создаёт бекап БД и отправляет в Telegram.
    Запускается каждый час, проверяет нужно ли делать бекап по настройкам частоты.
    """
    try:
        backup_settings = await settings_service.get_auto_backup_settings()

        if not backup_settings.enabled:
            return

        if not backup_settings.bot_token or not backup_settings.chat_id:
            logger.warning("[auto_backup] Bot token or chat_id not configured, skipping")
            return

        if not _should_run(backup_settings.frequency, backup_settings.last_backup_at):
            return

        logger.info(f"[auto_backup] Starting backup (frequency={backup_settings.frequency})")

        backup_dir = "/opt/remnasale/backups"
        os.makedirs(backup_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%d-%m-%y_%H-%M")
        filepath = os.path.join(backup_dir, f"Remnasale_{timestamp}.sql.gz")

        loop = asyncio.get_event_loop()
        success = await loop.run_in_executor(None, _do_backup, filepath)

        if not success:
            if os.path.exists(filepath):
                os.remove(filepath)
            logger.error("[auto_backup] Backup creation failed")
            return

        # Отправляем в Telegram в отдельном потоке
        sent = await loop.run_in_executor(
            None, _send_to_telegram, backup_settings.bot_token, backup_settings.chat_id, filepath
        )

        if sent:
            logger.info(f"[auto_backup] Backup sent successfully: {filepath}")
            now_iso = datetime.now(tz=timezone.utc).isoformat()
            await settings_service.set_auto_backup_last_run(now_iso)

            # В тихом режиме не отправляем уведомления разработчикам через основной бот
            if not backup_settings.silent_mode:
                # Отправляем бекап-файл разработчикам через основной бот
                from src.core.enums import UserRole
                devs = await notification_service.user_service.get_by_role(role=UserRole.DEV)
                size = os.path.getsize(filepath)
                size_str = f"{size // 1024}K" if size < 1024 * 1024 else f"{size / 1024 / 1024:.1f}M"
                msk = timezone(timedelta(hours=3))
                date_str = datetime.now(tz=msk).strftime("%d.%m.%Y %H:%M МСК")
                dev_caption = (
                    f"🤖 Система: Создание бэкапа!\n\n"
                    f"📦 Приложение: Remnasale\n"
                    f"👤 Получатель: <code>{backup_settings.chat_id}</code>\n"
                    f"📁 База данных\n"
                    f"📏 Размер: {size_str}\n"
                    f"📅 {date_str}\n\n"
                    f"✅ Бекап создан автоматически"
                )
                for dev in devs:
                    try:
                        close_btn = InlineKeyboardButton(
                            text="✅ Закрыть",
                            callback_data="Notification:CLOSE",
                        )
                        kb = InlineKeyboardBuilder()
                        kb.row(close_btn)
                        await bot.send_document(
                            chat_id=dev.telegram_id,
                            document=FSInputFile(filepath),
                            caption=dev_caption,
                            reply_markup=kb.as_markup(),
                        )
                    except Exception as e:
                        logger.warning(f"[auto_backup] Failed to send backup to dev {dev.telegram_id}: {e}")

            # Удаляем бекапы старше 7 дней
            cutoff = datetime.now() - timedelta(days=7)
            for name in os.listdir(backup_dir):
                if name.startswith("Remnasale_") and name.endswith(".sql.gz"):
                    fpath = os.path.join(backup_dir, name)
                    if datetime.fromtimestamp(os.path.getmtime(fpath)) < cutoff:
                        os.remove(fpath)
        else:
            logger.error("[auto_backup] Failed to send backup to Telegram")

    except Exception as e:
        logger.exception(f"[auto_backup] Unexpected error: {e}")
