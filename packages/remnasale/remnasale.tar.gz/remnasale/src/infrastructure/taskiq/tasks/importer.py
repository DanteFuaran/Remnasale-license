import traceback
from typing import Any
from uuid import UUID

from dishka.integrations.taskiq import FromDishka, inject
from loguru import logger
from remnapy import RemnawaveSDK
from remnapy.exceptions import BadRequestError
from remnapy.models import CreateUserRequestDto, UserResponseDto

from src.core.storage.keys import SyncRunningKey
from src.core.utils.message_payload import MessagePayload
from src.bot.keyboards import get_user_keyboard
from src.infrastructure.redis.repository import RedisRepository
from src.infrastructure.taskiq.broker import broker
from src.services.notification import NotificationService
from src.services.plan import PlanService
from src.services.remnawave import RemnawaveService
from src.services.subscription import SubscriptionService
from src.services.user import UserService


@broker.task(retry_on_error=False)
@inject
async def import_exported_users_task(
    imported_users: list[dict],
    active_internal_squads: list[UUID],
    remnawave: FromDishka[RemnawaveSDK],
) -> tuple[int, int]:
    logger.info(f"Starting import of '{len(imported_users)}' users")

    success_count = 0
    failed_count = 0

    for user in imported_users:
        try:
            username = user["username"]
            created_user = CreateUserRequestDto.model_validate(user)
            created_user.active_internal_squads = active_internal_squads
            await remnawave.users.create_user(created_user)
            success_count += 1
        except BadRequestError as error:
            logger.warning(f"User '{username}' already exists, skipping. Error: {error}")
            failed_count += 1

        except Exception as exception:
            logger.exception(f"Failed to create user '{username}' exception: {exception}")
            failed_count += 1

    logger.info(f"Import completed: '{success_count}' successful, '{failed_count}' failed")
    return success_count, failed_count


@broker.task(retry_on_error=False)
@inject
async def sync_all_users_from_panel_task(
    redis_repository: FromDishka[RedisRepository],
    remnawave: FromDishka[RemnawaveSDK],
    remnawave_service: FromDishka[RemnawaveService],
    user_service: FromDishka[UserService],
    subscription_service: FromDishka[SubscriptionService],
) -> dict[str, Any]:
    key = SyncRunningKey()
    all_remna_users: list[UserResponseDto] = []
    start = 0
    size = 50

    stats = await remnawave.system.get_stats()
    total_users = stats.users.total_users

    for start in range(0, total_users, size):
        response = await remnawave.users.get_all_users(start=start, size=size)
        if not response.users:
            break

        all_remna_users.extend(response.users)
        start += len(response.users)

        if len(response.users) < size:
            break

    bot_users = await user_service.get_all()
    bot_users_map = {user.telegram_id: user for user in bot_users}

    logger.info(f"Total users in panel: '{len(all_remna_users)}'")
    logger.info(f"Total users in bot: '{len(bot_users)}'")

    added_users = 0
    added_subscription = 0
    updated = 0
    errors = 0
    missing_telegram = 0

    try:
        for remna_user in all_remna_users:
            try:
                if not remna_user.telegram_id:
                    missing_telegram += 1
                    continue

                user = bot_users_map.get(remna_user.telegram_id)

                if not user:
                    await remnawave_service.sync_user(remna_user)
                    added_users += 1
                else:
                    current_subscription = await subscription_service.get_current(user.telegram_id)
                    if not current_subscription:
                        await remnawave_service.sync_user(remna_user)
                        added_subscription += 1
                    else:
                        await remnawave_service.sync_user(remna_user)
                        updated += 1

            except Exception as exception:
                if "Validation failed" in str(exception) or "validation" in str(exception).lower():
                    logger.debug(
                        f"⊘ User skipped (validation error): RemnaUser '{remna_user.telegram_id}'"
                    )
                else:
                    logger.exception(
                        f"Error syncing RemnaUser '{remna_user.telegram_id}' exception: {exception}"
                    )
                    errors += 1

        result = {
            "total_panel_users": len(all_remna_users),
            "total_bot_users": len(bot_users),
            "added_users": added_users,
            "added_subscription": added_subscription,
            "updated": updated,
            "errors": errors,
            "missing_telegram": missing_telegram,
        }

        logger.info(f"Sync users summary: '{result}'")
        return result
    finally:
        await redis_repository.delete(key)


@broker.task(retry_on_error=False)
@inject
async def sync_bot_to_panel_task(
    cleanup_before_sync: bool = False,
    remnawave: FromDishka[RemnawaveSDK] = None,  # type: ignore[assignment]
    remnawave_service: FromDishka[RemnawaveService] = None,  # type: ignore[assignment]
    user_service: FromDishka[UserService] = None,  # type: ignore[assignment]
    subscription_service: FromDishka[SubscriptionService] = None,  # type: ignore[assignment]
    plan_service: FromDishka[PlanService] = None,  # type: ignore[assignment]
    notification_service: FromDishka[NotificationService] = None,  # type: ignore[assignment]
) -> dict[str, Any]:
    """
    Синхронизирует данные пользователей ИЗ бота В панель Remnawave.
    - Использует первый доступный squad из панели для всех планов
    - Создаёт новых пользователей в панели если их нет
    - Обновляет существующих с приоритетом данных из бота
    - Создаёт/обновляет подписки пользователей в панели
    """
    logger.info("Starting sync from bot to Remnawave panel")
    
    # ========== ШАГ 1: Получение доступных squad'ов из панели ==========
    logger.info("Step 1: Getting available squads from Remnawave panel")
    
    # Получаем все squad из панели
    try:
        panel_squads_response = await remnawave.internal_squads.get_internal_squads()
        if panel_squads_response and panel_squads_response.internal_squads:
            first_squad = panel_squads_response.internal_squads[0]
            logger.info(
                f"Found {len(panel_squads_response.internal_squads)} internal squads in panel. "
                f"Will use first squad: '{first_squad.name}' ({first_squad.uuid})"
            )
            
            # Собираем множество валидных squad UUID для валидации
            valid_squad_uuids = {squad.uuid for squad in panel_squads_response.internal_squads}
            
            # ========== ШАГ 1.5: Синхронизация internal_squads планов ==========
            # При восстановлении бэкапа пропускаем: планы уже содержат корректные
            # назначения сквадов из дампа, перезаписывать их не нужно
            if not cleanup_before_sync:
                logger.info("Step 1.5: Syncing plans squads with panel")
                # Получаем external squads для валидации
                valid_external_squad_uuids: set | None = None
                try:
                    ext_squads_response = await remnawave.external_squads.get_external_squads()
                    if ext_squads_response and ext_squads_response.external_squads:
                        valid_external_squad_uuids = {s.uuid for s in ext_squads_response.external_squads}
                        logger.info(f"Found {len(valid_external_squad_uuids)} external squads in panel")
                    else:
                        logger.info("No external squads found in panel")
                except Exception as _ext_err:
                    logger.warning(f"Could not fetch external squads: {_ext_err}")
                plans_sync_result = await plan_service.sync_plans_squads(
                    valid_squad_uuids=valid_squad_uuids,
                    default_squad_uuid=first_squad.uuid,
                    valid_external_squad_uuids=valid_external_squad_uuids,
                )
                logger.info(
                    f"Plans squads sync completed: {plans_sync_result['updated']} updated, "
                    f"{plans_sync_result['unchanged']} unchanged"
                )
            else:
                logger.info("Step 1.5: Skipping plans squads sync (backup restore mode — trusting backup values)")
        else:
            logger.error("No internal squads found in panel - cannot sync users")
            return {
                "total_bot_users": 0,
                "created": 0,
                "updated": 0,
                "skipped": 0,
                "errors": 0,
                "error_users": {},
                "skipped_users": [],
            }
    except Exception as e:
        logger.error(f"Failed to get squads from panel: {e}")
        return {
            "total_bot_users": 0,
            "created": 0,
            "updated": 0,
            "skipped": 0,
            "errors": 0,
            "error_users": {},
            "skipped_users": [],
        }
    
    # ========== ШАГ 2: Синхронизация пользователей ==========
    
    # Получаем всех пользователей бота с подписками
    bot_users = await user_service.get_all()
    logger.info(f"Total users in bot: '{len(bot_users)}'")
    
    created = 0
    updated = 0
    errors = 0
    skipped = 0
    deleted_from_bot = 0
    deleted_from_panel = 0
    imported_from_panel = 0
    
    error_users: dict[str, str] = {}  # {user_info: error_reason}
    skipped_users: list[str] = []

    if cleanup_before_sync:
        # ═══════ CLEANUP MODE (after backup restore) ═══════
        # Простая загрузка: все пользователи из бэкапа в том же порядке.
        # 1. Получаем всех пользователей панели в map по telegram_id
        # 2. Итерируем ВСЕХ бот-юзеров (по ID, сохраняя порядок из бэкапа):
        #    — если есть в панели → обновляем данные панели из бота
        #    — если нет в панели → создаём в панели
        # 3. Пользователи панели без записи в боте → импортируем в бот
        # 4. Перезапускаем xray-ноды
        logger.info("Step 2: CLEANUP MODE — syncing panel with bot state after backup restore")

        # ── 2A: Получаем всех пользователей панели ──
        logger.info("Step 2A: Fetching all panel users")
        bot_telegram_ids = {u.telegram_id for u in bot_users}

        try:
            all_panel_users: list[UserResponseDto] = []
            stats = await remnawave.system.get_stats()
            total_panel = stats.users.total_users

            for page_start in range(0, total_panel + 50, 50):
                response = await remnawave.users.get_all_users(start=page_start, size=50)
                if not response.users:
                    break
                all_panel_users.extend(response.users)
                if len(response.users) < 50:
                    break

            panel_users_map: dict[int, UserResponseDto] = {}
            panel_only_users: list[UserResponseDto] = []

            for panel_user in all_panel_users:
                if panel_user.telegram_id:
                    if panel_user.telegram_id in bot_telegram_ids:
                        panel_users_map[panel_user.telegram_id] = panel_user
                    else:
                        panel_only_users.append(panel_user)

            logger.info(
                f"Step 2A complete: {len(panel_users_map)} panel users matched with bot, "
                f"{len(panel_only_users)} panel-only users to import"
            )
        except Exception as e:
            logger.error(f"Failed to fetch panel users: {e}")
            panel_users_map = {}
            panel_only_users = []

        # ── 2B: Синхронизируем ВСЕХ бот-юзеров с панелью (в порядке из бэкапа) ──
        sorted_bot_users = sorted(bot_users, key=lambda u: u.id or 0)
        logger.info(f"Step 2B: Syncing {len(sorted_bot_users)} bot users with panel")

        for user in sorted_bot_users:
            try:
                subscription = await subscription_service.get_current(user.telegram_id)

                if not subscription:
                    skipped += 1
                    logger.debug(
                        f"⊘ User has no subscription, kept in bot: {user.name} "
                        f"(telegram_id: {user.telegram_id})"
                    )
                    continue

                existing_panel_user = panel_users_map.get(user.telegram_id)

                if existing_panel_user:
                    # Проверяем short_uuid: если не совпадает с URL в бэкапе — пересоздаём
                    desired_short_uuid = None
                    if subscription.url:
                        try:
                            desired_short_uuid = subscription.url.rstrip('/').split('/')[-1]
                        except Exception:
                            pass

                    panel_short_uuid = existing_panel_user.short_uuid
                    need_recreate = (
                        desired_short_uuid
                        and panel_short_uuid
                        and desired_short_uuid != panel_short_uuid
                    )

                    if need_recreate:
                        logger.warning(
                            f"⚠ short_uuid mismatch for {user.name} "
                            f"(telegram_id: {user.telegram_id}): "
                            f"backup='{desired_short_uuid}', panel='{panel_short_uuid}'. "
                            f"Recreating to preserve correct subscription URL."
                        )
                        try:
                            await remnawave_service.remnawave.users.delete_user(
                                uuid=existing_panel_user.uuid
                            )
                            new_user = await remnawave_service.create_user(
                                user=user,
                                subscription=subscription,
                                force=False,
                            )
                            if new_user:
                                subscription.user_remna_id = new_user.uuid
                                if new_user.subscription_url:
                                    subscription.url = new_user.subscription_url
                                await subscription_service.update(subscription)
                                created += 1
                                logger.info(
                                    f"✓ User recreated [{created}]: {user.name} "
                                    f"(telegram_id: {user.telegram_id}, "
                                    f"panel_uuid: {new_user.uuid}, short_uuid: {new_user.short_uuid})"
                                )
                            else:
                                error_users[f"{user.name} ({user.telegram_id})"] = "recreate returned None"
                                errors += 1
                        except Exception as e:
                            error_msg = f"{type(e).__name__}: {str(e)}"
                            logger.error(
                                f"✗ Failed to recreate user: {user.name} "
                                f"(telegram_id: {user.telegram_id}). Error: {error_msg}"
                            )
                            error_users[f"{user.name} ({user.telegram_id})"] = error_msg
                            errors += 1
                    else:
                        # short_uuid совпадает — обновляем данные панели из бота
                        result_panel_user = await remnawave_service.updated_user(
                            user=user,
                            uuid=existing_panel_user.uuid,
                            subscription=subscription,
                        )
                        # Обновляем ссылки в БД бота из ответа API (актуальные данные)
                        changed = False
                        if subscription.user_remna_id != result_panel_user.uuid:
                            subscription.user_remna_id = result_panel_user.uuid
                            changed = True
                        if result_panel_user.subscription_url and result_panel_user.subscription_url != subscription.url:
                            subscription.url = result_panel_user.subscription_url
                            changed = True
                        if changed:
                            await subscription_service.update(subscription)
                        updated += 1
                        logger.info(
                            f"✓ User updated [{updated}]: {user.name} "
                            f"(telegram_id: {user.telegram_id}, "
                            f"panel_uuid: {result_panel_user.uuid})"
                        )
                else:
                    # Пользователя нет в панели — создаём
                    new_user = await remnawave_service.create_user(
                        user=user,
                        subscription=subscription,
                        force=True,
                    )
                    if new_user:
                        subscription.user_remna_id = new_user.uuid
                        if new_user.subscription_url:
                            subscription.url = new_user.subscription_url
                        await subscription_service.update(subscription)
                        created += 1
                        logger.info(
                            f"✓ User created in panel [{created}]: {user.name} "
                            f"(telegram_id: {user.telegram_id}, "
                            f"panel_uuid: {new_user.uuid}, short_uuid: {new_user.short_uuid})"
                        )
                    else:
                        error_users[f"{user.name} ({user.telegram_id})"] = "create_user returned None"
                        errors += 1
            except Exception as e:
                error_msg = f"{type(e).__name__}: {str(e)}"
                if "Validation failed" in str(e) or "validation" in str(e).lower():
                    logger.debug(
                        f"⊘ User skipped (validation error): {user.name} "
                        f"(telegram_id: {user.telegram_id})"
                    )
                else:
                    logger.error(
                        f"✗ Failed to sync user: {user.name} "
                        f"(telegram_id: {user.telegram_id}). Error: {error_msg}"
                    )
                    error_users[f"{user.name} ({user.telegram_id})"] = error_msg
                    errors += 1

        # ── 2C: Пользователи панели, которых нет в боте → импортируем в бот ──
        imported_from_panel = 0
        if panel_only_users:
            logger.info(
                f"Step 2C: Importing {len(panel_only_users)} panel-only users into bot"
            )
            for panel_user in panel_only_users:
                try:
                    if not panel_user.telegram_id:
                        logger.debug(
                            f"⊘ Panel user {panel_user.username} has no telegram_id, skipping import"
                        )
                        continue
                    await remnawave_service.sync_user(panel_user, creating=True)
                    imported_from_panel += 1
                    logger.info(
                        f"✓ Imported panel user into bot [{imported_from_panel}]: "
                        f"{panel_user.username} (telegram_id: {panel_user.telegram_id})"
                    )
                except Exception as e:
                    if "Validation failed" in str(e) or "validation" in str(e).lower():
                        logger.debug(
                            f"⊘ Panel user skipped (validation error): {panel_user.username} "
                            f"(telegram_id: {panel_user.telegram_id})"
                        )
                    else:
                        logger.warning(
                            f"Failed to import panel user {panel_user.username} "
                            f"(telegram_id: {panel_user.telegram_id}) into bot: {e}"
                        )
                        errors += 1

            logger.info(f"Step 2C complete: {imported_from_panel} users imported from panel")

    else:
        # ═══════ NORMAL MODE (regular sync without cleanup) ═══════
        logger.info("Step 2: Syncing users from bot to Remnawave panel")

        for user in bot_users:
            try:
                # Получаем текущую подписку пользователя
                subscription = await subscription_service.get_current(user.telegram_id)
                
                if not subscription:
                    logger.debug(
                        f"⊘ User skipped (no subscription): {user.name} (telegram_id: {user.telegram_id})"
                    )
                    skipped_users.append(f"{user.name} ({user.telegram_id})")
                    skipped += 1
                    continue
                
                # Проверяем, есть ли пользователь в панели Remnawave
                try:
                    panel_users = await remnawave.users.get_users_by_telegram_id(
                        telegram_id=str(user.telegram_id)
                    )
                except Exception as e:
                    logger.warning(f"Error getting user from panel: {e}")
                    panel_users = []
                
                if panel_users:
                    # Пользователь есть в панели - проверяем short_uuid
                    panel_user = panel_users[0]
                    logger.debug(f"User '{user.telegram_id}' found in panel, checking short_uuid...")
                    
                    # Проверяем, совпадает ли short_uuid
                    need_recreate = False
                    desired_short_uuid = None
                    
                    if subscription and subscription.url:
                        try:
                            desired_short_uuid = subscription.url.rstrip('/').split('/')[-1]
                            panel_short_uuid = panel_user.short_uuid
                            
                            logger.debug(
                                f"DEBUG: Comparing short_uuid for user {user.telegram_id}: "
                                f"panel='{panel_short_uuid}', backup='{desired_short_uuid}', "
                                f"subscription.url='{subscription.url}'"
                            )
                            
                            if panel_short_uuid != desired_short_uuid:
                                logger.warning(
                                    f"⚠️ short_uuid MISMATCH for user {user.telegram_id}: "
                                    f"panel={panel_short_uuid}, backup={desired_short_uuid}. "
                                    f"Will use REVOKE to update short_uuid."
                                )
                                need_recreate = True
                            else:
                                logger.debug(f"✓ short_uuid matches: {desired_short_uuid}")
                        except Exception as ex:
                            logger.warning(f"Failed to extract short_uuid from URL '{subscription.url}': {ex}")
                            traceback_str = traceback.format_exc()
                            logger.warning(f"Traceback: {traceback_str}")
                    
                    if need_recreate and desired_short_uuid:
                        try:
                            logger.info(
                                f"🔄 Recreating user {panel_user.uuid} to preserve short_uuid "
                                f"from backup: '{desired_short_uuid}' (current in panel: '{panel_user.short_uuid}')"
                            )
                            
                            old_uuid = panel_user.uuid
                            old_expire_at = panel_user.expire_at
                            old_status = panel_user.status
                            old_traffic_limit_bytes = panel_user.traffic_limit_bytes
                            old_traffic_limit_strategy = panel_user.traffic_limit_strategy
                            old_description = panel_user.description
                            old_tag = panel_user.tag
                            old_hwid_device_limit = panel_user.hwid_device_limit
                            old_active_squads = [squad.uuid for squad in (panel_user.active_internal_squads or [])]
                            
                            logger.info(f"Deleting user {old_uuid} from panel...")
                            await remnawave.users.delete_user(uuid=old_uuid)
                            logger.info(f"✓ User {old_uuid} deleted successfully")
                            
                            create_body = CreateUserRequestDto(
                                username=str(user.telegram_id),
                                telegram_id=user.telegram_id,
                                expire_at=old_expire_at,
                                status=old_status,
                                traffic_limit_bytes=old_traffic_limit_bytes,
                                traffic_limit_strategy=old_traffic_limit_strategy,
                                description=old_description,
                                tag=old_tag,
                                hwid_device_limit=old_hwid_device_limit,
                                active_internal_squads=old_active_squads if old_active_squads else None,
                                short_uuid=desired_short_uuid,
                            )
                            
                            logger.info(f"Creating new user with short_uuid='{desired_short_uuid}'...")
                            created_user = await remnawave.users.create_user(body=create_body)
                            
                            if created_user and created_user.uuid:
                                if created_user.short_uuid != desired_short_uuid:
                                    logger.error(
                                        f"❌ CRITICAL: After create, short_uuid didn't match! "
                                        f"Expected: '{desired_short_uuid}', Got: '{created_user.short_uuid}'"
                                    )
                                else:
                                    logger.info(f"✓ Verified: short_uuid correctly set to '{created_user.short_uuid}'")
                                
                                subscription.user_remna_id = created_user.uuid
                                if created_user.subscription_url:
                                    subscription.url = created_user.subscription_url
                                await subscription_service.update(subscription)
                                
                                updated += 1
                                logger.info(
                                    f"✓ User RECREATED with preserved short_uuid: {user.name} "
                                    f"(telegram_id: {user.telegram_id}, new_uuid: {created_user.uuid}, "
                                    f"short_uuid: {created_user.short_uuid})"
                                )
                            else:
                                error_msg = "create_user returned None or empty response after delete"
                                logger.error(
                                    f"✗ Failed to recreate user: {user.name} (telegram_id: {user.telegram_id}). "
                                    f"Error: {error_msg}"
                                )
                                error_users[f"{user.name} ({user.telegram_id})"] = error_msg
                                errors += 1
                        except Exception as e:
                            error_msg = f"{type(e).__name__}: {str(e)}"
                            traceback_str = traceback.format_exc()
                            if "Validation failed" in str(e) or "validation" in str(e).lower():
                                logger.debug(
                                    f"⊘ User skipped (validation error - likely inactive subscription): "
                                    f"{user.name} (telegram_id: {user.telegram_id})"
                                )
                            else:
                                logger.error(
                                    f"✗ Failed to recreate user with short_uuid: {user.name} (telegram_id: {user.telegram_id}). "
                                    f"Error: {error_msg}\nTraceback:\n{traceback_str}"
                                )
                                error_users[f"{user.name} ({user.telegram_id})"] = error_msg
                                errors += 1
                                
                                await notification_service.error_notify(
                                    error_id=user.telegram_id,
                                    traceback_str=traceback_str,
                                    payload=MessagePayload.not_deleted(
                                        i18n_key="ntf-event-error",
                                        i18n_kwargs={
                                            "user": True,
                                            "user_id": str(user.telegram_id),
                                            "user_name": user.name,
                                            "username": user.username or False,
                                            "error": f"Sync revoke error: {error_msg}",
                                        },
                                        reply_markup=get_user_keyboard(user.telegram_id),
                                    ),
                                )
                    else:
                        # short_uuid совпадает или нет URL - просто обновляем
                        try:
                            await remnawave_service.updated_user(
                                user=user,
                                uuid=panel_user.uuid,
                                subscription=subscription,
                            )
                            if panel_user.subscription_url and panel_user.subscription_url != subscription.url:
                                subscription.url = panel_user.subscription_url
                                await subscription_service.update(subscription)
                            updated += 1
                            logger.info(
                                f"✓ User updated: {user.name} (telegram_id: {user.telegram_id}, "
                                f"panel_uuid: {panel_user.uuid})"
                            )
                        except Exception as e:
                            error_msg = f"{type(e).__name__}: {str(e)}"
                            traceback_str = traceback.format_exc()
                            if "Validation failed" in str(e) or "validation" in str(e).lower():
                                logger.debug(
                                    f"⊘ User skipped (validation error - likely inactive subscription): "
                                    f"{user.name} (telegram_id: {user.telegram_id})"
                                )
                            else:
                                logger.error(
                                    f"✗ Failed to update user: {user.name} (telegram_id: {user.telegram_id}). "
                                    f"Error: {error_msg}\nTraceback:\n{traceback_str}"
                                )
                                error_users[f"{user.name} ({user.telegram_id})"] = error_msg
                                errors += 1
                                
                                await notification_service.error_notify(
                                    error_id=user.telegram_id,
                                    traceback_str=traceback_str,
                                    payload=MessagePayload.not_deleted(
                                        i18n_key="ntf-event-error",
                                        i18n_kwargs={
                                            "user": True,
                                            "user_id": str(user.telegram_id),
                                            "user_name": user.name,
                                            "username": user.username or False,
                                            "error": f"Sync update error: {error_msg}",
                                        },
                                        reply_markup=get_user_keyboard(user.telegram_id),
                                    ),
                                )
                else:
                    # Пользователя нет в панели - СОЗДАЁМ
                    logger.info(
                        f"User '{user.name}' (telegram_id: {user.telegram_id}) not found in panel, "
                        f"creating with short_uuid from URL..."
                    )
                    try:
                        new_user = await remnawave_service.create_user(
                            user=user,
                            subscription=subscription,
                            force=True,
                        )
                        
                        if new_user:
                            if subscription.user_remna_id != new_user.uuid:
                                subscription.user_remna_id = new_user.uuid
                                await subscription_service.update(subscription)
                            
                            created += 1
                            logger.info(
                                f"✓ User created: {user.name} (telegram_id: {user.telegram_id}, "
                                f"panel_uuid: {new_user.uuid}, short_uuid: {new_user.short_uuid})"
                            )
                        else:
                            logger.warning(
                                f"✗ Failed to create user: {user.name} (telegram_id: {user.telegram_id}). "
                                f"create_user returned None"
                            )
                            error_users[f"{user.name} ({user.telegram_id})"] = "create_user returned None"
                            errors += 1
                    except Exception as e:
                        error_msg = f"{type(e).__name__}: {str(e)}"
                        traceback_str = traceback.format_exc()
                        if "Validation failed" in str(e) or "validation" in str(e).lower():
                            logger.debug(
                                f"⊘ User skipped (validation error - likely inactive subscription): "
                                f"{user.name} (telegram_id: {user.telegram_id})"
                            )
                        else:
                            logger.error(
                                f"✗ Failed to create user: {user.name} (telegram_id: {user.telegram_id}). "
                                f"Error: {error_msg}\nTraceback:\n{traceback_str}"
                            )
                            error_users[f"{user.name} ({user.telegram_id})"] = error_msg
                            errors += 1
                            
                            await notification_service.error_notify(
                                error_id=user.telegram_id,
                                traceback_str=traceback_str,
                                payload=MessagePayload.not_deleted(
                                    i18n_key="ntf-event-error",
                                    i18n_kwargs={
                                        "user": True,
                                        "user_id": str(user.telegram_id),
                                        "user_name": user.name,
                                        "username": user.username or False,
                                        "error": f"Sync create error: {error_msg}",
                                    },
                                    reply_markup=get_user_keyboard(user.telegram_id),
                                ),
                            )
                
            except Exception as exception:
                error_msg = f"{type(exception).__name__}: {str(exception)}"
                traceback_str = traceback.format_exc()
                user_name = user.name if hasattr(user, 'name') else 'Unknown'
                user_telegram_id = user.telegram_id if hasattr(user, 'telegram_id') else 'Unknown'
                if "Validation failed" in str(exception) or "validation" in str(exception).lower():
                    logger.debug(
                        f"⊘ User skipped (validation error): {user_name} "
                        f"(telegram_id: {user_telegram_id})"
                    )
                else:
                    logger.exception(
                        f"✗ Error syncing user: {user_name} "
                        f"(telegram_id: {user_telegram_id}). "
                        f"Exception: {error_msg}\nTraceback:\n{traceback_str}"
                    )
                    error_users[f"{user_name} ({user_telegram_id})"] = error_msg
                    errors += 1
                    
                    if hasattr(user, 'telegram_id'):
                        await notification_service.error_notify(
                            error_id=user.telegram_id,
                            traceback_str=traceback_str,
                            payload=MessagePayload.not_deleted(
                                i18n_key="ntf-event-error",
                                i18n_kwargs={
                                    "user": True,
                                    "user_id": str(user.telegram_id),
                                    "user_name": user_name,
                                    "username": getattr(user, 'username', None) or False,
                                    "error": f"Sync error: {error_msg}",
                                },
                                reply_markup=get_user_keyboard(user.telegram_id),
                            ),
                        )
    
    result = {
        "total_bot_users": len(bot_users),
        "created": created,
        "updated": updated,
        "skipped": skipped,
        "deleted_from_bot": deleted_from_bot,
        "deleted_from_panel": deleted_from_panel,
        "imported_from_panel": imported_from_panel,
        "errors": errors,
        "error_users": error_users,
        "skipped_users": skipped_users,
    }
    
    logger.info(f"Sync bot to panel completed: {result}")
    return result

