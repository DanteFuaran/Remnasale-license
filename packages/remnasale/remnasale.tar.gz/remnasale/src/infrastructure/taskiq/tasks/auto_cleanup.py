"""Задача автоочистки EXPIRED пользователей из панели Remnawave."""
from datetime import timezone

from dishka.integrations.taskiq import FromDishka, inject
from loguru import logger
from remnapy import RemnawaveSDK

from src.bot.keyboards import get_buy_keyboard
from src.core.utils.message_payload import MessagePayload
from src.core.utils.time import datetime_now
from src.infrastructure.taskiq.broker import broker
from src.services.notification import NotificationService
from src.services.settings import SettingsService
from src.services.user import UserService


@broker.task(schedule=[{"cron": "0 3 * * *"}])  # Каждый день в 3:00
@inject
async def auto_cleanup_expired_users_task(
    settings_service: FromDishka[SettingsService],
    remnawave: FromDishka[RemnawaveSDK],
    user_service: FromDishka[UserService],
    notification_service: FromDishka[NotificationService],
) -> None:
    """
    Удаляет EXPIRED пользователей из панели Remnawave после N дней неактивности.
    Данные пользователей в боте сохраняются.
    """
    try:
        settings = await settings_service.get()
        cleanup = settings.features.auto_cleanup

        if not cleanup.enabled:
            logger.debug("[auto_cleanup] Auto cleanup is disabled")
            return

        days_threshold = cleanup.days_threshold
        notify_user = cleanup.notify_user
        now = datetime_now()

        logger.info(
            f"[auto_cleanup] Starting cleanup (threshold: {days_threshold} days, "
            f"notify: {notify_user})"
        )

        # Получаем всех пользователей из панели
        all_panel_users = []
        stats = await remnawave.system.get_stats()
        total_users = stats.users.total_users

        for start in range(0, total_users, 50):
            response = await remnawave.users.get_all_users(start=start, size=50)
            if not response.users:
                break
            all_panel_users.extend(response.users)
            if len(response.users) < 50:
                break

        deleted_count = 0
        notified_count = 0

        for panel_user in all_panel_users:
            try:
                is_active = (
                    panel_user.status
                    and str(panel_user.status).upper() == "ACTIVE"
                )

                if is_active:
                    continue

                if not panel_user.expire_at:
                    continue

                expire_at = panel_user.expire_at
                if expire_at.tzinfo is None:
                    expire_at = expire_at.replace(tzinfo=timezone.utc)

                days_expired = (now - expire_at).days

                if days_expired < days_threshold:
                    continue

                # Удаляем из панели
                try:
                    await remnawave.users.delete_user(uuid=panel_user.uuid)
                    deleted_count += 1
                    logger.info(
                        f"[auto_cleanup] Deleted user {panel_user.username} "
                        f"(expired {days_expired} days ago)"
                    )
                except Exception as e:
                    logger.warning(
                        f"[auto_cleanup] Failed to delete {panel_user.uuid}: {e}"
                    )
                    continue

                # Отправляем уведомление пользователю
                if notify_user and panel_user.telegram_id:
                    try:
                        telegram_id = int(panel_user.telegram_id)
                        user = await user_service.get(telegram_id)
                        if user:
                            if cleanup.notify_message:
                                payload = MessagePayload(
                                    text=cleanup.notify_message,
                                    reply_markup=get_buy_keyboard(),
                                    auto_delete_after=None,
                                    add_close_button=True,
                                )
                            else:
                                payload = MessagePayload(
                                    i18n_key="ntf-auto-cleanup-deleted",
                                    reply_markup=get_buy_keyboard(),
                                    auto_delete_after=None,
                                    add_close_button=True,
                                )
                            await notification_service.notify_user(
                                user=user,
                                payload=payload,
                            )
                            notified_count += 1
                    except Exception as e:
                        logger.warning(
                            f"[auto_cleanup] Failed to notify user "
                            f"{panel_user.telegram_id}: {e}"
                        )

            except Exception as e:
                logger.error(f"[auto_cleanup] Error processing user {panel_user.uuid}: {e}")

        logger.info(
            f"[auto_cleanup] Completed: {deleted_count} deleted, "
            f"{notified_count} notified"
        )

    except Exception as e:
        logger.error(f"[auto_cleanup] Task failed: {e}")
