from datetime import timedelta
from uuid import UUID

from dishka.integrations.taskiq import FromDishka, inject
from loguru import logger

from src.core.enums import TransactionStatus
from src.core.utils.time import datetime_now
from src.infrastructure.taskiq.broker import broker
from src.services.payment_gateway import PaymentGatewayService
from src.services.transaction import TransactionService


@broker.task()
@inject
async def handle_payment_transaction_task(
    payment_id: UUID,
    payment_status: TransactionStatus,
    payment_gateway_service: FromDishka[PaymentGatewayService],
) -> None:
    match payment_status:
        case TransactionStatus.COMPLETED:
            await payment_gateway_service.handle_payment_succeeded(payment_id)
        case TransactionStatus.CANCELED:
            await payment_gateway_service.handle_payment_canceled(payment_id)
        case TransactionStatus.PENDING:
            logger.debug(f"Transaction '{payment_id}' still pending, skipping")


@broker.task(schedule=[{"cron": "*/30 * * * *"}])
@inject
async def cancel_transaction_task(transaction_service: FromDishka[TransactionService]) -> None:
    transactions = await transaction_service.get_by_status(TransactionStatus.PENDING)

    if not transactions:
        logger.debug("No pending transactions found")
        return

    old_transactions = [tx for tx in transactions if tx.has_old]
    logger.debug(f"Found '{len(old_transactions)}' old transactions to cancel")

    for transaction in old_transactions:
        transaction.status = TransactionStatus.CANCELED
        await transaction_service.update(transaction)
        logger.debug(f"Transaction '{transaction.id}' canceled")


@broker.task(schedule=[{"cron": "*/5 * * * *"}])
@inject
async def reconcile_pending_payments_task(
    transaction_service: FromDishka[TransactionService],
    payment_gateway_service: FromDishka[PaymentGatewayService],
) -> None:
    transactions = await transaction_service.get_by_status(TransactionStatus.PENDING)
    if not transactions:
        return

    now = datetime_now()
    candidates = [
        tx
        for tx in transactions
        if tx.created_at
        and timedelta(minutes=2) < now - tx.created_at < timedelta(minutes=28)
    ]

    if not candidates:
        return

    logger.info(f"Reconciliation: checking {len(candidates)} pending transaction(s)")

    for tx in candidates:
        try:
            gateway_instance = await payment_gateway_service._get_gateway_instance(tx.gateway_type)
            status = await gateway_instance.check_payment_status(tx.payment_id)

            if status == TransactionStatus.COMPLETED:
                logger.info(
                    f"Reconciliation: payment {tx.payment_id} confirmed by {tx.gateway_type}"
                )
                await payment_gateway_service.handle_payment_succeeded(tx.payment_id)
            elif status == TransactionStatus.CANCELED:
                logger.info(
                    f"Reconciliation: payment {tx.payment_id} canceled by {tx.gateway_type}"
                )
                await payment_gateway_service.handle_payment_canceled(tx.payment_id)
        except Exception as exc:
            logger.warning(f"Reconciliation check failed for {tx.payment_id}: {exc}")
