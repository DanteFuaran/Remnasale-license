from typing import Union

from dishka import Provider, Scope, provide
from httpx import AsyncClient, Timeout
from loguru import logger
from remnapy import RemnawaveSDK

from src.core.config import AppConfig


def _patch_remnapy_models() -> None:
    """Patch remnapy models where xrayUptime is typed as str but Remnawave sends int."""
    from remnapy.models.nodes import GetAllNodesResponseDto, NodeResponseDto
    from remnapy.models.webhook import NodeDto

    for model in (NodeResponseDto, NodeDto):
        field = model.model_fields.get("xray_uptime")
        if field and field.annotation is str:
            field.annotation = Union[str, int]
            model.model_rebuild(force=True)

    # RootModel кеширует валидатор при создании класса —
    # нужно перестроить и его, иначе get_all_nodes() падает с ValidationError
    GetAllNodesResponseDto.model_rebuild(force=True)

    logger.debug("Patched remnapy xray_uptime: str -> Union[str, int]")


_patch_remnapy_models()


class RemnawaveProvider(Provider):
    scope = Scope.APP

    @provide
    def get_remnawave(self, config: AppConfig) -> RemnawaveSDK:
        logger.debug("Initializing RemnawaveSDK")

        headers = {}
        headers["Authorization"] = f"Bearer {config.remnawave.token.get_secret_value()}"
        headers["X-Api-Key"] = config.remnawave.caddy_token.get_secret_value()

        if not config.remnawave.is_external:
            headers["x-forwarded-proto"] = "https"
            headers["x-forwarded-for"] = "127.0.0.1"

        client = AsyncClient(
            base_url=f"{config.remnawave.url.get_secret_value()}/api",
            headers=headers,
            cookies=config.remnawave.cookies,
            verify=True,
            timeout=Timeout(connect=5.0, read=25.0, write=10.0, pool=5.0),
        )

        return RemnawaveSDK(client)
