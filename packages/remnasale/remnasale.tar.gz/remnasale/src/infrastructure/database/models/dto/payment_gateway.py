from typing import Annotated, Any, Literal, Optional, Union
from uuid import UUID

from pydantic import ConfigDict, Field, SecretStr

from src.core.enums import Currency, PaymentGatewayType, YookassaVatCode

from .base import TrackableDto


class PaymentResult(TrackableDto):
    id: UUID
    url: Optional[str] = None


class PaymentGatewayDto(TrackableDto):
    id: Optional[int] = Field(default=None, frozen=True)

    order_index: int
    type: PaymentGatewayType
    currency: Currency

    is_active: bool
    settings: Optional["AnyGatewaySettingsDto"] = None

    @property
    def requires_webhook(self) -> bool:
        return self.type not in {
            PaymentGatewayType.CRYPTOMUS,
            PaymentGatewayType.HELEKET,
            PaymentGatewayType.FREEKASSA,
            PaymentGatewayType.PAYMASTER,
        }


class GatewaySettingsDto(TrackableDto):
    model_config = ConfigDict(validate_assignment=True)

    @property
    def is_configure(self) -> bool:
        for name, value in self.__dict__.items():
            if value is None:
                return False
        return True

    @property
    def get_settings_as_list_data(self) -> list[dict[str, Any]]:
        return [
            {"field": field_name, "value": value}
            for field_name, value in self.__dict__.items()
            if field_name != "type"
        ]


class YookassaGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.YOOKASSA] = PaymentGatewayType.YOOKASSA
    shop_id: Optional[str] = None
    api_key: Optional[SecretStr] = None
    customer: Optional[str] = None
    vat_code: Optional[YookassaVatCode] = None


class YoomoneyGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.YOOMONEY] = PaymentGatewayType.YOOMONEY
    wallet_id: Optional[str] = None
    secret_key: Optional[SecretStr] = None


class CryptomusGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.CRYPTOMUS] = PaymentGatewayType.CRYPTOMUS
    merchant_id: Optional[str] = None
    api_key: Optional[SecretStr] = None


class HeleketGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.HELEKET] = PaymentGatewayType.HELEKET
    merchant_id: Optional[str] = None
    api_key: Optional[SecretStr] = None


class CryptopayGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.CRYPTOPAY] = PaymentGatewayType.CRYPTOPAY
    api_key: Optional[SecretStr] = None


class RobokassaGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.ROBOKASSA] = PaymentGatewayType.ROBOKASSA
    merchant_login: Optional[str] = None
    password1: Optional[SecretStr] = None
    password2: Optional[SecretStr] = None


class LavaGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.LAVA] = PaymentGatewayType.LAVA
    shop_id: Optional[str] = None
    secret_key: Optional[SecretStr] = None
    additional_key: Optional[SecretStr] = None


class PlategaGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.PLATEGA] = PaymentGatewayType.PLATEGA
    shop_id: Optional[str] = None
    secret_key: Optional[SecretStr] = None


class FreekassaGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.FREEKASSA] = PaymentGatewayType.FREEKASSA
    shop_id: Optional[int] = None
    api_key: Optional[SecretStr] = None
    secret_word_2: Optional[SecretStr] = None
    payment_system_id: Optional[int] = None
    customer_email: Optional[str] = None
    customer_ip: Optional[str] = None


class MulenpayGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.MULENPAY] = PaymentGatewayType.MULENPAY
    api_key: Optional[SecretStr] = None
    secret_key: Optional[SecretStr] = None
    shop_id: Optional[int] = None
    vat_code: Optional[int] = None


class PaymasterGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.PAYMASTER] = PaymentGatewayType.PAYMASTER
    merchant_id: Optional[str] = None
    api_key: Optional[SecretStr] = None


class UrlpayGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.URLPAY] = PaymentGatewayType.URLPAY
    shop_id: Optional[int] = None
    api_key: Optional[SecretStr] = None
    secret_key: Optional[SecretStr] = None
    vat_code: Optional[int] = None


class WataGatewaySettingsDto(GatewaySettingsDto):
    type: Literal[PaymentGatewayType.WATA] = PaymentGatewayType.WATA
    api_key: Optional[SecretStr] = None


AnyGatewaySettingsDto = Annotated[
    Union[
        YookassaGatewaySettingsDto,
        YoomoneyGatewaySettingsDto,
        CryptomusGatewaySettingsDto,
        HeleketGatewaySettingsDto,
        CryptopayGatewaySettingsDto,
        RobokassaGatewaySettingsDto,
        LavaGatewaySettingsDto,
        PlategaGatewaySettingsDto,
        FreekassaGatewaySettingsDto,
        MulenpayGatewaySettingsDto,
        PaymasterGatewaySettingsDto,
        UrlpayGatewaySettingsDto,
        WataGatewaySettingsDto,
    ],
    Field(discriminator="type"),
]
