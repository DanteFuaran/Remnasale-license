from types import TracebackType
from typing import Optional, Self, Type

from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from .repositories import RepositoriesFacade


class UnitOfWork:
    """Unit of Work — wraps an externally-managed AsyncSession.

    Session lifecycle (open / close) is handled by the DI provider.
    UoW only manages transactions (commit / rollback) and exposes repositories.
    """

    session: AsyncSession
    repository: RepositoriesFacade

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.repository = RepositoriesFacade(session=self.session)

    async def commit(self) -> None:
        await self.session.commit()

    async def rollback(self) -> None:
        await self.session.rollback()
        logger.debug(f"Session '{id(self.session)}' rolled back")
