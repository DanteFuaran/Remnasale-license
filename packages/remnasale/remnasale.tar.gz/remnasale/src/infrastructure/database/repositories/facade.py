from sqlalchemy.ext.asyncio import AsyncSession

from .balance_transfer import BalanceTransferRepository
from .broadcast import BroadcastRepository
from .extra_device_purchase import ExtraDevicePurchaseRepository
from .mirror_bot import MirrorBotRepository
from .payment_gateway import PaymentGatewayRepository
from .plan import PlanRepository
from .promocode import PromocodeRepository
from .referral import ReferralRepository
from .settings import SettingsRepository
from .subscription import SubscriptionRepository
from .ticket import TicketRepository
from .transaction import TransactionRepository
from .user import UserRepository
from .oauth_account import OAuthAccountRepository
from .web_credential import WebCredentialRepository


class RepositoriesFacade:
    session: AsyncSession

    balance_transfers: BalanceTransferRepository
    gateways: PaymentGatewayRepository
    plans: PlanRepository
    promocodes: PromocodeRepository
    subscriptions: SubscriptionRepository
    tickets: TicketRepository
    transactions: TransactionRepository
    users: UserRepository
    settings: SettingsRepository
    broadcasts: BroadcastRepository
    referrals: ReferralRepository
    extra_device_purchases: ExtraDevicePurchaseRepository
    mirror_bots: MirrorBotRepository
    web_credentials: WebCredentialRepository
    oauth_accounts: OAuthAccountRepository

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

        self.balance_transfers = BalanceTransferRepository(session)
        self.gateways = PaymentGatewayRepository(session)
        self.plans = PlanRepository(session)
        self.promocodes = PromocodeRepository(session)
        self.subscriptions = SubscriptionRepository(session)
        self.tickets = TicketRepository(session)
        self.transactions = TransactionRepository(session)
        self.users = UserRepository(session)
        self.settings = SettingsRepository(session)
        self.broadcasts = BroadcastRepository(session)
        self.referrals = ReferralRepository(session)
        self.extra_device_purchases = ExtraDevicePurchaseRepository(session)
        self.mirror_bots = MirrorBotRepository(session)
        self.web_credentials = WebCredentialRepository(session)
        self.oauth_accounts = OAuthAccountRepository(session)
