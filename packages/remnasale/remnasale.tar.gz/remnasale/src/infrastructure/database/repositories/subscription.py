from typing import Any, Optional

from sqlalchemy import select

from src.infrastructure.database.models.sql import Subscription
from src.infrastructure.database.models.sql.user import User

from .base import BaseRepository


class SubscriptionRepository(BaseRepository):
    async def create(self, subscription: Subscription) -> Subscription:
        return await self.create_instance(subscription)

    async def get(self, subscription_id: int) -> Optional[Subscription]:
        return await self._get_one(Subscription, Subscription.id == subscription_id)

    async def get_all_by_user(self, telegram_id: int) -> list[Subscription]:
        return await self._get_many(Subscription, Subscription.user_telegram_id == telegram_id)

    async def get_all(self) -> list[Subscription]:
        return await self._get_many(Subscription)

    async def update(self, subscription_id: int, **data: Any) -> Optional[Subscription]:
        return await self._update(Subscription, Subscription.id == subscription_id, **data)

    async def filter_by_plan_id(self, plan_id: int) -> list[Subscription]:
        return await self._get_many(Subscription, Subscription.plan["id"].as_integer() == plan_id)

    async def get_current_by_plan_id(self, plan_id: int) -> list[Subscription]:
        """Возвращает только ТЕКУЩИЕ подписки пользователей для указанного plan_id.
        
        Фильтрует через JOIN с users.current_subscription_id, чтобы исключить 
        орфанные подписки, которые больше не являются активной подпиской пользователя.
        """
        query = (
            select(Subscription)
            .join(User, User.current_subscription_id == Subscription.id)
            .where(Subscription.plan["id"].as_integer() == plan_id)
        )
        result = await self.session.execute(query)
        return list(result.unique().scalars().all())

    async def get_by_url(self, url: str) -> Optional[Subscription]:
        return await self._get_one(Subscription, Subscription.url == url)
