from typing import Any, Optional

from sqlalchemy import func, or_, update

from src.core.enums import UserRole
from src.infrastructure.database.models.sql import User

from .base import BaseRepository


class UserRepository(BaseRepository):
    async def create(self, user: User) -> User:
        return await self.create_instance(user)

    async def get(self, telegram_id: int) -> Optional[User]:
        return await self._get_one(User, User.telegram_id == telegram_id)

    async def get_by_ids(self, telegram_ids: list[int]) -> list[User]:
        return await self._get_many(User, User.telegram_id.in_(telegram_ids))

    async def get_by_partial_name(self, query: str) -> list[User]:
        search_pattern = f"%{query.lower()}%"
        conditions = [
            func.lower(User.name).like(search_pattern),
            func.lower(User.username).like(search_pattern),
        ]
        return await self._get_many(User, or_(*conditions))

    async def get_by_username(self, username: str) -> Optional[User]:
        """Get user by exact username (case-insensitive)."""
        return await self._get_one(User, func.lower(User.username) == username.lower())

    async def get_by_referral_code(self, referral_code: str) -> Optional[User]:
        from sqlalchemy import func
        return await self._get_one(User, func.lower(User.referral_code) == referral_code.lower())

    async def get_all(self) -> list[User]:
        return await self._get_many(User)

    async def update(self, telegram_id: int, **data: Any) -> Optional[User]:
        return await self._update(User, User.telegram_id == telegram_id, **data)

    async def delete(self, telegram_id: int) -> bool:
        return bool(await self._delete(User, User.telegram_id == telegram_id))

    async def count(self) -> int:
        return await self._count(User)

    async def filter_by_role(self, role: UserRole) -> list[User]:
        return await self._get_many(User, User.role == role)

    async def filter_by_blocked(self, blocked: bool) -> list[User]:
        return await self._get_many(User, User.is_blocked == blocked)

    async def atomic_add_balance(self, telegram_id: int, amount: int) -> bool:
        """Atomically add amount to user balance. Returns True if row was updated."""
        result = await self.session.execute(
            update(User)
            .where(User.telegram_id == telegram_id)
            .values(balance=User.balance + amount)
        )
        return result.rowcount > 0  # type: ignore[union-attr]

    async def atomic_subtract_balance(self, telegram_id: int, amount: int) -> bool:
        """Atomically subtract amount from balance. Only succeeds if balance >= amount."""
        result = await self.session.execute(
            update(User)
            .where(User.telegram_id == telegram_id, User.balance >= amount)
            .values(balance=User.balance - amount)
        )
        return result.rowcount > 0  # type: ignore[union-attr]
