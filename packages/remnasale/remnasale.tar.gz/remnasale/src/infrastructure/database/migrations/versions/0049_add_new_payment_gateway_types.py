from typing import Sequence, Union

from alembic import op

revision: str = "0049"
down_revision: Union[str, None] = "0048"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("ALTER TYPE payment_gateway_type ADD VALUE IF NOT EXISTS 'CRYPTOPAY'")
    op.execute("ALTER TYPE payment_gateway_type ADD VALUE IF NOT EXISTS 'ROBOKASSA'")
    op.execute("ALTER TYPE payment_gateway_type ADD VALUE IF NOT EXISTS 'FREEKASSA'")
    op.execute("ALTER TYPE payment_gateway_type ADD VALUE IF NOT EXISTS 'MULENPAY'")
    op.execute("ALTER TYPE payment_gateway_type ADD VALUE IF NOT EXISTS 'PAYMASTER'")
    op.execute("ALTER TYPE payment_gateway_type ADD VALUE IF NOT EXISTS 'WATA'")


def downgrade() -> None:
    # PostgreSQL doesn't support removing enum values
    pass
