# Database Management
msg-db-main =
    <b>🗄 Database Management</b>

    <blockquote>
    • <b>Save</b> - create a backup copy of the database
    • <b>Load</b> - restore database from backup
    • <b>Clear All</b> - delete all data from database
    • <b>Clear Users</b> - delete only users
    • <b>Sync</b> - synchronize data between bot and panel
    </blockquote>

    <b>🔽 Select an action:</b>
    
msg-db-clear-all-confirm =
    <b>⚠️ WARNING!</b>

    <blockquote>
    You are about to <b>completely clear the database</b>.
    
    Will be deleted:
    • All users
    • All subscriptions
    • All transactions
    • All promo codes and their activations
    • All referrals and rewards
    • All notifications
    </blockquote>

    <b>⚠️ This action is irreversible!</b>
    
    <i>Press the button again to confirm clearing.</i>

msg-db-clear-users-confirm =
    <b>⚠️ WARNING!</b>

    <blockquote>
    You are about to <b>delete all users</b> from the database.
    
    Will be deleted:
    • All users
    • All user subscriptions
    • All user transactions
    • All promo code activations
    • All referrals and rewards
    </blockquote>

    <b>⚠️ This action is irreversible!</b>
    
    <i>Press the button below again to confirm.</i>

msg-db-clear-users-result =
    <b>✅ User deletion completed successfully!</b>

    <blockquote>
    📊 Total:
    • Users: <b>{ $users }</b>
    • Subscriptions: <b>{ $subscriptions }</b>
    • Transactions: <b>{ $transactions }</b>
    • Activations: <b>{ $activations }</b>
    • Referrals: <b>{ $referrals }</b>
    • Rewards: <b>{ $rewards }</b>
    </blockquote>

msg-db-clear-users-failed =
    <b>❌ Error deleting users</b>

    { $error }

msg-db-imports =
    <b>📥 Import</b>

    Select a source for user import:

msg-db-load =
    <b>📁 Select file to load</b>

msg-db-load-upload =
    <b>📤 Upload Backup</b>

    Send a backup file (.sql.gz) to the bot.

msg-db-sync =
    <b>🔄 Data Synchronization</b>

    <blockquote>    
    • <b>From panel to bot</b>
    User data from the panel will be updated in the bot.
    If a user doesn't exist in the bot, they will be created.
    
    • <b>From bot to panel</b>
    User data from the bot will be updated in the panel.
    If a user doesn't exist in the panel, they will be created.
    </blockquote>

    <i>⚠️ Synchronization may take some time.</i>

msg-db-sync-progress =
    <b>🔄 Synchronizing...</b>

    <blockquote>
    Please wait. Synchronization is running in the background.
    You will receive a notification upon completion.
    </blockquote>

msg-db-import =
    <b>📥 SQLite Import</b>
    
    Select a file for import:

msg-db-restore-success =
    <b>✅ Database successfully restored from uploaded dump.</b>

msg-db-restore-failed =
    <b>❌ Error restoring database: { $error }</b>

# Settings
msg-dashboard-settings =
    <b>⚙️ Settings</b>

    🔽 Select a parameter:

msg-dashboard-settings-transfers =
    <b>💸 Transfer Settings</b>

    <blockquote>
    • Status: { $enabled ->
        [1] ✅ Enabled
        *[0] 🔴 Disabled
    }
    • Commission type: { $commission_type_display }
    • Commission: { $commission_display }
    • Minimum amount: { $min_amount } ₽
    • Maximum amount: { $max_amount } ₽
    </blockquote>


msg-dashboard-settings-transfers-commission-type =
    <b>💰 Commission Type Selection</b>

    <blockquote>
    • <b>Percentage</b> - commission is charged as a percentage of the transfer amount
    • <b>Fixed</b> - commission is charged as a fixed amount regardless of transfer amount
    </blockquote>

    Select commission type:

msg-dashboard-settings-transfers-commission-value =
    <b>💵 Commission Value</b>

    <blockquote>
    • Commission type: { $commission_type_display }
    • Current commission: { $db_commission_display }
    • Change to: { $selected_display }
    </blockquote>

    Select a price or enter your own:

msg-commission-manual-input =
    <b>✏️ Manual Input</b>

    <blockquote>
    Enter commission value:
    </blockquote>

msg-dashboard-settings-transfers-min-amount =
    <b>📉 Minimum Transfer Amount</b>

    <blockquote>
    • Current minimum amount: { $db_min_current_display }
    • Change to: { $min_selected_display }
    </blockquote>

    Select an amount or enter your own:

msg-min-amount-manual-input =
    <b>✏️ Manual Input</b>

    <blockquote>
    Enter minimum transfer amount (in rubles):
    </blockquote>

msg-dashboard-settings-transfers-max-amount =
    <b>📈 Maximum Transfer Amount</b>

    <blockquote>
    • Current maximum amount: { $db_max_current_display }
    • Change to: { $max_selected_display }
    </blockquote>

    Select an amount or enter your own:

msg-max-amount-manual-input =
    <b>✏️ Manual Input</b>

    <blockquote>
    Enter maximum transfer amount (in rubles):
    </blockquote>

# Balance Settings
msg-dashboard-settings-balance =
    <b>💰 Balance Settings</b>

    <blockquote>
    { lbl-status } { $enabled ->
        [1] { lbl-enabled }
        *[0] { lbl-disabled }
    }
    { lbl-min-topup-amount } { $balance_min_amount }
    { lbl-max-topup-amount } { $balance_max_amount }
    </blockquote>

    { hdr-balance-mode }
    <blockquote>
    { lbl-balance-mode-combined }
    { lbl-balance-mode-separate }
    </blockquote>

msg-dashboard-settings-balance-min-amount =
    <b>📉 Minimum Balance Top-up Amount</b>

    <blockquote>
    • Current minimum amount: { $balance_min_current_display }
    • Change to: { $balance_min_selected_display }
    </blockquote>

    Select an amount:

msg-dashboard-settings-balance-max-amount =
    <b>📈 Maximum Balance Top-up Amount</b>

    <blockquote>
    • Current maximum amount: { $balance_max_current_display }
    • Change to: { $balance_max_selected_display }
    </blockquote>

    Select an amount:

# Extra Devices Settings
msg-dashboard-extra-devices-settings =
    <b>📱 Extra Devices Settings</b>

    <blockquote>
    • Status: { $enabled ->
        [1] ✅ Enabled
        *[0] 🔴 Disabled
    }
    • Payment type: { $payment_type_display }
    • Minimum days: { $min_days } { $min_days ->
        [1] day
        *[other] days
    }
    </blockquote>


msg-dashboard-extra-devices-price =
    <b>💵 Extra Device Cost</b>

    <blockquote>
    • Current price: { $current_price } ₽
    • Change to: { $selected_price } ₽
    </blockquote>

    Select a price or enter your own:

msg-dashboard-extra-devices-price-manual =
    <b>✏️ Manual Price Entry</b>

    <blockquote>
    Enter extra device price (in rubles):
    </blockquote>

msg-dashboard-extra-devices-min-days =
    <b>⏳ Minimum Days</b>

    <blockquote>
    • Current: { $current_min_days } days
    • Change to: { $selected_min_days } days
    </blockquote>

    Minimum days remaining on subscription to allow purchasing an extra device slot.

msg-dashboard-extra-devices-min-days-manual =
    <b>⏳ Minimum Days</b>

    Enter minimum days (from 1 to 365)

    Select days:

# Global Discount Settings
msg-dashboard-settings-global-discount =
    <b>🏷️ Global Discount Settings</b>

    <blockquote>
    • Status: { $enabled ->
        [1] ✅ Enabled
        *[0] 🔴 Disabled
    }
    • Discount type: { $discount_type_display }
    • Discount: { $discount_display }
    • Mode: { $stack_mode_display }
    • Applies to: { $apply_to_display }
    </blockquote>

msg-global-discount-apply-to =
    <b>📌 What Discount Affects</b>

    <blockquote>
    Operations affected by global discount.
    </blockquote>

msg-global-discount-mode =
    <b>⚙️ Discount Application Mode</b>

    <blockquote>
    • <b>Maximum</b> - use the highest of the applied discounts
    
    • <b>Stacked</b> - combine both discounts
    </blockquote>

msg-dashboard-settings-global-discount-value =
    <b>💵 Discount Value</b>

    <blockquote>
    • Discount type: { $discount_type_display }
    • Current discount: { $db_discount_display }
    • Change to: { $selected_display }
    </blockquote>

    Select a discount or enter your own:

msg-global-discount-manual-input =
    <b>✏️ Manual Input</b>

    <blockquote>
    Enter discount value:
    </blockquote>

# Language Settings
msg-dashboard-settings-language =
    <b>🌐 Language Settings</b>
    <blockquote>
    • Multilingual: { $enabled ->
        [1] 🟢 Enabled
        *[0] 🔴 Disabled
    }
    • Current language: { $current_locale }
    </blockquote>

    <i>ℹ️ Multilingual:</i>
    🟢 Enabled - each user sees the bot in their language
    🔴 Disabled - all users see the selected language

msg-main-menu =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }{ frg-subscription-status-full }

msg-menu-connect =
    <b>🚀 Connection</b>

    📝 Instructions:
    <blockquote>
    • Download and install the app.
    • Press Activate subscription.
    • In the app press Enable.
    • Enjoy your freedom.
    </blockquote>

msg-menu-devices =
    <b>📱 Device Management</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { $has_subscription ->
        [0] <blockquote>
    • You have no active subscription.
    </blockquote>
        *[other] { frg-subscription }
    }

msg-add-device =
    <b>➕ Add Device</b>

msg-add-device-select-count =
    { $has_discount ->
    [1] ℹ️<i>Extra device cost: { $device_price }₽/mo  <s>{ $device_price_original }₽</s>/mo.</i>
    *[0] ℹ️<i>Extra device cost: { $device_price }₽/mo.</i>
    }

    📱 <b>Select number of devices:</b>

msg-add-device-full =
    <b>📱 Select number of devices:</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    { $has_discount ->
    [1] ℹ️<i>Extra device cost: { $device_price }₽/mo  <s>{ $device_price_original }₽</s>/mo.</i>
    *[0] ℹ️<i>Extra device cost: { $device_price }₽/mo.</i>
    }

msg-add-device-duration =
    <b>📅 Select Duration</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Purchase:</b>
    <blockquote>
    • <b>Extra devices:</b> { $device_count } pcs.
    </blockquote>

msg-add-device-payment =
    📱 <b>Purchase:</b>
    <blockquote>
    • <b>Extra devices:</b> { $device_count }
    </blockquote>

    💳 <b>Select payment method:</b>

msg-add-device-payment-full =
    <b>💳 Select Payment Method:</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Purchase:</b>
    <blockquote>
    • <b>Extra devices:</b> { $device_count }
    • <b>Duration:</b> { $period }
    </blockquote>

msg-add-device-confirm-full =
    <b>💳 Purchase Confirmation</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    <b>📋 Total:</b>
    <blockquote>
    • <b>Payment Method:</b> { gateway-type }
    • <b>Purchase:</b> 📱 Extra Devices { $device_count }
    {"────────────────────────"}
    { $has_discount ->
    [1]
    • <b>Amount to pay:</b> 💰 <s>{ $original_price }</s> { $total_price }
    *[0]
    • <b>Amount to pay:</b> 💰 { $total_price }
    }
    </blockquote>

    ⚠️ <i>The cost of extra devices is included in your subscription renewal price.</i>

    ⚠️ <i>You can remove extra devices in the "My Devices" menu.</i>

    { $is_balance_payment ->
        [1] {""}
        *[0] ⚠️ <i>Payment confirmation may take up to 5 minutes. Please do not repeat the payment.</i>
    }

msg-add-device-success-full =
    ✅ <i>{ $device_count } { $device_count_word } added to your subscription!</i>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    ⚠️ <i>The cost of extra devices is included in your subscription renewal price.</i>

    ⚠️ <i>You can remove extra devices in the "My Devices" menu.</i>

msg-extra-devices-list =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Extra Devices</b>
    { $purchases_empty ->
        [true] <i>You have no active extra devices.</i>
        *[false] <blockquote>
    💰 <b>Monthly cost:</b> { $total_monthly_cost }
    📱 <b>Total extra devices:</b> { $total_extra_devices }
    <i>Devices are active until the end of subscription month.</i>
    </blockquote>
    
    <i>Press ❌ to cancel device subscription.</i>
    }

msg-extra-device-manage =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Extra Device Management</b>
    
    <blockquote>
    • <b>Device count:</b> { $purchase_device_count }
    • <b>Cost/mo:</b> { $purchase_price } ₽
    • <b>Expires:</b> { $purchase_expires_at }
    • <b>Auto-renewal:</b> { $purchase_auto_renew ->
        [1] ✅ Enabled
        *[0] ❌ Disabled
    }
    </blockquote>
    
    { $purchase_auto_renew ->
        [1] <i>When auto-renewal is disabled, devices will be removed after expiration.</i>
        *[0] <i>Auto-renewal is disabled. Devices will be removed in { $purchase_days_remaining } days.</i>
    }

msg-add-device-confirm-details =
    📱 <b>Purchase:</b>
    <blockquote>
    • <b>Extra devices:</b> { $device_count }
    </blockquote>

    📋 <b>Total:</b>
    <blockquote>
    • <b>Payment method:</b> { $selected_method }
    • <b>Current balance:</b> { $balance }
    • <b>Balance after:</b> { $new_balance }
    </blockquote>

    💳<b>Confirm purchase:</b>

msg-balance-menu =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-status-full }

    <b>💰 Balance Management:</b>

msg-balance-select-gateway =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    <b>💰 Select payment method:</b>

msg-balance-select-amount =
    <b>💰 Balance Top-up</b>

    <blockquote>
    • <b>Payment method:</b> { $selected_gateway }
    </blockquote>

    Select top-up amount:

msg-balance-enter-amount =
    <b>💰 Balance Top-up</b>

    <blockquote>
    • <b>Payment method:</b> { $selected_gateway }
    </blockquote>

    Enter top-up amount (from { $min_amount } to { $max_amount } { $currency }):

msg-balance-confirm =
    <b>💰 Top-up Confirmation</b>

    <blockquote>• Purpose: 💰 Balance top-up
    • Payment method: 💳 { $selected_gateway }
    • Amount: 💰 { $topup_amount } { $currency }</blockquote>

    <i>⚠️ Payment confirmation may take up to 5 minutes. The menu will update automatically after confirmation.</i>

msg-balance-success =
    <b>✅ Balance topped up successfully!</b>
    
    <blockquote>
    <b>{ $amount }{ $currency }</b> credited to your account
    </blockquote>

msg-balance-transfer =
    <b>💸 Balance Transfer</b>

    { hdr-user-profile }
    <blockquote>
    { lbl-your-balance } <b>{ $balance }</b>
    { lbl-commission } { $commission_display }
    </blockquote>

    { hdr-transfer }
    <blockquote>
    { lbl-recipient } { $recipient_display }
    { lbl-transfer-amount } <b>{ $amount_display } ₽</b>
    { lbl-commission } <b>{ $transfer_commission } ₽</b>
    </blockquote>

    { hdr-message }
    <blockquote>
    { $message_display }
    </blockquote>

    { msg-fill-data-and-send }

msg-balance-transfer-recipient =
    <b>💸 Recipient</b>

    <blockquote>
    Enter recipient's <b>Telegram ID</b>:
    </blockquote>

msg-balance-transfer-recipient-history =
    <b>📜 User History</b>

    Select a recipient from the list of users you've previously transferred to:

msg-balance-transfer-no-history = <i>You don't have any transfer history yet.</i>

msg-balance-transfer-amount-value =
    <b>💸 Transfer Amount</b>

    <blockquote>
    • Current amount: { $current_display }
    • Change to: { $selected_display }
    </blockquote>

    Select an amount or enter your own:

msg-balance-transfer-amount-manual =
    <b>✏️ Manual Input</b>

    <blockquote>
    Enter transfer amount (from { $min_amount } to { $max_amount } ₽):
    </blockquote>

msg-balance-transfer-message =
    <b>💬 Message</b>

    <blockquote>
    { $message_display }
    </blockquote>

    <i>Enter a message for the transfer (max 200 characters):</i>

msg-balance-transfer-confirm =
    <b>💸 Transfer Confirmation</b>

    <blockquote>
    Recipient: <b>{ $recipient_name }</b> (<code>{ $recipient_id }</code>)
    Transfer amount: <b>{ $amount } ₽</b>
    Commission: <b>{ $commission } ₽</b>
    Total to deduct: <b>{ $total } ₽</b>
    </blockquote>

    ⚠️ <b>Warning:</b> This operation is irreversible!

msg-balance-transfer-success =
    <b>✅ Transfer completed successfully!</b>

    <blockquote>
    Recipient: <b>{ $recipient_name }</b>
    Amount: <b>{ $amount } ₽</b>
    Commission: <b>{ $commission } ₽</b>
    </blockquote>

msg-balance-transfer-error =
    <b>❌ Transfer Error</b>

    { $error }

msg-menu-invite =
    <b>👥 Invite Friends</b>

    { hdr-user-profile }
    { frg-user-invite }

    { hdr-subscription }{ frg-subscription-status-full }

    <b>🏆 Reward:</b>
    <blockquote>
    { $ref_reward_type ->
        [EXTRA_DAYS] { $ref_reward_strategy ->
            [PERCENT] • { $ref_reward_level_1_value }% of invitee's paid subscription days
            *[AMOUNT] • { $ref_reward_level_1_value } days for every 100 { $currency_symbol } topped up by invitee
        }
        [MONEY] { $ref_reward_strategy ->
            [AMOUNT] • { $ref_reward_level_1_value } { $currency_symbol } per invitee
            *[PERCENT] • { $ref_reward_level_1_value }% of the amount topped up by invitee
        }
        *[OTHER] • { $ref_reward_level_1_value } { $currency_symbol }
    }{ $ref_max_level ->
        [2] {""}
    
    { $ref_reward_type ->
        [EXTRA_DAYS] { $ref_reward_strategy ->
            [PERCENT] • { $ref_reward_level_2_value }% of invitee's invitees' paid subscription days
            *[AMOUNT] • { $ref_reward_level_2_value } days for every 100 { $currency_symbol } topped up by invitee's invitees
        }
        [MONEY] { $ref_reward_strategy ->
            [AMOUNT] • { $ref_reward_level_2_value } { $currency_symbol } per invitee's invitee
            *[PERCENT] • { $ref_reward_level_2_value }% of the amount topped up by invitee's invitees
        }
        *[OTHER] • { $ref_reward_level_2_value } { $currency_symbol }
    }
        *[1] {""}
    }
    </blockquote>

    <b>📊 Statistics:</b>
    <blockquote>
    👥 Total invited: { $referrals }
    💳 Payments via your link: { $payments }
    💳 Bonus received: { $total_bonus }{ $ref_reward_type ->
        [EXTRA_DAYS] { " " }days
        *[OTHER] {""}
    }
    💳 Cashback received: { $total_cashback }{ $ref_reward_type ->
        [EXTRA_DAYS] { " " }days
        *[OTHER] {""}
    }
    </blockquote>

    <i>ℹ️ Rewards are credited when users you invite make payments.</i>

msg-menu-invite-about =
    <b>🎁 More About Rewards</b>

    <b>✨ How to get rewards:</b>
    <blockquote>
    { $accrual_strategy ->
    [ON_FIRST_PAYMENT] Rewards are credited for the first subscription purchase by the invited user.
    [ON_EACH_PAYMENT] Rewards are credited for each purchase or subscription renewal by the invited user.
    *[OTHER] { $accrual_strategy }
    }
    </blockquote>

    <b>💎 What you get:</b>
    <blockquote>
    { $max_level -> 
    [1] For invited friends: { $reward_level_1 }
    *[MORE]
    { $identical_reward ->
    [0]
    1️⃣ For your friends: { $reward_level_1 }
    2️⃣ For friends invited by your friends: { $reward_level_2 }
    *[1]
    For your friends and friends invited by your friends: { $reward_level_1 }
    }
    }
    
    { $reward_strategy_type ->
    [AMOUNT] { $reward_type ->
        [MONEY] { space }
        [EXTRA_DAYS] <i>(All extra days are added to your current subscription)</i>
        *[OTHER] { $reward_type }
    }
    [PERCENT] { $reward_type ->
        [MONEY] <i>(Percentage of their purchased subscription cost)</i>
        [EXTRA_DAYS] <i>(Percentage of extra days from their purchased subscription)</i>
        *[OTHER] { $reward_type }
    }
    *[OTHER] { $reward_strategy_type }
    }
    </blockquote>

msg-invite-reward = { $value }{ $reward_strategy_type ->
    [AMOUNT] { $reward_type ->
        [POINTS] { space }{ $value -> 
            [one] point
            *[other] points
            }
        [EXTRA_DAYS] { space }extra { $value -> 
            [one] day
            *[other] days
            }
        [MONEY] ₽
        *[OTHER] { $reward_type }
    }
    [PERCENT] % { $reward_type ->
        [POINTS] points
        [EXTRA_DAYS] extra days
        [MONEY] of payment amount
        *[OTHER] { $reward_type }
    }
    *[OTHER] { $reward_strategy_type }
    }

msg-menu-invite-edit-code =
    ✏️ <b>Change Referral Code</b>

    <blockquote>• Current code: <code>{ $referral_code }</code></blockquote>

    <i>Enter your new referral code.</i>
    { $ref_code_error ->
        [invalid]

    ⚠️ <b>Invalid characters.</b>
    Allowed: A–Z, a–z, 0–9, _ - (length 3–32)
        [taken]

    ⚠️ This code is already taken. Choose another one.
        *[other] {""}
    }

# Dashboard
msg-dashboard-main =
    <b>🛠 Control Panel v{ $bot_version }</b> { $update_available ->
        [1] — 🔔 Update available: <b>{ $new_version }</b>
        *[0] {""}
    }
msg-bot-management =
    <b>🤖 Bot Management</b>
msg-mirror-bots =
    <b>🤖 Additional Bots</b>

    <blockquote>Here you can add mirror bots. Tap a bot to set it as <b>primary</b> - invite links will point to it.</blockquote>
msg-mirror-bot-add-token =
    <b>➕ Add New Bot</b>

    Send the API token for the new bot, obtained from @BotFather.
msg-dashboard-user-management =
    <b>👥 User Management</b>
msg-dashboard-features =
    <b>⚙️ Features</b>

    <blockquote>
    Here you can enable or disable various bot features.
    </blockquote>

msg-auto-cleanup =
    <b>🧹 User Auto Cleanup</b>

    <blockquote>
    Automatic deletion of EXPIRED users from Remnawave panel.
    User data in the bot is preserved.
    </blockquote>

    <b>Notification text:</b>
    <blockquote>{ $notify_text }</blockquote>

msg-auto-cleanup-days =
    <b>📅 Cleanup Threshold</b>

    <blockquote>
    How many days after subscription expiry to delete user from panel.
    </blockquote>

msg-auto-cleanup-days-manual =
    <b>✏️ Enter number of days</b>

    <blockquote>
    Enter a number from 1 to 365.
    </blockquote>

msg-auto-cleanup-notify-message-edit =
    <b>✏️ Notification Text</b>

    <blockquote>{ $notify_text }</blockquote>

    <i>Enter the notification text that will be sent to the user upon cleanup. HTML formatting is supported.</i>

msg-dashboard-extra-devices =
    <b>📱 Extra Devices</b>

    <b>Status:</b> { $enabled ->
        [1] ✅ Enabled
        *[0] ⬜ Disabled
    }
    <b>Cost:</b> { $price } ₽/mo per device

    <blockquote>
    Allows users to add extra devices to their subscription for an additional fee.
    </blockquote>

msg-dashboard-extra-devices-price =
    <b>💰 Change Extra Device Cost</b>

    <b>Current cost:</b> { $current_price } ₽

    Select a cost or enter manually:

msg-dashboard-extra-devices-price-manual =
    <b>💰 Manual Cost Entry</b>

    Enter new cost in rubles (integer from 0 to 100000):

msg-dashboard-extra-devices-settings =
    <b>📱 Extra Device Settings</b>

    <b>Current cost:</b> { $price } ₽ per device
    <b>Payment type:</b> { $is_one_time ->
    [1] One-time
    *[0] Monthly
    }

    <blockquote>
    <b>One-time</b> - user pays for devices once, they remain until deleted.
    
    <b>Monthly</b> - device cost is added with each subscription renewal.
    </blockquote>

msg-users-main = <b>👥 Users</b>
msg-broadcast-main = <b>📢 Broadcast</b>

msg-statistics-main = { $statistics }

msg-journal-main = { $journal }
    
msg-statistics-users =
    <b>👥 User Statistics</b>

    <blockquote>
    • <b>Total</b>: { $total_users }
    • <b>New today</b>: { $new_users_daily }
    • <b>New this week</b>: { $new_users_weekly }
    • <b>New this month</b>: { $new_users_monthly }

    • <b>With subscription</b>: { $users_with_subscription }
    • <b>Without subscription</b>: { $users_without_subscription }
    • <b>With trial</b>: { $users_with_trial }

    • <b>Blocked</b>: { $blocked_users }
    • <b>Blocked bot</b>: { $bot_blocked_users }

    • <b>User → purchase conversion</b>: { $user_conversion }%
    • <b>Trial → subscription conversion</b>: { $trial_conversion }%
    </blockquote>

msg-statistics-transactions =
    <b>🧾 Transaction Statistics</b>

    <blockquote>
    • <b>Total transactions</b>: { $total_transactions }
    • <b>Completed transactions</b>: { $completed_transactions }
    • <b>Free transactions</b>: { $free_transactions }
    { $popular_gateway ->
    [0] { empty }
    *[HAS] • <b>Popular payment system</b>: { $popular_gateway }
    }
    </blockquote>

    { $payment_gateways }

    { $bonus_gateways }

msg-statistics-subscriptions =
    <b>💳 Subscription Statistics</b>

    <blockquote>
    • <b>Active</b>: { $total_active_subscriptions }
    • <b>Expired</b>: { $total_expire_subscriptions }
    • <b>Trial</b>: { $active_trial_subscriptions }
    • <b>Expiring (7 days)</b>: { $expiring_subscriptions }
    </blockquote>

    <blockquote>
    • <b>Unlimited</b>: { $total_unlimited }
    • <b>Traffic limited</b>: { $total_traffic }
    • <b>Device limited</b>: { $total_devices }
    </blockquote>

msg-statistics-plans = 
    <b>📦 Plan Statistics</b>

    { $plans }

msg-statistics-extra-devices =
    <b>📱 Extra Devices Statistics</b>

    <b>From subscriptions:</b>
    <blockquote>
    • <b>Allocated slots</b>: { $subscription_total_slots }
    • <b>Occupied slots</b>: { $subscription_active_slots }
    </blockquote>

    <b>Bonus:</b>
    <blockquote>
    • <b>Allocated slots</b>: { $bonus_total_slots }
    • <b>Occupied slots</b>: { $bonus_active_slots }
    </blockquote>

    <b>Purchased:</b>
    <blockquote>
    • <b>Allocated slots</b>: { $purchased_total_slots }
    { $per_plan_total_details }

    • <b>Activated</b>: { $purchased_active_slots }
    { $per_plan_active_details }
    </blockquote>

msg-statistics-promocodes =
    <b>🎁 Promo Code Statistics</b>

    <blockquote>
    • <b>Total activations</b>: { $total_promo_activations }
    • <b>Most popular promo code</b>: { $most_popular_promo ->
    [0] { unknown }
    *[HAS] { $most_popular_promo }
    }
    • <b>Days issued</b>: { $total_promo_days }
    • <b>Traffic issued</b>: { $total_promo_days }
    • <b>Subscriptions issued</b>: { $total_promo_subscriptions }
    • <b>Personal discounts issued</b>: { $total_promo_personal_discounts }
    • <b>One-time discounts issued</b>: { $total_promo_purchase_discounts }
    </blockquote>

msg-statistics-referrals =
    <b>👪 Referral System Statistics</b>
    
    <blockquote>
    • <b></b>:
    </blockquote>

msg-statistics-transactions-gateway =
    <b>{ gateway-type }:</b>
    <blockquote>
    • <b>Total income</b>: { $total_income }{ $currency }
    • <b>Daily income</b>: { $daily_income }{ $currency }
    • <b>Weekly income</b>: { $weekly_income }{ $currency }
    • <b>Monthly income</b>: { $monthly_income }{ $currency }
    • <b>Average check</b>: { $average_check }{ $currency }
    • <b>Total discounts</b>: { $total_discounts }{ $currency }
    </blockquote>

msg-statistics-plan =
    <b>{ $plan_name }:</b> { $popular -> 
    [0] { space }
    *[HAS] (⭐)
    }
    <blockquote>
    • <b>Total subscriptions</b>: { $total_subscriptions }
    • <b>Active subscriptions</b>: { $active_subscriptions }
    • <b>Popular duration</b>: { $popular_duration }

    • <b>Total income</b>: 
    { $all_income }
    </blockquote>

msg-statistics-plan-income = { $income }{ $currency }
    


# Access
msg-access-main =
    <b>🔓 Access Mode</b>
    
    <blockquote>
    • <b>Mode</b>: { access-mode }
    • <b>Purchases</b>: { $purchases_allowed ->
    [0] disabled
    *[1] enabled
    }.
    • <b>Registration</b>: { $registration_allowed ->
    [0] disabled
    *[1] enabled
    }.
    </blockquote>

msg-access-conditions =
    <b>⚙️ Access Conditions</b>

msg-access-rules =
    <b>✳️ Change Rules Link</b>

    Enter the link (in format https://telegram.org/tos).
    
    This value is also used in the <b>User Agreement</b> menu.

msg-access-channel =
    <b>❇️ Change Channel/Group Link</b>

    If your group doesn't have a @username, send the group ID and invitation link in separate messages.
    
    If you have a public channel/group, just enter the @username.


# Broadcast
msg-broadcast-list = <b>📄 Broadcast List</b>
msg-broadcast-plan-select = <b>📦 Select plan for broadcast</b>
msg-broadcast-send = <b>📢 Send Broadcast ({ audience-type })</b>

    { $audience_count } { $audience_count ->
    [one] user
    *[other] users
    } will receive the broadcast

msg-broadcast-content =
    <b>✉️ Broadcast Content</b>

    <b>Current content:</b>

    { $has_content ->
        [1] <blockquote>{ $current_content }</blockquote>
        *[other] <blockquote>• Not filled</blockquote>
    }

    <i>Send any message: text, image or both together (HTML supported).</i>

msg-broadcast-buttons = <b>✳️ Broadcast Buttons</b>

msg-broadcast-view =
    <b>📢 Broadcast</b>

    <blockquote>
    • <b>ID</b>: <code>{ $broadcast_id }</code>
    • <b>Status</b>: { broadcast-status }
    • <b>Audience</b>: { audience-type }
    • <b>Created</b>: { $created_at }
    </blockquote>

    <blockquote>
    • <b>Total messages</b>: { $total_count }
    • <b>Successful</b>: { $success_count }
    • <b>Failed</b>: { $failed_count }
    </blockquote>


# Users
msg-users-recent-registered = <b>🆕 Recently Registered</b>
msg-users-recent-activity = <b>📝 Recently Active</b>
msg-users-all = <b>👥 All Users</b>
msg-user-transactions = <b>🧾 User Transactions</b>
msg-admin-change-device-days =
    <b>⏳ Change device duration</b>

    Enter the new number of days for this device slot:

msg-admin-add-device-days =
    <b>➕ Add Device</b>

    Enter the number of days for the extra device (default 30):

msg-user-devices = <b>📱 User Devices ({ $current_count } / { $max_count })</b>
msg-user-give-access = <b>🔑 Grant Plan Access</b>

msg-users-search =
    <b>🔍 User Search</b>

    Enter user ID, part of name, or forward any message from them.

msg-users-search-results =
    <b>🔍 User Search</b>

    Found <b>{ $count }</b> { $count ->
    [one] user
    *[other] users
    } matching the query

msg-user-main = 
    <b>📝 User Information</b>

    { hdr-user-profile }
    { frg-user-details }

    <b>💸 Discount:</b>
    <blockquote>
    • <b>Personal</b>: { $personal_discount }%
    • <b>Next purchase</b>: { $purchase_discount }%
    </blockquote>
    
    { hdr-subscription }
    { frg-subscription-status-short }

msg-user-referrals = 
    <b>👥 User Referrals</b>

    <b>Referral count:</b> { $referral_count }
    <b>Bonus received:</b> { $total_bonus }
    <b>Cashback received:</b> { $total_cashback }

msg-user-referrals-list =
    <b>📋 Referral List</b>

msg-user-referral-bind = 
    <b>🔗 Bind Referral</b>

    Enter Telegram ID or @username of the user you want to bind as a referral.

msg-user-delete-confirm =
    <b>❌ Delete User</b>

    <i>Are you sure? This action cannot be undone.</i>

msg-user-sync = 
    <b>🌀 Synchronize User</b>

    <b>🛍 Telegram:</b>
    <blockquote>
    { $has_bot_subscription -> 
    [0] No data
    *[HAS]{ $bot_subscription }
    }
    </blockquote>

    <b>🌊 Panel:</b> { $remna_version }
    <blockquote>
    { $has_remna_subscription -> 
    [0] No data
    *[HAS] { $remna_subscription }
    }
    </blockquote>

    Select current data for synchronization.

msg-user-sync-version = { $version ->
    [NEWER] (newer)
    [OLDER] (older)
    *[UNKNOWN] { empty }
    }

msg-user-sync-subscription =
    • <b>ID</b>: <code>{ $id }</code>
    • Status: { $status -> 
    [ACTIVE] Active
    [DISABLED] Disabled
    [LIMITED] Traffic exhausted
    [EXPIRED] Expired
    [DELETED] Deleted
    *[OTHER] { $status }
    }
    • Link: <a href="{ $url }">*********</a>

    • Traffic limit: { $traffic_limit }
    • Device limit: { $device_limit }
    • Remaining: { $expire_time }

    • Internal squads: { $internal_squads ->
    [0] { unknown }
    *[HAS] { $internal_squads }
    }
    • External squad: { $external_squad ->
    [0] { unknown }
    *[HAS] { $external_squad }
    }
    • Traffic reset: { $traffic_limit_strategy -> 
    [NO_RESET] On payment
    [DAY] Every day
    [WEEK] Every week
    [MONTH] Every month
    *[OTHER] { $traffic_limit_strategy }
    }
    • Tag: { $tag -> 
    [0] { unknown }
    *[HAS] { $tag }
    }

msg-user-sync-waiting =
    <b>🌀 User Synchronization</b>

    Please wait... User data synchronization in progress. You will automatically return to the user editor upon completion.

msg-user-give-subscription =
    <b>🎁 Grant Subscription</b>

    Select the plan you want to grant to the user.

msg-user-give-subscription-duration =
    <b>⏳ Select Duration</b>

    Select the duration of the subscription to grant.

msg-user-discount =
    <b>💸 Change Personal Discount</b>

    Select from button or enter your own value.

msg-user-balance-menu =
    <b>💰 User Balance</b>

    <b>Main balance:</b> { $current_balance } ₽
    <b>Referral balance:</b> { $referral_balance } ₽

    Select balance type to edit:

msg-user-finance-menu-full =
    <b>💰 Finance Management</b>

    { $is_balance_enabled ->
        [1] <b>Main balance:</b> { $current_balance } ₽
        *[0] {""}
    }
    { $is_referral_enable ->
        [1] <b>Bonus balance:</b> { $referral_balance } ₽
        *[0] {""}
    }
    <b>Permanent discount:</b> { $discount_value }%

    Select an item to edit:

msg-user-finance-menu-short =
    <b>💰 Finance Management</b>

    <b>Permanent discount:</b> { $discount_value }%

    Select an item to edit:

msg-user-main-balance =
    <b>💰 Main Balance</b>

    <b>Current balance: { $current_balance } ₽</b>
    { $has_pending_balance ->
        [1] <b>Pending: { $pending_balance_amount } ₽</b>
        *[0] {""}
    }

    Select an amount or enter your own value.

msg-user-referral-balance =
    <b>🎁 Bonus Balance</b>

    <b>Current balance: { $current_referral_balance } ₽</b>
    { $has_pending_referral ->
        [1] <b>Pending: { $pending_referral_amount } ₽</b>
        *[0] {""}
    }

    Select an amount or enter your own value.

msg-user-points =
    <b>💎 Change Balance</b>

    <b>Current balance: { $current_balance } ₽</b>

    Select from button or enter your own value to add or subtract.

msg-user-subscription-traffic-limit =
    <b>🌐 Change Traffic Limit</b>

    Select from button or enter your own value (in GB) to change traffic limit.

msg-user-subscription-device-limit =
    <b>📱 Bonus Devices</b>

    • Select number of bonus devices for the user, or enter a number from 0 to 100

msg-user-subscription-expire-time =
    <b>⏳ Change Expiration Time</b>

    <b>Expires in: { $expire_time }</b>

    Select from button or enter your own value (in days) to add or subtract.

msg-user-subscription-squads =
    <b>🔗 Squads</b>

    • Internal squad: { $internal_squads ->
    [0] not selected
    *[HAS] { $internal_squads }
    }
    • External squad: { $external_squad ->
    [0] not selected
    *[HAS] { $external_squad }
    }

    ✏️ Select squads:

msg-user-subscription-internal-squads =
    <b>⏺️ Change Internal Squads List</b>

    Select which internal groups will be assigned to this user.

msg-user-subscription-external-squads =
    <b>⏹️ Change External Squad</b>

    Select which external group will be assigned to this user.

msg-user-subscription-empty =
    <b>💳 Subscription Information</b>

    This user has no active subscription.

msg-user-subscription-info =
    <b>💳 Current Subscription Information</b>
    
    <b>💳 Subscription:</b>
    { frg-subscription-details }

    <blockquote>
    • <b>Squads</b>: { $squads -> 
    [0] { unknown }
    *[HAS] { $squads }
    }
    • <b>First connected</b>: { $first_connected_at -> 
    [0] { unknown }
    *[HAS] { $first_connected_at }
    }
    • <b>Last connected</b>: { $last_connected_at ->
    [0] { unknown }
    *[HAS] { $last_connected_at } ({ $node_name })
    } 
    </blockquote>

    { hdr-plan }
    { frg-plan-snapshot }

msg-user-transaction-info =
    <b>🧾 Transaction Information</b>

    { hdr-payment }
    <blockquote>
    • <b>ID</b>: <code>{ $payment_id }</code>
    • <b>Type</b>: { purchase-type }
    • <b>Status</b>: { transaction-status }
    • <b>Payment method</b>: { gateway-type }
    • <b>Amount</b>: { frg-payment-amount }
    • <b>Created</b>: { $created_at }
    </blockquote>

    { $is_test -> 
    [1] ⚠️ Test transaction
    *[0]
    { hdr-plan }
    { frg-plan-snapshot }
    }
    
msg-user-role = 
    <b>👮‍♂️ Change Role</b>
    
    Select a new role for the user.

msg-users-blacklist =
    <b>🚫 Blacklist</b>

    Blocked: <b>{ $count_blocked }</b> / <b>{ $count_users }</b> ({ $percent }%).

msg-user-message =
    <b>📩 Send Message to User</b>

    Send any message: text, image or both together (HTML supported).
    

# Panel
msg-monitoring =
    <b>📡 Monitoring</b>

    <b>👥 Users</b>
    <blockquote>
    • <b>Total</b>: { $users_total }
    • <b>Active</b>: { $users_active }
    • <b>Disabled</b>: { $users_disabled }
    • <b>Limited</b>: { $users_limited }
    • <b>Expired</b>: { $users_expired }
    • <b>Total online</b>: { $total_online }
    </blockquote>

    <b>📊 Statistics:</b>
    <blockquote>
    • <b>Total servers</b>: { $total_servers }
    • <b>Available</b>: { $available_servers }
    </blockquote>

    <b>📋 Server list:</b>
    <blockquote>
    { $servers_list }
    </blockquote>

msg-monitoring-no-servers = No servers available


# Telegram
msg-remnashop-main = <b>🛍 Telegram</b>
msg-admins-main = <b>👮‍♂️ Administrators</b>


# Gateways
msg-gateways-main = <b>🌐 Payment Systems</b>
msg-gateways-settings = <b>🌐 { gateway-type } Configuration</b>
msg-gateways-settings-detail =
    <b>⚙️ System settings: { gateway-type }</b>

    { $settings_display }

    Choose what to change:
msg-gateways-default-currency = <b>💸 Default Currency</b>
msg-gateways-placement = <b>🔢 Change Positioning</b>

msg-gateways-field =
    <b>🌐 { gateway-type } Configuration</b>

    Enter a new value for { $field }.


# Referral
msg-referral-main =
    <b>👥 Referral System</b>

    <blockquote>
    • <b>Status</b>: { $is_enable -> 
        [1] 🟢 Enabled
        *[0] 🔴 Disabled
        }
    • <b>Reward type</b>: { reward-type }
    • <b>Number of levels</b>: { $level_text }
    • <b>Accrual condition</b>: { accrual-strategy }
    • <b>Accrual form</b>: { reward-strategy }
    • <b>Reward</b>: { $reward_display }
    </blockquote>

    🔽 Select item to change.

msg-referral-level =
    <b>🔢 Change Level</b>

    Select number of referral system levels.

msg-referral-reward-type =
    <b>🎀 Change Reward Type</b>

    Select reward type for invited users.
    
msg-referral-accrual-strategy =
    <b>📍 Change Accrual Condition</b>

    Select the condition under which rewards will be credited.


msg-referral-reward-strategy =
    <b>⚖️ Change Accrual Form</b>

    Select reward calculation method.
    
    <i>When selecting "Days" type: N days are credited for every 100 rubles topped up/purchased.</i>


msg-referral-reward-level = { $level } level: { $value }{ $reward_strategy_type ->
    [AMOUNT] { $reward_type ->
        [POINTS] { space }{ $value -> 
            [one] point
            *[other] points
            }
        [EXTRA_DAYS] { space }extra { $value -> 
            [one] day
            *[other] days
            }
        [MONEY] ₽
        *[OTHER] { $reward_type }
    }
    [PERCENT] % { $reward_type ->
        [POINTS] points
        [EXTRA_DAYS] extra days
        [MONEY] of payment amount
        *[OTHER] { $reward_type }
    }
    *[OTHER] { $reward_strategy_type }
    }
    
msg-referral-reward =
    <b>🎁 Change Reward</b>

    <blockquote>
    { $reward }
    </blockquote>

    { $reward_type ->
        [EXTRA_DAYS] Select number of days per every 100₽ topped up/purchased, or enter value manually.
        *[OTHER] Select reward amount or enter value manually.
    }

msg-referral-reward-manual =
    <b>✏️ Manual Reward Entry</b>

msg-referral-invite-message =
    <b>✉️ Invitation Message Settings</b>

    🔽 Select an action:

msg-referral-invite-edit =
    <b>✉️ Invitation Message Settings</b>

    ℹ️ Available variables:
    <blockquote>
    • <code>{"{url}"}</code> - referral link
    • <code>{"{space}"}</code> - empty line at the beginning (not visible in preview)
    </blockquote>

    <i>✏️ Enter your invitation:</i>

msg-referral-invite-preview =

    { $preview_message }

# Plans
msg-plans-main = <b>📦 Plans</b>

msg-plan-configurator =
    <b>📦 Plan Configurator</b>

    <b>Plan</b>
    <blockquote>
    • <b>Name</b>: { $name }
    • <b>Tag</b>: { $tag }
    • <b>Internal squad</b>: { $internal_squads ->
    [0] { lbl-not-set }
    *[HAS] { $internal_squads }
    }
    • <b>External squad</b>: { $external_squad ->
    [0] { lbl-not-set }
    *[HAS] { $external_squad }
    }
    </blockquote>

    <b>Restrictions</b>
    <blockquote>
    • <b>Access</b>: { availability-type }
    • <b>Type</b>: { plan-type }
    • <b>Traffic limit</b>: { $is_unlimited_traffic ->
        [1] { unlimited }
        *[0] { $traffic_limit }
    }
    • <b>Device limit</b>: { $is_unlimited_devices ->
        [1] { unlimited }
        *[0] { $device_limit }
    }
    { $is_unlimited_devices ->
        [1] { "" }
        *[0] • <b>Extra device price</b>: { $device_price ->
            [0] not set
            *[other] { $device_price } ₽/mo
        }
    }
    • <b>Status</b>: { $is_active ->
        [1] 🟢 Enabled
        *[0] 🔴 Disabled
    }
    </blockquote>

    Select item to change.

msg-plan-name =
    <b>🏷️ Change Name</b>

    { $name ->
    [0] { space }
    *[HAS]
    <blockquote>
    { $name }
    </blockquote>
    }

    Enter new plan name.

msg-plan-description =
    <b>💬 Change Description</b>

    <blockquote>
    Description: { $description }
    </blockquote>

    Enter new plan description.

msg-plan-tag =
    <b>📌 Change Tag</b>

    <blockquote>
    Tag: { $tag }
    </blockquote>

    <i>ℹ️ Use uppercase Latin letters, numbers and underscore.</i>

    ✏️ Enter tag for the plan:

msg-plan-type =
    <b>🔖 Change Type</b>

    Select new plan type.

msg-plan-availability =
    <b>✴️ Change Availability</b>

    Select plan availability.

msg-plan-traffic =
    <b>🌐 Change Traffic Limit and Reset Strategy</b>

    Enter new plan traffic limit (in GB) and select reset strategy.

msg-plan-devices =
    <b>📱 Change Device Limit</b>

    Enter new plan device limit.

msg-plan-device-price =
    <b>📱 Extra Device Price</b>

    Current price: <b>{ $device_price } ₽/mo</b>

    Enter new extra device purchase price (in rubles per month) or select from the list below.

msg-plan-device-prices =
    <b>📱 Extra Devices Price</b>

    Select a plan to change the extra device price.

msg-plan-durations =
    <b>⏳ Plan Durations</b>

    Select duration to change price.

msg-plan-duration =
    <b>⏳ Add Plan Duration</b>

    Enter new duration (in days).

msg-plan-prices =
    <b>💰 Change Tariff Price for ({ $value ->
            [-1] { unlimited }
            *[other] { unit-day }
        })</b>

    Specify price in rubles.
    Prices in other currencies will be calculated automatically based on exchange rate.

msg-plan-price =
    <b>💰 Change Price for Tariff ({ $value ->
            [-1] { unlimited }
            *[other] { unit-day }
        })</b>

    Enter new price in rubles (₽).

msg-plan-allowed-users = 
    <b>👥 Change Allowed Users List</b>

    Enter user ID to add to the list.

msg-plan-squads =
    <b>🔗 Squads</b>

    <blockquote>
    • <b>Internal</b>: { $internal_squads ->
    [0] { lbl-not-set }
    *[HAS] { $internal_squads }
    }
    • <b>External</b>: { $external_squad ->
    [0] { lbl-not-set }
    *[HAS] { $external_squad }
    }
    </blockquote>

    ✏️ Select required squads:

msg-plan-internal-squads =
    <b>⏺️ Change Internal Squads List</b>

    Select which internal groups will be assigned to this plan.

msg-plan-external-squads =
    <b>⏹️ Change External Squad</b>

    Select which external group will be assigned to this plan.


# Notifications
msg-notifications-main = <b>🔔 Notification Settings</b>
msg-notifications-user = <b>👥 User Notifications</b>
msg-notifications-system = <b>⚙️ System Notifications</b>


# Subscription
msg-subscription-key-title = 
    🔑 <b>Your subscription key:</b>

msg-subscription-main =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    { $trial_available ->
    [1] {""}
    *[0] <b>💳 Subscription Management:</b>
    }

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    { $trial_available ->
    [1]
    { $is_referral_trial ->
    [1]
    { $is_referral_enable ->
    [1] <i>📢 A free referral subscription is available for you.</i>
    *[0] {""}
    }
    *[0]
    <i>🎁 A free trial subscription is available for you.</i>
    }
    *[0] {""}
    }
msg-subscription-plans =
    <b>📦 Plan Selection:</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }
msg-subscription-new-success = ✅ <i>Plan { $plan_name } has been activated.</i>
msg-subscription-renew-success = ✅ <i>Your subscription has been successfully renewed!</i>

msg-subscription-details =
    <b>💳 Subscription Being Purchased:</b>
    <blockquote>
    • <b>Plan:</b> { $plan_name }
    • <b>Traffic limit</b>: { $traffic }
    { $devices ->
    [0] { empty }
    *[HAS] • <b>Device limit</b>: { $devices }{ $has_planned_extra_devices ->
        [1] {" "}(+{ $planned_extra_devices } extra)
        *[0] {""}
    }
    }{ $purchase_type ->
        [RENEW] { $renew_extra_devices ->
            [0] {""}
            *[other] {"\u000A"}• <b>Extra devices:</b> { $renew_extra_devices } pcs.
        }
        *[OTHER] {""}
    }
    { $period ->
    [0] { empty }
    *[HAS] • <b>Duration</b>: { $period }
    }{ $description ->
    [0] {""}
    *[HAS] {""}
    • <b>Description:</b> <i>{ $description }</i>
    }
    </blockquote>

msg-subscription-duration =
    { $single_duration ->
    [1] {""}
    *[0] <b>⏳ Select Duration</b>
    }

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    { msg-subscription-details }

msg-subscription-payment-method =
    <b>💳 Select Payment Method</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    <b>💳 Subscription Being Purchased:</b>
    <blockquote>
    • <b>Plan:</b> { $plan_name }
    • <b>Traffic limit</b>: { $traffic }
    • <b>Device limit</b>: { $device_limit }{ $is_plan_device_unlimited ->
        [0] {" "}pcs.
        *[1] {""}
    }{ $purchase_type ->
        [RENEW] { $renew_extra_devices ->
            [0] {""}
            *[other] {"\u000A"}• <b>Extra devices:</b> { $renew_extra_devices } pcs.
        }
        *[OTHER] {""}
    }
    • <b>Duration:</b> { $period }
    { $description ->
    [0] {""}
    *[HAS] {""}
    • <b>Description:</b> <i>{ $description }</i>
    }
    </blockquote>

msg-subscription-confirm-balance =
    <b>✅ Payment Confirmation</b>

    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    <b>📋 Total:</b>
    <blockquote>
    • <b>Payment Method:</b> 💰 From Balance{ $discount_percent ->
        [0] {""}
        *[OTHER] {"\u000A"}• <b>Discount:</b> { $discount_percent }%
    }
    • <b>Subscription price:</b> { $subscription_price }{ $discount_percent ->
        [0] {""}
        *[OTHER] {" "}<s>{ $original_subscription_price }</s>
    }{ $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Extra devices:</b> { $extra_devices_cost }
            *[0] {""}
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Extra devices:</b> { $extra_devices_cost }
            *[0] {""}
        }
        *[OTHER] {""}
    }
    {"────────────────────────"}
    • <b>Total amount:</b> 💰 { $total_payment }{ $discount_percent ->
        [0] {""}
        *[OTHER] {" "}<s>{ $original_total }</s>
    }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Your current subscription will be renewed.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
            *[0] ⚠️ <i>Subscription will be replaced without recalculating remaining time, and extra devices will be removed.</i>
        }
    }
        *[OTHER] {""}
    }

msg-subscription-confirm-yoomoney =
    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    <b>📋 Total:</b>
    <blockquote>
    • <b>Payment Method:</b> 💳 YooMoney{ $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Extra Devices:</b> { $extra_devices_cost } ({ $extra_devices_monthly_cost }/mo)
            *[0] {""}
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Extra Devices:</b> { $extra_devices_cost }
            *[0] {""}
        }
        *[OTHER] {""}
    }
    • <b>Amount to Pay:</b> 💰 { $total_payment }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Your current subscription will be renewed.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
            *[0] ⚠️ <i>Subscription will be replaced without recalculating remaining time, and extra devices will be removed.</i>
        }
    }
        *[OTHER] {""}
    }

    <i>⚠️ Payment confirmation may take up to 5 minutes. The menu will update automatically after confirmation.</i>

msg-subscription-confirm-yookassa =
    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    <b>📋 Total:</b>
    <blockquote>
    • <b>Payment Method:</b> 💳 YooKassa
    { $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] • <b>Subscription:</b> 💳 { $original_amount }
    • <b>Extra Devices:</b> { $extra_devices_cost } ({ $extra_devices_monthly_cost }/mo)
            *[0] • <b>Subscription:</b> 💳 { $original_amount }
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] • <b>Subscription:</b> 💳 { $original_amount }
    • <b>Extra Devices:</b> { $extra_devices_cost }
            *[0] • <b>Subscription:</b> 💳 { $original_amount }
        }
        *[OTHER] • <b>Subscription:</b> 💳 { $original_amount }
    }
    • <b>Amount to Pay:</b> 💰 { $total_payment }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Your current subscription will be renewed.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
            *[0] ⚠️ <i>Subscription will be replaced without recalculating remaining time, and extra devices will be removed.</i>
        }
    }
        *[OTHER] {""}
    }

    <i>⚠️ Payment confirmation may take up to 5 minutes. The menu will update automatically after confirmation.</i>

msg-subscription-confirm =
    { $is_free ->
        [1] <b>🎁 Confirmation</b>
        *[0] {""}
    }
    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    { $is_free ->
        [1] { $purchase_type ->
        [RENEW] <i>⚠️ Your current subscription will be renewed.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
            *[0] ⚠️ <i>Subscription will be replaced without recalculating remaining time, and extra devices will be removed.</i>
        }
    }
        *[OTHER] {""}
    }
        *[0] <b>📋 Total:</b>
    <blockquote>
    • <b>Payment Method:</b> { gateway-type }{ $discount_percent ->
        [0] {""}
        *[OTHER] {"\u000A"}• <b>Discount:</b> { $discount_percent }%
    }{ $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Extra Devices:</b> { $extra_devices_cost } ({ $extra_devices_monthly_cost }/mo)
            *[0] {""}
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Extra Devices:</b> { $extra_devices_cost }
            *[0] {""}
        }
        *[OTHER] {""}
    }
    • <b>Amount to Pay:</b> 💰 { $total_payment }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Your current subscription will be renewed.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Current subscription will be replaced without recalculating remaining time.</i>
            *[0] ⚠️ <i>Subscription will be replaced without recalculating remaining time, and extra devices will be removed.</i>
        }
    }
        *[OTHER] {""}
    }

    <i>⚠️ Payment confirmation may take up to 5 minutes. The menu will update automatically after confirmation.</i>
    }

msg-subscription-trial =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    <b>✅ Trial subscription successfully received!</b>

msg-subscription-referral-code =
    <b>📢 Referral Subscription</b>

    Enter the referral code of the user who invited you:

msg-subscription-referral-success =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    <b>🎉 Subscription successfully upgraded to Referral!</b>

msg-subscription-referral-attached =
    <b>🎉 Congratulations!</b>

    You have joined the referral program and will now receive additional bonuses when topping up your balance!

msg-subscription-promocode =
    <b>🎟 Enter Promo Code</b>

    Send the promo code to activate bonuses or discounts.

    You can enter a user's <b>referral code</b> to participate in the referral program.

msg-subscription-success =
    { $purchase_type ->
    [ADD_DEVICE] ✅<i>{ $device_count } { $device_count ->
        [1] device
        *[other] devices
    } added to your subscription!</i>
    [NEW] { msg-subscription-new-success }
    [RENEW] { msg-subscription-renew-success }
    [CHANGE] { msg-subscription-change-success }
    *[OTHER] {""}
    }

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

msg-subscription-new-success = ✅ <i>The { $plan_name } plan has been activated.</i>
msg-subscription-renew-success = ✅ <i>Your subscription has been successfully renewed!</i>
msg-subscription-change-success = ✅<i>Your subscription has been changed.</i>

msg-subscription-failed = 
    <b>❌ An error occurred!</b>

    Don't worry, support has been notified and will contact you soon. We apologize for the inconvenience.


# Importer
msg-importer-main =
    <b>📥 User Import</b>

    Starting synchronization: checking all users in the Panel. If a user is not in the bot database, they will be created and receive a temporary subscription. If user data differs, it will be automatically updated.

msg-importer-from-xui =
    <b>📥 User Import (3X-UI)</b>
    
    { $has_exported -> 
    [1]
    <b>🔍 Found:</b>
    <blockquote>
    Total users: { $total }
    With active subscription: { $active }
    With expired subscription: { $expired }
    </blockquote>
    *[0]
    All active users with numeric email are imported.

    It is recommended to disable users who don't have a Telegram ID in the email field beforehand. The operation may take considerable time depending on the number of users.

    Send the database file (in .db format).
    }

msg-importer-squads =
    <b>🔗 Internal Squads List</b>

    Select which internal groups will be available to imported users.

msg-importer-import-completed =
    <b>📥 User Import Completed</b>
    
    <b>📃 Information:</b>
    <blockquote>
    • <b>Total users</b>: { $total_count }
    • <b>Successfully imported</b>: { $success_count }
    • <b>Failed to import</b>: { $failed_count }
    </blockquote>

msg-importer-sync-completed =
    <b>📥 User Synchronization Completed</b>

    <b>📃 Information:</b>
    <blockquote>
    Total users in panel: { $total_panel_users }
    Total users in bot: { $total_bot_users }

    New users: { $added_users }
    Subscriptions added: { $added_subscription }
    Subscriptions updated: { $updated}
    
    Users without Telegram ID: { $missing_telegram }
    Synchronization errors: { $errors }
    </blockquote>

msg-importer-sync-bot-to-panel-completed =
    <b>📤 Synchronization from Telegram to Panel Completed</b>

    <b>📃 Information:</b>
    <blockquote>
    Total users in bot: { $total_bot_users }

    Created in panel: { $created }
    Updated in panel: { $updated }
    Skipped (no subscription): { $skipped }
    Synchronization errors: { $errors }
    </blockquote>


# Promocodes
msg-promocodes-main = <b>🎟 Promo Codes</b>

    Create and manage promo codes for users.

msg-promocodes-search = <b>🔍 Promo Code Search</b>

    Enter promo code to search.

msg-promocodes-list = <b>📃 Promo Code List</b>

    { $count ->
        [0] No promo codes created.
        [1] Found { $count } promo code.
        *[other] Found { $count } promo codes.
    }

msg-promocode-view =
    <b>🎟 View Promo Code</b>

    <blockquote>
    • <b>Code</b>: <code>{ $code }</code>
    • <b>Type</b>: { promocode-type }
    • <b>Status</b>: { $is_active -> 
        [1] 🟢 Enabled
        *[0] 🔴 Disabled
        }
    </blockquote>

    <blockquote>
    { $promocode_type ->
    [DURATION] • <b>Bonus</b>: +{ $reward }
    [PERSONAL_DISCOUNT] • <b>Permanent discount</b>: { $reward }%
    [PURCHASE_DISCOUNT] • <b>One-time discount</b>: { $reward }%
    *[OTHER] • <b>Reward</b>: { $reward }
    }
    • <b>Validity</b>: { $lifetime }
    • <b>Used</b>: { $activations_count } / { $max_activations }
    </blockquote>

msg-promocode-configurator =
    <b>🎟 Create Promo Code</b>

    <blockquote>
    • <b>Name</b>: { $name }
    • <b>Code</b>: <code>{ $code }</code>
    • <b>Reward type</b>: { promocode-type }
    </blockquote>

    <blockquote>
    { $promocode_type ->
    [DURATION] • <b>Bonus</b>: +{ $reward }
    [PERSONAL_DISCOUNT] • <b>Permanent discount</b>: { $reward }%
    [PURCHASE_DISCOUNT] • <b>One-time discount</b>: { $reward }%
    *[OTHER] • <b>Reward</b>: { $reward }
    }
    • <b>Validity</b>: { $lifetime }
    • <b>Activation limit</b>: { $max_activations }
    </blockquote>

    Select item to change.

msg-promocode-name = <b>📝 Promo Code Name</b>

    Enter promo code name (1-50 characters).

msg-promocode-code = <b>🏷️ Promo Code</b>

    Enter promo code (3-20 characters) or press button to generate random code.

msg-promocode-type = <b>🔖 Select Promo Code Type:</b>

    <blockquote>
    • <b>One-time discount</b> - discount will expire after first purchase, or when promo code validity ends.

    • <b>Permanent discount</b> - permanent discount for the user.

    • <b>Days to subscription</b> - Adding days to user's subscription.
    </blockquote>

msg-promocode-reward = <b>🎁 Reward</b>

    <b>Reward type</b>: { promocode-type }

    { $promocode_type ->
    [DURATION] Enter <b>number of days</b> for subscription bonus.
    [PERSONAL_DISCOUNT] Enter <b>discount percentage</b> (1-100) for permanent discount.
    [PURCHASE_DISCOUNT] Enter <b>discount percentage</b> (1-100) for purchase discount.
    *[OTHER] Enter reward value.
    }

msg-promocode-lifetime = <b>⌛ Validity Period</b>

    Select promo code validity period in days.

msg-promocode-lifetime-input = ⌛️Enter promo code validity period in days.

msg-promocode-quantity = <b>🔢 Activation Count</b>

    Select maximum promo code activation count.

msg-promocode-quantity-input = 🔢 Enter promo code activation count.
msg-promocode-access = <b>📦 Plan Access</b>

# Bonus Activation
msg-bonus-activate =
    <b>💎 Bonus Activation</b>

    Available bonuses: <b>{ $referral_balance }</b>
    Selected amount: <b>{ $current_bonus_amount } ₽</b>

msg-bonus-activate-custom =
    <b>💎 Bonus Activation</b>

    Available bonuses: <b>{ $referral_balance }</b>

    Enter amount to activate (from 1 to { $referral_balance }):

# Terms of Service Settings
msg-dashboard-settings-tos =
    <b>📋 User Agreement</b>
    
    <blockquote>
    • Status: { $status }
    • Source: { $source }
    </blockquote>

    🔽 Specify link to the rules document.

msg-dashboard-settings-tos-url =
    <b>🔗 Agreement Link</b>

    <blockquote>
    Enter the link (in format https://telegram.org/tos).
    </blockquote>

# Community Settings
msg-dashboard-settings-community =
    <b>👥 Community</b>
    
    <blockquote>
    • Status: { $status }
    • Telegram group: { $url_display }
    </blockquote>

    🔽 Specify link to Telegram group.

msg-dashboard-settings-community-url =
    <b>🔗 Telegram Group Link</b>

    <blockquote>
    Enter the link (in format https://t.me/+code or https://t.me/group_name).
    </blockquote>

# Finances Settings
msg-dashboard-settings-finances =
    <b>💰 Finances</b>
    
    <blockquote>
    • <b>Default currency:</b> { $default_currency } ({ $default_currency_name })
    </blockquote>

    <i>ℹ️ When sync is enabled, exchange rates are automatically synchronized with the Central Bank of Russia rate.</i>

# Currency Rates Settings
msg-dashboard-settings-currency-rates =
    <b>💱 Exchange Rates</b>

    Specify exchange rate relative to ruble.
    Plan prices will be automatically recalculated.

msg-dashboard-settings-currency-rate-input =
    <b>💱 { $currency } Rate</b>

    Enter { $symbol } to ruble rate (e.g.: 90.5).
    1 { $symbol } = X ₽

# Payment Link for Extra Devices
msg-add-device-payment-link =
    <b>💳 Payment Link</b>

    Click the button below to proceed to payment for extra devices.

# Device Deletion Warning
msg-device-deletion-warning = ⚠️ Press the delete button again to confirm.
    Device will work until the end of the paid period.
msg-extra-device-deletion-confirm = ⚠️ Extra devices will be removed on { $expires_date }.
    They will work until the end of the paid period and will not be counted during subscription renewal.
    Press the delete button again to confirm.

# Autobackup
msg-db-autobackup =
    <b>⏰ Auto-Backup Settings</b>

    <blockquote>
    • <b>Bot Token:</b> { $token_display }
    • <b>Telegram recipient ID:</b> { $chat_id_display }
    • <b>Frequency:</b> { $frequency_display }
    • <b>Last Backup:</b> { $last_backup }
    </blockquote>

    The bot will automatically send backups to the recipient at the specified frequency.

msg-db-autobackup-token =
    <b>🤖 Bot Token for Auto-Backup</b>

    Enter the token of the bot that will send backups.
    Get a token from <a href="https://t.me/BotFather">@BotFather</a>.

msg-db-autobackup-chat-id =
    <b>💬 Chat ID for Auto-Backup</b>

    Enter the Telegram ID of the chat or user to receive backups.
    Find your ID via <a href="https://t.me/userinfobot">@userinfobot</a>.

msg-db-autobackup-frequency =
    <b>🕐 Auto-Backup Frequency</b>

    Select how often to create backups:


# Support Settings
msg-bot-support-settings =
    <b>🆘 Support Settings</b>

    <blockquote>
    • Recipient: { $has_recipient ->
        [1] <code>{ $recipient }</code>
        *[0] Not assigned
    }
    </blockquote>

    ℹ️<i> The "Help" button will be hidden in the main menu if no functions are assigned.</i>

msg-bot-support-recipient =
    <b>📝 Support Recipient</b>

    <blockquote>
    • Recipient: { $has_recipient ->
        [1] <code>{ $recipient }</code>
        *[0] Not assigned
    }
    </blockquote>

    <i>ℹ️ Send a username (e.g. <code>support_bot</code>)
    or a Telegram ID of the recipient.</i>

msg-bot-support-faq =
    <b>❓ FAQ</b>

    { $has_faq ->
        [1] { $faq_preview }
        *[0] <i>No questions added yet.</i>
    }

    <i>ℹ️ Send text with questions and answers.
    Use <code>+++</code> to separate between question blocks.</i>

# Help menu (user)
msg-help-menu =
    <b>🆘 Help</b>

    <i>Choose an action:</i>

msg-help-faq =
    <b>❓ Frequently Asked Questions</b>

    { $faq_text }

msg-branding =
    <b>🎨 Branding</b>

    Select an option.

msg-branding-upload-banner =
    <b>🖼 Upload Banner</b>

    Send an image (JPG or PNG) that will become the banner.
