# Database Management
msg-db-main =
    <b>🗄 Управление базой данных</b>

    <blockquote>
    • <b>Сохранить</b> - создать резервную копию базы
    • <b>Загрузить</b> - восстановить базу из бэкапа
    • <b>Очистить всё</b> - удалить все данные из базы
    • <b>Очистить пользователей</b> - удалить только пользователей
    • <b>Синхронизация</b> - синхронизировать данные между ботом и панелью
    </blockquote>

    <b>🔽 Выберите действие:</b>
    
msg-db-clear-all-confirm =
    <b>⚠️ ВНИМАНИЕ!</b>

    <blockquote>
    Вы собираетесь <b>полностью очистить базу данных</b>.
    
    Будут удалены:
    • Все пользователи
    • Все подписки
    • Все транзакции
    • Все промокоды и их активации
    • Все рефералы и награды
    • Все уведомления
    </blockquote>

    <b>⚠️ Это действие необратимо!</b>
    
    <i>Нажмите кнопку повторно для подтверждения очистки.</i>

msg-db-clear-users-confirm =
    <b>⚠️ ВНИМАНИЕ!</b>

    <blockquote>
    Вы собираетесь <b>удалить всех пользователей</b> из базы данных.
    
    Будут удалены:
    • Все пользователи
    • Все подписки пользователей
    • Все транзакции пользователей
    • Все активации промокодов
    • Все рефералы и награды
    </blockquote>

    <b>⚠️ Это действие необратимо!</b>
    
    <i>Нажмите кнопку ниже повторно для подтверждения.</i>

msg-db-clear-users-result =
    <b>✅ Удаление пользователей завершено успешно!</b>

    <blockquote>
    📊 Итого:
    • Пользователи: <b>{ $users }</b>
    • Подписки: <b>{ $subscriptions }</b>
    • Транзакции: <b>{ $transactions }</b>
    • Активации: <b>{ $activations }</b>
    • Рефералы: <b>{ $referrals }</b>
    • Награды: <b>{ $rewards }</b>
    </blockquote>

msg-db-clear-users-failed =
    <b>❌ Ошибка при удалении пользователей</b>

    { $error }

msg-db-imports =
    <b>📥 Імпорт</b>

    Виберіть джерело для імпорту користувачів:

msg-db-load =
    <b>📁 Выбор файла загрузки</b>

msg-db-load-upload =
    <b>📁 Завантаження бази даних</b>

    Відправте файл бекапу боту для відновлення бази даних.

    ⚠️ <b>Увага:</b> поточна база даних буде замінена даними з файлу!

msg-db-sync =
    <b>🔄 Синхронізація даних</b>

    <blockquote>    
    • <b>З панелі в бота</b>
    Дані користувачів з панелі будуть оновлені в боті.
    Якщо користувача немає в боті, він буде створений.
    
    • <b>З бота в панель</b>
    Дані користувачів з бота будуть оновлені в панелі.
    Якщо користувача немає в панелі, він буде створений.
    </blockquote>

    <i>⚠️ Синхронізація може зайняти деякий час.</i>

msg-db-sync-progress =
    <b>🔄 Синхронизация...</b>

    <blockquote>
    Пожалуйста, подождите. Синхронизация выполняется в фоновом режиме.
    Вы получите уведомление по завершении.
    </blockquote>

msg-db-import =
    <b>📥 Импорт из SQLite</b>
    
    Выберите файл для импорта:

msg-db-restore-success =
    <b>✅ База данных успешно восстановлена из загруженного дампа.</b>

msg-db-restore-failed =
    <b>❌ Ошибка при восстановлении базы: { $error }</b>

# Settings
msg-dashboard-settings =
    <b>⚙️ Настройки</b>

    🔽 Выберите интересующий параметр:

msg-dashboard-settings-transfers =
    <b>💸 Настройка переводов</b>

    <blockquote>
    • Статус: { $enabled ->
        [1] ✅ Включено
        *[0] 🔴 Выключено
    }
    • Тип комиссии: { $commission_type_display }
    • Комиссия: { $commission_display }
    • Минимальная сумма: { $min_amount } ₽
    • Максимальная сумма: { $max_amount } ₽
    </blockquote>


msg-dashboard-settings-transfers-commission-type =
    <b>💰 Выбор типа комиссии</b>

    <blockquote>
    • <b>Процентная</b> - комиссия взимается в процентах от суммы перевода
    • <b>Фиксированная</b> - комиссия взимается в фиксированной сумме независимо от суммы перевода
    </blockquote>

    Выберите тип комиссии:

msg-dashboard-settings-transfers-commission-value =
    <b>💵 Значение комиссии</b>

    <blockquote>
    • Тип комиссии: { $commission_type_display }
    • Текущая комиссия: { $db_commission_display }
    • Изменить на: { $selected_display }
    </blockquote>

    Выберите цену или введите свою:

msg-commission-manual-input =
    <b>✏️ Ручной ввод</b>

    <blockquote>
    Введите стоимость комиссии:
    </blockquote>

msg-dashboard-settings-transfers-min-amount =
    <b>📉 Минимальная сумма перевода</b>

    <blockquote>
    • Текущая минимальная сумма: { $db_min_current_display }
    • Изменить на: { $min_selected_display }
    </blockquote>

    Выберите сумму или введите свою:

msg-min-amount-manual-input =
    <b>✏️ Ручной ввод</b>

    <blockquote>
    Введите минимальную сумму перевода (в рублях):
    </blockquote>

msg-dashboard-settings-transfers-max-amount =
    <b>📈 Максимальная сумма перевода</b>

    <blockquote>
    • Текущая максимальная сумма: { $db_max_current_display }
    • Изменить на: { $max_selected_display }
    </blockquote>

    Выберите сумму или введите свою:

msg-max-amount-manual-input =
    <b>✏️ Ручной ввод</b>

    <blockquote>
    Введите максимальную сумму перевода (в рублях):
    </blockquote>

# Balance Settings
msg-dashboard-settings-balance =
    <b>💰 Настройка баланса</b>

    <blockquote>
    { lbl-status } { $enabled ->
        [1] { lbl-enabled }
        *[0] { lbl-disabled }
    }
    { lbl-min-topup-amount } { $balance_min_amount }
    { lbl-max-topup-amount } { $balance_max_amount }
    </blockquote>

    { hdr-balance-mode }
    <blockquote>
    { lbl-balance-mode-combined }
    { lbl-balance-mode-separate }
    </blockquote>

msg-dashboard-settings-balance-min-amount =
    <b>📉 Минимальная сумма пополнения баланса</b>

    <blockquote>
    • Текущая минимальная сумма: { $balance_min_current_display }
    • Изменить на: { $balance_min_selected_display }
    </blockquote>

    Выберите сумму:

msg-dashboard-settings-balance-max-amount =
    <b>📈 Максимальная сумма пополнения баланса</b>

    <blockquote>
    • Текущая максимальная сумма: { $balance_max_current_display }
    • Изменить на: { $balance_max_selected_display }
    </blockquote>

    Выберите сумму:

# Extra Devices Settings
msg-dashboard-extra-devices-settings =
    <b>📱 Настройка доп. устройств</b>

    <blockquote>
    • Статус: { $enabled ->
        [1] ✅ Включено
        *[0] 🔴 Выключено
    }
    • Тип оплаты: { $payment_type_display }
    • Минімальна кількість днів: { $min_days } { $min_days ->
        [1] день
        [2] дні
        [3] дні
        [4] дні
        *[other] днів
    }
    </blockquote>


msg-dashboard-extra-devices-price =
    <b>💵 Стоимость доп. устройства</b>

    <blockquote>
    • Текущая цена: { $current_price } ₽
    • Изменить на: { $selected_price } ₽
    </blockquote>

    Выберите цену или введите свою:

msg-dashboard-extra-devices-price-manual =
    <b>✏️ Ручной ввод цены</b>

    <blockquote>
    Введите цену доп. устройства (в рублях):
    </blockquote>

msg-dashboard-extra-devices-min-days =
    <b>⏳ Минимальное количество дней</b>

    <blockquote>
    • Текущее: { $current_min_days } дней
    • Изменить на: { $selected_min_days } дней
    </blockquote>

    Минимальное количество дней до окончания подписки, при котором разрешена покупка дополнительного слота устройства.

msg-dashboard-extra-devices-min-days-manual =
    <b>⏳ Минимальное количество дней</b>

    Введите минимальное количество дней (от 1 до 365)

    Выберите количество дней:

# Global Discount Settings
msg-dashboard-settings-global-discount =
    <b>🏷️ Настройка глобальной скидки</b>

    <blockquote>
    • Статус: { $enabled ->
        [1] ✅ Включено
        *[0] 🔴 Выключено
    }
    • Тип скидки: { $discount_type_display }
    • Скидка: { $discount_display }
    • Режим: { $stack_mode_display }
    • Влияние: { $apply_to_display }
    </blockquote>

msg-global-discount-apply-to =
    <b>📌 На что влияет скидка</b>

    <blockquote>
    Операции на которые влияет глобальная скидка.
    </blockquote>

msg-global-discount-mode =
    <b>⚙️ Режим применения скидок</b>

    <blockquote>
    • <b>Максимальная</b> - использовать наибольшую из примененных скидок
    
    • <b>Сложенная</b> - складывать обе скидки
    </blockquote>

msg-dashboard-settings-global-discount-value =
    <b>💵 Значение скидки</b>

    <blockquote>
    • Тип скидки: { $discount_type_display }
    • Текущая скидка: { $db_discount_display }
    • Изменить на: { $selected_display }
    </blockquote>

    Выберите скидку или введите свою:

msg-global-discount-manual-input =
    <b>✏️ Ручной ввод</b>

    <blockquote>
    Введите значение скидки:
    </blockquote>

# Language Settings
msg-dashboard-settings-language =
    <b>🌐 Налаштування мови</b>
    <blockquote>
    • Мультимовність: { $enabled ->
        [1] 🟢 Увімкнено
        *[0] 🔴 Вимкнено
    }
    • Поточна мова: { $current_locale }
    </blockquote>

    <i>ℹ️ Мультимовність:</i>
    🟢 Увімкнено - кожен користувач бачить бота своєю мовою
    🔴 Вимкнено - всі користувачі бачать обрану мову

msg-main-menu =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }{ frg-subscription-status-full }

msg-menu-connect =
    <b>🚀 Підключення</b>

    📝 Інструкція:
    <blockquote>
    • Скачайте і встановіть програму.
    • Натисніть Активувати підписку.
    • У програмі натисніть Увімкнути.
    • Насолоджуйтесь свободою.
    </blockquote>

msg-menu-devices =
    <b>📱 Управління пристроями</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { $has_subscription ->
        [0] <blockquote>
    • У вас немає оформленої підписки.
    </blockquote>
        *[other] { frg-subscription }
    }

msg-add-device =
    <b>➕ Добавить устройство</b>

msg-add-device-select-count =
    { $has_discount ->
    [1] ℹ️<i>Стоимость каждого доп.устройства: { $device_price }₽/мес  <s>{ $device_price_original }₽</s>/мес.</i>
    *[0] ℹ️<i>Стоимость каждого доп.устройства: { $device_price }₽/мес.</i>
    }

    📱 <b>Выберите количество устройств:</b>

msg-add-device-full =
    <b>📱 Виберіть кількість пристроїв:</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    { $has_discount ->
    [1] ℹ️<i>Стоимость каждого доп.устройства: { $device_price }₽/мес  <s>{ $device_price_original }₽</s>/мес.</i>
    *[0] ℹ️<i>Стоимость каждого доп.устройства: { $device_price }₽/мес.</i>
    }

msg-add-device-duration =
    <b>📅 Вибір тривалості</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Покупка:</b>
    <blockquote>
    • <b>Доп. устройства:</b> { $device_count } шт.
    </blockquote>

msg-add-device-payment =
    📱 <b>Покупка:</b>
    <blockquote>
    • <b>Доп. устройства:</b> { $device_count }
    </blockquote>

    💳 <b>Выберите способ оплаты:</b>

msg-add-device-payment-full =
    <b>💳 Вибір способу оплати:</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Покупка:</b>
    <blockquote>
    • <b>Доп. устройства:</b> { $device_count }
    • <b>Тривалість:</b> { $period }
    </blockquote>

msg-add-device-confirm-full =
    <b>💳 Підтвердження покупки</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    <b>📋 Разом:</b>
    <blockquote>
    • <b>Спосіб оплати:</b> { gateway-type }
    • <b>Покупка:</b> 📱 Дод. пристрої { $device_count }
    {"────────────────────────"}
    { $has_discount ->
    [1]
    • <b>Сума до сплати:</b> 💰 <s>{ $original_price }</s> { $total_price }
    *[0]
    • <b>Сума до сплати:</b> 💰 { $total_price }
    }
    </blockquote>

    ⚠️ <i>Вартість доп.пристроїв враховується при продовженні підписки.</i>

    ⚠️ <i>Видалити доп.пристрій можна у меню "Мої пристрої".</i>

    { $is_balance_payment ->
        [1] {""}
        *[0] ⚠️ <i>Підтвердження оплати може зайняти до 5 хвилин. Будь ласка, не повторюйте оплату.</i>
    }

msg-add-device-success-full =
    ✅ <i>К вашей подписке добавлено { $device_count } { $device_count_word }!</i>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    ⚠️ <i>Вартість доп.пристроїв враховується при продовженні підписки.</i>

    ⚠️ <i>Видалити доп.пристрій можна у меню "Мої пристрої".</i>

msg-extra-devices-list =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Дополнительные устройства</b>
    { $purchases_empty ->
        [true] <i>У вас нет активных дополнительных устройств.</i>
        *[false] <blockquote>
    💰 <b>Ежемесячная стоимость:</b> { $total_monthly_cost }
    📱 <b>Всего доп. устройств:</b> { $total_extra_devices }
    <i>Устройства активны до конца месяца подписки.</i>
    </blockquote>
    
    <i>Нажмите ❌ чтобы отменить подписку на устройство.</i>
    }

msg-extra-device-manage =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    📱 <b>Управление дополнительными устройствами</b>
    
    <blockquote>
    • <b>Количество устройств:</b> { $purchase_device_count }
    • <b>Стоимость/мес:</b> { $purchase_price } ₽
    • <b>Истекает:</b> { $purchase_expires_at }
    • <b>Автопродление:</b> { $purchase_auto_renew ->
        [1] ✅ Включено
        *[0] ❌ Отключено
    }
    </blockquote>
    
    { $purchase_auto_renew ->
        [1] <i>При отключении автопродления, устройства будут удалены по истечению срока.</i>
        *[0] <i>Автопродление отключено. Устройства будут удалены через { $purchase_days_remaining } дн.</i>
    }

msg-add-device-confirm-details =
    📱 <b>Покупка:</b>
    <blockquote>
    • <b>Доп. устройства:</b> { $device_count }
    </blockquote>

    📋 <b>Итого:</b>
    <blockquote>
    • <b>Способ оплаты:</b> { $selected_method }
    • <b>Текущий баланс:</b> { $balance }
    • <b>Баланс после:</b> { $new_balance }
    </blockquote>

    💳<b>Подтверждение покупки:</b>

msg-balance-menu =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-status-full }

    <b>💰 Управление балансом:</b>

msg-balance-select-gateway =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    <b>💰 Выбор способа оплаты:</b>

msg-balance-select-amount =
    <b>💰 Поповнення балансу</b>

    <blockquote>
    • <b>Спосіб оплати:</b> { $selected_gateway }
    </blockquote>

    Оберіть суму поповнення:

msg-balance-enter-amount =
    <b>💰 Поповнення балансу</b>

    <blockquote>
    • <b>Спосіб оплати:</b> { $selected_gateway }
    </blockquote>

    Введіть суму поповнення (від { $min_amount } до { $max_amount } { $currency }):

msg-balance-confirm =
    <b>💰 Підтвердження поповнення</b>

    <blockquote>• Призначення: 💰 Поповнення балансу
    • Спосіб оплати: 💳 { $selected_gateway }
    • Сума: 💰 { $topup_amount } { $currency }</blockquote>

    <i>⚠️ Підтвердження оплати може зайняти до 5 хвилин. Меню оновиться автоматично після підтвердження.</i>

msg-balance-success =
    <b>✅ Баланс успешно пополнен!</b>
    
    <blockquote>
    На ваш счёт зачислено <b>{ $amount }{ $currency }</b>
    </blockquote>

msg-balance-transfer =
    <b>💸 Перевод баланса</b>

    { hdr-user-profile }
    <blockquote>
    { lbl-your-balance } <b>{ $balance }</b>
    { lbl-commission } { $commission_display }
    </blockquote>

    { hdr-transfer }
    <blockquote>
    { lbl-recipient } { $recipient_display }
    { lbl-transfer-amount } <b>{ $amount_display } ₽</b>
    { lbl-commission } <b>{ $transfer_commission } ₽</b>
    </blockquote>

    { hdr-message }
    <blockquote>
    { $message_display }
    </blockquote>

    { msg-fill-data-and-send }

msg-balance-transfer-recipient =
    <b>💸 Получатель</b>

    <blockquote>
    Введите <b>Telegram ID</b> получателя:
    </blockquote>

msg-balance-transfer-recipient-history =
    <b>📜 История пользователей</b>

    Выберите получателя из списка пользователей, которым вы ранее отправляли переводы:

msg-balance-transfer-no-history = <i>У вас пока нет истории переводов.</i>

msg-balance-transfer-amount-value =
    <b>💸 Сумма перевода</b>

    <blockquote>
    • Текущая сумма: { $current_display }
    • Изменить на: { $selected_display }
    </blockquote>

    Выберите сумму или введите свою:

msg-balance-transfer-amount-manual =
    <b>✏️ Ручной ввод</b>

    <blockquote>
    Введите сумму перевода (от { $min_amount } до { $max_amount } ₽):
    </blockquote>

msg-balance-transfer-message =
    <b>💬 Сообщение</b>

    <blockquote>
    { $message_display }
    </blockquote>

    <i>Введите сообщение для перевода (макс. 200 символов):</i>

msg-balance-transfer-confirm =
    <b>💸 Подтверждение перевода</b>

    <blockquote>
    Получатель: <b>{ $recipient_name }</b> (<code>{ $recipient_id }</code>)
    Сумма перевода: <b>{ $amount } ₽</b>
    Комиссия: <b>{ $commission } ₽</b>
    Итого к списанию: <b>{ $total } ₽</b>
    </blockquote>

    ⚠️ <b>Внимание:</b> Операция необратима!

msg-balance-transfer-success =
    <b>✅ Перевод выполнен успешно!</b>

    <blockquote>
    Получатель: <b>{ $recipient_name }</b>
    Сумма: <b>{ $amount } ₽</b>
    Комиссия: <b>{ $commission } ₽</b>
    </blockquote>

msg-balance-transfer-error =
    <b>❌ Ошибка перевода</b>

    { $error }

msg-menu-invite =
    <b>👥 Пригласить друзей</b>

    { hdr-user-profile }
    { frg-user-invite }

    { hdr-subscription }{ frg-subscription-status-full }

    <b>🏆 Награда:</b>
    <blockquote>
    { $ref_reward_type ->
        [EXTRA_DAYS] { $ref_reward_strategy ->
            [PERCENT] • { $ref_reward_level_1_value }% від днів підписки оплачених запрошеним
            *[AMOUNT] • { $ref_reward_level_1_value } дн. за кожні 100 { $currency_symbol } поповнення запрошеним
        }
        [MONEY] { $ref_reward_strategy ->
            [AMOUNT] • { $ref_reward_level_1_value } { $currency_symbol } за запрошеного
            *[PERCENT] • { $ref_reward_level_1_value }% від суми поповнення запрошеним
        }
        *[OTHER] • { $ref_reward_level_1_value } { $currency_symbol }
    }{ $ref_max_level ->
        [2] {""}
    
    { $ref_reward_type ->
        [EXTRA_DAYS] { $ref_reward_strategy ->
            [PERCENT] • { $ref_reward_level_2_value }% від днів підписки оплачених запрошеним запрошеними
            *[AMOUNT] • { $ref_reward_level_2_value } дн. за кожні 100 { $currency_symbol } поповнення запрошеним запрошеними
        }
        [MONEY] { $ref_reward_strategy ->
            [AMOUNT] • { $ref_reward_level_2_value } { $currency_symbol } за запрошеного запрошеними
            *[PERCENT] • { $ref_reward_level_2_value }% від суми поповнення запрошеним запрошеними
        }
        *[OTHER] • { $ref_reward_level_2_value } { $currency_symbol }
    }
        *[1] {""}
    }
    </blockquote>

    <b>📊 Статистика:</b>
    <blockquote>
    👥 Всего приглашенных: { $referrals }
    💳 Платежей по вашей ссылке: { $payments }
    💳 Отримано бонусів: { $total_bonus }{ $ref_reward_type ->
        [EXTRA_DAYS] { " " }дн.
        *[OTHER] {""}
    }
    💳 Отримано кешбеком: { $total_cashback }{ $ref_reward_type ->
        [EXTRA_DAYS] { " " }дн.
        *[OTHER] {""}
    }
    </blockquote>

    <i>ℹ️ Награда начисляется при оплатах приведенных вами пользователей.</i>

msg-menu-invite-about =
    <b>🎁 Подробнее о вознаграждении</b>

    <b>✨ Как получить награду:</b>
    <blockquote>
    { $accrual_strategy ->
    [ON_FIRST_PAYMENT] Награда начисляется за первую покупку подписки приглашенным пользователем.
    [ON_EACH_PAYMENT] Награда начисляется за каждую покупку, или продление подписки приглашенным пользователем.
    *[OTHER] { $accrual_strategy }
    }
    </blockquote>

    <b>💎 Что вы получаете:</b>
    <blockquote>
    { $max_level -> 
    [1] За приглашенных друзей: { $reward_level_1 }
    *[MORE]
    { $identical_reward ->
    [0]
    1️⃣ За ваших друзей: { $reward_level_1 }
    2️⃣ За приглашенных вашими друзьями: { $reward_level_2 }
    *[1]
    За ваших друзей и приглашенных вашими друзьями: { $reward_level_1 }
    }
    }
    
    { $reward_strategy_type ->
    [AMOUNT] { $reward_type ->
        [MONEY] { space }
        [EXTRA_DAYS] <i>(Все дополнительные дни начисляются к вашей текущей подписке)</i>
        *[OTHER] { $reward_type }
    }
    [PERCENT] { $reward_type ->
        [MONEY] <i>(Процент от стоимости их приобретенной подписки)</i>
        [EXTRA_DAYS] <i>(Процент доп. дней от их приобретенной подписки)</i>
        *[OTHER] { $reward_type }
    }
    *[OTHER] { $reward_strategy_type }
    }
    </blockquote>

msg-invite-reward =
    { $value }{ $reward_strategy_type ->
        [AMOUNT] { $reward_type ->
            [MONEY] { space }₽
            [EXTRA_DAYS] { space }доп. { $value ->
                [one] день
                [few] дня
                *[other] дней
            }
            *[OTHER] { $reward_type }
        }
        [PERCENT] % { $reward_type ->
            [MONEY] {""}
            [EXTRA_DAYS] доп. дней
            *[OTHER] { $reward_type }
        }
        *[OTHER] { $reward_strategy_type }
    }

msg-menu-invite-edit-code =
    ✏️ <b>Зміна реферального коду</b>

    <blockquote>• Поточний код: <code>{ $referral_code }</code></blockquote>

    <i>Введіть новий реферальний код.</i>
    { $ref_code_error ->
        [invalid]

    ⚠️ <b>Недопустимі символи.</b>
    Дозволено: A–Z, a–z, 0–9, _ - (довжина 3–32)
        [taken]

    ⚠️ Цей код вже зайнятий. Оберіть інший.
        *[other] {""}
    }


# Dashboard
msg-dashboard-main =
    <b>🛠 Панель управління v{ $bot_version }</b> { $update_available ->
        [1] — 🔔 Доступне оновлення: <b>{ $new_version }</b>
        *[0] {""}
    }
msg-bot-management =
    <b>🤖 Керування ботом</b>
msg-mirror-bots =
    <b>🤖 Додаткові боти</b>

    <blockquote>Тут можна додати дзеркальних ботів. Натисніть на бота, щоб призначити його <b>основним</b> - запрошувальні посилання вестимуть на нього.</blockquote>
msg-mirror-bot-add-token =
    <b>➕ Додавання нового бота</b>

    Надішліть API-токен нового бота, отриманий від @BotFather.
msg-dashboard-user-management =
    <b>👥 Керування користувачами</b>
msg-dashboard-features =
    <b>⚙️ Функціонал</b>

    <blockquote>
    Тут ви можете увімкнути або вимкнути різні функції бота.
    </blockquote>

msg-auto-cleanup =
    <b>🧹 Автоочищення користувачів</b>

    <blockquote>
    Автоматичне видалення EXPIRED користувачів з панелі Remnawave.
    Дані в телеграм боті зберігаються.
    </blockquote>

    <b>Текст сповіщення:</b>
    <blockquote>{ $notify_text }</blockquote>

msg-auto-cleanup-days =
    <b>📅 Термін очищення</b>

    <blockquote>
    Через скільки днів після закінчення підписки видаляти користувача з панелі.
    </blockquote>

msg-auto-cleanup-days-manual =
    <b>✏️ Введіть кількість днів</b>

    <blockquote>
    Введіть число від 1 до 365.
    </blockquote>

msg-auto-cleanup-notify-message-edit =
    <b>✏️ Текст сповіщення</b>

    <blockquote>{ $notify_text }</blockquote>

    <i>Вкажіть текст сповіщення, який буде надіслано користувачу при видаленні. Підтримується HTML-форматування.</i>

msg-dashboard-extra-devices =
    <b>📱 Дополнительные устройства</b>

    <b>Статус:</b> { $enabled ->
        [1] ✅ Включено
        *[0] ⬜ Выключено
    }
    <b>Стоимость:</b> { $price } ₽/мес за устройство

    <blockquote>
    Позволяет пользователям добавлять дополнительные устройства к подписке за отдельную плату.
    </blockquote>

msg-dashboard-extra-devices-price =
    <b>💰 Изменение стоимости доп. устройств</b>

    <b>Текущая стоимость:</b> { $current_price } ₽

    Выберите стоимость или введите вручную:

msg-dashboard-extra-devices-price-manual =
    <b>💰 Ручной ввод стоимости</b>

    Введите новую стоимость в рублях (целое число от 0 до 100000):

msg-dashboard-extra-devices-settings =
    <b>📱 Настройка доп. устройств</b>

    <b>Текущая стоимость:</b> { $price } ₽ за устройство
    <b>Тип оплаты:</b> { $is_one_time ->
    [1] Единоразово
    *[0] Ежемесячно
    }

    <blockquote>
    <b>Единоразово</b> - пользователь оплачивает устройства один раз, они сохраняются до удаления.
    
    <b>Ежемесячно</b> - стоимость устройств добавляется при каждом продлении подписки.
    </blockquote>

msg-users-main = <b>👥 Пользователи</b>
msg-broadcast-main = <b>📢 Рассылка</b>

msg-statistics-main = { $statistics }

msg-journal-main = { $journal }
    
msg-statistics-users =
    <b>👥 Статистика по пользователям</b>

    <blockquote>
    • <b>Всего</b>: { $total_users }
    • <b>Новые за день</b>: { $new_users_daily }
    • <b>Новые за неделю</b>: { $new_users_weekly }
    • <b>Новые за месяц</b>: { $new_users_monthly }

    • <b>С подпиской</b>: { $users_with_subscription }
    • <b>Без подписки</b>: { $users_without_subscription }
    • <b>С пробным периодом</b>: { $users_with_trial }

    • <b>Заблокированные</b>: { $blocked_users }
    • <b>Заблокировали бота</b>: { $bot_blocked_users }

    • <b>Конверсия пользователей → покупка</b>: { $user_conversion }%
    • <b>Конверсия пробников → подписка</b>: { $trial_conversion }%
    </blockquote>

msg-statistics-transactions =
    <b>🧾 Статистика по транзакциям</b>

    <blockquote>
    • <b>Всего транзакций</b>: { $total_transactions }
    • <b>Завершенных транзакций</b>: { $completed_transactions }
    • <b>Бесплатных транзакций</b>: { $free_transactions }
    { $popular_gateway ->
    [0] { empty }
    *[HAS] • <b>Популярная платежная система</b>: { $popular_gateway }
    }
    </blockquote>

    { $payment_gateways }

    { $bonus_gateways }

msg-statistics-subscriptions =
    <b>💳 Статистика по подпискам</b>

    <blockquote>
    • <b>Активные</b>: { $total_active_subscriptions }
    • <b>Истекшие</b>: { $total_expire_subscriptions }
    • <b>Пробные</b>: { $active_trial_subscriptions }
    • <b>Истекающие (7 дней)</b>: { $expiring_subscriptions }
    </blockquote>

    <blockquote>
    • <b>С безлимитом</b>: { $total_unlimited }
    • <b>С лимитом трафика</b>: { $total_traffic }
    • <b>С лимитом устройств</b>: { $total_devices }
    </blockquote>

msg-statistics-plans = 
    <b>📦 Статистика по планам</b>

    { $plans }

msg-statistics-extra-devices =
    <b>📱 Статистика дод. пристроїв</b>

    <b>З підписок:</b>
    <blockquote>
    • <b>Видано слотів</b>: { $subscription_total_slots }
    • <b>Зайнятих слотів</b>: { $subscription_active_slots }
    </blockquote>

    <b>Бонусні:</b>
    <blockquote>
    • <b>Видано слотів</b>: { $bonus_total_slots }
    • <b>Зайнятих слотів</b>: { $bonus_active_slots }
    </blockquote>

    <b>Куплено:</b>
    <blockquote>
    • <b>Видано слотів</b>: { $purchased_total_slots }
    { $per_plan_total_details }

    • <b>Активовано</b>: { $purchased_active_slots }
    { $per_plan_active_details }
    </blockquote>

msg-statistics-promocodes =
    <b>🎁 Статистика по промокодам</b>

    <blockquote>
    • <b>Общее кол-во активаций</b>: { $total_promo_activations }
    • <b>Самый популярный промокод</b>: { $most_popular_promo ->
    [0] { unknown }
    *[HAS] { $most_popular_promo }
    }
    • <b>Выдано дней</b>: { $total_promo_days }
    • <b>Выдано трафика</b>: { $total_promo_days }
    • <b>Выдано подписок</b>: { $total_promo_subscriptions }
    • <b>Выдано личных скидок</b>: { $total_promo_personal_discounts }
    • <b>Выдано одноразовых скидок</b>: { $total_promo_purchase_discounts }
    </blockquote>

msg-statistics-referrals =
    <b>👪 Статистика по реферальной системе</b>
    
    <blockquote>
    • <b></b>:
    </blockquote>

msg-statistics-transactions-gateway =
    <b>{ gateway-type }:</b>
    <blockquote>
    • <b>Общий доход</b>: { $total_income }{ $currency }
    • <b>Доход за день</b>: { $daily_income }{ $currency }
    • <b>Доход за неделю</b>: { $weekly_income }{ $currency }
    • <b>Доход за месяц</b>: { $monthly_income }{ $currency }
    • <b>Средний чек</b>: { $average_check }{ $currency }
    • <b>Сумма скидок</b>: { $total_discounts }{ $currency }
    </blockquote>

msg-statistics-plan =
    <b>{ $plan_name }:</b> { $popular -> 
    [0] { space }
    *[HAS] (⭐)
    }
    <blockquote>
    • <b>Всего подписок</b>: { $total_subscriptions }
    • <b>Активных подписок</b>: { $active_subscriptions }
    • <b>Популярная длительность</b>: { $popular_duration }

    • <b>Общий доход</b>: 
    { $all_income }
    </blockquote>

msg-statistics-plan-income = { $income }{ $currency }
    


# Access
msg-access-main =
    <b>🔓 Режим доступа</b>
    
    <blockquote>
    • <b>Режим</b>: { access-mode }
    • <b>Покупки</b>: { $purchases_allowed ->
    [0] запрещены
    *[1] разрешены
    }.
    • <b>Регистрация</b>: { $registration_allowed ->
    [0] запрещена
    *[1] разрешена
    }.
    </blockquote>

msg-access-conditions =
    <b>⚙️ Условия доступа</b>

msg-access-rules =
    <b>✳️ Изменить ссылку на правила</b>

    Введите ссылку (в формате https://telegram.org/tos).
    
    Это же значение используется в меню <b>Соглашение с пользователем</b>.

msg-access-channel =
    <b>❇️ Изменить ссылку на канал/группу</b>

    Если ваша группа не имеет @username, отправьте ID группы и ссылку-приглашение отдельными сообщениями.
    
    Если у вас публичный канал/группа, введите только @username.


# Broadcast
msg-broadcast-list = <b>📄 Список рассылок</b>
msg-broadcast-plan-select = <b>📦 Выберите план для рассылки</b>
msg-broadcast-send = <b>📢 Отправить рассылку ({ audience-type })</b>

    { $audience_count } { $audience_count ->
    [one] пользователю
    [few] пользователям
    *[more] пользователей
    } будет отправлена рассылка

msg-broadcast-content =
    <b>✉️ Вміст розсилки</b>

    <b>Поточний вміст:</b>

    { $has_content ->
        [1] <blockquote>{ $current_content }</blockquote>
        *[other] <blockquote>• Не заповнено</blockquote>
    }

    <i>Надішліть будь-яке повідомлення: текст, зображення або все разом (підтримується HTML).</i>

msg-broadcast-buttons = <b>✳️ Кнопки рассылки</b>

msg-broadcast-view =
    <b>📢 Рассылка</b>

    <blockquote>
    • <b>ID</b>: <code>{ $broadcast_id }</code>
    • <b>Статус</b>: { broadcast-status }
    • <b>Аудитория</b>: { audience-type }
    • <b>Создано</b>: { $created_at }
    </blockquote>

    <blockquote>
    • <b>Всего сообщений</b>: { $total_count }
    • <b>Успешных</b>: { $success_count }
    • <b>Неудачных</b>: { $failed_count }
    </blockquote>


# Users
msg-users-recent-registered = <b>🆕 Последние зарегистрированные</b>
msg-users-recent-activity = <b>📝 Последние взаимодействующие</b>
msg-users-all = <b>👥 Все пользователи</b>
msg-user-transactions = <b>🧾 Транзакции пользователя</b>
msg-admin-change-device-days =
    <b>⏳ Змінити термін пристрою</b>

    Введіть нову кількість днів для цього слота пристрою:

msg-admin-add-device-days =
    <b>➕ Додати пристрій</b>

    Введіть кількість днів для додаткового пристрою (за замовчуванням 30):

msg-user-devices = <b>📱 Устройства пользователя ({ $current_count } / { $max_count })</b>
msg-user-give-access = <b>🔑 Предоставить доступ к плану</b>

msg-users-search =
    <b>🔍 Поиск пользователя</b>

    Введите ID пользователя, часть имени или перешлите любое его сообщение.

msg-users-search-results =
    <b>🔍 Поиск пользователя</b>

    Найдено <b>{ $count }</b> { $count ->
    [one] пользователь
    [few] пользователя
    *[more] пользователей
    }, { $count ->
    [one] соответствующий
    *[more] соответствующих
    } запросу

msg-user-main = 
    <b>📝 Информация о пользователе</b>

    { hdr-user-profile }
    { frg-user-details }

    <b>💸 Скидка:</b>
    <blockquote>
    • <b>Персональная</b>: { $personal_discount }%
    • <b>На следующую покупку</b>: { $purchase_discount }%
    </blockquote>
    
    { hdr-subscription }
    { frg-subscription-status-short }

msg-user-referrals = 
    <b>👥 Реферали користувача</b>

    <b>Кількість рефералів:</b> { $referral_count }
    <b>Отримано бонусів:</b> { $total_bonus }
    <b>Отримано кешбеком:</b> { $total_cashback }

msg-user-referrals-list =
    <b>📋 Список рефералів</b>

msg-user-referral-bind = 
    <b>🔗 Прив'язати реферала</b>

    Введіть Telegram ID або @username користувача, якого хочете прив'язати як реферала.

msg-user-delete-confirm =
    <b>❌ Видалення користувача</b>

    <i>Ви впевнені? Цю дію неможливо скасувати.</i>

msg-user-sync = 
    <b>🌀 Синхронизировать пользователя</b>

    <b>🛍 Телеграм:</b>
    <blockquote>
    { $has_bot_subscription -> 
    [0] Данные отсутствуют
    *[HAS]{ $bot_subscription }
    }
    </blockquote>

    <b>🌊 Панель:</b> { $remna_version }
    <blockquote>
    { $has_remna_subscription -> 
    [0] Данные отсутствуют
    *[HAS] { $remna_subscription }
    }
    </blockquote>

    Выберите актуальные данные для синхронизации.

msg-user-sync-version = { $version ->
    [NEWER] (новее)
    [OLDER] (старее)
    *[UNKNOWN] { empty }
    }

msg-user-sync-subscription =
    • <b>ID</b>: <code>{ $id }</code>
    • Статус: { $status -> 
    [ACTIVE] Активна
    [DISABLED] Отключена
    [LIMITED] Исчерпан трафик
    [EXPIRED] Истекла
    [DELETED] Удалена
    *[OTHER] { $status }
    }
    • Ссылка: <a href="{ $url }">*********</a>

    • Лимит трафика: { $traffic_limit }
    • Лимит устройств: { $device_limit }
    • Осталось: { $expire_time }

    • Внутренние сквады: { $internal_squads ->
    [0] { unknown }
    *[HAS] { $internal_squads }
    }
    • Внешний сквад: { $external_squad ->
    [0] { unknown }
    *[HAS] { $external_squad }
    }
    • Сброс трафика: { $traffic_limit_strategy -> 
    [NO_RESET] При оплате
    [DAY] Каждый день
    [WEEK] Каждую неделю
    [MONTH] Каждый месяц
    *[OTHER] { $traffic_limit_strategy }
    }
    • Тег: { $tag -> 
    [0] { unknown }
    *[HAS] { $tag }
    }

msg-user-sync-waiting =
    <b>🌀 Синхронизация пользователя</b>

    Пожалуйста, подождите... Идет процесс синхронизации данных пользователя. Вы автоматически вернетесь к редактору пользователя по завершении.

msg-user-give-subscription =
    <b>🎁 Выдать подписку</b>

    Выберите план, который хотите выдать пользователю.

msg-user-give-subscription-duration =
    <b>⏳ Выберите длительность</b>

    Выберите длительность выдаваемой подписки.

msg-user-discount =
    <b>💸 Изменить персональную скидку</b>

    Выберите по кнопке или введите свой вариант.

msg-user-balance-menu =
    <b>💰 Баланс користувача</b>

    <b>Основний баланс:</b> { $current_balance } ₽
    <b>Реферальний баланс:</b> { $referral_balance } ₽

    Виберіть тип балансу для редагування:

msg-user-finance-menu-full =
    <b>💰 Управління фінансами</b>

    { $is_balance_enabled ->
        [1] <b>Основний баланс:</b> { $current_balance } ₽
        *[0] {""}
    }
    { $is_referral_enable ->
        [1] <b>Бонусний баланс:</b> { $referral_balance } ₽
        *[0] {""}
    }
    <b>Постійна знижка:</b> { $discount_value }%

    Виберіть пункт для редагування:

msg-user-finance-menu-short =
    <b>💰 Управління фінансами</b>

    <b>Постійна знижка:</b> { $discount_value }%

    Виберіть пункт для редагування:

msg-user-main-balance =
    <b>💰 Основний баланс</b>

    <b>Поточний баланс: { $current_balance } ₽</b>
    { $has_pending_balance ->
        [1] <b>Нарахування: { $pending_balance_amount } ₽</b>
        *[0] {""}
    }

    Оберіть суму або введіть свій варіант.

msg-user-referral-balance =
    <b>🎁 Бонусний баланс</b>

    <b>Поточний баланс: { $current_referral_balance } ₽</b>
    { $has_pending_referral ->
        [1] <b>Нарахування: { $pending_referral_amount } ₽</b>
        *[0] {""}
    }

    Оберіть суму або введіть свій варіант.

msg-user-points =
    <b>� Изменить баланс</b>

    <b>Текущий баланс: { $current_balance } ₽</b>

    Выберите по кнопке или введите свой вариант, чтобы добавить или отнять.

msg-user-subscription-traffic-limit =
    <b>🌐 Изменить лимит трафика</b>

    Выберите по кнопке или введите свой вариант (в ГБ), чтобы изменить лимит трафика.

msg-user-subscription-device-limit =
    <b>📱 Бонусные устройства</b>

    • Выберите количество бонусных устройств для пользователя, или введите количество от 0 до 100

msg-user-subscription-expire-time =
    <b>⏳ Изменить срок действия</b>

    <b>Закончится через: { $expire_time }</b>

    Выберите по кнопке или введите свой вариант (в днях), чтобы добавить или отнять.

msg-user-subscription-squads =
    <b>🔗 Сквады</b>

    • Внутренний сквад: { $internal_squads ->
    [0] не выбран
    *[HAS] { $internal_squads }
    }
    • Внешний сквад: { $external_squad ->
    [0] не выбран
    *[HAS] { $external_squad }
    }

    ✏️ Выберите сквады:

msg-user-subscription-internal-squads =
    <b>⏺️ Изменить список внутренних сквадов</b>

    Выберите, какие внутренние группы будут присвоены этому пользователю.

msg-user-subscription-external-squads =
    <b>⏹️ Изменить внешний сквад</b>

    Выберите, какая внешняя группа будет присвоена этому пользователю.

msg-user-subscription-empty =
    <b>💳 Информация о подписке</b>

    У данного пользователя нет активной подписки.

msg-user-subscription-info =
    <b>💳 Информация о текущей подписке</b>
    
    <b>💳 Підписка:</b>
    { frg-subscription-details }

    <blockquote>
    • <b>Сквады</b>: { $squads -> 
    [0] { unknown }
    *[HAS] { $squads }
    }
    • <b>Первое подключение</b>: { $first_connected_at -> 
    [0] { unknown }
    *[HAS] { $first_connected_at }
    }
    • <b>Последнее подключение</b>: { $last_connected_at ->
    [0] { unknown }
    *[HAS] { $last_connected_at } ({ $node_name })
    } 
    </blockquote>

    { hdr-plan }
    { frg-plan-snapshot }

msg-user-transaction-info =
    <b>🧾 Информация о транзакции</b>

    { hdr-payment }
    <blockquote>
    • <b>ID</b>: <code>{ $payment_id }</code>
    • <b>Тип</b>: { purchase-type }
    • <b>Статус</b>: { transaction-status }
    • <b>Способ оплаты</b>: { gateway-type }
    • <b>Сумма</b>: { frg-payment-amount }
    • <b>Создано</b>: { $created_at }
    </blockquote>

    { $is_test -> 
    [1] ⚠️ Тестовая транзакция
    *[0]
    { hdr-plan }
    { frg-plan-snapshot }
    }
    
msg-user-role = 
    <b>👮‍♂️ Изменить роль</b>
    
    Выберите новую роль для пользователя.

msg-users-blacklist =
    <b>🚫 Черный список</b>

    Заблокировано: <b>{ $count_blocked }</b> / <b>{ $count_users }</b> ({ $percent }%).

msg-user-message =
    <b>📩 Отправить сообщение пользователю</b>

    Отправьте любое сообщение: текст, изображение или все вместе (поддерживается HTML).
    

# Панель
msg-monitoring =
    <b>📡 Моніторинг</b>

    <b>👥 Користувачі</b>
    <blockquote>
    • <b>Всього</b>: { $users_total }
    • <b>Активних</b>: { $users_active }
    • <b>Вимкнених</b>: { $users_disabled }
    • <b>Обмежених</b>: { $users_limited }
    • <b>Закінчилися</b>: { $users_expired }
    • <b>Всього онлайн</b>: { $total_online }
    </blockquote>

    <b>📊 Статистика:</b>
    <blockquote>
    • <b>Всього серверів</b>: { $total_servers }
    • <b>Доступно</b>: { $available_servers }
    </blockquote>

    <b>📋 Список серверів:</b>
    <blockquote>
    { $servers_list }
    </blockquote>

msg-monitoring-no-servers = Немає доступних серверів


# Телеграм
msg-remnashop-main = <b>🛍 Телеграм</b>
msg-admins-main = <b>👮‍♂️ Администраторы</b>


# Gateways
msg-gateways-main = <b>🌐 Платежные системы</b>
msg-gateways-settings = <b>🌐 Конфигурация { gateway-type }</b>
msg-gateways-settings-detail =
    <b>⚙️ Налаштування системи: { gateway-type }</b>

    { $settings_display }

    Оберіть що змінити:
msg-gateways-default-currency = <b>💸 Валюта по умолчанию</b>
msg-gateways-placement = <b>🔢 Изменить позиционирование</b>

msg-gateways-field =
    <b>🌐 Конфигурация { gateway-type }</b>

    Введите новое значение для { $field }.


# Referral
msg-referral-main =
    <b>👥 Реферальная система</b>

    <blockquote>
    • <b>Статус</b>: { $is_enable -> 
        [1] 🟢 Включено
        *[0] 🔴 Выключено
        }
    • <b>Тип награды</b>: { reward-type }
    • <b>Количество уровней</b>: { $level_text }
    • <b>Условие начисления</b>: { accrual-strategy }
    • <b>Форма начисления</b>: { reward-strategy }
    • <b>Награда</b>: { $reward_display }
    </blockquote>

    🔽 Выберите пункт для изменения.

msg-referral-level =
    <b>🔢 Изменить уровень</b>

    Выберите количество уровней реферальной системы.

msg-referral-reward-type =
    <b>🎀 Изменить тип награды</b>

    Выберите тип награды за приглашенных пользователей.
    
msg-referral-accrual-strategy =
    <b>📍 Изменить условие начисления</b>

    Выберите, при каком условии будет начисляться награда.


msg-referral-reward-strategy =
    <b>⚖️ Изменить форму начисления</b>

    Выберите способ расчета награды.
    
    <i>При выборе типа "Дни": начисляется N дней за каждые 100 рублей пополнения/покупки.</i>


msg-referral-reward-level = { $level } уровень: { $value }{ $reward_strategy_type ->
    [AMOUNT] { $reward_type ->
        [POINTS] { space }{ $value -> 
            [one] балл
            [few] балла
            *[more] баллов
            }
        [EXTRA_DAYS] { space }доп. { $value -> 
            [one] день
            [few] дня
            *[more] дней
            }
        [MONEY] ₽
        *[OTHER] { $reward_type }
    }
    [PERCENT] % { $reward_type ->
        [POINTS] баллов
        [EXTRA_DAYS] доп. дней
        [MONEY] от суммы платежа
        *[OTHER] { $reward_type }
    }
    *[OTHER] { $reward_strategy_type }
    }
    
msg-referral-reward =
    <b>🎁 Изменить награду</b>

    <blockquote>
    { $reward }
    </blockquote>

    { $reward_type ->
        [EXTRA_DAYS] Выберите количество дней за каждые 100₽ пополнения/покупки, или введите значение вручную.
        *[OTHER] Выберите размер награды или введите значение вручную.
    }

msg-referral-reward-manual =
    <b>✏️ Ручной ввод награды</b>

msg-referral-invite-message =
    <b>✉️ Настройка сообщения приглашения</b>

    🔽 Выберите действие:

msg-referral-invite-edit =
    <b>✉️ Настройка сообщения приглашения</b>

    ℹ️ Доступные переменные:
    <blockquote>
    • <code>{"{url}"}</code> - реферальная ссылка
    • <code>{"{space}"}</code> - пустая строка в начале (не видна в превью)
    </blockquote>

    <i>✏️ Введите ваше приглашение:</i>

msg-referral-invite-preview =

    { $preview_message }

# Plans
msg-plans-main = <b>📦 Планы</b>

msg-plan-configurator =
    <b>📦 Конфигуратор плана</b>

    <blockquote>
    • <b>Название</b>: { $name }
    • <b>Тег</b>: { $tag }
    • <b>Внутренний сквад</b>: { $internal_squads ->
    [0] { lbl-not-set }
    *[HAS] { $internal_squads }
    }
    • <b>Внешний сквад</b>: { $external_squad ->
    [0] { lbl-not-set }
    *[HAS] { $external_squad }
    }
    • <b>Доступ</b>: { availability-type }
    </blockquote>
    
    <blockquote>
    • <b>Тип</b>: { plan-type }
    • <b>Лимит трафика</b>: { $is_unlimited_traffic ->
        [1] { unlimited }
        *[0] { $traffic_limit }
    }
    • <b>Лимит устройств</b>: { $is_unlimited_devices ->
        [1] { unlimited }
        *[0] { $device_limit }
    }
    { $is_unlimited_devices ->
        [1] { "" }
        *[0] • <b>Вартість дод. пристрою</b>: { $device_price ->
            [0] не задано
            *[other] { $device_price } ₽/міс
        }
    }
    </blockquote>
    
    <blockquote>
    • <b>Статус</b>: { $is_active ->
        [1] 🟢 Включен
        *[0] 🔴 Выключен
    }
    </blockquote>

    Выберите пункт для изменения.

msg-plan-name =
    <b>🏷️ Изменить название</b>

    { $name ->
    [0] { space }
    *[HAS]
    <blockquote>
    { $name }
    </blockquote>
    }

    Введите новое название плана.

msg-plan-description =
    <b>💬 Изменить описание</b>

    <blockquote>
    Описание: { $description }
    </blockquote>

    Введите новое описание плана.

msg-plan-tag =
    <b>📌 Изменить тег</b>

    <blockquote>
    Тег: { $tag }
    </blockquote>

    <i>ℹ️ Используйте латинские заглавные буквы, цифры и символ подчеркивания.</i>

    ✏️ Введите тег для плана:

msg-plan-type =
    <b>🔖 Изменить тип</b>

    Выберите новый тип плана.

msg-plan-availability =
    <b>✴️ Изменить доступность</b>

    Выберите доступность плана.

msg-plan-traffic =
    <b>🌐 Изменить лимит и стратегию сброса трафика</b>

    Введите новый лимит трафика плана (в ГБ) и выберите стратегию его сброса.

msg-plan-devices =
    <b>📱 Изменить лимит устройств</b>

    Введите новий лімит пристроїв плану.

msg-plan-device-price =
    <b>📱 Вартість дод. пристрою</b>

    Поточна вартість: <b>{ $device_price } ₽/міс</b>

    Введіть нову вартість покупки додаткового пристрою (у рублях за місяць) або оберіть зі списку нижче.

msg-plan-device-prices =
    <b>📱 Вартість дод. пристроїв</b>

    Оберіть тариф, для якого бажаєте змінити вартість додаткового пристрою.

msg-plan-durations =
    <b>⏳ Длительности плана</b>

    Выберите длительность для изменения цены.

msg-plan-duration =
    <b>⏳ Добавить длительность плана</b>

    Введите новую длительность (в днях).

msg-plan-prices =
    <b>💰 Изменить цену тарифа на ({ $value ->
            [-1] { unlimited }
            *[other] { unit-day }
        })</b>

    Укажите цену в рублях.
    Цены в других валютах будут рассчитаны автоматически по курсу.

msg-plan-price =
    <b>💰 Изменить цену для тарифа на ({ $value ->
            [-1] { unlimited }
            *[other] { unit-day }
        })</b>

    Введите новую цену в рублях (₽).

msg-plan-allowed-users = 
    <b>👥 Изменить список разрешенных пользователей</b>

    Введите ID пользователя для добавления в список.

msg-plan-squads =
    <b>🔗 Сквады</b>

    <blockquote>
    • <b>Внутренние</b>: { $internal_squads ->
    [0] { lbl-not-set }
    *[HAS] { $internal_squads }
    }
    • <b>Внешний</b>: { $external_squad ->
    [0] { lbl-not-set }
    *[HAS] { $external_squad }
    }
    </blockquote>

    ✏️ Выберите необходимые сквады:

msg-plan-internal-squads =
    <b>⏺️ Изменить список внутренних сквадов</b>

    Выберите, какие внутренние группы будут присвоены этому плану.

msg-plan-external-squads =
    <b>⏹️ Изменить внешний сквад</b>

    Выберите, какая внешняя группа будет присвоена этому плану.


# Notifications
msg-notifications-main = <b>🔔 Настройка уведомлений</b>
msg-notifications-user = <b>👥 Пользовательские уведомления</b>
msg-notifications-system = <b>⚙️ Системные уведомления</b>


# Subscription
msg-subscription-key-title = 
    🔑 <b>Ваш ключ підписки:</b>

msg-subscription-main =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    { $trial_available ->
    [1] {""}
    *[0] <b>💳 Управление подпиской:</b>
    }

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    { $trial_available ->
    [1]
    { $is_referral_trial ->
    [1]
    { $is_referral_enable ->
    [1] <i>📢 Для вас доступна бесплатная реферальная подписка.</i>
    *[0] {""}
    }
    *[0]
    <i>🎁 Для вас доступна бесплатная пробная подписка.</i>
    }
    *[0] {""}
    }
msg-subscription-plans =
    <b>📦 Вибір тарифного плану:</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }
msg-subscription-new-success = ✅ <i>Було підключено тарифний план { $plan_name }.</i>
msg-subscription-renew-success = ✅ <i>Вашу підписку успішно продовжено!</i>

msg-subscription-details =
    <b>💳 Підписка, що купується:</b>
    <blockquote>
    • <b>Тариф:</b> { $plan_name }
    • <b>Ліміт трафіку</b>: { $traffic }
    { $devices ->
    [0] { empty }
    *[HAS] • <b>Ліміт пристроїв</b>: { $devices }{ $has_planned_extra_devices ->
        [1] {" "}(+{ $planned_extra_devices } дод.)
        *[0] {""}
    }
    }{ $purchase_type ->
        [RENEW] { $renew_extra_devices ->
            [0] {""}
            *[other] {"\u000A"}• <b>Дод. пристрої:</b> { $renew_extra_devices } шт.
        }
        *[OTHER] {""}
    }
    { $period ->
    [0] { empty }
    *[HAS] • <b>Тривалість</b>: { $period }
    }{ $description ->
    [0] {""}
    *[HAS] {""}
    • <b>Опис:</b> <i>{ $description }</i>
    }
    </blockquote>

msg-subscription-duration =
    { $single_duration ->
    [1] {""}
    *[0] <b>⏳ Вибір тривалості</b>
    }

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    { msg-subscription-details }

msg-subscription-payment-method =
    <b>💳 Вибір способу оплати</b>

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription-conditional }

    <b>💳 Підписка, що купується:</b>
    <blockquote>
    • <b>Тариф:</b> { $plan_name }
    • <b>Ліміт трафіку</b>: { $traffic }
    • <b>Ліміт пристроїв</b>: { $device_limit }{ $is_plan_device_unlimited ->
        [0] {" "}шт.
        *[1] {""}
    }{ $purchase_type ->
        [RENEW] { $renew_extra_devices ->
            [0] {""}
            *[other] {"\u000A"}• <b>Дод. пристрої:</b> { $renew_extra_devices } шт.
        }
        *[OTHER] {""}
    }
    • <b>Тривалість:</b> { $period }
    { $description ->
    [0] {""}
    *[HAS] {""}
    • <b>Опис:</b> <i>{ $description }</i>
    }
    </blockquote>

msg-subscription-confirm-balance =
    <b>✅ Підтвердження оплати</b>

    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    <b>📋 Підсумок:</b>
    <blockquote>
    • <b>Спосіб оплати:</b> 💰 З балансу{ $discount_percent ->
        [0] {""}
        *[OTHER] {"\u000A"}• <b>Знижка:</b> { $discount_percent }%
    }
    • <b>Ціна підписки:</b> { $subscription_price }{ $discount_percent ->
        [0] {""}
        *[OTHER] {" "}<s>{ $original_subscription_price }</s>
    }{ $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод.пристрої:</b> { $extra_devices_cost }
            *[0] {""}
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод.пристрої:</b> { $extra_devices_cost }
            *[0] {""}
        }
        *[OTHER] {""}
    }
    {"────────────────────────"}
    • <b>Загальна вартість:</b> 💰 { $total_payment }{ $discount_percent ->
        [0] {""}
        *[OTHER] {" "}<s>{ $original_total }</s>
    }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Вашу поточну підписку буде продовжено.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
            *[0] ⚠️ <i>Підписка буде замінена без перерахунку залишкового терміну, а додаткові пристрої будуть видалені.</i>
        }
    }
        *[OTHER] {""}
    }

msg-subscription-confirm-yoomoney =
    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    <b>📋 Підсумок:</b>
    <blockquote>
    • <b>Спосіб оплати:</b> 💳 Банківська картка{ $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод. пристрої:</b> { $extra_devices_cost } ({ $extra_devices_monthly_cost }/міс)
            *[0] {""}
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод. пристрої:</b> { $extra_devices_cost }
            *[0] {""}
        }
        *[OTHER] {""}
    }
    • <b>Сума до оплати:</b> 💰 { $total_payment }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Вашу поточну підписку буде продовжено.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
            *[0] ⚠️ <i>Підписка буде замінена без перерахунку залишкового терміну, а додаткові пристрої будуть видалені.</i>
        }
    }
        *[OTHER] {""}
    }

    <i>⚠️ Підтвердження оплати може зайняти до 5 хвилин. Меню оновиться автоматично після підтвердження.</i>

msg-subscription-confirm-yookassa =
    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    <b>📋 Підсумок:</b>
    <blockquote>
    • <b>Спосіб оплати:</b> 💳 Банківська картка{ $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод. пристрої:</b> { $extra_devices_cost } ({ $extra_devices_monthly_cost }/міс)
            *[0] {""}
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод. пристрої:</b> { $extra_devices_cost }
            *[0] {""}
        }
        *[OTHER] {""}
    }
    • <b>Сума до оплати:</b> 💰 { $total_payment }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Вашу поточну підписку буде продовжено.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
            *[0] ⚠️ <i>Підписка буде замінена без перерахунку залишкового терміну, а додаткові пристрої будуть видалені.</i>
        }
    }
        *[OTHER] {""}
    }

    <i>⚠️ Підтвердження оплати може зайняти до 5 хвилин. Меню оновиться автоматично після підтвердження.</i>

msg-subscription-confirm =
    { $is_free ->
        [1] <b>🎁 Підтвердження отримання</b>
        *[0] {""}
    }
    { hdr-user-profile }
    <blockquote>
    { frg-user-info-inline }
    </blockquote>

    { hdr-subscription }
    <blockquote>
    { frg-subscription-inline }
    </blockquote>

    { msg-subscription-details }

    { $is_free ->
        [1] { $purchase_type ->
        [RENEW] <i>⚠️ Вашу поточну підписку буде продовжено.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
            *[0] ⚠️ <i>Підписка буде замінена без перерахунку залишкового терміну, а додаткові пристрої будуть видалені.</i>
        }
    }
        *[OTHER] {""}
    }
        *[0] <b>📋 Підсумок:</b>
    <blockquote>
    • <b>Спосіб оплати:</b> { gateway-type }{ $discount_percent ->
        [0] {""}
        *[OTHER] {"\u000A"}• <b>Знижка:</b> { $discount_percent }%
    }{ $purchase_type ->
        [RENEW] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод. пристрої:</b> { $extra_devices_cost } ({ $extra_devices_monthly_cost }/міс)
            *[0] {""}
        }
        [CHANGE] { $has_extra_devices_cost ->
            [1] {"\u000A"}• <b>Дод. пристрої:</b> { $extra_devices_cost }
            *[0] {""}
        }
        *[OTHER] {""}
    }
    • <b>Сума до оплати:</b> 💰 { $total_payment }
    </blockquote>

    { $purchase_type ->
        [RENEW] <i>⚠️ Вашу поточну підписку буде продовжено.</i>
        [CHANGE] 
    { $extra_devices ->
        [0] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
        *[OTHER] { $is_plan_device_unlimited ->
            [1] ⚠️ <i>Поточна підписка буде замінена без перерахунку залишкового терміну.</i>
            *[0] ⚠️ <i>Підписка буде замінена без перерахунку залишкового терміну, а додаткові пристрої будуть видалені.</i>
        }
    }
        *[OTHER] {""}
    }

    <i>⚠️ Підтвердження оплати може зайняти до 5 хвилин. Меню оновиться автоматично після підтвердження.</i>
    }

msg-subscription-trial =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    <b>✅ Пробная подписка успешно получена!</b>

msg-subscription-referral-code =
    <b>📢 Реферальная подписка</b>

    Введите реферальный код пользователя, который вас пригласил:

msg-subscription-referral-success =
    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

    <b>🎉 Підписка успішно покращена до Реферальної!</b>

msg-subscription-referral-attached =
    <b>🎉 Вітаємо!</b>

    Ви стали учасником реферальної програми і тепер будете отримувати додаткові бонуси при поповненні рахунку!

msg-subscription-promocode =
    <b>🎟 Введіть промокод</b>

    Надішліть код промокоду для активації бонусів або знижок.

    Ви можете ввести <b>реферальний код</b> користувача, щоб брати участь у реферальній програмі.

msg-subscription-success =
    { $purchase_type ->
    [ADD_DEVICE] ✅<i>До вашої підписки додано { $device_count } { $device_count ->
        [1] пристрій
        [2] пристрої
        [3] пристрої
        [4] пристрої
        *[other] пристроїв
    }!</i>
    [NEW] { msg-subscription-new-success }
    [RENEW] { msg-subscription-renew-success }
    [CHANGE] { msg-subscription-change-success }
    *[OTHER] {""}
    }

    { hdr-user-profile }
    { frg-user }

    { hdr-subscription }
    { frg-subscription }

msg-subscription-new-success = ✅ <i>Було підключено тарифний план { $plan_name }.</i>
msg-subscription-renew-success = ✅ <i>Вашу підписку успішно продовжено!</i>
msg-subscription-change-success = ✅<i>Вашу підписку було змінено.</i>

msg-subscription-failed = 
    <b>❌ Произошла ошибка!</b>

    Не волнуйтесь, техподдержка уже уведомлена и свяжется с вами в ближайшее время. Приносим извинения за неудобства.


# Importer
msg-importer-main =
    <b>📥 Импорт пользователей</b>

    Запуск синхронизации: проверка всех пользователей в Панели. Если пользователя нет в базе бота, он будет создан и получит временную подписку. Если данные пользователя отличаются, они будут автоматически обновлены.

msg-importer-from-xui =
    <b>📥 Импорт пользователей (3X-UI)</b>
    
    { $has_exported -> 
    [1]
    <b>🔍 Найдено:</b>
    <blockquote>
    Всего пользователей: { $total }
    С активной подпиской: { $active }
    С истекшей подпиской: { $expired }
    </blockquote>
    *[0]
    Импортируются все активные пользователи с числовым email.

    Рекомендуется заранее отключить пользователей, у которых в поле email отсутствует Telegram ID. Операция может занять значительное время в зависимости от количества пользователей.

    Отправьте файл базы данных (в формате .db).
    }

msg-importer-squads =
    <b>🔗 Список внутренних сквадов</b>

    Выберите, какие внутренние группы будут доступны импортированным пользователям.

msg-importer-import-completed =
    <b>📥 Импорт пользователей завершен</b>
    
    <b>📃 Информация:</b>
    <blockquote>
    • <b>Всего пользователей</b>: { $total_count }
    • <b>Успешно импортированы</b>: { $success_count }
    • <b>Не удалось импортировать</b>: { $failed_count }
    </blockquote>

msg-importer-sync-completed =
    <b>📥 Синхронизация пользователей завершена</b>

    <b>📃 Информация:</b>
    <blockquote>
    Всего пользователей в панели: { $total_panel_users }
    Всего пользователей в боте: { $total_bot_users }

    Новые пользователи: { $added_users }
    Добавлены подписки: { $added_subscription }
    Обновлены подписки: { $updated}
    
    Пользователи без Telegram ID: { $missing_telegram }
    Ошибки при синхронизации: { $errors }
    </blockquote>

msg-importer-sync-bot-to-panel-completed =
    <b>📤 Синхронизация из телеграма в панель завершена</b>

    <b>📃 Информация:</b>
    <blockquote>
    Всего пользователей в боте: { $total_bot_users }

    Создано в панели: { $created }
    Обновлено в панели: { $updated }
    Пропущено (без подписки): { $skipped }
    Ошибки при синхронизации: { $errors }
    </blockquote>


# Promocodes
msg-promocodes-main = <b>🎟 Промокоды</b>

    Создавайте и управляйте промокодами для пользователей.

msg-promocodes-search = <b>🔍 Поиск промокода</b>

    Введите код промокода для поиска.

msg-promocodes-list = <b>📃 Список промокодов</b>

    { $count ->
        [0] Нет созданных промокодов.
        [1] Найден { $count } промокод.
        [2] Найдено { $count } промокода.
        [3] Найдено { $count } промокода.
        [4] Найдено { $count } промокода.
        *[other] Найдено { $count } промокодов.
    }

msg-promocode-view =
    <b>🎟 Просмотр промокода</b>

    <blockquote>
    • <b>Код</b>: <code>{ $code }</code>
    • <b>Тип</b>: { promocode-type }
    • <b>Статус</b>: { $is_active -> 
        [1] 🟢 Включен
        *[0] 🔴 Выключен
        }
    </blockquote>

    <blockquote>
    { $promocode_type ->
    [DURATION] • <b>Бонус</b>: +{ $reward }
    [PERSONAL_DISCOUNT] • <b>Постоянная скидка</b>: { $reward }%
    [PURCHASE_DISCOUNT] • <b>Одноразовая скидка</b>: { $reward }%
    *[OTHER] • <b>Награда</b>: { $reward }
    }
    • <b>Срок действия</b>: { $lifetime }
    • <b>Использовано</b>: { $activations_count } / { $max_activations }
    </blockquote>

msg-promocode-configurator =
    <b>🎟 Создание промокода</b>

    <blockquote>
    • <b>Название</b>: { $name }
    • <b>Код</b>: <code>{ $code }</code>
    • <b>Тип награды</b>: { promocode-type }
    </blockquote>

    <blockquote>
    { $promocode_type ->
    [DURATION] • <b>Бонус</b>: +{ $reward }
    [PERSONAL_DISCOUNT] • <b>Постоянная скидка</b>: { $reward }%
    [PURCHASE_DISCOUNT] • <b>Одноразовая скидка</b>: { $reward }%
    *[OTHER] • <b>Награда</b>: { $reward }
    }
    • <b>Срок действия</b>: { $lifetime }
    • <b>Лимит активаций</b>: { $max_activations }
    </blockquote>

    Выберите пункт для изменения.

msg-promocode-name = <b>📝 Название промокода</b>

    Введите название промокода (1-50 символов).

msg-promocode-code = <b>🏷️ Код промокода</b>

    Введите код промокода (3-20 символов) или нажмите кнопку для генерации случайного кода.

msg-promocode-type = <b>🔖 Выберите тип промокода:</b>

    <blockquote>
    • <b>Одноразовая скидка</b> - скидка исчезнет после первой покупки, или по истечению срока действия промокода.

    • <b>Постоянная скидка</b> - постоянная скидка для пользователя.

    • <b>Дни к подписке</b> - Добавление дней к подписке пользователя.
    </blockquote>

msg-promocode-reward = <b>🎁 Награда</b>

    <b>Тип награды</b>: { promocode-type }

    { $promocode_type ->
    [DURATION] Введите <b>количество дней</b> для бонуса к подписке.
    [PERSONAL_DISCOUNT] Введите <b>процент скидки</b> (1-100) для постоянной скидки.
    [PURCHASE_DISCOUNT] Введите <b>процент скидки</b> (1-100) для скидки на покупку.
    *[OTHER] Введите значение награды.
    }

msg-promocode-lifetime = <b>⌛ Срок действия</b>

    Выберите срок действия промокода в днях.

msg-promocode-lifetime-input = ⌛️Введите срок действия промокода в днях.

msg-promocode-quantity = <b>🔢 Количество активаций</b>

    Выберите максимальное количество активаций промокода.

msg-promocode-quantity-input = 🔢 Введите количество активаций промокода.
msg-promocode-access = <b>📦 Доступ к тарифам</b>

# Bonus Activation
msg-bonus-activate =
    <b>💎 Активация бонусов</b>

    Доступно бонусов: <b>{ $referral_balance }</b>
    Выбранная сумма: <b>{ $current_bonus_amount } ₽</b>

msg-bonus-activate-custom =
    <b>💎 Активация бонусов</b>

    Доступно бонусов: <b>{ $referral_balance }</b>

    Введите сумму для активации (от 1 до { $referral_balance }):

# Terms of Service Settings
msg-dashboard-settings-tos =
    <b>📋 Соглашение с пользователем</b>
    
    <blockquote>
    • Статус: { $status }
    • Источник: { $source }
    </blockquote>

    🔽 Укажите ссылку на документ с правилами.

msg-dashboard-settings-tos-url =
    <b>🔗 Ссылка на Соглашение</b>

    <blockquote>
    Введите ссылку (в формате https://telegram.org/tos).
    </blockquote>

# Community Settings
msg-dashboard-settings-community =
    <b>👥 Сообщество</b>
    
    <blockquote>
    • Статус: { $status }
    • Телеграм группа: { $url_display }
    </blockquote>

    🔽 Укажите ссылку на Telegram группу.

msg-dashboard-settings-community-url =
    <b>🔗 Ссылка на Telegram группу</b>

    <blockquote>
    Введите ссылку (в формате https://t.me/+код или https://t.me/название_группы).
    </blockquote>

# Finances Settings
msg-dashboard-settings-finances =
    <b>💰 Финансы</b>
    
    <blockquote>
    • <b>Валюта по умолчанию:</b> { $default_currency } ({ $default_currency_name })
    </blockquote>

    <i>ℹ️ При включении синхронизации курс валют автоматически синхронизируются с курсом центрабанка РФ.</i>

# Currency Rates Settings
msg-dashboard-settings-currency-rates =
    <b>💱 Курс валют</b>

    Укажите курс обмена относительно рубля.
    Цены в тарифах будут автоматически пересчитываться.

msg-dashboard-settings-currency-rate-input =
    <b>💱 Курс { $currency }</b>

    Введите курс { $symbol } к рублю (например: 90.5).
    1 { $symbol } = X ₽

# Payment Link for Extra Devices
msg-add-device-payment-link =
    <b>💳 Посилання для оплати</b>

    Натисніть кнопку нижче, щоб перейти до оплати за додаткові пристрої.

# Device Deletion Warning
msg-device-deletion-warning = ⚠️ Для видалення натисніть ще раз на кнопку видалити.
    Пристрій працюватиме до кінця оплаченого терміну.
msg-extra-device-deletion-confirm = ⚠️ Додаткові пристрої будуть видалені { $expires_date }.
    Вони працюватимуть до кінця оплаченого терміну і не будуть враховуватися при подовженні підписки.
    Натисніть кнопку видалення повторно для підтвердження.

# Autobackup
msg-db-autobackup =
    <b>⏰ Налаштування автобекапу</b>

    <blockquote>
    • <b>Токен бота:</b> { $token_display }
    • <b>Telegram ID отримувача:</b> { $chat_id_display }
    • <b>Частота:</b> { $frequency_display }
    • <b>Останній бекап:</b> { $last_backup }
    </blockquote>

    Бот автоматично надсилатиме бекап отримувачу із заданою частотою.

msg-db-autobackup-token =
    <b>🤖 Токен бота для автобекапу</b>

    Введіть токен бота, від якого надсилатимуться бекапи.
    Отримати токен можна у <a href="https://t.me/BotFather">@BotFather</a>.

msg-db-autobackup-chat-id =
    <b>💬 Chat ID для автобекапу</b>

    Введіть Telegram ID чату або користувача для отримання бекапів.
    Дізнатися свій ID можна у <a href="https://t.me/userinfobot">@userinfobot</a>.

msg-db-autobackup-frequency =
    <b>🕐 Частота автобекапу</b>

    Оберіть як часто створювати резервні копії:


# Support Settings
msg-bot-support-settings =
    <b>🆘 Налаштування підтримки</b>

    <blockquote>
    • Отримувач: { $has_recipient ->
        [1] <code>{ $recipient }</code>
        *[0] Не призначено
    }
    </blockquote>

    ℹ️<i> Кнопка «Допомога» буде прихована в головному меню, якщо жодна з функцій не призначена.</i>

msg-bot-support-recipient =
    <b>📝 Отримувач підтримки</b>

    <blockquote>
    • Отримувач: { $has_recipient ->
        [1] <code>{ $recipient }</code>
        *[0] Не призначено
    }
    </blockquote>

    <i>ℹ️ Надішліть username (наприклад <code>support_bot</code>)
    або Telegram ID отримувача.</i>

msg-bot-support-faq =
    <b>❓ Часті питання</b>

    { $has_faq ->
        [1] { $faq_preview }
        *[0] <i>Питання не заповнені.</i>
    }

    <i>ℹ️ Надішліть текст із питаннями та відповідями.
    Використовуйте <code>+++</code> для розділення між блоками питань.</i>

# Help menu (user)
msg-help-menu =
    <b>🆘 Допомога</b>

    <i>Оберіть дію:</i>

msg-help-faq =
    <b>❓ Часті питання</b>

    { $faq_text }

msg-branding =
    <b>🎨 Брендування</b>

    Оберіть потрібний пункт.

msg-branding-upload-banner =
    <b>🖼 Завантаження банера</b>

    Надішліть зображення (JPG або PNG), яке стане банером.
