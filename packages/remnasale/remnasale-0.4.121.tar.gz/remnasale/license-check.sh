#!/bin/bash
# ═══════════════════════════════════════════════
# Периодическая проверка лицензии Remnasale
# Устанавливается как systemd timer
# ═══════════════════════════════════════════════

PROJECT_DIR="/opt/remnasale"
ENV_FILE="$PROJECT_DIR/.env"
STATE_FILE="/var/lib/remnasale-license/state"
INTERVAL_FILE="/var/lib/remnasale-license/interval"
LAST_OK_FILE="/var/lib/remnasale-license/last_ok"
OFFLINE_FILE="/var/lib/remnasale-license/offline_since"
BLOCKED_FILE="$PROJECT_DIR/.license_blocked"
NOTIFIED_FILE="$PROJECT_DIR/.license_notified"
SHUTDOWN_DELAY=3600   # 1 час
OFFLINE_GRACE=1209600  # 14 дней (по умолчанию, перезаписывается настройкой сервера)
GRACE_FILE="/var/lib/remnasale-license/offline_grace_days"

mkdir -p /var/lib/remnasale-license

# Читаем .env
if [ ! -f "$ENV_FILE" ]; then
    exit 0
fi

LICENSE_KEY=$(grep '^LICENSE_KEY=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
LICENSE_SERVER=$(grep '^LICENSE_SERVER=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
BOT_TOKEN=$(grep '^BOT_TOKEN=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
DB_USER=$(grep '^DATABASE_USER=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')
DB_NAME=$(grep '^DATABASE_NAME=' "$ENV_FILE" 2>/dev/null | cut -d'=' -f2- | tr -d '\t\r\n ')

if [ -z "$LICENSE_KEY" ] || [ -z "$LICENSE_SERVER" ]; then
    exit 0
fi

# ── Отправка Telegram-сообщения всем DEV-пользователям ──────────────────────
_send_tg_message() {
    local text="$1"
    local btn_text="$2"
    local btn_style="${3:-}"

    [ -z "$BOT_TOKEN" ] && return 0
    [ -z "$DB_USER" ] && return 0
    [ -z "$DB_NAME" ] && return 0

    local ADMIN_IDS
    ADMIN_IDS=$(docker exec remnasale-db psql -U "$DB_USER" -d "$DB_NAME" -t \
        -c "SELECT telegram_id FROM users WHERE role='DEV';" 2>/dev/null | tr -d ' ')

    for TG_ID in $ADMIN_IDS; do
        [ -z "$TG_ID" ] && continue
        curl -s --max-time 10 \
            -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
            -H "Content-Type: application/json" \
            -d "$(python3 -c "
import json, sys
style = sys.argv[4] if len(sys.argv) > 4 else None
btn = {'text': sys.argv[3], 'callback_data': 'license_warning_close'}
if style:
    btn['style'] = style
print(json.dumps({
    'chat_id': int(sys.argv[2]),
    'text': sys.argv[1],
    'parse_mode': 'HTML',
    'reply_markup': {'inline_keyboard': [[btn]]}
}))
" "$text" "$TG_ID" "$btn_text" "$btn_style")" \
            >/dev/null 2>&1 || true
    done
}

# Определяем IP сервера
SERVER_IP=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null || \
            curl -s --max-time 5 https://ifconfig.me 2>/dev/null || \
            curl -s --max-time 5 https://icanhazip.com 2>/dev/null || echo "")

# ── Уведомление сервера лицензий о потере/восстановлении связи ──────────────
_notify_license_server() {
    local event="$1"
    local days_left="${2:-0}"
    [ -z "$LICENSE_SERVER" ] && return
    [ -z "$LICENSE_KEY" ] && return
    curl -s --max-time 10 \
        -X POST "${LICENSE_SERVER}/api/v1/notify/offline" \
        -H "Content-Type: application/json" \
        -d "{\"license_key\":\"$LICENSE_KEY\",\"server_ip\":\"$SERVER_IP\",\"days_left\":$days_left,\"event\":\"$event\"}" \
        >/dev/null 2>&1 || true
}

# ── Офлайн grace period ───────────────────────────────────────────────────────
_check_offline_grace() {
    local NOW
    NOW=$(date +%s)

    # Startup grace: не отправлять уведомление если система только запустилась
    # (ждём как минимум один интервал проверки после перезагрузки)
    local _UPTIME
    _UPTIME=$(awk '{print int($1)}' /proc/uptime 2>/dev/null || echo 999999)
    local _STARTUP_GRACE_SECS=120  # по умолчанию 2 минуты
    if [ -f "$INTERVAL_FILE" ]; then
        local _SAVED_INTERVAL
        _SAVED_INTERVAL=$(cat "$INTERVAL_FILE" 2>/dev/null | tr -d '\n' || echo 1)
        if [[ "$_SAVED_INTERVAL" =~ ^[0-9]+$ ]] && [ "$_SAVED_INTERVAL" -gt 0 ]; then
            _STARTUP_GRACE_SECS=$(( _SAVED_INTERVAL * 60 ))
        fi
    fi
    if [ "$_UPTIME" -lt "$_STARTUP_GRACE_SECS" ]; then
        # Система только загрузилась — не тревожить, дождаться следующей проверки
        echo "offline" > "$STATE_FILE"
        exit 0
    fi

    # Читаем сохранённый grace period (из настроек сервера)
    local _GRACE="$OFFLINE_GRACE"
    if [ -f "$GRACE_FILE" ]; then
        local _saved_days
        _saved_days=$(cat "$GRACE_FILE" 2>/dev/null | tr -d '\n')
        if [[ "$_saved_days" =~ ^[0-9]+$ ]] && [ "$_saved_days" -gt 0 ]; then
            _GRACE=$(( _saved_days * 86400 ))
        fi
    fi

    # Если есть запись последней успешной проверки — считаем от неё
    if [ -f "$LAST_OK_FILE" ]; then
        local LAST_OK
        LAST_OK=$(cat "$LAST_OK_FILE" 2>/dev/null | tr -d '\n')
        local OFFLINE_ELAPSED=$(( NOW - LAST_OK ))

        # Записываем начало офлайна и уведомляем сервер лицензий
        if [ ! -f "$OFFLINE_FILE" ]; then
            echo "$NOW" > "$OFFLINE_FILE"
            echo "$(date): License server unreachable, offline grace started" >> /var/lib/remnasale-license/check.log
            # Округляем ВВЕРХ чтобы показывать 7, а не 6 из-за потраченных секунд
            local DAYS_LEFT=$(( (_GRACE - OFFLINE_ELAPSED + 86399) / 86400 ))
            [ "$DAYS_LEFT" -lt 0 ] && DAYS_LEFT=0
            _notify_license_server "offline" "$DAYS_LEFT"
        fi

        if [ "$OFFLINE_ELAPSED" -ge "$_GRACE" ]; then
            local GRACE_DAYS=$(( _GRACE / 86400 ))
            echo "$(date): Offline grace expired (${OFFLINE_ELAPSED}s), shutting down" >> /var/lib/remnasale-license/check.log
            local SHUTDOWN_MSG
            SHUTDOWN_MSG=$(printf '🔴 Автономный режим завершён!\n\nСервер лицензий недоступен более %d дней.\nБот остановлен.' "$GRACE_DAYS")
            _send_tg_message "$SHUTDOWN_MSG" "❌ Закрыть" "danger"
            cd "$PROJECT_DIR" && docker compose stop remnasale remnasale-taskiq-worker remnasale-taskiq-scheduler >/dev/null 2>&1
            echo "offline_expired" > "$STATE_FILE"
            exit 1
        fi
    else
        # Первый запуск — считаем текущий момент как последнюю проверку
        echo "$NOW" > "$LAST_OK_FILE"
    fi

    echo "offline" > "$STATE_FILE"
    exit 0
}

if [ -z "$SERVER_IP" ]; then
    _check_offline_grace
fi

# Проверяем лицензию
RESPONSE=$(curl -s --max-time 10 \
    -X POST "${LICENSE_SERVER}/api/v1/license/verify" \
    -H "Content-Type: application/json" \
    -d "{\"license_key\": \"$LICENSE_KEY\", \"server_ip\": \"$SERVER_IP\"}" \
    2>/dev/null)

if [ -z "$RESPONSE" ]; then
    _check_offline_grace
fi

VALID=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('valid',''))" 2>/dev/null || echo "")
REASON=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('reason',''))" 2>/dev/null || echo "")

# Ответ не JSON (например nginx 502 при рестарте) — считаем как офлайн
if [ -z "$VALID" ]; then
    _check_offline_grace
fi

CHECK_INTERVAL=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('check_interval',1))" 2>/dev/null || echo "1")

echo "$CHECK_INTERVAL" > "$INTERVAL_FILE"

# Обновляем интервал systemd-таймера если он изменился
_TIMER_FILE="/etc/systemd/system/remnasale-license-check.timer"
if [ -f "$_TIMER_FILE" ]; then
    _CURRENT_INTERVAL=$(grep 'OnUnitActiveSec=' "$_TIMER_FILE" 2>/dev/null | sed 's/OnUnitActiveSec=//')
    _NEW_INTERVAL="${CHECK_INTERVAL}min"
    if [ "$_CURRENT_INTERVAL" != "$_NEW_INTERVAL" ]; then
        sed -i "s/OnUnitActiveSec=.*/OnUnitActiveSec=${_NEW_INTERVAL}/" "$_TIMER_FILE"
        systemctl daemon-reload >/dev/null 2>&1
        systemctl restart remnasale-license-check.timer >/dev/null 2>&1
    fi
fi

if [ "$VALID" = "True" ]; then
    NOW_OK=$(date +%s)
    echo "$NOW_OK" > "$LAST_OK_FILE"

    # Сохраняем настройку offline_grace_days с сервера
    OFFLINE_GRACE_DAYS=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('offline_grace_days',14))" 2>/dev/null || echo "14")
    echo "$OFFLINE_GRACE_DAYS" > "$GRACE_FILE" 2>/dev/null || true

    # Отправляем информацию о боте на лицензионный сервер
    _report_bot_info() {
        [ -z "$BOT_TOKEN" ] && return 0
        [ -z "$LICENSE_SERVER" ] && return 0
        local BOT_USERNAME
        BOT_USERNAME=$(curl -s --max-time 5 "https://api.telegram.org/bot${BOT_TOKEN}/getMe" \
            2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('result',{}).get('username',''))" 2>/dev/null || echo "")
        local DEV_IDS=""
        if [ -n "$DB_USER" ] && [ -n "$DB_NAME" ]; then
            DEV_IDS=$(docker exec remnasale-db psql -U "$DB_USER" -d "$DB_NAME" -t \
                -c "SELECT telegram_id FROM users WHERE role='DEV';" 2>/dev/null \
                | tr -d ' ' | grep -v '^$' | tr '\n' ',' | sed 's/,$//')
        fi
        local REMNASALE_VERSION=""
        REMNASALE_VERSION=$(grep '^version:' "${PROJECT_DIR}/version" 2>/dev/null | awk '{print $2}' || echo "")
        curl -s --max-time 10 \
            -X POST "${LICENSE_SERVER}/api/v1/license/report" \
            -H "Content-Type: application/json" \
            -d "{\"license_key\":\"$LICENSE_KEY\",\"bot_token\":\"$BOT_TOKEN\",\"bot_username\":\"$BOT_USERNAME\",\"dev_ids\":\"$DEV_IDS\",\"remnasale_version\":\"$REMNASALE_VERSION\"}" \
            >/dev/null 2>&1 || true
    }
    _report_bot_info

    # Были офлайн — уведомляем сервер лицензий о восстановлении связи
    if [ -f "$OFFLINE_FILE" ]; then
        rm -f "$OFFLINE_FILE"
        echo "$(date): License server connection restored" >> /var/lib/remnasale-license/check.log
        _notify_license_server "online" "0"
    fi

    # Лицензия валидна — если была блокировка, разблокируем и уведомляем
    if [ -f "$BLOCKED_FILE" ]; then
        rm -f "$BLOCKED_FILE"
        rm -f "$NOTIFIED_FILE"
        cd "$PROJECT_DIR" && docker compose up -d >/dev/null 2>&1
        echo "$(date): License restored, services started" >> /var/lib/remnasale-license/check.log
    fi
    echo "ok" > "$STATE_FILE"
    exit 0
fi

# ── Лицензия невалидна ──────────────────────────────────────────────
REASON_TEXT="Неизвестная ошибка"
case "$REASON" in
    ip_mismatch)     REASON_TEXT="Лицензионный ключ зафиксирован на другом сервере" ;;
    suspended)       REASON_TEXT="Лицензия приостановлена" ;;
    expired)         REASON_TEXT="Срок лицензии истёк" ;;
    not_found)       REASON_TEXT="Лицензионный ключ не найден" ;;
    domain_mismatch) REASON_TEXT="Домен сервера не совпадает" ;;
    blacklisted)     REASON_TEXT="Ключ заблокирован администратором" ;;
esac

NOW=$(date +%s)

# Первое обнаружение — уведомляем и записываем время
if [ ! -f "$BLOCKED_FILE" ]; then
    echo "$NOW:$REASON_TEXT" > "$BLOCKED_FILE"
    echo "$(date): License BLOCKED - $REASON_TEXT" >> /var/lib/remnasale-license/check.log

    echo "blocked:$REASON" > "$STATE_FILE"
    exit 0
fi

# Уже заблокировано — проверяем, прошло ли 1 час
BLOCKED_AT=$(cat "$BLOCKED_FILE" | cut -d: -f1)
ELAPSED=$(( NOW - BLOCKED_AT ))

if [ "$ELAPSED" -ge "$SHUTDOWN_DELAY" ]; then
    echo "$(date): License shutdown after ${ELAPSED}s - $REASON_TEXT" >> /var/lib/remnasale-license/check.log
    cd "$PROJECT_DIR" && docker compose stop remnasale remnasale-taskiq-worker remnasale-taskiq-scheduler >/dev/null 2>&1
fi

echo "blocked:$REASON" > "$STATE_FILE"
