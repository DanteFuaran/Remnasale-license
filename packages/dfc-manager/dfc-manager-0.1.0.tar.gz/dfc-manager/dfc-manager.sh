#!/bin/bash
# ═══════════════════════════════════════════════════════════
#   DFC Manager — Установщик Remnawave VPN & DFC Ecosystem
#   https://about.dfc-online.com
#   Установка: bash <(curl -sL https://rs-license.dfc-online.com/api/v1/manager/install)
# ═══════════════════════════════════════════════════════════

# ─── Bootstrap: запуск через curl или не из установленной копии ─────────
_INSTALL_DIR="/usr/local/dfc-manager"
_INSTALL_SCRIPT="${_INSTALL_DIR}/dfc-manager.sh"
_DFC_SERVER="https://rs-license.dfc-online.com"

# Если запущены не из установленной копии (напр. через curl/pipe/tmp) — установить или переключиться
if [ "$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null)" != "$_INSTALL_SCRIPT" ]; then
    if [ -f "$_INSTALL_SCRIPT" ] && [ -d "${_INSTALL_DIR}/lib" ]; then
        exec "$_INSTALL_SCRIPT" "$@"
    fi
    _BLUE='\033[1;34m'; _GREEN='\033[0;32m'; _RED='\033[0;31m'; _NC='\033[0m'
    echo -e "${_BLUE}══════════════════════════════════════${_NC}"
    echo -e "${_GREEN}      🛠️  Установка DFC Manager${_NC}"
    echo -e "${_BLUE}══════════════════════════════════════${_NC}"
    echo
    trap 'stty sane 2>/dev/null; tput cnorm 2>/dev/null; rm -rf "${_INSTALL_DIR}" 2>/dev/null; exit 130' INT TERM
    cd /opt >/dev/null 2>&1 || true
    mkdir -p /usr/local/bin || { echo -e "${_RED}✖ Ошибка создания /usr/local/bin${_NC}"; exit 1; }
    rm -rf "${_INSTALL_DIR}"
    mkdir -p "${_INSTALL_DIR}"

    echo -ne "  ${_BLUE}Загрузка DFC Manager...${_NC}"
    if ! curl -sL --max-time 120 --connect-timeout 15 \
            "${_DFC_SERVER}/api/v1/manager/download" \
            | tar -xz -C "${_INSTALL_DIR}" --strip-components=1 2>/dev/null; then
        echo -e "\r  ${_RED}✖ Не удалось загрузить DFC Manager${_NC}                "
        echo -e "  ${_RED}Проверьте соединение с интернетом${_NC}"
        rm -rf "${_INSTALL_DIR}"
        exit 1
    fi
    echo -e "\r  ${_GREEN}✅ DFC Manager загружен${_NC}                         "

    chmod +x "$_INSTALL_SCRIPT"
    exec "$_INSTALL_SCRIPT" "$@"
fi

# ─── Основной скрипт ─────────────────────────────────────────
cd /opt >/dev/null 2>&1 || true

set -euo pipefail

# Определяем директорию скрипта — bootstrap гарантирует запуск из _INSTALL_DIR
_resolved="$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null)" || true
if [ -n "$_resolved" ] && [ -f "$_resolved" ]; then
    SCRIPT_DIR="$(cd "$(dirname "$_resolved")" && pwd)"
else
    SCRIPT_DIR="${_INSTALL_DIR%/}"
fi
unset _resolved

# ─── Загрузка модулей ───

# Core: базовые определения (порядок важен)
source "${SCRIPT_DIR}/lib/core/constants.sh"
source "${SCRIPT_DIR}/lib/core/colors.sh"
source "${SCRIPT_DIR}/lib/core/terminal.sh"
source "${SCRIPT_DIR}/lib/core/ui.sh"
source "${SCRIPT_DIR}/lib/core/system.sh"
source "${SCRIPT_DIR}/lib/core/nginx.sh"

# Install: генераторы и утилиты установки
source "${SCRIPT_DIR}/lib/install/generators.sh"
source "${SCRIPT_DIR}/lib/install/log_rotation.sh"
source "${SCRIPT_DIR}/lib/install/domain.sh"
source "${SCRIPT_DIR}/lib/install/certificates.sh"
source "${SCRIPT_DIR}/lib/install/templates.sh"
source "${SCRIPT_DIR}/lib/install/api.sh"
source "${SCRIPT_DIR}/lib/install/config.sh"
source "${SCRIPT_DIR}/lib/install/full.sh"
source "${SCRIPT_DIR}/lib/install/panel.sh"
source "${SCRIPT_DIR}/lib/install/node.sh"
source "${SCRIPT_DIR}/lib/install/subpage.sh"

# License: управление лицензионными ключами
source "${SCRIPT_DIR}/lib/license/license.sh"

# Install: Remnasale и DFC Support (требуют лицензии)
source "${SCRIPT_DIR}/lib/install/remnasale.sh"
source "${SCRIPT_DIR}/lib/install/support.sh"

# Manage: управление установкой
source "${SCRIPT_DIR}/lib/manage/detect.sh"
source "${SCRIPT_DIR}/lib/manage/services.sh"
source "${SCRIPT_DIR}/lib/manage/database.sh"
source "${SCRIPT_DIR}/lib/manage/domains.sh"
source "${SCRIPT_DIR}/lib/manage/access.sh"
source "${SCRIPT_DIR}/lib/manage/node.sh"
source "${SCRIPT_DIR}/lib/manage/template.sh"

# Extra: дополнительные настройки
source "${SCRIPT_DIR}/lib/extra/swap.sh"
source "${SCRIPT_DIR}/lib/extra/bbr.sh"
source "${SCRIPT_DIR}/lib/extra/fail2ban.sh"
source "${SCRIPT_DIR}/lib/extra/ufw.sh"
source "${SCRIPT_DIR}/lib/extra/logrotate.sh"
source "${SCRIPT_DIR}/lib/extra/warp.sh"
source "${SCRIPT_DIR}/lib/extra/beszel.sh"
source "${SCRIPT_DIR}/lib/extra/menu.sh"

# Update: обновление и удаление
source "${SCRIPT_DIR}/lib/update/version.sh"
source "${SCRIPT_DIR}/lib/update/script.sh"

# Menu: главное меню
source "${SCRIPT_DIR}/lib/menu/main.sh"

# ═══════════════════════════════════════════════
# ТОЧКА ВХОДА
# ═══════════════════════════════════════════════


check_root
check_os

# Если запущены НЕ из установленной копии - скачиваем свежую и переключаемся
install_script
if [ "${DFC_INSTALLED_RUN:-}" != "1" ]; then
    export DFC_INSTALLED_RUN=1
    exec /usr/local/bin/dfc-manager
fi

# ─── Подготовка к запуску — спиннер единожды, минимум 1 сек ──────────────────
if [ "${DFC_AUTO_UPDATED:-}" != "1" ]; then
    export DFC_AUTO_UPDATED=1
    _UPDATE_FLAG="/tmp/.dfc_upd_$$"
    export _START_TIME=$(date +%s)
    (
        # Проверяем обновления с нашего сервера
        _remote_ver=$(curl -s --max-time 5 "${DFC_LICENSE_SERVER}/api/v1/manager/version" 2>/dev/null \
            | grep -o '"version":"[^"]*"' | cut -d'"' -f4 || true)
        _local_ver="$SCRIPT_VERSION"
        if [ -n "$_remote_ver" ] && [ -n "$_local_ver" ] && [ "$_remote_ver" != "$_local_ver" ]; then
            _ln=$(echo "$_local_ver" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
            _rn=$(echo "$_remote_ver" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
            if [ "$_rn" -gt "$_ln" ] 2>/dev/null; then
                # Скачиваем обновление
                rm -rf "${DIR_SCRIPT}"
                mkdir -p "${DIR_SCRIPT}"
                if curl -sL --max-time 120 "${DFC_LICENSE_SERVER}/api/v1/manager/download" \
                    | tar -xz -C "${DIR_SCRIPT}" --strip-components=1 2>/dev/null; then
                    chmod +x "${DIR_SCRIPT}dfc-manager.sh"
                    ln -sf "${DIR_SCRIPT}dfc-manager.sh" /usr/local/bin/dfc-manager
                    ln -sf /usr/local/bin/dfc-manager /usr/local/bin/dfc
                    ln -sf /usr/local/bin/dfc-manager /usr/local/bin/rw
                    touch "$_UPDATE_FLAG"
                fi
            fi
        fi
        rm -f "${UPDATE_AVAILABLE_FILE}" "${UPDATE_CHECK_TIME_FILE}" 2>/dev/null || true
        # Гарантируем минимум 1 сек на экране
        _ELAPSED=$(($(date +%s) - _START_TIME))
        [ $_ELAPSED -lt 1 ] && sleep $((1 - _ELAPSED))
    ) &
    show_spinner_prepare "Подготовка скрипта к запуску"

    if [ -f "$_UPDATE_FLAG" ]; then
        rm -f "$_UPDATE_FLAG"
        exec /usr/local/bin/dfc-manager
    fi
    unset _UPDATE_FLAG _START_TIME
fi

main_menu
