# ═══════════════════════════════════════════════
# КОНСТАНТЫ И ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ
# ═══════════════════════════════════════════════

DIR_SCRIPT="/usr/local/dfc-manager/"
DIR_PANEL="/opt/remnawave/"
DIR_NODE="/opt/remnanode/"
DIR_SUB="/opt/subscribe-page/"
DIR_REMNASALE="/opt/remnasale/"
DIR_SUPPORT="/opt/dfc-support-bot/"

# License Server
DFC_LICENSE_SERVER="https://rs-license.dfc-online.com"

# Версия — источник: /usr/local/dfc-manager/version (всегда присутствует)
SCRIPT_VERSION="0.1.0"
SCRIPT_BRANCH="main"
_vf="${DIR_SCRIPT}version"
if [ -f "$_vf" ]; then
    _sv=$(grep '^version:' "$_vf" 2>/dev/null | cut -d: -f2 | tr -d ' ')
    _br=$(grep '^branch:'  "$_vf" 2>/dev/null | cut -d: -f2 | tr -d ' ')
    [ -n "$_sv" ] && SCRIPT_VERSION="$_sv"
    [ -n "$_br" ] && SCRIPT_BRANCH="$_br"
fi
unset _sv _br _vf

# Лицензионный ключ (для Remnasale/DFC Support)
DFC_LICENSE_KEY=""
[ -f "${DIR_SCRIPT}.license_key" ] && DFC_LICENSE_KEY=$(cat "${DIR_SCRIPT}.license_key" | tr -d '[:space:]')

# Файлы кэша проверки обновлений
UPDATE_AVAILABLE_FILE="${DIR_SCRIPT}update_available"
UPDATE_CHECK_TIME_FILE="${DIR_SCRIPT}last_update_check"
