# ═══════════════════════════════════════════════
# УПРАВЛЕНИЕ ЛИЦЕНЗИОННЫМ КЛЮЧОМ
# ═══════════════════════════════════════════════

_license_key_file="${DIR_SCRIPT}.license_key"

# Получить текущий IP сервера
get_server_ip() {
    local ip=""
    ip=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null)
    [ -z "$ip" ] && ip=$(curl -s --max-time 5 https://ifconfig.me 2>/dev/null)
    [ -z "$ip" ] && ip=$(curl -s --max-time 5 https://icanhazip.com 2>/dev/null)
    echo "$ip"
}

# Проверить наличие лицензионного ключа
has_license_key() {
    [ -n "$DFC_LICENSE_KEY" ] && return 0
    return 1
}

# Сохранить лицензионный ключ
save_license_key() {
    local key="$1"
    echo "$key" > "$_license_key_file"
    chmod 600 "$_license_key_file"
    DFC_LICENSE_KEY="$key"
}

# Удалить лицензионный ключ
remove_license_key() {
    rm -f "$_license_key_file"
    DFC_LICENSE_KEY=""
}

# Запросить ключ у пользователя
prompt_license_key() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "    ${GREEN}🔑  Лицензионный ключ${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    echo -e "  Для установки этого компонента"
    echo -e "  необходим лицензионный ключ."
    echo
    echo -e "  Получить ключ можно в боте:"
    echo -e "  ${CYAN}@DFC_License_Bot${NC}"
    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    tput cnorm
    read -r -p "  Введите ключ: " _input_key
    tput civis 2>/dev/null || true

    _input_key=$(echo "$_input_key" | tr -d '[:space:]')
    if [ -z "$_input_key" ]; then
        print_error "Ключ не может быть пустым"
        echo
        show_continue_prompt || true
        return 1
    fi

    save_license_key "$_input_key"
    return 0
}

# Проверить лицензию для продукта через API лиц. сервера
verify_product_license() {
    local product="$1"
    local server_ip="$2"

    if [ -z "$DFC_LICENSE_KEY" ]; then
        return 1
    fi

    local response
    response=$(curl -s --max-time 15 \
        -X POST "${DFC_LICENSE_SERVER}/api/v1/product/verify" \
        -H "Content-Type: application/json" \
        -d "{\"license_key\":\"${DFC_LICENSE_KEY}\",\"product\":\"${product}\",\"server_ip\":\"${server_ip}\"}" \
        2>/dev/null)

    if [ -z "$response" ]; then
        print_error "Не удалось подключиться к серверу лицензий"
        return 1
    fi

    local valid
    valid=$(echo "$response" | grep -o '"valid":[a-z]*' | cut -d: -f2)

    if [ "$valid" = "true" ]; then
        return 0
    fi

    local reason
    reason=$(echo "$response" | grep -o '"reason":"[^"]*"' | cut -d'"' -f4)

    case "$reason" in
        not_found)
            print_error "Лицензионный ключ не найден"
            ;;
        suspended)
            print_error "Лицензия приостановлена"
            ;;
        expired)
            print_error "Срок действия лицензии истёк"
            ;;
        blacklisted)
            print_error "Лицензия заблокирована"
            ;;
        product_not_included)
            print_error "Данный продукт не включён в вашу лицензию"
            ;;
        product_ip_bound)
            local bound_ip
            bound_ip=$(echo "$response" | grep -o '"bound_ip":"[^"]*"' | cut -d'"' -f4)
            echo
            echo -e "${RED}⚠️  Копия программы уже привязана к другому IP!${NC}"
            echo
            echo -e "  Текущий IP:     ${WHITE}${server_ip}${NC}"
            echo -e "  Привязанный IP: ${YELLOW}${bound_ip}${NC}"
            echo
            echo -e "  Для переноса на другой сервер, сбросьте"
            echo -e "  привязку IP в меню 'Сменить лиц. ключ'"
            ;;
        *)
            print_error "Ошибка лицензии: ${reason:-unknown}"
            ;;
    esac
    return 1
}

# Скачать продукт с сервера лицензий
download_product() {
    local product="$1"
    local dest_dir="$2"

    local url="${DFC_LICENSE_SERVER}/api/v1/product/download?key=${DFC_LICENSE_KEY}&product=${product}"

    mkdir -p "$dest_dir"
    if ! curl -sL --max-time 300 --connect-timeout 15 "$url" \
        | tar -xz -C "$dest_dir" --strip-components=1; then
        return 1
    fi
    return 0
}

# Скачать DFC Manager (публичный, без ключа)
download_manager_update() {
    local dest_dir="$1"
    local url="${DFC_LICENSE_SERVER}/api/v1/manager/download"

    mkdir -p "$dest_dir"
    if ! curl -sL --max-time 120 --connect-timeout 15 "$url" \
        | tar -xz -C "$dest_dir" --strip-components=1; then
        return 1
    fi
    return 0
}

# Получить удалённую версию DFC Manager
get_remote_manager_version() {
    local response
    response=$(curl -s --max-time 5 "${DFC_LICENSE_SERVER}/api/v1/manager/version" 2>/dev/null)
    echo "$response" | grep -o '"version":"[^"]*"' | cut -d'"' -f4
}

# Получить удалённую версию продукта
get_remote_product_version() {
    local product="$1"
    local response
    response=$(curl -s --max-time 5 "${DFC_LICENSE_SERVER}/api/v1/product/version?product=${product}" 2>/dev/null)
    echo "$response" | grep -o '"version":"[^"]*"' | cut -d'"' -f4
}

# Меню смены лицензионного ключа
manage_license_key() {
    while true; do
        tput civis 2>/dev/null || true
        clear
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo -e "    ${GREEN}🔑  Управление лицензией${NC}"
        echo -e "${BLUE}══════════════════════════════════════${NC}"
        echo

        if has_license_key; then
            local masked_key="${DFC_LICENSE_KEY:0:8}...${DFC_LICENSE_KEY: -8}"
            echo -e "  Текущий ключ: ${CYAN}${masked_key}${NC}"
        else
            echo -e "  Ключ: ${DARKGRAY}не установлен${NC}"
        fi
        echo
        echo -e "${BLUE}══════════════════════════════════════${NC}"

        local -a lic_items=() lic_actions=()
        if has_license_key; then
            lic_items+=("🔄  Сменить ключ");    lic_actions+=("change")
            lic_items+=("🗑️   Удалить ключ");    lic_actions+=("remove")
        else
            lic_items+=("🔑  Ввести ключ");      lic_actions+=("enter")
        fi
        lic_items+=("──────────────────────────────────────"); lic_actions+=("sep")
        lic_items+=("⬅️   Назад");               lic_actions+=("back")

        show_arrow_menu "🔑  Лицензионный ключ" "${lic_items[@]}"
        local lic_choice=$?
        [[ $lic_choice -eq 255 ]] && return
        local lic_action="${lic_actions[$lic_choice]:-sep}"

        case "$lic_action" in
            enter|change)
                if prompt_license_key; then
                    print_success "Ключ сохранён"
                    echo
                    show_continue_prompt || true
                fi
                ;;
            remove)
                remove_license_key
                print_success "Ключ удалён"
                echo
                show_continue_prompt || true
                ;;
            back) return ;;
            sep)  continue ;;
        esac
    done
}
