# ═══════════════════════════════════════════════
# ПРОВЕРКА ВЕРСИИ
# ═══════════════════════════════════════════════

# Читает версию из файла version (формат: "version: x.y.z")
parse_version_from_file() {
    local file="$1"
    if [ -f "$file" ]; then
        grep '^version:' "$file" 2>/dev/null | cut -d: -f2 | tr -d ' '
    fi
}

get_installed_version() {
    local ver=""
    if [ -f "${DIR_SCRIPT}version" ]; then
        ver=$(parse_version_from_file "${DIR_SCRIPT}version")
    fi
    [ -z "$ver" ] && ver="$SCRIPT_VERSION"
    echo "$ver"
}

get_remote_version() {
    # Получаем версию с нашего сервера лицензий
    get_remote_manager_version
}

check_for_updates() {
    local remote_version
    remote_version=$(get_remote_version)

    if [ -z "$remote_version" ]; then
        return 1
    fi

    local local_version
    local_version=$(get_installed_version)

    if [ -z "$local_version" ] || [ "$remote_version" = "$local_version" ]; then
        return 1
    fi

    # Сравнение семантических версий
    local local_num remote_num
    local_num=$(echo "$local_version" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')
    remote_num=$(echo "$remote_version" | awk -F. '{printf "%03d%03d%03d", $1, $2, $3}')

    if [ "$remote_num" -gt "$local_num" ] 2>/dev/null; then
        echo "$remote_version"
        return 0
    fi
    return 1
}

show_update_notification() {
    local new_version=$1
    echo
    echo -e "${YELLOW}┌──────────────────────────────────────────────────┐${NC}"
    echo -e "${YELLOW}│${NC}  ${GREEN}🔔 ДОСТУПНО ОБНОВЛЕНИЕ!${NC}                        ${YELLOW}│${NC}"
    echo -e "${YELLOW}│${NC}                                                  ${YELLOW}│${NC}"
    echo -e "${YELLOW}│${NC}  Текущая версия:  ${WHITE}v$SCRIPT_VERSION${NC}                      ${YELLOW}│${NC}"
    echo -e "${YELLOW}│${NC}  Новая версия:     ${GREEN}v$new_version${NC}                      ${YELLOW}│${NC}"
    echo -e "${YELLOW}│${NC}                                                  ${YELLOW}│${NC}"
    echo -e "${YELLOW}│${NC}  Обновите скрипт через меню:                    ${YELLOW}│${NC}"
    echo -e "${YELLOW}│${NC}  ${BLUE}🔄 Обновить скрипт${NC}                             ${YELLOW}│${NC}"
    echo -e "${YELLOW}└──────────────────────────────────────────────────┘${NC}"
    echo
}
