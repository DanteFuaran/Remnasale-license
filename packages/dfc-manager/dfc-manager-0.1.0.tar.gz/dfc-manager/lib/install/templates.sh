# ═══════════════════════════════════════════════
# ШАБЛОНЫ SELFSTEAL
# ═══════════════════════════════════════════════

# Список шаблонов: ID|Название
get_templates_list() {
    echo "1|NexCore - Корпоративный портал"
    echo "2|DevForge - Технологический хаб"
    echo "3|Nimbus - Облачные сервисы"
    echo "4|PayVault - Финтех платформа"
    echo "5|LearnHub - Образовательная платформа"
    echo "6|StreamBox - Медиа портал"
    echo "7|ShopWave - E-commerce"
    echo "8|NeonArena - Игровой портал"
    echo "9|ConnectMe - Социальная сеть"
    echo "10|DataPulse - Аналитический центр"
    echo "11|CryptoNex - Крипто биржа"
    echo "12|WanderWorld - Туристическое агентство"
    echo "13|IronPulse - Фитнес платформа"
    echo "14|ВестникПРО - Новостной портал"
    echo "15|SoundWave - Музыкальный сервис"
    echo "16|HomeNest - Недвижимость"
    echo "17|FastBite - Доставка еды"
    echo "18|AutoElite - Автомобильный портал"
    echo "19|Prisma Studio - Дизайн студия"
    echo "20|Vertex Advisory - Консалтинг центр"
}

# Применить конкретный шаблон (из локальной директории)
apply_template() {
    local template_id=$1
    
    local template_data=$(get_templates_list | grep "^${template_id}|")
    if [ -z "$template_data" ]; then
        echo -e "${RED}✖${NC} Шаблон #${template_id} не найден"
        return 1
    fi
    
    IFS='|' read -r id name <<< "$template_data"
    
    echo ""

    # Создаём директорию если не существует
    mkdir -p /var/www/html/
    
    # Очищаем директорию (кроме метаданных)
    find /var/www/html/ -mindepth 1 -not -name '.current_template' -not -name '.template_changed' -delete 2>/dev/null
    
    # Копируем шаблон из локальной директории скрипта
    local _template_file="${DIR_SCRIPT}templates/${template_id}/index.html"
    
    if [ -f "$_template_file" ] && cp "$_template_file" /var/www/html/index.html 2>/dev/null; then
        echo "$name" > /var/www/.current_template
        echo "$(date '+%Y-%m-%d %H:%M:%S')" > /var/www/.template_changed
        echo -e "${GREEN}✅${NC} Установка шаблона: ${WHITE}${name}${NC}"
    else
        echo -e "${RED}✖${NC} Ошибка установки шаблона. Файл не найден: ${_template_file}"
        # Создаём заглушку на случай ошибки
        echo "<html><body><h1>Site under maintenance</h1></body></html>" > /var/www/html/index.html
        return 1
    fi
}

# Случайный шаблон
randomhtml() {
    local random_id=$((RANDOM % 20 + 1))
    apply_template "$random_id"
}
