# ═══════════════════════════════════════════════
# УСТАНОВКА REMNASALE
# ═══════════════════════════════════════════════

is_remnasale_installed() {
    [ -f "${DIR_REMNASALE}docker-compose.yml" ] && return 0
    return 1
}

get_remnasale_version() {
    local ver=""
    if [ -f "${DIR_REMNASALE}version" ]; then
        ver=$(grep '^version:' "${DIR_REMNASALE}version" 2>/dev/null | cut -d: -f2 | tr -d ' ')
    fi
    echo "$ver"
}

installation_remnasale() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "    ${GREEN}🤖  Установка Remnasale${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # Проверка лицензии
    if ! has_license_key; then
        if ! prompt_license_key; then
            return 1
        fi
    fi

    echo -ne "  ${BLUE}Определение IP сервера...${NC}"
    local server_ip
    server_ip=$(get_server_ip)
    if [ -z "$server_ip" ]; then
        echo -e "\r  ${RED}❌ Не удалось определить IP сервера${NC}   "
        echo
        show_continue_prompt || true
        return 1
    fi
    echo -e "\r  ${GREEN}✅ IP: ${WHITE}${server_ip}${NC}                    "

    echo -ne "  ${BLUE}Проверка лицензии...${NC}"
    if ! verify_product_license "remnasale" "$server_ip"; then
        echo
        show_continue_prompt || true
        return 1
    fi
    echo -e "\r  ${GREEN}✅ Лицензия подтверждена${NC}                    "
    echo

    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "  📦 Загрузка и установка Remnasale..."
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # Загрузка и распаковка
    local tmp_dir
    tmp_dir=$(mktemp -d /tmp/remnasale-install.XXXXXX)
    (
        download_product "remnasale" "$tmp_dir" || exit 1
    ) &
    show_spinner "Загрузка Remnasale"

    if [ ! -f "${tmp_dir}/remnasale-install.sh" ] && [ ! -f "${tmp_dir}/docker-compose.yml" ]; then
        print_error "Ошибка загрузки. Файлы установки не найдены."
        rm -rf "$tmp_dir"
        show_continue_prompt || true
        return 1
    fi

    # Запускаем установочный скрипт Remnasale с нужными переменными
    export REMNASALE_LICENSE_KEY="$DFC_LICENSE_KEY"
    export REMNASALE_LICENSE_SERVER="$DFC_LICENSE_SERVER"

    if [ -f "${tmp_dir}/remnasale-install.sh" ]; then
        chmod +x "${tmp_dir}/remnasale-install.sh"
        cd "$tmp_dir"
        bash "${tmp_dir}/remnasale-install.sh" --install
        local exit_code=$?
        cd /opt
        rm -rf "$tmp_dir"
        return $exit_code
    fi

    # Если нет скрипта установки, стандартная процедура
    mkdir -p "${DIR_REMNASALE}"
    cp -a "${tmp_dir}/." "${DIR_REMNASALE}"
    rm -rf "$tmp_dir"

    print_success "Remnasale распакован в ${DIR_REMNASALE}"
    echo -e "  Запустите установку: ${CYAN}cd ${DIR_REMNASALE} && bash remnasale-install.sh${NC}"
    echo
    show_continue_prompt || true
    return 0
}

update_remnasale() {
    if ! is_remnasale_installed; then
        print_error "Remnasale не установлен"
        show_continue_prompt || true
        return 1
    fi

    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "    ${GREEN}🔄  Обновление Remnasale${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    local current_ver
    current_ver=$(get_remnasale_version)
    local remote_ver
    remote_ver=$(get_remote_product_version "remnasale")

    echo -e "  Текущая версия:  ${WHITE}${current_ver:-неизвестно}${NC}"
    echo -e "  Доступная версия: ${GREEN}${remote_ver:-неизвестно}${NC}"
    echo

    if [ -n "$current_ver" ] && [ -n "$remote_ver" ] && [ "$current_ver" = "$remote_ver" ]; then
        print_success "У вас установлена последняя версия"
        echo
        show_continue_prompt || true
        return 0
    fi

    echo -e "${BLUE}══════════════════════════════════════${NC}"
    if ! confirm_action; then return; fi

    if ! has_license_key; then
        if ! prompt_license_key; then return 1; fi
    fi

    local server_ip
    server_ip=$(get_server_ip)
    if ! verify_product_license "remnasale" "$server_ip"; then
        echo
        show_continue_prompt || true
        return 1
    fi

    # Backup .env и data перед обновлением
    local backup_dir="/tmp/remnasale-backup-$(date +%s)"
    mkdir -p "$backup_dir"
    [ -f "${DIR_REMNASALE}.env" ] && cp "${DIR_REMNASALE}.env" "$backup_dir/"
    [ -d "${DIR_REMNASALE}assets" ] && cp -a "${DIR_REMNASALE}assets" "$backup_dir/"
    [ -d "${DIR_REMNASALE}backups" ] && cp -a "${DIR_REMNASALE}backups" "$backup_dir/"

    # Загрузка нового файла
    (
        download_product "remnasale" "${DIR_REMNASALE}" || exit 1
    ) &
    show_spinner "Загрузка обновления"

    # Восстанавливаем .env и data
    [ -f "$backup_dir/.env" ] && cp "$backup_dir/.env" "${DIR_REMNASALE}.env"
    [ -d "$backup_dir/assets" ] && cp -a "$backup_dir/assets/." "${DIR_REMNASALE}assets/"
    [ -d "$backup_dir/backups" ] && cp -a "$backup_dir/backups/." "${DIR_REMNASALE}backups/"
    rm -rf "$backup_dir"

    # Пересборка и перезапуск
    (
        cd "${DIR_REMNASALE}"
        docker compose build --no-cache >/dev/null 2>&1
        docker compose up -d >/dev/null 2>&1
    ) &
    show_spinner "Пересборка и перезапуск"

    print_success "Remnasale обновлён до версии ${remote_ver}"
    echo
    show_continue_prompt || true
}

manage_remnasale() {
    while true; do
        tput civis 2>/dev/null || true

        local has_remnasale=false
        is_remnasale_installed && has_remnasale=true

        local rs_title="🤖  Remnasale — Бот продаж"
        if [ "$has_remnasale" = true ]; then
            local rs_ver
            rs_ver=$(get_remnasale_version)
            [ -n "$rs_ver" ] && rs_title="${rs_title} v${rs_ver}"
        fi

        local -a rs_items=() rs_actions=()

        if [ "$has_remnasale" = false ]; then
            rs_items+=("📦  Установить Remnasale"); rs_actions+=("install")
        else
            rs_items+=("▶️   Запустить");              rs_actions+=("start")
            rs_items+=("⏹️   Остановить");             rs_actions+=("stop")
            rs_items+=("🔄  Перезапустить");           rs_actions+=("restart")
            rs_items+=("📋  Просмотр логов");          rs_actions+=("logs")
            rs_items+=("──────────────────────────────────────"); rs_actions+=("sep")
            rs_items+=("🔄  Обновить Remnasale");      rs_actions+=("update")
            rs_items+=("──────────────────────────────────────"); rs_actions+=("sep")
            rs_items+=("🗑️   Удалить Remnasale");       rs_actions+=("delete")
        fi
        rs_items+=("──────────────────────────────────────"); rs_actions+=("sep")
        rs_items+=("⬅️   Назад"); rs_actions+=("back")

        show_arrow_menu "$rs_title" "${rs_items[@]}"
        local rs_choice=$?
        [[ $rs_choice -eq 255 ]] && return
        local rs_action="${rs_actions[$rs_choice]:-sep}"

        case "$rs_action" in
            install) installation_remnasale ;;
            start)
                ( cd "${DIR_REMNASALE}" && docker compose up -d >/dev/null 2>&1 ) &
                show_spinner "Запуск Remnasale"
                print_success "Remnasale запущен"
                show_continue_prompt || true
                ;;
            stop)
                ( cd "${DIR_REMNASALE}" && docker compose down >/dev/null 2>&1 ) &
                show_spinner "Остановка Remnasale"
                print_success "Remnasale остановлен"
                show_continue_prompt || true
                ;;
            restart)
                ( cd "${DIR_REMNASALE}" && docker compose restart >/dev/null 2>&1 ) &
                show_spinner "Перезапуск Remnasale"
                print_success "Remnasale перезапущен"
                show_continue_prompt || true
                ;;
            logs)
                clear
                cd "${DIR_REMNASALE}" && docker compose logs -f --tail 100
                show_continue_prompt || true
                ;;
            update)  update_remnasale ;;
            delete)
                clear
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo -e "${RED}   🗑️  Удаление Remnasale${NC}"
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo
                echo -e "${RED}⚠️  Все данные Remnasale будут удалены!${NC}"
                echo
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                if ! confirm_action; then continue; fi
                (
                    cd "${DIR_REMNASALE}" 2>/dev/null
                    docker compose down -v --rmi all >/dev/null 2>&1 || true
                ) &
                show_spinner "Удаление Remnasale"
                rm -rf "${DIR_REMNASALE}"
                # Удаляем nginx блок
                if [ -f "${DIR_NGINX:-/opt/nginx/}nginx.conf" ]; then
                    sed -i '/# BEGIN_REMNASALE_BLOCK/,/# END_REMNASALE_BLOCK/d' "${DIR_NGINX:-/opt/nginx/}nginx.conf" 2>/dev/null || true
                    nginx_reload 2>/dev/null || true
                fi
                print_success "Remnasale удалён"
                echo
                show_continue_prompt || true
                ;;
            back) return ;;
            sep)  continue ;;
        esac
    done
}
