# ═══════════════════════════════════════════════
# УСТАНОВКА DFC SUPPORT
# ═══════════════════════════════════════════════

is_support_installed() {
    [ -f "${DIR_SUPPORT}docker-compose.yml" ] && return 0
    return 1
}

get_support_version() {
    local ver=""
    if [ -f "${DIR_SUPPORT}version" ]; then
        ver=$(grep '^version:' "${DIR_SUPPORT}version" 2>/dev/null | cut -d: -f2 | tr -d ' ')
    fi
    echo "$ver"
}

installation_support() {
    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "    ${GREEN}💬  Установка DFC Support${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # Проверка лицензии
    if ! has_license_key; then
        if ! prompt_license_key; then
            return 1
        fi
    fi

    echo -ne "  ${BLUE}Определение IP сервера...${NC}"
    local server_ip
    server_ip=$(get_server_ip)
    if [ -z "$server_ip" ]; then
        echo -e "\r  ${RED}❌ Не удалось определить IP сервера${NC}   "
        echo
        show_continue_prompt || true
        return 1
    fi
    echo -e "\r  ${GREEN}✅ IP: ${WHITE}${server_ip}${NC}                    "

    echo -ne "  ${BLUE}Проверка лицензии...${NC}"
    if ! verify_product_license "dfc_support" "$server_ip"; then
        echo
        show_continue_prompt || true
        return 1
    fi
    echo -e "\r  ${GREEN}✅ Лицензия подтверждена${NC}                    "
    echo

    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "  📦 Загрузка и установка DFC Support..."
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    # Загрузка и распаковка
    local tmp_dir
    tmp_dir=$(mktemp -d /tmp/dfc-support-install.XXXXXX)
    (
        download_product "dfc_support" "$tmp_dir" || exit 1
    ) &
    show_spinner "Загрузка DFC Support"

    if [ ! -f "${tmp_dir}/install.sh" ] && [ ! -f "${tmp_dir}/docker-compose.yml" ]; then
        print_error "Ошибка загрузки. Файлы установки не найдены."
        rm -rf "$tmp_dir"
        show_continue_prompt || true
        return 1
    fi

    # Если есть install.sh — запускаем его
    if [ -f "${tmp_dir}/install.sh" ]; then
        chmod +x "${tmp_dir}/install.sh"
        export DFC_SUPPORT_SOURCE_DIR="$tmp_dir"
        export DFC_LICENSE_KEY="$DFC_LICENSE_KEY"
        cd "$tmp_dir"
        bash "${tmp_dir}/install.sh" --from-manager
        local exit_code=$?
        cd /opt
        rm -rf "$tmp_dir"
        return $exit_code
    fi

    # Стандартная процедура: копируем файлы и помогаем с настройкой
    mkdir -p "${DIR_SUPPORT}"
    cp -a "${tmp_dir}/." "${DIR_SUPPORT}"
    rm -rf "$tmp_dir"

    # Интерактивная настройка
    _setup_support_config

    # Сборка и запуск
    (
        cd "${DIR_SUPPORT}"
        docker compose build --no-cache >/dev/null 2>&1
        docker compose up -d >/dev/null 2>&1
    ) &
    show_spinner "Сборка и запуск DFC Support"

    if [ -f "${DIR_SUPPORT}docker-compose.yml" ]; then
        print_success "DFC Support установлен и запущен"
    else
        print_error "Ошибка установки DFC Support"
    fi
    echo
    show_continue_prompt || true
    return 0
}

_setup_support_config() {
    # Запрос настроек если .env не существует
    if [ -f "${DIR_SUPPORT}.env" ]; then
        return 0
    fi

    echo
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "    ${GREEN}⚙️  Настройка DFC Support${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo
    tput cnorm

    local bot_token="" group_id="" inactivity_days="5"

    read -r -p "  Токен бота (@BotFather): " bot_token
    echo
    read -r -p "  ID группы поддержки (Форум): " group_id
    echo
    read -r -p "  Дней до автозакрытия [5]: " inactivity_days
    [ -z "$inactivity_days" ] && inactivity_days="5"

    tput civis 2>/dev/null || true

    cat > "${DIR_SUPPORT}.env" <<EOF
BOT_TOKEN=${bot_token}
SUPPORT_GROUP_ID=${group_id}
INACTIVITY_DAYS=${inactivity_days}
EOF

    chmod 600 "${DIR_SUPPORT}.env"
    mkdir -p "${DIR_SUPPORT}data" "${DIR_SUPPORT}logs"
}

update_support() {
    if ! is_support_installed; then
        print_error "DFC Support не установлен"
        show_continue_prompt || true
        return 1
    fi

    clear
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo -e "    ${GREEN}🔄  Обновление DFC Support${NC}"
    echo -e "${BLUE}══════════════════════════════════════${NC}"
    echo

    local current_ver
    current_ver=$(get_support_version)
    local remote_ver
    remote_ver=$(get_remote_product_version "dfc_support")

    echo -e "  Текущая версия:  ${WHITE}${current_ver:-неизвестно}${NC}"
    echo -e "  Доступная версия: ${GREEN}${remote_ver:-неизвестно}${NC}"
    echo

    if [ -n "$current_ver" ] && [ -n "$remote_ver" ] && [ "$current_ver" = "$remote_ver" ]; then
        print_success "У вас установлена последняя версия"
        echo
        show_continue_prompt || true
        return 0
    fi

    echo -e "${BLUE}══════════════════════════════════════${NC}"
    if ! confirm_action; then return; fi

    if ! has_license_key; then
        if ! prompt_license_key; then return 1; fi
    fi

    local server_ip
    server_ip=$(get_server_ip)
    if ! verify_product_license "dfc_support" "$server_ip"; then
        echo
        show_continue_prompt || true
        return 1
    fi

    # Backup .env и data
    local backup_dir="/tmp/dfc-support-backup-$(date +%s)"
    mkdir -p "$backup_dir"
    [ -f "${DIR_SUPPORT}.env" ] && cp "${DIR_SUPPORT}.env" "$backup_dir/"
    [ -d "${DIR_SUPPORT}data" ] && cp -a "${DIR_SUPPORT}data" "$backup_dir/"

    # Загрузка
    (
        download_product "dfc_support" "${DIR_SUPPORT}" || exit 1
    ) &
    show_spinner "Загрузка обновления"

    # Восстановление .env и data
    [ -f "$backup_dir/.env" ] && cp "$backup_dir/.env" "${DIR_SUPPORT}.env"
    [ -d "$backup_dir/data" ] && cp -a "$backup_dir/data/." "${DIR_SUPPORT}data/"
    rm -rf "$backup_dir"

    # Пересборка и перезапуск
    (
        cd "${DIR_SUPPORT}"
        docker compose build --no-cache >/dev/null 2>&1
        docker compose up -d >/dev/null 2>&1
    ) &
    show_spinner "Пересборка и перезапуск"

    print_success "DFC Support обновлён до версии ${remote_ver}"
    echo
    show_continue_prompt || true
}

manage_support() {
    while true; do
        tput civis 2>/dev/null || true

        local has_support=false
        is_support_installed && has_support=true

        local sp_title="💬  DFC Support — Бот поддержки"
        if [ "$has_support" = true ]; then
            local sp_ver
            sp_ver=$(get_support_version)
            [ -n "$sp_ver" ] && sp_title="${sp_title} v${sp_ver}"
        fi

        local -a sp_items=() sp_actions=()

        if [ "$has_support" = false ]; then
            sp_items+=("📦  Установить DFC Support"); sp_actions+=("install")
        else
            sp_items+=("▶️   Запустить");              sp_actions+=("start")
            sp_items+=("⏹️   Остановить");             sp_actions+=("stop")
            sp_items+=("🔄  Перезапустить");           sp_actions+=("restart")
            sp_items+=("📋  Просмотр логов");          sp_actions+=("logs")
            sp_items+=("──────────────────────────────────────"); sp_actions+=("sep")
            sp_items+=("🔄  Обновить DFC Support");    sp_actions+=("update")
            sp_items+=("──────────────────────────────────────"); sp_actions+=("sep")
            sp_items+=("🗑️   Удалить DFC Support");     sp_actions+=("delete")
        fi
        sp_items+=("──────────────────────────────────────"); sp_actions+=("sep")
        sp_items+=("⬅️   Назад"); sp_actions+=("back")

        show_arrow_menu "$sp_title" "${sp_items[@]}"
        local sp_choice=$?
        [[ $sp_choice -eq 255 ]] && return
        local sp_action="${sp_actions[$sp_choice]:-sep}"

        case "$sp_action" in
            install) installation_support ;;
            start)
                ( cd "${DIR_SUPPORT}" && docker compose up -d >/dev/null 2>&1 ) &
                show_spinner "Запуск DFC Support"
                print_success "DFC Support запущен"
                show_continue_prompt || true
                ;;
            stop)
                ( cd "${DIR_SUPPORT}" && docker compose down >/dev/null 2>&1 ) &
                show_spinner "Остановка DFC Support"
                print_success "DFC Support остановлен"
                show_continue_prompt || true
                ;;
            restart)
                ( cd "${DIR_SUPPORT}" && docker compose restart >/dev/null 2>&1 ) &
                show_spinner "Перезапуск DFC Support"
                print_success "DFC Support перезапущен"
                show_continue_prompt || true
                ;;
            logs)
                clear
                cd "${DIR_SUPPORT}" && docker compose logs -f --tail 100
                show_continue_prompt || true
                ;;
            update)  update_support ;;
            delete)
                clear
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo -e "${RED}   🗑️  Удаление DFC Support${NC}"
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                echo
                echo -e "${RED}⚠️  Все данные DFC Support будут удалены!${NC}"
                echo
                echo -e "${BLUE}══════════════════════════════════════${NC}"
                if ! confirm_action; then continue; fi
                (
                    cd "${DIR_SUPPORT}" 2>/dev/null
                    docker compose down -v --rmi all >/dev/null 2>&1 || true
                ) &
                show_spinner "Удаление DFC Support"
                rm -rf "${DIR_SUPPORT}"
                print_success "DFC Support удалён"
                echo
                show_continue_prompt || true
                ;;
            back) return ;;
            sep)  continue ;;
        esac
    done
}
